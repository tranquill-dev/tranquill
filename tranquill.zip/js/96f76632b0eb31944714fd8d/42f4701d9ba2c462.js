var tranquill_global = typeof self !== "undefined" ? self : globalThis;
if (!tranquill_global.tranquill_runtime_ready) {
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::c882198ca34f17b696c9b80e0eca21ea"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = "tranquill_tranquill_tranquill";
        tranquill_global.tranquill_runtime_ready = true;
}

(function tranquill_init_shard() {
  const a = new Uint8Array([7, 32, 225, 65, 195, 103, 173, 207, 4, 43, 242, 70, 199, 124, 224, 142, 27, 58, 229, 78, 211, 113, 224, 134, 25, 33, 244, 70, 214, 100, 169, 149, 18, 44, 160, 70, 217, 40, 166, 157, 22, 37, 229, 6, 245, 44, 8, 194, 178, 96, 101, 25, 243, 57, 3, 216, 169, 95, 67, 23, 249, 52, 41, 250, 179, 119, 237, 61, 127, 249, 58, 253, 188, 109, 252, 60, 102, 249, 42, 241, 160, 112, 233, 38, 50, 176, 55, 251, 166, 112, 248, 62, 123, 163, 48, 252, 181, 47, 78, 197, 156, 72, 101, 31, 194, 171, 41, 197, 145, 81, 98, 22, 214, 254, 52, 193, 127, 11, 98, 248, 178, 71, 121, 13, 228, 216, 41, 196, 119, 20, 127, 122, 129, 226, 197, 39, 82, 112, 11, 104, 207, 45, 216, 118, 141, 238, 201, 43, 94, 95, 249, 138, 182, 10, 251, 206, 225, 71, 187, 135, 173, 16, 191, 204, 234, 89, 187, 144, 180, 26, 186, 209, 225, 90, 151, 44, 207, 168, 74, 127, 141, 182, 85, 178, 80, 229, 131, 56, 219, 188, 94, 107, 57, 2, 97, 6, 100, 209, 59, 110, 76, 7, 110, 7, 6, 204, 48, 96, 133, 11, 101, 22, 211, 201, 56, 108, 141, 11, 174, 141, 234, 72, 235, 132, 178, 2, 239, 151, 227, 67, 235, 132, 167, 15, 160, 150, 242, 13, 226, 193, 181, 30, 174, 131, 227, 55, 137, 18, 214, 98, 139, 214, 129, 47, 203, 13, 214, 115, 216, 206, 129, 50, 238, 212, 247, 95, 187, 249, 227, 128, 56, 172, 236, 196, 111, 225, 172, 159, 56, 189, 178, 220, 111, 252, 197, 80, 50, 57, 144, 185, 120, 114, 224, 54, 101, 25, 181, 52, 33, 78, 248, 116, 102, 4, 160, 112, 106, 77, 224, 61, 102, 14, 165, 228, 77, 147, 36, 177, 79, 87, 115, 252, 15, 144, 57, 164, 11, 28, 98, 237, 93, 153, 33, 166, 84, 66, 133, 230, 183, 6, 107, 152, 251, 208, 217, 140, 158, 133, 12, 14, 90, 82, 193, 206, 146, 159, 25, 64, 86, 82, 152, 134, 144, 153, 28, 66, 88, 89, 223, 206, 151, 150, 17, 66, 84, 83, 162, 127, 87, 87, 237, 53, 142, 2, 165, 111, 21, 186, 194, 58, 78, 33, 159, 176, 4, 97, 203, 248, 70, 47, 209, 161, 0, 105, 223, 229, 71, 37, 209, 163, 13, 121, 196, 244, 91, 60, 143, 176, 105, 129, 75, 247, 37, 143, 140, 172, 105, 155, 90, 184, 58, 202, 140, 189, 124, 107, 76, 79, 146, 42, 28, 140, 209, 113, 86, 81, 194, 44, 16, 146, 199, 106, 25, 90, 154, 40, 16, 141, 199, 124, 51, 21, 13, 6, 104, 201, 84, 29, 48, 229, 14, 92, 96, 166, 205, 7, 42, 251, 83, 75, 125, 165, 215, 28, 32, 241, 124, 162, 58, 42, 169, 99, 230, 216, 121, 181, 32, 44, 236, 99, 254, 224, 124, 160, 48, 45, 247, 48, 229, 225, 109, 190, 33, 38, 161, 48, 252, 231, 109, 179, 33, 32, 186, 117, 23, 78, 239, 64, 194, 143, 179, 178, 18, 89, 245, 70, 135, 139, 161, 138, 19, 85, 238, 68, 135, 154, 175, 145, 71, 93, 227, 87, 206, 138, 165, 195, 21, 89, 241, 86, 194, 143, 180, 224, 219, 216, 1, 181, 154, 4, 115, 229, 204, 194, 7, 240, 128, 19, 78, 245, 143, 101, 135, 99, 202, 56, 215, 59, 130, 98, 147, 51, 219, 36, 213, 61, 159, 99, 153, 51, 223, 62, 221, 52, 140, 105, 134, 203, 221, 211, 146, 15, 26, 31, 28, 207, 199, 219, 155, 28, 16, 0, 28, 221, 212, 222, 144, 25, 20, 17, 87, 155, 193, 219, 145, 30, 26, 7, 72, 194, 160, 128, 119, 25, 252, 89, 86, 78, 2, 178, 5, 153, 89, 184, 68, 93, 2, 185, 17, 157, 77, 240, 84, 88, 172, 215, 16, 159, 224, 45, 86, 89, 170, 222, 1, 130, 96, 131, 38, 135, 35, 198, 47, 223, 105, 194, 60, 142, 40, 198, 47, 219, 110, 131, 33, 159, 41, 207, 47, 223, 116, 139, 40, 140, 35, 208, 46, 136, 38, 30, 121, 36, 32, 48, 8, 58, 104, 123, 223, 36, 36, 57, 9, 42, 88, 108, 233, 91, 137, 46, 161, 13, 28, 2, 166, 22, 107, 74, 162, 39, 219, 158, 243, 34, 158, 83, 182, 44, 218, 148, 250, 34, 154, 73, 190, 37, 201, 158, 229, 14, 60, 144, 205, 127, 109, 82, 133, 41, 197, 42, 1, 32, 147, 111, 67, 104, 132, 53, 20, 33, 144, 110, 72, 123, 205, 37, 77, 45, 133, 101, 70, 124, 212, 39, 14, 42, 229, 94, 189, 90, 184, 141, 229, 136, 33, 2, 179, 205, 99, 74, 164, 151, 52, 3, 176, 204, 104, 89, 237, 135, 109, 6, 161, 221, 105, 66, 243, 138, 199, 53, 157, 0, 182, 100, 95, 72, 224, 194, 86, 26, 131, 6, 150, 211, 12, 193, 70, 18, 153, 21, 151, 151, 88, 194, 90, 16, 139, 21, 129, 151, 72, 197, 86, 87, 152, 31, 211, 213, 77, 211, 88, 4, 156, 17, 144, 210, 182, 65, 48, 95, 236, 10, 121, 91, 181, 76, 63, 85, 241, 11, 115, 91, 167, 69, 61, 80, 246, 20, 127, 24, 160, 85, 19, 205, 188, 17, 212, 129, 208, 68, 24, 199, 161, 21, 218, 143, 247, 87, 252, 139, 171, 12, 190, 193, 164, 76, 254, 149, 161, 31, 175, 204, 234, 89, 187, 142, 161, 7, 191, 202, 243, 80, 151, 44, 207, 168, 74, 127, 154, 167, 75, 190, 74, 231, 131, 56, 219, 188, 94, 107, 91, 61, 169, 104, 21, 102, 243, 11, 209, 38, 166, 124, 2, 117, 247, 51, 10, 22, 63, 26, 81, 204, 64, 214, 13, 29, 14, 13, 70, 217, 103, 6, 33, 50, 27, 80, 100, 112, 211, 71, 47, 59, 18, 72, 127, 123, 221, 9, 61, 43, 0, 59, 32, 129, 214, 96, 124, 91, 139, 43, 62, 193, 182, 235, 127, 145, 245, 168, 36, 219, 168, 182, 104, 153, 246, 175, 52, 251, 151, 95, 33, 178, 82, 30, 101, 185, 153, 85, 36, 182, 73, 21, 107, 247, 139, 69, 54, 4, 117, 24, 43, 200, 35, 10, 193, 32, 60, 206, 134, 108, 66, 19, 199, 38, 249, 143, 23, 4, 162, 220, 209, 69, 171, 154, 28, 0, 165, 222, 219, 76, 171, 154, 29, 15, 172, 147, 213, 139, 122, 215, 18, 199, 7, 134, 201, 171, 119, 215, 20, 220, 49, 179, 197, 203, 106, 247, 2, 7, 100, 162, 206, 222, 109, 245, 12, 30, 45, 172, 195, 138, 119, 247, 12, 30, 33, 227, 206, 194, 101, 237, 10, 15, 32, 160, 141, 22, 112, 228, 202, 218, 13, 169, 139, 3, 118, 245, 209, 222, 61, 131, 145, 22, 108, 228, 159, 172, 38, 211, 90, 231, 96, 31, 143, 166, 99, 219, 66, 227, 109, 31, 133, 175, 99, 216, 83, 236, 119, 3, 143, 182, 42, 200, 10, 241, 119, 10, 152, 182, 151, 44, 207, 168, 74, 127, 141, 182, 85, 178, 80, 229, 123, 26, 101, 135, 63, 93, 41, 137, 120, 11, 106, 157, 35, 87, 48, 192, 104, 82, 97, 135, 47, 18, 48, 192, 102, 23, 107, 156, 63, 42, 72, 232, 31, 113, 148, 177, 20, 119, 14, 1, 79, 43, 84, 220, 4, 35, 5, 27, 67, 99, 77, 220, 20, 125, 9, 27, 64, 126, 106, 101, 5, 175, 189, 163, 196, 63, 121, 110, 1, 177, 189, 169, 205, 63, 122, 127, 14, 171, 161, 163, 212, 118, 106, 38, 19, 171, 168, 180, 212, 222, 237, 52, 80, 154, 170, 120, 173, 215, 235, 33, 86, 139, 177, 124, 157, 235, 235, 49, 39, 242, 254, 109, 226, 57, 56, 161, 55, 248, 187, 101, 250, 61, 53, 161, 61, 241, 187, 102, 235, 50, 47, 189, 55, 232, 242, 118, 178, 57, 53, 177, 184, 225, 137, 133, 247, 171, 208, 80, 191, 163, 196, 201, 130, 248, 24, 147, 95, 179, 144, 194, 152, 244, 133, 124, 15, 101, 193, 59, 67, 24, 140, 122, 26, 99, 208, 32, 71, 40, 183, 117, 13, 96, 198, 36, 79, 40, 144, 196, 121, 97, 135, 1, 235, 191, 91, 203, 127, 100, 135, 17, 162, 175, 2, 199, 106, 111, 137, 22, 187, 173, 65, 192, 43, 123, 139, 11, 175, 163, 85, 66, 235, 184, 210, 6, 172, 244, 47, 75, 237, 173, 212, 23, 183, 240, 31, 115, 225, 182, 206, 6, 177, 114, 248, 253, 116, 185, 62, 49, 161, 120, 189, 245, 108, 189, 51, 49, 171, 113, 189, 246, 125, 178, 41, 45, 161, 104, 244, 230, 36, 189, 63, 42, 182, 104, 21, 236, 159, 245, 81, 171, 211, 251, 22, 253, 144, 239, 77, 161, 202, 178, 6, 164, 159, 249, 74, 182, 202, 190, 1, 83, 177, 22, 254, 134, 90, 103, 172, 225, 129, 59, 246, 188, 74, 51, 163, 247, 134, 44, 246, 95, 170, 146, 252, 155, 248, 69, 245, 45, 198, 64, 165, 109, 137, 129, 231, 61, 212, 235, 233, 211, 54, 175, 174, 159, 56, 248, 238, 220, 44, 190, 175, 134, 56, 232, 226, 192, 49, 171, 181, 210, 106, 254, 224, 214, 33, 242, 241, 40, 28, 182, 182, 100, 113, 237, 247, 61, 23, 172, 173, 91, 87, 227, 253, 48]);
  const pack = self["tranquill_PACK"] = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  pack.data.push(a);
  const shard = pack.data.length - 1;
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 0,
    len: 43,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 43,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 62,
    len: 35,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 97,
    len: 2,
    kind: 2
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 99,
    len: 14,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 113,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 119,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 125,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 131,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 137,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 143,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 149,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 174,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 180,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 180,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 186,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 186,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 192,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 192,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 198,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 198,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 206,
    len: 11,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 217,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 245,
    len: 17,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 262,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 267,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 284,
    len: 8,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 292,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 313,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 333,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 338,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 344,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 376,
    len: 9,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 385,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 390,
    len: 26,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 416,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 435,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 460,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 467,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 486,
    len: 38,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 524,
    len: 39,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 563,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 580,
    len: 27,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 607,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 639,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 646,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 662,
    len: 14,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 676,
    len: 30,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 706,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 711,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 723,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 732,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 737,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 759,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 768,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 796,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 802,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 828,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 837,
    len: 39,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 876,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 901,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 917,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 942,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 948,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 954,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 960,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 961,
    len: 15,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 976,
    len: 15,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 991,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1011,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1020,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1037,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1057,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1063,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1074,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1095,
    len: 16,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1111,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1143,
    len: 21,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1164,
    len: 34,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 1198,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1204,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1210,
    len: 29,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1239,
    len: 7,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1246,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1267,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1299,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1318,
    len: 32,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1350,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 1359,
    len: 13,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1372,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1397,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1429,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1450,
    len: 34,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1484,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1509,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 1514,
    len: 15,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 1529,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1536,
    len: 11,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1547,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1575,
    len: 19,
    kind: 1
  });
})();
let _tranquill_cond = typeof event.code === tranquill_S("0x6c62272e07bb0142");
if (_tranquill_cond) {
  event.code;
} else {
  tranquill_S("0x6c62272e07bb0142");
}
(() => {
  if (window.__tranquillPhantomInitialized) {
    log.debug(tranquill_S("0x6c62272e07bb0142"));
    chrome.runtime?.sendMessage?.({
      action: tranquill_S("0x6c62272e07bb0142")
    });
    return;
  }
  window.__tranquillPhantomInitialized = true;
  log.info(tranquill_S("0x6c62272e07bb0142"));
  const DEFAULT_SUPPRESSION_MS = 320;
  const SUPPRESSION_PADDING_MS = 200;
  const TRIGGER_FAILSAFE_MS = tranquill_RN("0x6c62272e07bb0142");
  const SYNTHETIC_GRACE_MS = 480;
  const SYNTHETIC_BACKSPACE_WINDOW_MS = 600;
  const SETTINGS_STORAGE_KEY = tranquill_S("0x6c62272e07bb0142");
  const DEFAULT_ABORT_KEY = Object.freeze({
    key: tranquill_S("0x6c62272e07bb0142"),
    code: tranquill_S("0x6c62272e07bb0142"),
    altKey: false,
    ctrlKey: false,
    metaKey: false,
    shiftKey: false
  });
  let abortBinding = {
    ...DEFAULT_ABORT_KEY
  };
  let isActive = false;
  let suppressionTimer = null;
  let suppressionActive = false;
  let currentSyntheticCharacter = null;
  let activeRequest = null;
  let requestSequence = 0;
  const triggerQueue = [];
  let allowSyntheticBackspace = false;
  let syntheticBackspaceTimer = null;
  const stats = {
    enqueued: 0,
    completed: 0,
    backspaces: 0,
    aborted: 0
  };
  const normalizeAbortKey = rawBinding => {
    if (rawBinding && typeof rawBinding === tranquill_S("0x6c62272e07bb0142")) {
      const key = typeof rawBinding.key === tranquill_S("0x6c62272e07bb0142") && rawBinding.key.length > 0 ? rawBinding["key"] : DEFAULT_ABORT_KEY.key;
      const code = typeof rawBinding.code === tranquill_S("0x6c62272e07bb0142") && rawBinding.code.length > 0 ? rawBinding.code : key;
      return {
        key,
        code,
        altKey: rawBinding.altKey === true,
        ctrlKey: rawBinding.ctrlKey === true,
        metaKey: rawBinding.metaKey === true,
        shiftKey: rawBinding.shiftKey === true
      };
    }
    if (typeof rawBinding === tranquill_S("0x6c62272e07bb0142") && rawBinding["trim"]().length > 0) {
      const value = rawBinding.trim();
      return {
        key: value,
        code: value,
        altKey: false,
        ctrlKey: false,
        metaKey: false,
        shiftKey: false
      };
    }
    return {
      ...DEFAULT_ABORT_KEY
    };
  };
  const updateAbortBinding = binding => {
    abortBinding = normalizeAbortKey(binding);
    log.debug(tranquill_S("0x6c62272e07bb0142"), abortBinding);
  };
  const matchesAbortBinding = event => {
    if (!event || !abortBinding) return false;
    const code = _tranquill_cond;
    const key = typeof event.key === tranquill_S("0x6c62272e07bb0142") ? event["key"] : tranquill_S("0x6c62272e07bb0142");
    const bindingCode = typeof abortBinding["code"] === tranquill_S("0x6c62272e07bb0142") && abortBinding.code.length > 0 ? abortBinding.code : tranquill_S("0x6c62272e07bb0142");
    const bindingKey = typeof abortBinding.key === tranquill_S("0x6c62272e07bb0142") && abortBinding.key["length"] > 0 ? abortBinding.key : tranquill_S("0x6c62272e07bb0142");
    const baseMatch = bindingCode ? bindingCode === code : bindingKey === key;
    if (!baseMatch) return false;
    return event["altKey"] === Boolean(abortBinding.altKey) && event.ctrlKey === Boolean(abortBinding.ctrlKey) && event.metaKey === Boolean(abortBinding.metaKey) && event["shiftKey"] === Boolean(abortBinding.shiftKey);
  };
  const sendAbortMessage = (reason = tranquill_S("0x6c62272e07bb0142")) => {
    try {
      chrome.runtime?.sendMessage?.({
        action: tranquill_S("0x6c62272e07bb0142"),
        reason
      });
    } catch (err) {
      log.warn(tranquill_S("0x6c62272e07bb0142"), err);
    }
  };
  const handleAbortKey = event => {
    if (!matchesAbortBinding(event)) return false;
    if (event.repeat) return true;
    log.info(tranquill_S("0x6c62272e07bb0142"), {
      key: event.key ?? null,
      code: event.code ?? null,
      isActive
    });
    triggerQueue["length"] = 0;
    if (isActive) {
      finalizeActiveRequest(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      resetState();
    }
    sendAbortMessage(tranquill_S("0x6c62272e07bb0142"));
    return true;
  };
  const loadAbortBinding = () => {
    try {
      chrome.storage?.local?.get?.(SETTINGS_STORAGE_KEY, res => {
        const err = chrome.runtime?.lastError ?? null;
        if (err) {
          log.warn(tranquill_S("0x6c62272e07bb0142"), err);
          updateAbortBinding(DEFAULT_ABORT_KEY);
          return;
        }
        const settings = res?.[SETTINGS_STORAGE_KEY] ?? null;
        updateAbortBinding(settings?.abortKey);
      });
    } catch (error) {
      log["warn"](tranquill_S("0x6c62272e07bb0142"), error);
      updateAbortBinding(DEFAULT_ABORT_KEY);
    }
  };
  loadAbortBinding();
  chrome.storage?.onChanged?.addListener?.((changes, areaName) => {
    if (areaName !== tranquill_S("0x6c62272e07bb0142")) return;
    if (!changes || typeof changes !== tranquill_S("0x6c62272e07bb0142")) return;
    const delta = changes[SETTINGS_STORAGE_KEY];
    if (!delta) return;
    try {
      updateAbortBinding(delta.newValue?.abortKey);
    } catch (error) {
      log.warn(tranquill_S("0x6c62272e07bb0142"), error);
    }
  });
  const clearSuppressionTimer = () => {
    if (suppressionTimer !== null) {
      clearTimeout(suppressionTimer);
      suppressionTimer = null;
    }
  };
  const clearSyntheticBackspace = () => {
    if (syntheticBackspaceTimer !== null) {
      clearTimeout(syntheticBackspaceTimer);
      syntheticBackspaceTimer = null;
    }
    allowSyntheticBackspace = false;
  };
  const finalizeActiveRequest = (status, reason) => {
    if (activeRequest?.fallbackTimer) {
      clearTimeout(activeRequest.fallbackTimer);
      activeRequest.fallbackTimer = null;
    }
    const completedId = activeRequest ? activeRequest.id : null;
    clearSuppressionTimer();
    suppressionActive = false;
    currentSyntheticCharacter = null;
    clearSyntheticBackspace();
    if (activeRequest && status === tranquill_S("0x6c62272e07bb0142")) stats["completed"] += 1;
    if (status === tranquill_S("0x6c62272e07bb0142")) stats.aborted += 1;
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      requestId: completedId,
      status,
      reason,
      queueLength: triggerQueue.length
    });
    activeRequest = null;
    processQueue();
  };
  const resetState = () => {
    triggerQueue.length = 0;
    activeRequest = null;
    clearSuppressionTimer();
    suppressionActive = false;
    currentSyntheticCharacter = null;
    clearSyntheticBackspace();
    log.debug(tranquill_S("0x6c62272e07bb0142"));
  };
  const beginSuppression = (duration, requestId) => {
    const ms = Number["isFinite"](duration) && duration > 0 ? duration : DEFAULT_SUPPRESSION_MS;
    clearSuppressionTimer();
    suppressionActive = true;
    suppressionTimer = window.setTimeout(() => {
      suppressionTimer = null;
      suppressionActive = false;
      log.warn(tranquill_S("0x6c62272e07bb0142"), {
        requestId: requestId ?? null,
        queueLength: triggerQueue.length
      });
      finalizeActiveRequest(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
    }, ms + SUPPRESSION_PADDING_MS);
  };
  const processQueue = () => {
    if (!isActive) {
      log["debug"](tranquill_S("0x6c62272e07bb0142"));
      return;
    }
    if (activeRequest) {
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        requestId: activeRequest["id"],
        queueLength: triggerQueue["length"]
      });
      return;
    }
    if (triggerQueue["length"] === 0) {
      log["debug"](tranquill_S("0x6c62272e07bb0142"));
      return;
    }
    const next = triggerQueue.shift();
    activeRequest = next;
    beginSuppression(DEFAULT_SUPPRESSION_MS, next.id);
    stats.enqueued += 1;
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      requestId: next.id,
      queueLength: triggerQueue.length
    });
    next.fallbackTimer = window.setTimeout(() => {
      log.warn(tranquill_S("0x6c62272e07bb0142"), {
        requestId: next.id
      });
      finalizeActiveRequest(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
    }, TRIGGER_FAILSAFE_MS);
    try {
      chrome.runtime?.sendMessage?.({
        action: tranquill_S("0x6c62272e07bb0142"),
        requestId: next.id,
        key: next.key,
        timeStamp: next.timeStamp
      });
    } catch (err) {
      log.error(tranquill_S("0x6c62272e07bb0142"), err);
      finalizeActiveRequest(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
    }
  };
  const shouldIntercept = ev => {
    if (!isActive) return false;
    if (ev.isComposing) return false;
    if (ev["ctrlKey"] || ev.metaKey || ev.altKey) return false;
    if (ev.key === tranquill_S("0x6c62272e07bb0142")) return true;
    if (ev.key.length === 1) return true;
    if (ev.key === tranquill_S("0x6c62272e07bb0142")) return true;
    return false;
  };
  const enqueueTrigger = ev => {
    const entry = {
      id: ++requestSequence,
      key: ev.key,
      timeStamp: ev.timeStamp ?? null,
      createdAt: Date["now"](),
      expectedKeys: [],
      fallbackTimer: null
    };
    triggerQueue["push"](entry);
    let _tranquill_cond2 = activeRequest;
    if (_tranquill_cond2) {
      activeRequest["id"];
    } else {
      null;
    }
    log["debug"](tranquill_S("0x6c62272e07bb0142"), {
      requestId: entry.id,
      queueLength: triggerQueue["length"],
      suppressionActive,
      activeRequest: _tranquill_cond2
    });
    processQueue();
  };
  const handleKeyDown = ev => {
    if (handleAbortKey(ev)) return;
    if (!shouldIntercept(ev)) return;
    if (allowSyntheticBackspace && ev.key === tranquill_S("0x6c62272e07bb0142")) {
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        queueLength: triggerQueue.length
      });
      clearSyntheticBackspace();
      return;
    }
    if (activeRequest?.expectedKeys?.length) {
      const expect = activeRequest["expectedKeys"][0];
      if (typeof expect === tranquill_S("0x6c62272e07bb0142") && ev["key"] === expect) {
        activeRequest.expectedKeys.shift();
        log.debug(tranquill_S("0x6c62272e07bb0142"), {
          requestId: activeRequest["id"],
          key: ev.key,
          remaining: activeRequest.expectedKeys.length
        });
        return;
      }
    }
    if (ev.key === tranquill_S("0x6c62272e07bb0142")) {
      ev["preventDefault"]();
      ev.stopImmediatePropagation?.();
      ev.stopPropagation();
      if (triggerQueue["length"] > 0) {
        const removed = triggerQueue.pop();
        log.debug(tranquill_S("0x6c62272e07bb0142"), {
          removedRequest: removed?.id ?? null,
          queueLength: triggerQueue.length
        });
        return;
      }
      stats.backspaces += 1;
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        activeRequest: activeRequest ? activeRequest.id : null
      });
      chrome["runtime"]?.sendMessage?.({
        action: tranquill_S("0x6c62272e07bb0142")
      });
      return;
    }
    if (ev.repeat) {
      ev.preventDefault();
      ev.stopImmediatePropagation?.();
      ev["stopPropagation"]();
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        key: ev.key
      });
      return;
    }
    ev.preventDefault();
    ev.stopImmediatePropagation?.();
    ev.stopPropagation();
    enqueueTrigger(ev);
  };
  const handleBeforeInput = ev => {
    if (!isActive || ev.isComposing) return;
    if (typeof ev["inputType"] === tranquill_S("0x6c62272e07bb0142") && ev["inputType"].startsWith(tranquill_S("0x6c62272e07bb0142"))) return;
    const syntheticMatch = (() => {
      if (typeof ev.data === tranquill_S("0x6c62272e07bb0142") && ev.data.length > 0) {
        return ev.data === currentSyntheticCharacter;
      }
      if (currentSyntheticCharacter === tranquill_S("0x6c62272e07bb0142")) {
        return ev.inputType === tranquill_S("0x6c62272e07bb0142") || ev.inputType === tranquill_S("0x6c62272e07bb0142");
      }
      return false;
    })();
    const allowBySuppressionState = suppressionActive && !activeRequest && triggerQueue["length"] === 0 && currentSyntheticCharacter === null;
    if (syntheticMatch || allowBySuppressionState) {
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        reason: syntheticMatch ? tranquill_S("0x6c62272e07bb0142") : tranquill_S("0x6c62272e07bb0142"),
        inputType: ev.inputType,
        requestId: activeRequest ? activeRequest.id : null
      });
      currentSyntheticCharacter = null;
      return;
    }
    log["debug"](tranquill_S("0x6c62272e07bb0142"), {
      inputType: ev.inputType,
      data: ev.data,
      suppressionActive,
      activeRequest: activeRequest ? activeRequest.id : null
    });
    ev.preventDefault();
    ev["stopImmediatePropagation"]?.();
    ev.stopPropagation();
  };
  chrome["runtime"].onMessage.addListener((message, _sender, sendResponse) => {
    if (!message || typeof message !== tranquill_S("0x6c62272e07bb0142")) {
      sendResponse?.({
        success: false
      });
      return false;
    }
    if (message["action"] === tranquill_S("0x6c62272e07bb0142")) {
      log.debug(tranquill_S("0x6c62272e07bb0142"));
      sendResponse?.({
        success: true,
        pong: true
      });
      return false;
    }
    if (message.action === tranquill_S("0x6c62272e07bb0142")) {
      isActive = !!message["active"];
      log["info"](tranquill_S("0x6c62272e07bb0142"), {
        isActive
      });
      if (!isActive) {
        resetState();
      } else {
        processQueue();
      }
      sendResponse?.({
        success: true
      });
      return false;
    }
    if (message["action"] === tranquill_S("0x6c62272e07bb0142")) {
      if (!activeRequest || message["requestId"] !== activeRequest.id) {
        log.warn(tranquill_S("0x6c62272e07bb0142"), {
          requestId: message["requestId"] ?? null,
          activeRequest: activeRequest ? activeRequest["id"] : null
        });
        sendResponse?.({
          success: false,
          accepted: false
        });
        return false;
      }
      activeRequest.expectedKeys = Array.isArray(message["keys"]) ? message.keys.filter(k => typeof k === tranquill_S("0x6c62272e07bb0142") && k.length > 0) : [];
      currentSyntheticCharacter = typeof message.character === tranquill_S("0x6c62272e07bb0142") ? message.character : null;
      beginSuppression(Number(message.duration), activeRequest["id"]);
      if (activeRequest.fallbackTimer) {
        clearTimeout(activeRequest.fallbackTimer);
      }
      const timeout = Math.max(DEFAULT_SUPPRESSION_MS, Number(message.duration) || DEFAULT_SUPPRESSION_MS);
      activeRequest.fallbackTimer = window.setTimeout(() => {
        log.warn(tranquill_S("0x6c62272e07bb0142"), {
          requestId: activeRequest?.id ?? null
        });
        finalizeActiveRequest(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      }, timeout + SYNTHETIC_GRACE_MS);
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        requestId: activeRequest.id,
        expectedKeys: activeRequest.expectedKeys,
        character: currentSyntheticCharacter
      });
      sendResponse?.({
        success: true,
        accepted: true
      });
      return false;
    }
    if (message.action === tranquill_S("0x6c62272e07bb0142")) {
      if (!activeRequest || message.requestId !== activeRequest.id) {
        log.warn(tranquill_S("0x6c62272e07bb0142"), {
          requestId: message.requestId ?? null,
          activeRequest: activeRequest ? activeRequest.id : null
        });
        sendResponse?.({
          success: false
        });
        return false;
      }
      finalizeActiveRequest(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      sendResponse?.({
        success: true
      });
      return false;
    }
    if (message.action === tranquill_S("0x6c62272e07bb0142")) {
      clearSyntheticBackspace();
      allowSyntheticBackspace = true;
      const windowMs = Math.max(SYNTHETIC_BACKSPACE_WINDOW_MS, Number(message.duration) || 0);
      syntheticBackspaceTimer = window.setTimeout(clearSyntheticBackspace, windowMs + SYNTHETIC_GRACE_MS);
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        windowMs
      });
      sendResponse?.({
        success: true
      });
      return false;
    }
    if (message.action === tranquill_S("0x6c62272e07bb0142")) {
      if (!activeRequest || message.requestId !== activeRequest.id) {
        let _tranquill_cond3 = activeRequest;
        if (_tranquill_cond3) {
          activeRequest.id;
        } else {
          null;
        }
        log.warn(tranquill_S("0x6c62272e07bb0142"), {
          requestId: message["requestId"] ?? null,
          activeRequest: _tranquill_cond3
        });
        sendResponse?.({
          success: false
        });
        return false;
      }
      log.warn(tranquill_S("0x6c62272e07bb0142"), {
        requestId: activeRequest.id,
        character: message["character"] ?? null
      });
      finalizeActiveRequest(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      sendResponse?.({
        success: true
      });
      return false;
    }
    sendResponse?.({
      success: false
    });
    return false;
  });
  window.addEventListener(tranquill_S("0x6c62272e07bb0142"), handleKeyDown, true);
  window.addEventListener(tranquill_S("0x6c62272e07bb0142"), handleBeforeInput, true);
  log["info"](tranquill_S("0x6c62272e07bb0142"), stats);
  chrome["runtime"]?.sendMessage?.({
    action: tranquill_S("0x6c62272e07bb0142")
  });
})();
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}