const tranquill_global = typeof self !== "undefined" ? self : globalThis;
if (!tranquill_global.tranquill_runtime_ready) {
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::16fd2ce4be226d9f78b1905b71de3935"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = "tranquill_tranquill_tranquill";
        tranquill_global.tranquill_runtime_ready = true;
}

"use strict";
(function tranquill_0() {
  const tranquill_1 = new Uint8Array([51, 160, 204, 76, 46, 189, 53, 63, 84, 66, 40, 44, 91, 162, 48, 82, 250, 61, 91, 90, 228, 239, 85, 75, 65, 184, 167, 72, 66, 88, 79, 39, 35, 69, 82, 18, 1, 173, 45, 15, 28, 36, 155, 91, 55, 57, 134, 50, 26, 93, 59, 34, 17, 221, 61, 63, 12, 52, 107, 75, 7, 41, 118, 34, 230, 199, 1, 46, 240, 229, 186, 146, 7, 242, 50, 253, 229, 0, 5, 18, 54, 119, 17, 30, 32, 4, 146, 189, 237, 29, 148, 189, 246, 17, 29, 215, 188, 234, 0, 196, 203, 143, 46, 232, 199, 153, 233, 27, 200, 230, 244, 8, 227, 141, 66, 240, 254, 158, 231, 241, 30, 206, 254, 247, 30, 213, 242, 252, 35, 70, 215, 239, 164, 59, 19, 198, 179, 216, 240, 189, 215, 212, 230, 206, 96, 47, 221, 211, 115, 192, 234, 161, 215, 221, 249, 200, 113, 227, 234, 175, 35, 218, 223, 170, 36, 210, 221, 183, 12, 162, 15, 71, 160, 225, 0, 168, 245, 212, 5, 175, 253, 214, 24, 135, 180, 214, 27, 189, 180, 217, 27, 180, 231, 213, 24, 191, 180, 222, 29, 169, 228, 219, 0, 185, 252, 154, 18, 187, 253, 214, 17, 190, 143, 200, 174, 123, 149, 206, 185, 32, 139, 194, 174, 102, 153, 223, 87, 134, 178, 105, 95, 159, 214, 170, 106, 154, 209, 162, 104, 135, 249, 235, 104, 132, 195, 235, 116, 132, 214, 191, 36, 143, 205, 184, 116, 138, 208, 168, 108, 203, 194, 170, 109, 135, 193, 175, 49, 29, 132, 33, 52, 26, 140, 35, 41, 43, 128, 57, 44, 12, 128, 7, 18, 38, 161, 78, 86, 251, 42, 75, 81, 243, 40, 86, 96, 255, 50, 83, 71, 255, 12, 109, 109, 222, 23, 91, 72, 238, 43, 199, 94, 59, 46, 192, 86, 57, 51, 241, 90, 35, 54, 214, 90, 29, 8, 252, 123, 225, 33, 201, 23, 243, 61, 200, 26, 12, 53, 233, 26, 24, 57, 253, 22, 17, 17, 249, 231, 3, 13, 248, 234, 28, 5, 249, 234, 232, 73, 13, 230, 212, 77, 241, 226, 193, 60, 112, 196, 215, 63, 99, 221, 145, 57, 127, 214, 222, 112, 99, 213, 197, 34, 120, 213, 199, 49, 125, 144, 215, 49, 120, 220, 212, 52, 194, 239, 39, 192, 160, 220, 209, 164, 182, 223, 194, 189, 240, 217, 222, 182, 191, 144, 194, 181, 164, 194, 217, 181, 166, 209, 220, 240, 164, 216, 194, 181, 167, 227, 189, 153, 94, 181, 170, 132, 157, 48, 175, 245, 252, 77, 216, 177, 92, 20, 179, 163, 39, 134, 128, 175, 49, 215, 114, 188, 211, 129, 111, 175, 131, 62, 189, 158, 153, 39, 184, 148, 208, 60, 102, 134, 204, 61, 107, 140, 232, 36, 158, 158, 244, 37, 147, 106, 7, 148, 103, 112, 30, 145, 70, 207, 160, 127, 69, 145, 12, 190, 161, 146, 9, 247, 185, 152, 77, 165, 168, 132, 2, 187, 187, 146, 77, 163, 164, 154, 8, 173, 162, 153, 8, 247, 171, 152, 31, 247, 133, 160, 36, 147, 73, 252, 119, 92, 83, 229, 114, 64, 53, 190, 85, 90, 44, 187, 69, 83, 38, 36, 78, 84, 21, 8, 107, 40, 15, 17, 110, 44, 65, 210, 33, 54, 88, 215, 59, 150, 5, 54, 33, 143, 0, 56, 189, 57, 75, 152, 54, 36, 88, 194, 114, 163, 193, 170, 86, 139, 233, 254, 5, 142, 236, 237, 64, 153, 241, 3, 109, 34, 16, 30, 126, 5, 239, 164, 18, 24, 252, 31, 81, 62, 236, 2, 66, 209, 19, 176, 238, 204, 0, 211, 166, 50, 213, 187, 149, 18, 246, 254, 130, 15, 226, 76, 131, 241, 255, 95, 236, 208, 131, 241, 252, 165, 206, 201, 251, 165, 152, 232, 207, 137, 252, 128, 255, 165, 214, 197, 234, 161, 204, 197, 252, 199, 182, 98, 217, 246, 242, 153, 223, 245, 247, 208, 199, 255, 179, 153, 221, 249, 231, 153, 210, 252, 250, 138, 214, 176, 247, 149, 197, 249, 240, 149, 147, 216, 196, 185, 247, 163, 218, 134, 181, 146, 232, 51, 155, 250, 221, 21, 176, 174, 204, 14, 173, 187, 207, 90, 185, 187, 214, 22, 170, 168, 218, 138, 231, 63, 155, 143, 224, 55, 153, 146, 184, 50, 154, 153, 184, 45, 129, 140, 240, 63, 152, 75, 15, 174, 104, 71, 25, 110, 138, 9, 67, 114, 136, 49, 106, 107, 138, 17, 120, 84, 23, 117, 122, 91, 29, 90, 108, 92, 28, 121, 92, 103, 241, 68, 91, 105, 240, 81, 168, 183, 88, 82, 72, 127, 55, 83, 85, 98, 70, 246, 41, 87, 90, 254, 191, 89, 86, 232, 69, 80, 176, 44, 64, 87, 184, 46, 93, 110, 190, 37, 62, 159, 21, 18, 187, 103, 7, 23, 188, 111, 5, 10, 142, 99, 29, 46, 158, 79, 45, 61, 160, 152, 15, 195, 126, 226, 205, 171, 91, 206, 248, 254, 76, 216, 253, 171, 79, 202, 224, 231, 76, 207, 245, 42, 64, 22, 240, 45, 72, 20, 237, 29, 79, 11, 244, 42, 68, 52, 232, 59, 68, 22, 242, 61, 255, 219, 151, 237, 237, 199, 150, 224, 237, 175, 98, 195, 207, 181, 100, 134, 198, 167, 117, 195, 129, 179, 111, 199, 215, 167, 104, 202, 192, 164, 109, 195, 172, 216, 208, 188, 183, 150, 139, 227, 176, 222, 197, 162, 181, 217, 205, 160, 168, 130, 199, 175, 235, 187, 141, 26, 242, 164, 151, 2, 240, 165, 144, 5, 250, 173, 145, 6, 243, 161, 198, 83, 161, 173, 144, 5, 242, 164, 151, 87, 236, 164, 144, 87, 243, 162, 155, 86, 244, 247, 154, 83, 247, 244, 154, 6, 242, 187, 201, 70, 204, 58, 237, 197, 211, 32, 245, 199, 210, 39, 242, 205, 218, 38, 241, 196, 214, 113, 164, 150, 218, 39, 242, 197, 211, 32, 160, 219, 129, 34, 160, 146, 219, 114, 247, 196, 129, 44, 163, 198, 210, 113, 243, 205, 204, 126, 177, 221, 171, 252, 212, 194, 177, 228, 214, 195, 182, 227, 220, 203, 183, 224, 213, 199, 224, 181, 135, 203, 182, 227, 212, 194, 177, 177, 202, 151, 180, 178, 213, 194, 224, 231, 215, 203, 188, 226, 128, 149, 177, 176, 210, 221, 239, 160, 110, 64, 207, 63, 113, 90, 215, 61, 112, 93, 208, 55, 120, 92, 211, 62, 116, 11, 134, 108, 120, 93, 208, 63, 113, 90, 130, 33, 113, 93, 217, 55, 113, 10, 130, 111, 37, 15, 215, 55, 118, 8, 132, 62, 110, 4, 147, 127, 113, 222, 78, 96, 107, 198, 76, 97, 108, 193, 70, 105, 109, 194, 79, 101, 58, 151, 29, 105, 108, 193, 78, 96, 107, 147, 80, 55, 61, 151, 76, 98, 60, 195, 72, 104, 107, 198, 72, 97, 59, 147, 29, 127, 53, 130, 176, 126, 209, 129, 175, 100, 201, 131, 174, 99, 206, 137, 166, 98, 205, 128, 170, 53, 152, 210, 166, 99, 206, 129, 175, 100, 156, 159, 171, 52, 157, 212, 173, 98, 199, 134, 248, 103, 205, 133, 173, 100, 154, 130, 176, 58, 141, 129, 111, 160, 144, 158, 117, 184, 146, 159, 114, 191, 152, 151, 115, 188, 145, 155, 36, 233, 195, 151, 114, 191, 144, 158, 117, 237, 142, 151, 37, 182, 195, 201, 120, 234, 149, 202, 35, 186, 147, 203, 117, 188, 145, 129, 43, 252, 34, 148, 3, 235, 61, 142, 27, 233, 60, 137, 28, 227, 52, 136, 31, 234, 56, 223, 74, 184, 52, 137, 28, 235, 61, 142, 78, 245, 58, 130, 24, 185, 57, 137, 20, 184, 57, 220, 73, 238, 63, 137, 30, 239, 34, 208, 95, 51, 5, 146, 122, 44, 31, 138, 120, 45, 24, 141, 114, 37, 25, 142, 123, 41, 78, 219, 41, 37, 24, 141, 122, 44, 31, 223, 100, 126, 26, 222, 123, 46, 29, 220, 40, 124, 24, 137, 125, 123, 79, 217, 121, 51, 65, 206, 68, 178, 101, 77, 91, 168, 125, 79, 90, 175, 122, 69, 82, 174, 121, 76, 94, 249, 44, 30, 82, 175, 122, 77, 91, 168, 40, 83, 8, 172, 43, 25, 89, 253, 43, 79, 88, 253, 43, 24, 90, 254, 114, 24, 68, 246, 57, 85, 35, 116, 92, 74, 57, 108, 94, 75, 62, 107, 84, 67, 63, 104, 93, 79, 104, 61, 15, 67, 62, 107, 92, 74, 57, 57, 66, 29, 111, 62, 14, 78, 104, 111, 14, 79, 58, 99, 91, 29, 111, 106, 14, 85, 103, 40, 230, 216, 71, 167, 249, 194, 95, 165, 248, 197, 88, 175, 240, 196, 91, 166, 252, 147, 14, 244, 240, 197, 88, 167, 249, 194, 10, 185, 255, 194, 10, 247, 173, 149, 88, 160, 249, 149, 91, 163, 255, 206, 92, 160, 230, 156, 27, 247, 201, 86, 54, 232, 211, 78, 52, 233, 212, 73, 62, 225, 213, 74, 55, 237, 130, 31, 101, 225, 212, 73, 54, 232, 211, 27, 40, 238, 208, 65, 49, 186, 211, 73, 62, 188, 131, 75, 51, 189, 214, 75, 98, 247, 141, 10, 98, 11, 30, 119, 46, 22, 73, 32, 127, 70, 25, 32, 124, 66, 79, 119, 46, 16, 2, 46, 63, 51, 5, 146, 40, 121, 77, 223, 42, 121, 31, 142, 46, 37, 31, 137, 46, 36, 24, 138, 40, 127, 31, 138, 124, 127, 72, 141, 100, 42, 24, 216, 122, 43, 18, 136, 124, 37, 25, 217, 115, 123, 18, 216, 46, 51, 65, 206]);
  const tranquill_2 = self.tranquill_PACK = self["tranquill_PACK"] || {
    idx: new Map(),
    data: []
  };
  tranquill_2.data["push"](tranquill_1);
  const tranquill_3 = tranquill_2.data["length"] - 1;
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 0,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 6,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 12,
    len: 3,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 15,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 19,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 24,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 29,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 35,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 41,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 47,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 51,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 57,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 63,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 69,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 74,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 79,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 85,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 94,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 100,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 106,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 112,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 118,
    len: 9,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 127,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 132,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 137,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 143,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 149,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 155,
    len: 3,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 158,
    len: 11,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 169,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 173,
    len: 39,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 212,
    len: 14,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 226,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 230,
    len: 36,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 266,
    len: 19,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 285,
    len: 23,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 308,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 327,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 335,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 339,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 343,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 351,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 355,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 359,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 363,
    len: 30,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 393,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 397,
    len: 29,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 426,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 427,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 427,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 433,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 440,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 444,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 450,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 451,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 457,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 464,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 472,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 480,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 487,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 492,
    len: 35,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 527,
    len: 7,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 534,
    len: 7,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 541,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 547,
    len: 7,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 554,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 561,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 568,
    len: 2,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 570,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 576,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 592,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 598,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 604,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 610,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 616,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 616,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 627,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 633,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 637,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 658,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 662,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 694,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 698,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 720,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 740,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 746,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 757,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 761,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 769,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 776,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 781,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 787,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 791,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 797,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 809,
    len: 3,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 812,
    len: 16,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 828,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 832,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 851,
    len: 22,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 873,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 881,
    len: 24,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 905,
    len: 21,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 926,
    len: 47,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 973,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1020,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1067,
    len: 47,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1114,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1161,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1208,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1255,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1302,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1349,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1396,
    len: 47,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1443,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1490,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1537,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1558,
    len: 47,
    kind: 1
  });
})();
const tranquill_4 = Object.freeze({
  silent: 0,
  error: 1,
  warn: 2,
  info: 3,
  debug: 4
});
self.TRANQUILL_LOG_LEVEL = tranquill_S("0x6c62272e07bb0142");
const tranquill_5 = (tranquill_6, {
  allowSilent: tranquill_7 = false
} = {}) => {
  if (typeof tranquill_6 !== tranquill_S("0x6c62272e07bb0142")) return null;
  const tranquill_9 = tranquill_6.toLowerCase();
  if (tranquill_9 === tranquill_S("0x6c62272e07bb0142")) return tranquill_S("0x6c62272e07bb0142");
  if (tranquill_9 === tranquill_S("0x6c62272e07bb0142")) return tranquill_S("0x6c62272e07bb0142");
  if (tranquill_9 === tranquill_S("0x6c62272e07bb0142") && tranquill_7) return tranquill_S("0x6c62272e07bb0142");
  if (Object.prototype.hasOwnProperty.call(tranquill_4, tranquill_9)) {
    return tranquill_9;
  }
  return null;
};
const tranquill_a = () => {
  const tranquill_b = tranquill_5(self["TRANQUILL_LOG_LEVEL"], {
    allowSilent: true
  });
  return tranquill_b || tranquill_S("0x6c62272e07bb0142");
};
const tranquill_c = tranquill_d => {
  const tranquill_e = tranquill_5(tranquill_d) || tranquill_S("0x6c62272e07bb0142");
  if (tranquill_e === tranquill_S("0x6c62272e07bb0142")) return false;
  const tranquill_f = tranquill_a();
  if (tranquill_f === tranquill_S("0x6c62272e07bb0142")) return false;
  return tranquill_4[tranquill_e] <= tranquill_4[tranquill_f];
};
const tranquill_g = tranquill_h => {
  const tranquill_i = tranquill_5(tranquill_h, {
    allowSilent: true
  });
  if (!tranquill_i) return null;
  const tranquill_k = tranquill_a();
  if (tranquill_k === tranquill_i) return {
    previous: tranquill_k,
    next: tranquill_k,
    changed: false
  };
  self.TRANQUILL_LOG_LEVEL = tranquill_i;
  return {
    previous: tranquill_k,
    next: tranquill_i,
    changed: true
  };
};
const tranquill_l = new Set();
const tranquill_m = tranquill_n => {
  if (!tranquill_n || typeof tranquill_n !== tranquill_S("0x6c62272e07bb0142")) return tranquill_n;
  switch (tranquill_n["kind"]) {
    case tranquill_S("0x6c62272e07bb0142"):
      {
        const tranquill_q = new Error(tranquill_n.message);
        tranquill_q.name = tranquill_n["name"] || tranquill_S("0x6c62272e07bb0142");
        if (tranquill_n.stack) tranquill_q.stack = tranquill_n.stack;
        return tranquill_q;
      }
    case tranquill_S("0x6c62272e07bb0142"):
    case tranquill_S("0x6c62272e07bb0142"):
      return tranquill_n.value;
    case tranquill_S("0x6c62272e07bb0142"):
      return tranquill_n.value;
    default:
      return tranquill_n.value;
  }
};
const tranquill_r = tranquill_s => {
  if (!tranquill_s || typeof tranquill_s !== tranquill_S("0x6c62272e07bb0142")) {
    if (typeof tranquill_s === tranquill_S("0x6c62272e07bb0142")) return {
      kind: tranquill_S("0x6c62272e07bb0142"),
      value: tranquill_s
    };
    return {
      kind: tranquill_S("0x6c62272e07bb0142"),
      value: tranquill_s
    };
  }
  if (tranquill_s.kind && Object.prototype["hasOwnProperty"].call(tranquill_s, tranquill_S("0x6c62272e07bb0142"))) {
    return tranquill_s;
  }
  if (tranquill_s instanceof Error) {
    return {
      kind: tranquill_S("0x6c62272e07bb0142"),
      name: tranquill_s.name,
      message: tranquill_s.message,
      stack: tranquill_s.stack || null
    };
  }
  try {
    return {
      kind: tranquill_S("0x6c62272e07bb0142"),
      value: JSON.parse(JSON.stringify(tranquill_s))
    };
  } catch (tranquill_w) {
    return {
      kind: tranquill_S("0x6c62272e07bb0142"),
      value: String(tranquill_s)
    };
  }
};
const tranquill_x = (tranquill_y, tranquill_z, tranquill_A = {}, tranquill_B = null) => {
  const tranquill_C = typeof tranquill_y === tranquill_S("0x6c62272e07bb0142") ? tranquill_y.toLowerCase() : tranquill_S("0x6c62272e07bb0142");
  if (!tranquill_c(tranquill_C)) return;
  const tranquill_E = Array.isArray(tranquill_z) ? tranquill_z : [];
  const tranquill_F = console?.[tranquill_C] || console?.log;
  try {
    tranquill_F?.call(console, tranquill_S("0x6c62272e07bb0142"), ...tranquill_E);
  } catch (tranquill_G) {
    if (tranquill_c(tranquill_S("0x6c62272e07bb0142"))) {
      console?.warn?.(tranquill_S("0x6c62272e07bb0142"), tranquill_G);
    }
  }
  const tranquill_H = {
    level: tranquill_C,
    args: Array.isArray(tranquill_B) ? tranquill_B.map(tranquill_I => tranquill_r(tranquill_I)) : tranquill_E.map(tranquill_J => tranquill_r(tranquill_J)),
    meta: {
      source: tranquill_A.source || tranquill_S("0x6c62272e07bb0142"),
      timestamp: tranquill_A.timestamp || Date["now"]()
    }
  };
  tranquill_l.forEach(tranquill_K => {
    try {
      tranquill_K.postMessage(tranquill_H);
    } catch (tranquill_L) {
      try {
        tranquill_K.disconnect();
      } catch (tranquill_M) {}
      tranquill_l.delete(tranquill_K);
      if (tranquill_c(tranquill_S("0x6c62272e07bb0142"))) {
        console?.warn?.(tranquill_S("0x6c62272e07bb0142"), tranquill_L);
      }
    }
  });
};
self.__tranquillDirectLog = (tranquill_N, tranquill_O, tranquill_P) => {
  tranquill_x(tranquill_N, tranquill_O, tranquill_P);
};
const tranquill_Q = tranquill_S("0x6c62272e07bb0142");
const tranquill_R = tranquill_S("0x6c62272e07bb0142");
const tranquill_S = tranquill_S("0x6c62272e07bb0142");
const tranquill_T = 32;
const tranquill_U = 32;
let tranquillHWIDPromise = null;
let tranquillHWIDValue = null;
const tranquill_V = (tranquill_W, tranquill_X) => new Promise(tranquill_Y => {
  if (!tranquill_W || typeof tranquill_W.get !== tranquill_S("0x6c62272e07bb0142")) {
    tranquill_Y(null);
    return;
  }
  try {
    tranquill_W.get(tranquill_X, tranquill_10 => {
      const tranquill_11 = chrome.runtime?.lastError ?? null;
      if (tranquill_11) {
        tranquill_x(tranquill_S("0x6c62272e07bb0142"), [`storage get failed for key "${tranquill_X}"`, tranquill_11]);
        tranquill_Y(null);
        return;
      }
      tranquill_Y(tranquill_10?.[tranquill_X] ?? null);
    });
  } catch (tranquill_12) {
    tranquill_x(tranquill_S("0x6c62272e07bb0142"), [`storage get threw for key "${tranquill_X}"`, tranquill_12]);
    tranquill_Y(null);
  }
});
const tranquill_13 = (tranquill_14, tranquill_15, tranquill_16) => new Promise(tranquill_17 => {
  if (!tranquill_14 || typeof tranquill_14.set !== tranquill_S("0x6c62272e07bb0142")) {
    tranquill_17(false);
    return;
  }
  try {
    tranquill_14.set({
      [tranquill_15]: tranquill_16
    }, () => {
      const tranquill_19 = chrome["runtime"]?.lastError ?? null;
      if (tranquill_19) {
        tranquill_x(tranquill_S("0x6c62272e07bb0142"), [`storage set failed for key "${tranquill_15}"`, tranquill_19]);
        tranquill_17(false);
        return;
      }
      tranquill_17(true);
    });
  } catch (tranquill_1a) {
    tranquill_x(tranquill_S("0x6c62272e07bb0142"), [`storage set threw for key "${tranquill_15}"`, tranquill_1a]);
    tranquill_17(false);
  }
});
const tranquill_1b = () => new Promise(tranquill_1c => {
  try {
    chrome.runtime.getPlatformInfo(tranquill_1d => {
      const tranquill_1e = chrome["runtime"]?.lastError ?? null;
      if (tranquill_1e) {
        tranquill_x(tranquill_S("0x6c62272e07bb0142"), [tranquill_S("0x6c62272e07bb0142"), tranquill_1e]);
        tranquill_1c(null);
        return;
      }
      tranquill_1c(tranquill_1d || null);
    });
  } catch (tranquill_1f) {
    tranquill_x(tranquill_S("0x6c62272e07bb0142"), [tranquill_S("0x6c62272e07bb0142"), tranquill_1f]);
    tranquill_1c(null);
  }
});
const tranquill_1g = tranquill_1h => Array.from(new Uint8Array(tranquill_1h)).map(tranquill_1i => tranquill_1i["toString"](16)["padStart"](2, tranquill_S("0x6c62272e07bb0142"))).join(tranquill_S("0x6c62272e07bb0142"));
const tranquill_1j = async (tranquill_1k, {
  context: tranquill_1l = tranquill_S("0x6c62272e07bb0142")
} = {}) => {
  const tranquill_1m = new TextEncoder();
  const tranquill_1n = tranquill_1m.encode(tranquill_1k);
  if (crypto?.subtle?.digest) {
    try {
      const tranquill_1o = await crypto["subtle"].digest(tranquill_S("0x6c62272e07bb0142"), tranquill_1n);
      return tranquill_1g(tranquill_1o);
    } catch (tranquill_1p) {
      tranquill_x(tranquill_S("0x6c62272e07bb0142"), [`${tranquill_1l} sha-256 failed`, tranquill_1p]);
    }
  }
  const tranquill_1q = new Uint8Array(tranquill_T);
  for (let index = 0; index < tranquill_1q.length; index += 1) {
    tranquill_1q[index] = index * 37 & 0xff;
  }
  for (let index = 0; index < tranquill_1n.length; index += 1) {
    const tranquill_1r = tranquill_1n[index];
    const tranquill_1s = index % tranquill_1q["length"];
    const tranquill_1t = (tranquill_1s * 13 + tranquill_1q["length"] - 1) % tranquill_1q.length;
    tranquill_1q[tranquill_1s] = (tranquill_1q[tranquill_1s] ^ tranquill_1r) & 0xff;
    tranquill_1q[tranquill_1t] = tranquill_1q[tranquill_1t] + tranquill_1r + tranquill_1s & 0xff;
  }
  return tranquill_1g(tranquill_1q.buffer);
};
const tranquill_1u = async () => {
  const tranquill_1v = [];
  const tranquill_1w = typeof navigator === tranquill_S("0x6c62272e07bb0142") && navigator ? navigator : {};
  const tranquill_1x = Array.isArray(tranquill_1w.languages) ? tranquill_1w.languages.join(tranquill_S("0x6c62272e07bb0142")) : typeof tranquill_1w.language === tranquill_S("0x6c62272e07bb0142") ? tranquill_1w.language : tranquill_S("0x6c62272e07bb0142");
  const tranquill_1y = (() => {
    try {
      const tranquill_1z = typeof Intl?.DateTimeFormat === tranquill_S("0x6c62272e07bb0142") ? new Intl.DateTimeFormat() : null;
      const tranquill_1A = tranquill_1z && typeof tranquill_1z.resolvedOptions === tranquill_S("0x6c62272e07bb0142") ? tranquill_1z["resolvedOptions"]() : null;
      return tranquill_1A?.timeZone || tranquill_S("0x6c62272e07bb0142");
    } catch (tranquill_1B) {
      tranquill_x(tranquill_S("0x6c62272e07bb0142"), [tranquill_S("0x6c62272e07bb0142"), tranquill_1B]);
      return tranquill_S("0x6c62272e07bb0142");
    }
  })();
  tranquill_1v.push(`platform:${tranquill_1w.platform || tranquill_S("0x6c62272e07bb0142")}`);
  tranquill_1v.push(`languages:${tranquill_1x}`);
  tranquill_1v.push(`timezone:${tranquill_1y}`);
  tranquill_1v["push"](`hardwareConcurrency:${tranquill_1w.hardwareConcurrency || 0}`);
  if (typeof tranquill_1w.deviceMemory === tranquill_S("0x6c62272e07bb0142")) {
    tranquill_1v.push(`deviceMemory:${tranquill_1w.deviceMemory}`);
  }
  const tranquill_1C = await tranquill_1b();
  if (tranquill_1C) {
    tranquill_1v.push(`os:${tranquill_1C.os || tranquill_S("0x6c62272e07bb0142")}`);
    tranquill_1v.push(`arch:${tranquill_1C.arch || tranquill_S("0x6c62272e07bb0142")}`);
    tranquill_1v["push"](`nacl:${tranquill_1C.nacl_arch || tranquill_S("0x6c62272e07bb0142")}`);
  }
  return tranquill_1v.join(tranquill_S("0x6c62272e07bb0142"));
};
const tranquill_1D = async tranquill_1E => {
  if (typeof tranquill_1E !== tranquill_S("0x6c62272e07bb0142") || tranquill_1E.length === 0) return null;
  const tranquill_1G = await tranquill_1j(`tranquill::salt::${tranquill_1E}`, {
    context: tranquill_S("0x6c62272e07bb0142")
  });
  if (typeof tranquill_1G !== tranquill_S("0x6c62272e07bb0142") || tranquill_1G.length === 0) return null;
  return tranquill_1G.slice(0, tranquill_U);
};
const tranquill_1I = async tranquill_1J => {
  const tranquill_1K = await tranquill_V(chrome.storage?.local, tranquill_R);
  if (typeof tranquill_1K === tranquill_S("0x6c62272e07bb0142") && tranquill_1K["length"] > 0) return tranquill_1K;
  const tranquill_1M = await tranquill_V(chrome["storage"]?.sync, tranquill_R);
  if (typeof tranquill_1M === tranquill_S("0x6c62272e07bb0142") && tranquill_1M.length > 0) {
    await tranquill_13(chrome["storage"]?.local, tranquill_R, tranquill_1M);
    return tranquill_1M;
  }
  const tranquill_1O = await tranquill_1D(tranquill_1J);
  if (typeof tranquill_1O !== tranquill_S("0x6c62272e07bb0142") || tranquill_1O.length === 0) return null;
  await Promise.all([tranquill_13(chrome["storage"]?.local, tranquill_R, tranquill_1O), tranquill_13(chrome["storage"]?.sync, tranquill_R, tranquill_1O)]);
  return tranquill_1O;
};
const tranquill_1Q = async () => {
  const tranquill_1R = await tranquill_1u();
  const tranquill_1S = await tranquill_1I(tranquill_1R);
  const tranquill_1T = await tranquill_1j(`tranquill::hwid::${tranquill_1S || tranquill_S("0x6c62272e07bb0142")}::${tranquill_1R}`, {
    context: tranquill_S("0x6c62272e07bb0142")
  });
  return `tranquill-${tranquill_1T}`;
};
const tranquill_1U = async () => {
  if (tranquillHWIDValue) return tranquillHWIDValue;
  const tranquill_1V = tranquillHWIDPromise;
  if (tranquill_1V) return tranquill_1V;
  tranquillHWIDPromise = (async () => {
    const tranquill_1W = await tranquill_V(chrome.storage?.local, tranquill_Q);
    if (typeof tranquill_1W === tranquill_S("0x6c62272e07bb0142") && tranquill_1W.length > 0) {
      tranquillHWIDValue = tranquill_1W;
      await tranquill_13(chrome.storage?.session, tranquill_S, tranquill_1W);
      return tranquill_1W;
    }
    const tranquill_1Y = await tranquill_1Q();
    tranquillHWIDValue = tranquill_1Y;
    await tranquill_13(chrome.storage?.local, tranquill_Q, tranquill_1Y);
    await tranquill_13(chrome.storage?.session, tranquill_S, tranquill_1Y);
    tranquill_x(tranquill_S("0x6c62272e07bb0142"), [tranquill_S("0x6c62272e07bb0142")]);
    return tranquill_1Y;
  })().catch(tranquill_1Z => {
    tranquill_x(tranquill_S("0x6c62272e07bb0142"), [tranquill_S("0x6c62272e07bb0142"), tranquill_1Z]);
    tranquillHWIDValue = null;
    throw tranquill_1Z;
  }).finally(() => {
    tranquillHWIDPromise = null;
  });
  return tranquillHWIDPromise;
};
tranquill_1U().catch(tranquill_20 => {
  tranquill_x(tranquill_S("0x6c62272e07bb0142"), [tranquill_S("0x6c62272e07bb0142"), tranquill_20]);
});
chrome.runtime.onConnect.addListener(tranquill_21 => {
  if (!tranquill_21 || tranquill_21.name !== tranquill_S("0x6c62272e07bb0142")) return;
  tranquill_l.add(tranquill_21);
  tranquill_21["onDisconnect"].addListener(() => {
    tranquill_l.delete(tranquill_21);
  });
  let _tranquill_cond5 = tranquill_23.enabled;
  if (_tranquill_cond5) {
    tranquill_S("0x6c62272e07bb0142");
  } else {
    tranquill_S("0x6c62272e07bb0142");
  }
  tranquill_21.onMessage.addListener(tranquill_23 => {
    if (!tranquill_23 || typeof tranquill_23 !== tranquill_S("0x6c62272e07bb0142")) return;
    if (tranquill_23.type === tranquill_S("0x6c62272e07bb0142")) {
      const tranquill_26 = tranquill_g(tranquill_23["level"]);
      if (tranquill_26?.changed) {
        tranquill_x(tranquill_S("0x6c62272e07bb0142"), [`log level set to "${tranquill_26.next}" via popup`]);
      }
      return;
    }
    if (tranquill_23.type === tranquill_S("0x6c62272e07bb0142") && typeof tranquill_23.enabled === tranquill_S("0x6c62272e07bb0142")) {
      const tranquill_27 = _tranquill_cond5;
      const tranquill_28 = tranquill_g(tranquill_27);
      if (tranquill_28?.changed) {
        tranquill_x(tranquill_S("0x6c62272e07bb0142"), [`log level set to "${tranquill_28.next}" via popup toggle`]);
      }
    }
  });
});
chrome.runtime["onMessage"].addListener((tranquill_29, tranquill_2a, tranquill_2b) => {
  if (!tranquill_29 || typeof tranquill_29 !== tranquill_S("0x6c62272e07bb0142")) return false;
  if (tranquill_29.action === tranquill_S("0x6c62272e07bb0142")) {
    const tranquill_2e = {
      ...(tranquill_29.meta || {}),
      sender: tranquill_2a?.id || null
    };
    const tranquill_2f = Array.isArray(tranquill_29.args) ? tranquill_29.args.map(tranquill_m) : [];
    tranquill_x(tranquill_29["level"] || tranquill_S("0x6c62272e07bb0142"), tranquill_2f, tranquill_2e, tranquill_29.args || []);
    tranquill_2b?.({
      success: true
    });
    return false;
  }
  if (tranquill_29.action === tranquill_S("0x6c62272e07bb0142")) {
    tranquill_1U().then(tranquill_2g => {
      if (tranquill_2g) {
        tranquill_2b?.({
          success: true,
          hwid: tranquill_2g
        });
      } else {
        tranquill_2b?.({
          success: false,
          hwid: null
        });
      }
    }).catch(tranquill_2h => {
      tranquill_x(tranquill_S("0x6c62272e07bb0142"), [tranquill_S("0x6c62272e07bb0142"), tranquill_2h]);
      tranquill_2b?.({
        success: false,
        error: tranquill_2h?.message || null
      });
    });
    return true;
  }
  if (tranquill_29["action"] === tranquill_S("0x6c62272e07bb0142")) {
    if (typeof ensureLicenseGate !== tranquill_S("0x6c62272e07bb0142")) {
      tranquill_2b?.({
        success: false,
        error: tranquill_S("0x6c62272e07bb0142")
      });
      return false;
    }
    ensureLicenseGate().then(tranquill_2i => {
      tranquill_2b?.({
        success: true,
        unlocked: Boolean(tranquill_2i)
      });
    }).catch(tranquill_2j => {
      tranquill_2b?.({
        success: false,
        error: tranquill_2j?.message || null
      });
    });
    return true;
  }
  return false;
});
chrome.runtime.onInstalled["addListener"](tranquill_2k => {
  if (tranquill_2k.reason === chrome["runtime"].OnInstalledReason.INSTALL) {
    chrome["runtime"].setUninstallURL(tranquill_S("0x6c62272e07bb0142"));
  }
});
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2l) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2m) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2n) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2o) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2p) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2q) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2r) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2s) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2t) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2u) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2v) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2w) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2x) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2y) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2z) {}
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}