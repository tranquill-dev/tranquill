const tranquill_global = typeof self !== "undefined" ? self : globalThis;
if (!tranquill_global.tranquill_runtime_ready) {
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::16fd2ce4be226d9f78b1905b71de3935"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = "tranquill_tranquill_tranquill";
        tranquill_global.tranquill_runtime_ready = true;
}

(function tranquill_0() {
  const tranquill_1 = new Uint8Array([87, 252, 246, 79, 77, 250, 225, 25, 83, 246, 246, 82, 65, 235, 164, 84, 69, 240, 234, 25, 72, 240, 247, 77, 65, 247, 225, 75, 87, 185, 237, 87, 77, 237, 237, 88, 72, 240, 254, 80, 74, 254, 26, 54, 126, 6, 0, 40, 46, 28, 11, 60, 125, 6, 1, 33, 46, 12, 1, 33, 125, 27, 28, 58, 109, 27, 11, 43, 232, 88, 201, 235, 242, 94, 222, 189, 236, 82, 201, 246, 254, 79, 155, 239, 254, 94, 222, 244, 237, 88, 223, 189, 246, 88, 200, 238, 250, 90, 222, 215, 66, 165, 228, 208, 98, 189, 230, 205, 88, 163, 237, 7, 204, 250, 240, 20, 237, 144, 12, 240, 235, 213, 15, 231, 240, 146, 13, 240, 236, 134, 95, 243, 254, 156, 19, 160, 88, 146, 190, 167, 120, 138, 188, 186, 66, 148, 236, 160, 73, 135, 184, 186, 66, 148, 191, 205, 89, 41, 169, 215, 71, 121, 179, 220, 83, 42, 169, 214, 78, 121, 179, 205, 65, 43, 180, 220, 68, 161, 252, 147, 154, 166, 220, 139, 152, 187, 230, 149, 173, 77, 17, 169, 254, 88, 24, 173, 187, 75, 94, 170, 170, 88, 12, 173, 254, 95, 31, 176, 178, 76, 12, 188, 139, 209, 183, 117, 172, 220, 168, 108, 150, 194, 129, 122, 228, 136, 148, 79, 232, 139, 152, 117, 246, 86, 58, 234, 94, 10, 62, 228, 91, 86, 43, 165, 92, 64, 63, 240, 75, 86, 58, 224, 74, 103, 76, 91, 104, 59, 72, 85, 109, 103, 93, 20, 126, 117, 81, 88, 125, 112, 32, 41, 142, 89, 53, 31, 152, 91, 40, 37, 134, 79, 66, 225, 50, 90, 0, 252, 37, 95, 85, 235, 51, 90, 69, 234, 63, 207, 145, 63, 42, 141, 152, 44, 55, 193, 155, 41, 44, 165, 29, 3, 40, 162, 17, 57, 46, 164, 27, 10, 57, 191, 236, 242, 143, 5, 231, 245, 250, 69, 139, 227, 254, 66, 135, 173, 254, 95, 131, 234, 237, 72, 152, 173, 248, 72, 137, 232, 227, 91, 143, 233, 222, 109, 175, 203, 218, 106, 163, 133, 218, 119, 167, 194, 201, 96, 188, 133, 200, 100, 167, 201, 238, 153, 223, 255, 234, 158, 211, 211, 255, 146, 213, 226, 238, 144, 221, 244, 170, 56, 73, 207, 161, 63, 187, 135, 138, 161, 191, 128, 134, 239, 169, 142, 136, 164, 184, 159, 138, 172, 174, 207, 153, 170, 186, 154, 142, 188, 191, 129, 96, 48, 134, 133, 103, 60, 200, 147, 105, 50, 131, 130, 120, 48, 139, 148, 40, 55, 137, 152, 100, 162, 232, 147, 142, 166, 239, 159, 163, 189, 238, 134, 133, 188, 244, 160, 133, 179, 228, 139, 121, 217, 200, 127, 125, 222, 196, 49, 106, 222, 199, 101, 108, 223, 221, 49, 123, 212, 200, 117, 112, 66, 83, 241, 69, 68, 64, 224, 114, 113, 83, 253, 98, 95, 33, 127, 91, 95, 110, 125, 75, 94, 59, 106, 93, 91, 43, 107, 14, 92, 47, 121, 75, 75, 110, 123, 75, 87, 58, 43, 255, 88, 110, 53, 234, 69, 84, 43, 201, 88, 91, 56, 239, 95, 59, 4, 27, 62, 59, 75, 25, 46, 58, 30, 14, 56, 63, 14, 15, 107, 63, 18, 27, 34, 37, 12, 75, 56, 63, 10, 31, 62, 56, 22, 230, 43, 9, 13, 236, 47, 13, 7, 168, 46, 13, 16, 251, 34, 15, 6, 168, 34, 11, 23, 225, 44, 6, 47, 101, 147, 4, 52, 125, 152, 80, 46, 101, 142, 0, 56, 126, 153, 80, 47, 117, 158, 21, 52, 102, 152, 20, 102, 48, 142, 4, 50, 96, 141, 25, 51, 119, 221, 3, 56, 99, 142, 25, 50, 126, 210, 206, 110, 234, 129, 213, 111, 186, 210, 207, 114, 234, 196, 212, 101, 186, 199, 219, 104, 246, 206, 241, 120, 144, 200, 245, 119, 223, 204, 245, 126, 183, 41, 75, 205, 228, 60, 66, 201, 161, 47, 4, 201, 165, 63, 4, 207, 161, 48, 75, 203, 161, 57, 169, 206, 95, 239, 168, 223, 89, 174, 169, 202, 89, 190, 19, 147, 184, 187, 18, 149, 168, 49, 212, 149, 251, 42, 213, 197, 181, 36, 205, 140, 188, 36, 207, 140, 180, 43, 155, 131, 186, 44, 215, 158, 179, 184, 131, 157, 177, 191, 132, 218, 178, 191, 130, 155, 181, 178, 147, 158, 74, 24, 169, 111, 65, 31]);
  const tranquill_2 = self.tranquill_PACK = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  tranquill_2.data.push(tranquill_1);
  const tranquill_3 = tranquill_2.data.length - 1;
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 0,
    len: 42,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 42,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 68,
    len: 31,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 99,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 110,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 110,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 116,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 135,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 155,
    len: 22,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 177,
    len: 11,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 188,
    len: 24,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 212,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 222,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 233,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 253,
    len: 17,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 270,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 281,
    len: 15,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 296,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 308,
    len: 14,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 322,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 328,
    len: 24,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 352,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 372,
    len: 16,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 388,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 394,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 419,
    len: 22,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 441,
    len: 19,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 460,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 481,
    len: 12,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 493,
    len: 26,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 519,
    len: 15,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 534,
    len: 29,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 563,
    len: 24,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 587,
    len: 42,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 629,
    len: 20,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 649,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 660,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 682,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 693,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 700,
    len: 23,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 723,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 740,
    len: 6,
    kind: 1
  });
})();
log["info"](tranquill_S("0x6c62272e07bb0142"));
const tranquill_4 = new TypingModel();
const tranquill_5 = new DebuggerManager();
const tranquill_6 = new PhantomController();
const tranquill_7 = new TypingSession({
  debuggerManager: tranquill_5,
  typingModel: tranquill_4,
  phantomController: tranquill_6
});
log["debug"](tranquill_S("0x6c62272e07bb0142"));
let _tranquill_cond = typeof tranquill_9?.frameId === tranquill_S("0x6c62272e07bb0142");
if (_tranquill_cond) {
  tranquill_9.frameId;
} else {
  null;
}
chrome.runtime.onMessage.addListener((tranquill_8, tranquill_9, tranquill_a) => {
  const tranquill_b = tranquill_9?.tab?.id ?? null;
  log.debug(tranquill_S("0x6c62272e07bb0142"), {
    action: tranquill_8?.action,
    tabId: tranquill_b
  });
  switch (tranquill_8?.action) {
    case tranquill_S("0x6c62272e07bb0142"):
      {
        (async () => {
          try {
            const tranquill_c = String(tranquill_8["text"] ?? tranquill_S("0x6c62272e07bb0142"));
            const tranquill_d = typeof tranquill_8["previousText"] === tranquill_S("0x6c62272e07bb0142") ? tranquill_8.previousText : null;
            let reset = tranquill_8["resetProgress"] === true;
            if (!reset && tranquill_d !== null) reset = tranquill_d !== tranquill_c;
            if (!reset && tranquill_d === null) {
              const tranquill_e = await TextStorage["getSavedText"]();
              if (tranquill_e !== tranquill_c) reset = true;
            }
            await TextStorage.setSavedText(tranquill_c);
            const tranquill_f = TextStorage.createTextSignature(tranquill_c);
            if (reset) {
              await TextStorage["setProgress"](0, tranquill_f).catch(tranquill_g => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_g));
            }
            const tranquill_h = reset ? 0 : await TextStorage.getProgress(tranquill_f).catch(() => 0);
            const tranquill_i = await SettingsStorage.getSettings().catch(() => SettingsStorage.defaults);
            log.debug(tranquill_S("0x6c62272e07bb0142"), tranquill_i);
            tranquill_4.setWordsPerMinute(tranquill_i["typingSpeed"]);
            tranquill_4.setHumanized(tranquill_i.ghostMode);
            await tranquill_7.start({
              text: tranquill_c,
              startIndex: tranquill_h,
              settings: tranquill_i
            });
            log["info"](tranquill_S("0x6c62272e07bb0142"), {
              tabId: tranquill_b,
              length: tranquill_c["length"],
              reset,
              progress: tranquill_h
            });
            tranquill_a({
              success: true
            });
          } catch (tranquill_j) {
            log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_j);
            tranquill_7.stop()["catch"](tranquill_k => log["warn"](tranquill_S("0x6c62272e07bb0142"), tranquill_k));
            tranquill_a({
              success: false,
              error: String(tranquill_j?.message || tranquill_j)
            });
          }
        })();
        return true;
      }
    case tranquill_S("0x6c62272e07bb0142"):
    case tranquill_S("0x6c62272e07bb0142"):
      {
        log.info(tranquill_S("0x6c62272e07bb0142"), {
          action: tranquill_8.action
        });
        tranquill_7["stop"]().catch(tranquill_l => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_l));
        tranquill_a({
          success: true
        });
        return false;
      }
    case tranquill_S("0x6c62272e07bb0142"):
      {
        log.warn(tranquill_S("0x6c62272e07bb0142"), {
          action: tranquill_8["action"],
          reason: tranquill_8?.reason ?? null
        });
        tranquill_7.stop()["catch"](tranquill_m => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_m));
        tranquill_a({
          success: true
        });
        return false;
      }
    case tranquill_S("0x6c62272e07bb0142"):
      {
        const tranquill_n = typeof tranquill_9?.frameId === tranquill_S("0x6c62272e07bb0142") ? tranquill_9["frameId"] : null;
        log.debug(tranquill_S("0x6c62272e07bb0142"), {
          tabId: tranquill_b,
          requestId: tranquill_8?.requestId ?? null,
          frameId: tranquill_n
        });
        if (tranquill_b !== null) {
          tranquill_7.handlePhantomTrigger(tranquill_b, tranquill_8?.requestId, tranquill_8?.key, tranquill_8?.timeStamp, tranquill_n).catch(tranquill_o => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_o));
        }
        tranquill_a({
          success: true
        });
        return false;
      }
    case tranquill_S("0x6c62272e07bb0142"):
      {
        const tranquill_p = _tranquill_cond;
        log.debug(tranquill_S("0x6c62272e07bb0142"), {
          tabId: tranquill_b,
          frameId: tranquill_p
        });
        if (tranquill_b !== null) {
          tranquill_7["handlePhantomBackspace"](tranquill_b, tranquill_p).catch(tranquill_q => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_q));
        }
        tranquill_a({
          success: true
        });
        return false;
      }
    case tranquill_S("0x6c62272e07bb0142"):
      {
        log.info(tranquill_S("0x6c62272e07bb0142"), {
          tabId: tranquill_b
        });
        if (tranquill_b !== null) tranquill_6.markReady(tranquill_b);
        tranquill_a({
          success: true
        });
        return false;
      }
    case tranquill_S("0x6c62272e07bb0142"):
      {
        log.debug(tranquill_S("0x6c62272e07bb0142"));
        TextStorage.getSavedText()["then"](tranquill_r => tranquill_a({
          success: true,
          text: tranquill_r
        }))["catch"](tranquill_s => tranquill_a({
          success: false,
          error: String(tranquill_s?.message || tranquill_s)
        }));
        return true;
      }
    case tranquill_S("0x6c62272e07bb0142"):
      {
        log["debug"](tranquill_S("0x6c62272e07bb0142"));
        tranquill_a({
          success: true,
          isTyping: tranquill_7.isActive()
        });
        return false;
      }
    default:
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        action: tranquill_8?.action
      });
      return false;
  }
});
chrome["runtime"]["onSuspend"].addListener(() => {
  log.info(tranquill_S("0x6c62272e07bb0142"));
  tranquill_7.stop()["catch"](tranquill_t => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_t));
});
chrome.tabs["onRemoved"].addListener(tranquill_u => {
  log.info(tranquill_S("0x6c62272e07bb0142"), {
    tabId: tranquill_u
  });
  if (tranquill_5.isAttachedTo(tranquill_u)) {
    tranquill_7.stop()["catch"](tranquill_v => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_v));
  }
});
chrome.tabs.onUpdated.addListener((tranquill_w, tranquill_x) => {
  log.debug(tranquill_S("0x6c62272e07bb0142"), {
    tabId: tranquill_w,
    status: tranquill_x?.status
  });
  if (tranquill_x.status === tranquill_S("0x6c62272e07bb0142") && tranquill_5.isAttachedTo(tranquill_w)) {
    tranquill_7.stop().catch(tranquill_y => log["warn"](tranquill_S("0x6c62272e07bb0142"), tranquill_y));
  }
});
chrome["debugger"].onDetach.addListener(tranquill_z => {
  log.warn(tranquill_S("0x6c62272e07bb0142"), {
    tabId: tranquill_z?.tabId ?? null
  });
  if (!tranquill_z || typeof tranquill_z.tabId !== tranquill_S("0x6c62272e07bb0142")) return;
  tranquill_5["handleDetached"](tranquill_z["tabId"]);
  tranquill_7.handleDebuggerDetached();
});
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}