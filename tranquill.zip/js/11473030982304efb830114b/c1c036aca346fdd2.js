const tranquill_global = typeof self !== "undefined" ? self : globalThis;
if (!tranquill_global.tranquill_runtime_ready) {
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::16fd2ce4be226d9f78b1905b71de3935"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = "tranquill_tranquill_tranquill";
        tranquill_global.tranquill_runtime_ready = true;
}

(function tranquill_0() {
  const tranquill_1 = new Uint8Array([51, 189, 210, 64, 46, 174, 11, 22, 143, 58, 42, 26, 150, 61, 9, 31, 152, 61, 55, 22, 139, 115, 58, 28, 151, 32, 45, 1, 140, 48, 45, 22, 157, 114, 186, 206, 105, 78, 182, 182, 101, 122, 178, 194, 97, 118, 174, 202, 125, 98, 170, 218, 121, 126, 166, 198, 117, 104, 94, 84, 73, 104, 101, 99, 220, 176, 17, 103, 166, 195, 50, 38, 54, 10, 19, 42, 47, 13, 48, 47, 33, 13, 14, 38, 50, 67, 3, 49, 37, 2, 20, 38, 36, 67, 18, 38, 54, 10, 19, 42, 47, 13, 235, 246, 111, 218, 202, 250, 118, 221, 233, 255, 120, 221, 215, 246, 107, 157, 219, 230, 112, 223, 221, 179, 106, 199, 216, 225, 109, 133, 223, 129, 179, 164, 211, 152, 180, 135, 214, 150, 180, 185, 223, 133, 244, 181, 207, 158, 182, 179, 154, 148, 181, 186, 202, 155, 191, 163, 223]);
  const tranquill_2 = self.tranquill_PACK = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  tranquill_2["data"].push(tranquill_1);
  const tranquill_3 = tranquill_2.data.length - 1;
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 0,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 6,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 6,
    len: 27,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 33,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 37,
    len: 0,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 37,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 41,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 45,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 49,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 53,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 57,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 63,
    len: 0,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 63,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 70,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 102,
    len: 27,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 129,
    len: 30,
    kind: 1
  });
})();
class tranquill_4 {
  constructor(tranquill_5, tranquill_6, tranquill_7 = 0) {
    this.text = typeof tranquill_5 === tranquill_S("0x6c62272e07bb0142") ? tranquill_5 : tranquill_S("0x6c62272e07bb0142");
    this.typingModel = tranquill_6;
    this.startIndex = Math.max(0, Math.min(tranquill_7, this.text.length));
    this.config = Object.freeze({
      minTriggerDistance: 55,
      maxTriggerDistance: 165,
      minSegmentLength: 4,
      maxSegmentLength: 22,
      maxLookback: 48,
      minMeaningfulCharacters: 3
    });
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      length: this["text"].length,
      startIndex: this.startIndex
    });
  }
  #rand(tranquill_9, tranquill_a) {
    const tranquill_b = Math.ceil(tranquill_9),
      tranquill_c = Math.floor(tranquill_a);
    if (tranquill_c <= tranquill_b) return tranquill_b;
    return Math.floor(Math.random() * (tranquill_c - tranquill_b + 1)) + tranquill_b;
  }
  #isBoundary(tranquill_d) {
    if (tranquill_d <= this.startIndex || tranquill_d > this.text.length) return false;
    const tranquill_e = this["text"][tranquill_d - 1];
    if (!tranquill_e || tranquill_S("0x6c62272e07bb0142").test(tranquill_e)) return false;
    const tranquill_g = this.text[tranquill_d] || tranquill_S("0x6c62272e07bb0142");
    if (tranquill_S("0x6c62272e07bb0142").test(tranquill_e) && tranquill_S("0x6c62272e07bb0142").test(tranquill_g)) return false;
    return true;
  }
  #adjustStart(tranquill_h, tranquill_i) {
    let s = Math.max(this["startIndex"], tranquill_h);
    const tranquill_j = Math.max(this.startIndex, tranquill_i - this["config"]["maxLookback"]);
    if (s < tranquill_j) s = tranquill_j;
    while (s < tranquill_i && tranquill_S("0x6c62272e07bb0142").test(this.text[s]) && s - this.startIndex > 0) s += 1;
    while (s < tranquill_i && s > this.startIndex && tranquill_S("0x6c62272e07bb0142").test(this.text[s]) && tranquill_S("0x6c62272e07bb0142").test(this.text[s - 1])) s += 1;
    return s;
  }
  #create(tranquill_k) {
    const tranquill_l = this.#rand(this["config"].minSegmentLength, this.config["maxSegmentLength"]);
    let start = Math["max"](this.startIndex, tranquill_k - tranquill_l);
    start = this.#adjustStart(start, tranquill_k);
    if (start >= tranquill_k) return null;
    const tranquill_m = this.text.slice(start, tranquill_k);
    if (tranquill_m.length < this["config"]["minSegmentLength"]) return null;
    if (tranquill_m.replace(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")).length < this.config["minMeaningfulCharacters"]) return null;
    if (tranquill_S("0x6c62272e07bb0142").test(tranquill_m)) return null;
    const tranquill_n = start > 0 ? this.text[start - 1] : null;
    const tranquill_o = this.typingModel.baseDelay();
    const tranquill_p = this.typingModel.getMinimumDelay();
    const tranquill_q = Math.max(tranquill_p * 3, tranquill_o * 2.4 + Math.random() * 220);
    const tranquill_r = Math.max(tranquill_p * 2, tranquill_o * 1.6 + Math.random() * 160);
    const tranquill_s = Array.from(tranquill_m, () => Math.max(tranquill_p, tranquill_o * 0.6 + Math.random() * 45));
    const tranquill_t = [];
    let prior = tranquill_n;
    for (const tranquill_u of tranquill_m) {
      tranquill_t.push(Math.max(tranquill_p, this["typingModel"].getDelay ? this["typingModel"].getDelay(tranquill_u, prior) : this["typingModel"]["baseDelay"]()));
      prior = tranquill_u;
    }
    const tranquill_v = {
      triggerIndex: tranquill_k,
      segmentText: tranquill_m,
      previousCharacter: tranquill_n,
      pauseBefore: Math.round(tranquill_q),
      pauseAfter: Math.round(tranquill_r),
      backspaceDelays: tranquill_s["map"](Math.round),
      retypeDelays: tranquill_t.map(Math["round"])
    };
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      triggerIndex: tranquill_k,
      length: tranquill_m.length
    });
    return tranquill_v;
  }
  build() {
    const tranquill_w = [];
    if (!this["text"] || this.startIndex >= this.text.length) return tranquill_w;
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      textLength: this["text"]["length"],
      startIndex: this["startIndex"]
    });
    let ptr = this["startIndex"],
      dist = 0;
    let nextTrig = this.#rand(this.config.minTriggerDistance, this["config"].maxTriggerDistance);
    while (ptr < this["text"].length) {
      ptr += 1;
      dist += 1;
      if (dist < nextTrig) continue;
      if (!this.#isBoundary(ptr)) continue;
      const tranquill_x = this.#create(ptr);
      if (tranquill_x) {
        tranquill_w["push"](tranquill_x);
        dist = 0;
        nextTrig = this.#rand(this.config.minTriggerDistance, this["config"].maxTriggerDistance);
      }
    }
    log["debug"](tranquill_S("0x6c62272e07bb0142"), {
      count: tranquill_w.length
    });
    return tranquill_w;
  }
}
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}