const tranquill_global = typeof self !== "undefined" ? self : globalThis;
if (!tranquill_global.tranquill_runtime_ready) {
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::16fd2ce4be226d9f78b1905b71de3935"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = "tranquill_tranquill_tranquill";
        tranquill_global.tranquill_runtime_ready = true;
}

(function tranquill_0() {
  const tranquill_1 = new Uint8Array([10, 231, 104, 40, 195, 78, 51, 43, 193, 73, 52, 108, 207, 95, 7, 56, 210, 77, 37, 36, 195, 72, 39, 62, 1, 78, 36, 60, 6, 73, 99, 50, 16, 122, 55, 47, 2, 88, 43, 62, 7, 111, 44, 20, 235, 114, 27, 23, 233, 117, 28, 80, 233, 117, 26, 49, 237, 100, 7, 6, 235, 68, 15, 18, 199, 116, 78, 25, 224, 102, 1, 27, 235, 116, 196, 192, 202, 238, 233, 219, 131, 249, 239, 143, 158, 238, 232, 143, 142, 234, 254, 202, 137, 251, 239, 203, 203, 108, 237, 220, 200, 110, 234, 219, 143, 108, 225, 218, 218, 123, 234, 232, 219, 125, 238, 202, 199, 108, 235, 250, 87, 92, 231, 249, 85, 91, 224, 190, 83, 74, 230, 255, 81, 86, 247, 250, 165, 8, 3, 184, 166, 10, 4, 191, 225, 9, 4, 185, 160, 14, 9, 168, 165, 211, 199, 181, 183, 208, 197, 178, 176, 151, 198, 178, 182, 214, 193, 191, 226, 209, 195, 190, 174, 210, 198, 136, 119, 238, 135, 139, 117, 233, 128, 204, 122, 237, 156, 136, 126, 233, 182, 137, 102, 237, 145, 132, 119, 232, 126, 86, 24, 102, 125, 84, 31, 97, 58, 85, 21, 112, 111, 64, 63, 119, 115, 71, 27, 113, 118, 86, 59, 97, 127, 82, 107, 81, 10, 249, 126, 71, 3, 162, 73, 89, 3, 249, 99, 89, 3, 186, 44, 23, 80, 173, 99, 26, 79, 176, 32, 18, 101, 182, 32, 12, 80, 249, 126, 89, 11, 188, 47, 85, 3, 175, 42, 28, 84, 240, 99, 68, 29, 249, 56, 115, 3, 249, 99, 89, 3, 249, 99, 89, 74, 191, 99, 81, 2, 188, 47, 80, 3, 171, 38, 13, 86, 171, 45, 89, 69, 184, 47, 10, 70, 226, 73, 89, 3, 249, 99, 89, 3, 249, 99, 26, 76, 183, 48, 13, 3, 171, 99, 68, 3, 188, 47, 87, 68, 188, 55, 59, 76, 172, 45, 29, 74, 183, 36, 58, 79, 176, 38, 23, 87, 139, 38, 26, 87, 241, 106, 66, 41, 249, 99, 89, 3, 249, 99, 89, 3, 186, 44, 23, 80, 173, 99, 1, 3, 228, 99, 52, 66, 173, 43, 87, 81, 182, 54, 23, 71, 241, 49, 87, 79, 188, 37, 13, 3, 242, 99, 11, 13, 174, 42, 29, 87, 177, 108, 75, 10, 226, 73, 89, 3, 249, 99, 89, 3, 249, 99, 26, 76, 183, 48, 13, 3, 160, 99, 68, 3, 148, 34, 13, 75, 247, 49, 22, 86, 183, 39, 81, 81, 247, 55, 22, 83, 249, 104, 89, 110, 184, 55, 17, 13, 180, 42, 23, 11, 171, 109, 17, 70, 176, 36, 17, 87, 246, 113, 85, 3, 235, 115, 80, 10, 226, 73, 89, 3, 249, 99, 89, 3, 249, 99, 26, 76, 183, 48, 13, 3, 176, 45, 16, 87, 249, 126, 89, 88, 249, 33, 12, 65, 187, 47, 28, 80, 227, 55, 11, 86, 188, 111, 89, 64, 184, 45, 26, 70, 181, 34, 27, 79, 188, 121, 13, 81, 172, 38, 85, 3, 186, 47, 16, 70, 183, 55, 33, 25, 161, 111, 89, 64, 181, 42, 28, 77, 173, 26, 67, 90, 245, 99, 27, 86, 173, 55, 22, 77, 227, 115, 85, 3, 187, 54, 13, 87, 182, 45, 10, 25, 232, 99, 4, 24, 211, 99, 89, 3, 249, 99, 89, 3, 249, 37, 22, 81, 249, 107, 26, 76, 183, 48, 13, 3, 173, 99, 22, 69, 249, 24, 91, 78, 182, 54, 10, 70, 189, 44, 14, 77, 251, 111, 91, 78, 182, 54, 10, 70, 172, 51, 91, 15, 251, 32, 21, 74, 186, 40, 91, 126, 240, 99, 28, 79, 247, 39, 16, 80, 169, 34, 13, 64, 177, 6, 15, 70, 183, 55, 81, 77, 188, 52, 89, 110, 182, 54, 10, 70, 156, 53, 28, 77, 173, 107, 13, 15, 249, 42, 23, 74, 173, 106, 80, 24, 211, 99, 89, 3, 249, 99, 89, 3, 249, 55, 11, 90, 249, 56, 89, 70, 181, 109, 31, 76, 186, 54, 10, 11, 162, 99, 9, 81, 188, 53, 28, 77, 173, 16, 26, 81, 182, 47, 21, 25, 249, 55, 11, 86, 188, 99, 4, 10, 226, 99, 4, 3, 186, 34, 13, 64, 177, 99, 2, 3, 188, 47, 87, 69, 182, 32, 12, 80, 241, 106, 66, 3, 164, 73, 89, 3, 249, 99, 89, 3, 249, 99, 16, 69, 249, 107, 15, 74, 188, 52, 70, 13, 191, 44, 26, 86, 170, 106, 89, 85, 176, 38, 14, 13, 191, 44, 26, 86, 170, 107, 80, 24, 211, 99, 89, 3, 249, 99, 89, 3, 249, 49, 28, 87, 172, 49, 23, 3, 173, 49, 12, 70, 226, 73, 89, 3, 249, 99, 89, 3, 164, 120, 115, 41, 249, 99, 89, 3, 249, 99, 26, 76, 183, 48, 13, 3, 170, 38, 21, 119, 182, 6, 23, 71, 249, 126, 89, 11, 189, 44, 26, 15, 249, 38, 21, 10, 249, 126, 71, 3, 162, 73, 89, 3, 249, 99, 89, 3, 249, 99, 26, 76, 183, 48, 13, 3, 170, 99, 68, 3, 189, 44, 26, 13, 190, 38, 13, 112, 188, 47, 28, 64, 173, 42, 22, 77, 230, 109, 81, 10, 226, 99, 16, 69, 249, 107, 88, 80, 249, 63, 5, 3, 248, 38, 21, 10, 249, 49, 28, 87, 172, 49, 23, 24, 211, 99, 89, 3, 249, 99, 89, 3, 249, 32, 22, 77, 170, 55, 89, 81, 184, 45, 30, 70, 249, 126, 89, 71, 182, 32, 87, 64, 171, 38, 24, 87, 188, 17, 24, 77, 190, 38, 81, 10, 226, 73, 89, 3, 249, 99, 89, 3, 249, 99, 11, 66, 183, 36, 28, 13, 170, 38, 21, 70, 186, 55, 55, 76, 189, 38, 58, 76, 183, 55, 28, 77, 173, 48, 81, 70, 181, 106, 66, 3, 171, 34, 23, 68, 188, 109, 26, 76, 181, 47, 24, 83, 170, 38, 81, 69, 184, 47, 10, 70, 240, 120, 115, 3, 249, 99, 89, 3, 249, 99, 89, 80, 247, 49, 28, 78, 182, 53, 28, 98, 181, 47, 43, 66, 183, 36, 28, 80, 241, 106, 66, 3, 170, 109, 24, 71, 189, 17, 24, 77, 190, 38, 81, 81, 184, 45, 30, 70, 240, 120, 115, 3, 249, 99, 89, 3, 249, 62, 66, 41, 211, 99, 89, 3, 249, 99, 89, 87, 171, 58, 89, 88, 211, 99, 89, 3, 249, 99, 89, 3, 249, 108, 86, 3, 158, 44, 22, 68, 181, 38, 89, 103, 182, 32, 10, 3, 176, 37, 11, 66, 180, 38, 115, 3, 249, 99, 89, 3, 249, 99, 89, 64, 182, 45, 10, 87, 249, 42, 31, 81, 184, 46, 28, 3, 228, 99, 29, 76, 186, 54, 20, 70, 183, 55, 87, 82, 172, 38, 11, 90, 138, 38, 21, 70, 186, 55, 22, 81, 241, 100, 16, 69, 171, 34, 20, 70, 247, 39, 22, 64, 170, 110, 13, 70, 161, 55, 28, 85, 188, 45, 13, 87, 184, 49, 30, 70, 173, 110, 16, 69, 171, 34, 20, 70, 245, 99, 16, 69, 171, 34, 20, 70, 247, 39, 22, 64, 170, 110, 13, 70, 161, 55, 28, 85, 188, 45, 13, 87, 184, 49, 30, 70, 173, 100, 80, 24, 211, 99, 89, 3, 249, 99, 89, 3, 249, 42, 31, 3, 241, 42, 31, 81, 184, 46, 28, 28, 247, 32, 22, 77, 173, 38, 23, 87, 142, 42, 23, 71, 182, 52, 70, 13, 189, 44, 26, 86, 180, 38, 23, 87, 240, 99, 2, 41, 249, 99, 89, 3, 249, 99, 89, 3, 249, 99, 26, 76, 183, 48, 13, 3, 174, 42, 23, 3, 228, 99, 16, 69, 171, 34, 20, 70, 247, 32, 22, 77, 173, 38, 23, 87, 142, 42, 23, 71, 182, 52, 85, 3, 189, 44, 26, 3, 228, 99, 14, 74, 183, 109, 29, 76, 186, 54, 20, 70, 183, 55, 66, 41, 249, 99, 89, 3, 249, 99, 89, 3, 249, 99, 26, 76, 183, 48, 13, 3, 173, 34, 11, 68, 188, 55, 89, 30, 249, 39, 22, 64, 247, 50, 12, 70, 171, 58, 42, 70, 181, 38, 26, 87, 182, 49, 81, 4, 130, 32, 22, 77, 173, 38, 23, 87, 188, 39, 16, 87, 184, 33, 21, 70, 228, 97, 13, 81, 172, 38, 91, 126, 254, 106, 89, 95, 165, 99, 29, 76, 186, 109, 27, 76, 189, 58, 66, 41, 249, 99, 89, 3, 249, 99, 89, 3, 249, 99, 16, 69, 249, 107, 26, 79, 176, 32, 18, 101, 182, 32, 12, 80, 241, 55, 24, 81, 190, 38, 13, 15, 249, 52, 16, 77, 240, 106, 89, 88, 249, 48, 28, 79, 141, 44, 60, 77, 189, 107, 29, 76, 186, 111, 89, 87, 184, 49, 30, 70, 173, 106, 66, 3, 171, 38, 13, 86, 171, 45, 89, 88, 249, 48, 12, 64, 186, 38, 10, 80, 227, 55, 11, 86, 188, 111, 89, 64, 173, 59, 67, 1, 189, 44, 26, 80, 244, 42, 31, 81, 184, 46, 28, 1, 249, 62, 66, 3, 164, 73, 89, 3, 249, 99, 89, 3, 249, 99, 4, 41, 249, 99, 89, 3, 249, 99, 89, 3, 246, 108, 89, 100, 188, 45, 28, 81, 176, 32, 115, 3, 249, 99, 89, 3, 249, 99, 89, 64, 182, 45, 10, 87, 249, 38, 29, 3, 228, 99, 29, 76, 186, 54, 20, 70, 183, 55, 87, 82, 172, 38, 11, 90, 138, 38, 21, 70, 186, 55, 22, 81, 241, 100, 34, 64, 182, 45, 13, 70, 183, 55, 28, 71, 176, 55, 24, 65, 181, 38, 68, 1, 173, 49, 12, 70, 251, 30, 85, 3, 189, 42, 15, 120, 171, 44, 21, 70, 228, 97, 13, 70, 161, 55, 27, 76, 161, 97, 36, 15, 249, 55, 28, 91, 173, 34, 11, 70, 184, 111, 89, 74, 183, 51, 12, 87, 130, 55, 0, 83, 188, 126, 91, 87, 188, 59, 13, 1, 132, 100, 80, 24, 211, 99, 89, 3, 249, 99, 89, 3, 249, 42, 31, 3, 241, 32, 21, 74, 186, 40, 63, 76, 186, 54, 10, 11, 188, 39, 85, 3, 174, 42, 23, 71, 182, 52, 80, 10, 249, 49, 28, 87, 172, 49, 23, 3, 162, 99, 10, 86, 186, 32, 28, 80, 170, 121, 13, 81, 172, 38, 85, 3, 186, 55, 1, 25, 251, 38, 29, 74, 173, 34, 27, 79, 188, 97, 89, 94, 226, 73, 89, 3, 249, 99, 89, 3, 249, 99, 11, 70, 173, 54, 11, 77, 249, 56, 89, 80, 172, 32, 26, 70, 170, 48, 67, 69, 184, 47, 10, 70, 249, 62, 66, 41, 249, 99, 89, 3, 249, 99, 4, 3, 186, 34, 13, 64, 177, 99, 81, 70, 240, 99, 2, 3, 171, 38, 13, 86, 171, 45, 89, 88, 249, 48, 12, 64, 186, 38, 10, 80, 227, 37, 24, 79, 170, 38, 85, 3, 188, 49, 11, 76, 171, 121, 89, 70, 230, 109, 20, 70, 170, 48, 24, 68, 188, 99, 4, 24, 249, 62, 115, 3, 249, 99, 89, 94, 240, 107, 80, 24, 209, 5, 205, 228, 234, 29, 198, 190, 230, 6, 194, 252, 246, 17, 215, 245, 44, 14, 120, 226, 21, 5, 57, 244, 22, 64, 127, 239, 26, 21, 106, 160, 28, 4, 112, 244, 22, 18, 15, 223, 41, 47, 12, 221, 46, 40, 75, 220, 36, 57, 30, 201, 14, 62, 2, 206, 42, 56, 7, 223, 10, 40, 14, 219, 107, 41, 30, 217, 40, 63, 24, 201, 165, 125, 3, 205, 166, 127, 4, 202, 225, 108, 24, 200, 164, 91, 9, 217, 179, 121, 2, 204, 164, 106, 174, 252, 183, 135, 147, 188, 163, 155, 148, 226, 166, 134, 132, 250, 140, 151, 158, 215, 177, 151, 137, 230]);
  const tranquill_2 = self.tranquill_PACK = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  tranquill_2.data.push(tranquill_1);
  const tranquill_3 = tranquill_2.data.length - 1;
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 0,
    len: 3,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 3,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 22,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 43,
    len: 31,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 74,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 96,
    len: 23,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 119,
    len: 17,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 136,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 153,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 175,
    len: 23,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 198,
    len: 26,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 224,
    len: 1643,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1867,
    len: 16,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1883,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1905,
    len: 34,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1939,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1961,
    len: 22,
    kind: 1
  });
})();
class tranquill_4 {
  constructor() {
    this.attachedTabId = null;
    this.protocolVersion = tranquill_S("0x6c62272e07bb0142");
  }
  isAttached() {
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      attachedTabId: this["attachedTabId"]
    });
    return this.attachedTabId !== null;
  }
  isAttachedTo(tranquill_5) {
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      tabId: tranquill_5,
      attachedTabId: this.attachedTabId
    });
    return this.attachedTabId === tranquill_5;
  }
  async getActiveTabId() {
    log.debug(tranquill_S("0x6c62272e07bb0142"));
    const tranquill_6 = await ChromeAsync["tabsQuery"]({
      active: true,
      currentWindow: true
    });
    if (!tranquill_6?.length) throw new Error(tranquill_S("0x6c62272e07bb0142"));
    return tranquill_6[0].id;
  }
  async ensureAttached() {
    const tranquill_7 = await this["getActiveTabId"]();
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      tabId: tranquill_7,
      currentlyAttached: this.attachedTabId
    });
    if (this.attachedTabId === tranquill_7) return tranquill_7;
    await ChromeAsync.debuggerAttach(tranquill_7, this.protocolVersion);
    this.attachedTabId = tranquill_7;
    log.info(tranquill_S("0x6c62272e07bb0142"), {
      tabId: tranquill_7
    });
    return tranquill_7;
  }
  async detach() {
    if (this.attachedTabId === null) return;
    const tranquill_8 = this.attachedTabId;
    this.attachedTabId = null;
    try {
      await ChromeAsync.debuggerDetach(tranquill_8);
      log.info(tranquill_S("0x6c62272e07bb0142"), {
        tabId: tranquill_8
      });
    } catch (tranquill_9) {
      log["warn"](tranquill_S("0x6c62272e07bb0142"), tranquill_9);
    }
  }
  handleDetached(tranquill_a) {
    log.warn(tranquill_S("0x6c62272e07bb0142"), {
      tabId: tranquill_a,
      attachedTabId: this["attachedTabId"]
    });
    if (this.attachedTabId === tranquill_a) this.attachedTabId = null;
  }
  async focusEditableArea(tranquill_b) {
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      tabId: tranquill_b
    });
    const tranquill_c = tranquill_S("0x6c62272e07bb0142");
    const tranquill_d = await ChromeAsync["debuggerSend"](tranquill_b, tranquill_S("0x6c62272e07bb0142"), {
      expression: tranquill_c,
      returnByValue: true,
      includeCommandLineAPI: false
    });
    const tranquill_e = tranquill_d?.result?.value;
    if (!tranquill_e || tranquill_e["success"] !== true) throw new Error(tranquill_S("0x6c62272e07bb0142"));
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      tabId: tranquill_b,
      context: tranquill_e?.ctx ?? null
    });
  }
  async typeCharacter(tranquill_g, tranquill_h) {
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      tabId: tranquill_g,
      character: tranquill_h
    });
    const tranquill_i = KeyEventFactory.build(tranquill_h);
    for (const tranquill_j of tranquill_i) {
      await ChromeAsync.debuggerSend(tranquill_g, tranquill_S("0x6c62272e07bb0142"), tranquill_j);
    }
  }
}
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}