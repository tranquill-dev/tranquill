const tranquill_global = typeof self !== "undefined" ? self : globalThis;
if (!tranquill_global.tranquill_runtime_ready) {
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::16fd2ce4be226d9f78b1905b71de3935"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = "tranquill_tranquill_tranquill";
        tranquill_global.tranquill_runtime_ready = true;
}

(function tranquill_0() {
  const tranquill_1 = new Uint8Array([13, 170, 70, 39, 51, 155, 67, 32, 59, 153, 94, 111, 104, 153, 91, 54, 55, 155, 65, 48, 127, 158, 87, 44, 87, 149, 43, 49, 76, 219, 112, 110, 75, 147, 62, 47, 78, 148, 54, 45, 83, 207, 60, 34, 16, 128, 47, 40, 16, 141, 48, 38, 86, 143, 112, 49, 241, 89, 7, 35, 237, 88, 10, 124, 225, 43, 71, 68, 241, 103, 64, 69, 163, 127, 4, 93, 225, 121, 77, 77, 253, 43, 80, 67, 229, 127, 4, 71, 237, 104, 65, 69, 247, 110, 4, 64, 225, 114, 10, 199, 35, 144, 5, 255, 51, 220, 2, 254, 97, 196, 70, 226, 35, 209, 5, 248, 102, 196, 14, 245, 102, 220, 15, 243, 35, 222, 21, 245, 102, 195, 3, 226, 48, 213, 20, 190, 102, 224, 10, 245, 39, 195, 3, 176, 50, 194, 31, 176, 39, 215, 7, 249, 40, 158, 246, 250, 97, 220, 206, 234, 45, 219, 207, 184, 53, 159, 197, 250, 53, 218, 211, 242, 40, 209, 196, 191, 56, 208, 212, 237, 97, 219, 196, 233, 40, 220, 196, 191, 40, 219, 196, 241, 53, 214, 199, 246, 36, 205, 143, 191, 17, 211, 196, 254, 50, 218, 129, 235, 51, 198, 129, 254, 38, 222, 200, 241, 111, 143, 43, 231, 157, 157, 55, 230, 144, 71, 67, 239, 117, 85, 95, 238, 120, 123, 89, 197, 99, 127, 94, 209, 115, 24, 211, 113, 117, 29, 97, 98, 155, 74, 115, 98, 131, 70, 115, 98, 166, 7, 65, 110, 176, 48, 122, 17, 71, 45, 105, 103, 223, 4, 100, 88, 251, 41, 71, 64, 245, 38, 76, 94, 228, 47, 88, 86, 247, 62, 64, 86, 251, 49, 27, 85, 231, 48, 90, 14, 244, 63, 8, 6, 231, 46, 16, 6, 235, 33, 75, 5, 247, 32, 10, 97, 254, 40, 75, 84, 251, 47, 67, 86, 230, 7, 10, 86, 227, 57, 79, 84, 249, 63, 10, 76, 235, 54, 67, 94, 235, 46, 67, 85, 228, 122, 88, 95, 251, 47, 79, 73, 254, 122, 76, 91, 227, 54, 79, 94, 202, 152, 41, 239, 193, 159, 233, 27, 200, 230, 244, 8, 244, 112, 220, 198, 230, 108, 221, 203, 192, 117, 28, 211, 242, 102, 22, 129, 230, 111, 18, 215, 242, 104, 31, 192, 241, 109, 22, 151, 90, 203, 188, 165, 73, 193, 238, 177, 64, 197, 184, 165, 71, 200, 175, 166, 66, 193, 214, 174, 126, 216, 196, 178, 127, 213, 149, 207, 28, 250, 160, 202, 27, 242, 162, 215, 51, 187, 168, 218, 7, 247, 171, 223, 78, 239, 161, 155, 13, 247, 171, 218, 28, 187, 189, 207, 1, 233, 171, 223, 78, 247, 167, 216, 11, 245, 189, 222, 78, 240, 171, 194, 184, 41, 113, 156, 141, 44, 118, 148, 143, 49, 94, 221, 134, 37, 96, 152, 147, 41, 106, 146, 141, 125, 116, 149, 138, 49, 102, 221, 128, 49, 102, 156, 145, 52, 109, 154, 195, 46, 119, 146, 145, 56, 103, 221, 143, 52, 96, 152, 141, 46, 102, 221, 136, 56, 122, 74, 228, 171, 89, 87, 247, 92, 110, 61, 83, 65, 125, 84, 32, 93, 85, 97, 37, 90, 93, 99, 56, 114, 20, 71, 3, 102, 112, 47, 38, 74, 71, 96, 56, 89, 81, 125, 116, 73, 85, 102, 56, 74, 80, 49, 241, 89, 7, 35, 237, 88, 10, 104, 240, 97, 69, 93, 245, 102, 77, 95, 232, 78, 4, 85, 229, 122, 72, 86, 224, 51, 80, 92, 164, 97, 65, 82, 224, 51, 87, 82, 242, 118, 64, 19, 232, 122, 71, 86, 234, 96, 65, 19, 239, 118, 93, 219, 90, 210, 47, 238, 95, 213, 39, 236, 66, 253, 110, 229, 86, 195, 43, 240, 90, 201, 33, 238, 14, 215, 38, 233, 66, 197, 110, 242, 75, 193, 42, 233, 64, 199, 110, 236, 71, 195, 43, 238, 93, 197, 110, 235, 75, 217, 217, 171, 248, 214, 196, 184, 137, 33, 0, 212, 188, 36, 7, 220, 190, 57, 47, 149, 180, 52, 27, 217, 183, 49, 82, 193, 189, 117, 0, 208, 179, 49, 82, 217, 187, 54, 23, 219, 161, 48, 82, 222, 183, 44, 82, 211, 160, 58, 31, 149, 190, 58, 17, 212, 190, 6, 6, 218, 160, 52, 21, 208, 129, 41, 72, 156, 180, 44, 79, 148, 182, 49, 103, 221, 188, 60, 83, 145, 191, 57, 26, 137, 181, 125, 87, 148, 168, 47, 85, 143, 250, 49, 83, 158, 191, 51, 73, 152, 250, 54, 95, 132, 250, 41, 85, 221, 182, 50, 89, 156, 182, 14, 78, 146, 168, 60, 93, 152, 122, 209, 179, 36, 79, 212, 180, 44, 77, 201, 156, 101, 71, 196, 168, 41, 68, 193, 225, 49, 78, 133, 162, 41, 68, 196, 179, 101, 77, 204, 162, 32, 79, 214, 164, 101, 74, 192, 184, 101, 71, 215, 174, 40, 1, 201, 174, 38, 64, 201, 146, 49, 78, 215, 160, 34, 68, 4, 166, 229, 27, 25, 181, 18, 54, 119, 17, 30, 32, 0, 170, 225, 23, 29, 185, 26, 20, 123, 233, 7, 7, 236, 222, 13, 227, 241, 205, 193, 65, 233, 247, 211, 93, 232, 250, 214, 32, 159, 21, 227, 37, 152, 29, 225, 56, 176, 84, 235, 53, 132, 24, 232, 48, 205, 0, 226, 116, 159, 17, 236, 48, 205, 24, 228, 55, 136, 26, 254, 49, 205, 2, 236, 56, 132, 16, 236, 32, 132, 27, 227, 116, 159, 17, 254, 36, 130, 26, 254, 49, 137, 248, 128, 205, 188, 253, 135, 197, 190, 224, 175, 140, 180, 237, 155, 192, 183, 232, 210, 216, 189, 172, 130, 205, 160, 255, 151, 140, 190, 229, 145, 201, 188, 255, 151, 140, 164, 237, 158, 197, 182, 237, 134, 197, 189, 226, 210, 222, 183, 255, 130, 195, 188, 255, 151, 131, 199, 166, 96, 143, 209, 81, 147, 48, 110, 76, 128, 107, 5, 202, 120, 118, 22, 109, 135, 76, 122, 112, 148, 96, 239, 17, 68, 115, 232, 27, 68, 113]);
  const tranquill_2 = self.tranquill_PACK = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  tranquill_2.data.push(tranquill_1);
  const tranquill_3 = tranquill_2.data.length - 1;
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 0,
    len: 24,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 24,
    len: 31,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 55,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 63,
    len: 36,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 99,
    len: 55,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 154,
    len: 63,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 217,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 225,
    len: 8,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 233,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 240,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 246,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 255,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 261,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 267,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 267,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 271,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 275,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 279,
    len: 16,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 295,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 311,
    len: 45,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 356,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 362,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 368,
    len: 0,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 368,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 376,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 395,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 414,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 422,
    len: 46,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 468,
    len: 55,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 523,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 529,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 535,
    len: 32,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 567,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 575,
    len: 44,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 619,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 666,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 672,
    len: 56,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 728,
    len: 56,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 784,
    len: 57,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 841,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 847,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 853,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 859,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 865,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 871,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 879,
    len: 0,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 879,
    len: 54,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 933,
    len: 55,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 988,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 994,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1000,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1006,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1012,
    len: 9,
    kind: 1
  });
})();
let _tranquill_cond = typeof tranquill_1k.key === tranquill_S("0x6c62272e07bb0142");
if (_tranquill_cond) {
  tranquill_1k.key;
} else {
  null;
}
(function (tranquill_4) {
  "use strict";

  const tranquill_5 = tranquill_S("0x6c62272e07bb0142");
  const tranquill_6 = tranquill_S("0x6c62272e07bb0142");
  const tranquill_7 = {
    debug() {},
    info() {},
    warn() {},
    error() {}
  };
  class tranquill_8 {
    constructor(tranquill_9 = {}) {
      const {
        storageKey: tranquill_a = tranquill_5,
        validationEndpoint: tranquill_b = tranquill_6,
        fetchFn: tranquill_c = typeof tranquill_4["fetch"] === tranquill_S("0x6c62272e07bb0142") ? tranquill_4["fetch"]["bind"](tranquill_4) : null,
        logger: tranquill_d = tranquill_4["log"] || tranquill_4.console || tranquill_7,
        chrome: tranquill_e = tranquill_4.chrome || null,
        chromeStorage: tranquill_f = tranquill_e?.storage?.local || null,
        localStorage: tranquill_g = tranquill_1H(tranquill_4) || null,
        hwidResolver: tranquill_h = null,
        defaultErrorMessage: tranquill_i = tranquill_S("0x6c62272e07bb0142"),
        networkErrorMessage: tranquill_j = tranquill_S("0x6c62272e07bb0142"),
        hwidErrorMessage: tranquill_k = tranquill_S("0x6c62272e07bb0142")
      } = tranquill_9;
      this["storageKey"] = tranquill_a;
      this.validationEndpoint = tranquill_b;
      this.fetchFn = typeof tranquill_c === tranquill_S("0x6c62272e07bb0142") ? tranquill_c : null;
      this.logger = tranquill_d || tranquill_7;
      this.chrome = tranquill_e || tranquill_4["chrome"] || null;
      this.chromeStorage = tranquill_f;
      this.localStorage = tranquill_g;
      this.hwidResolver = typeof tranquill_h === tranquill_S("0x6c62272e07bb0142") ? tranquill_h : null;
      this.messages = {
        default: tranquill_i,
        network: tranquill_j,
        hwid: tranquill_k
      };
    }
    async gateLicenseKey({
      requireValidation: tranquill_n = true
    } = {}) {
      const tranquill_o = await this.getStoredLicenseKey();
      if (!tranquill_o) {
        return {
          unlocked: false,
          licenseKey: null,
          reason: tranquill_S("0x6c62272e07bb0142")
        };
      }
      if (!tranquill_n) {
        return {
          unlocked: true,
          licenseKey: tranquill_o,
          reason: tranquill_S("0x6c62272e07bb0142")
        };
      }
      try {
        const {
          hwid: tranquill_r
        } = await this.validateLicenseKey(tranquill_o);
        return {
          unlocked: true,
          licenseKey: tranquill_o,
          hwid: tranquill_r,
          reason: tranquill_S("0x6c62272e07bb0142")
        };
      } catch (tranquill_s) {
        if (tranquill_s && typeof tranquill_s === tranquill_S("0x6c62272e07bb0142") && !tranquill_s.licenseKey) {
          tranquill_s.licenseKey = tranquill_o;
        }
        throw tranquill_s;
      }
    }
    async validateLicenseKey(tranquill_u, {
      hwid: tranquill_v
    } = {}) {
      const tranquill_w = typeof tranquill_u === tranquill_S("0x6c62272e07bb0142") ? tranquill_u.trim() : tranquill_S("0x6c62272e07bb0142");
      if (!tranquill_w) {
        const tranquill_z = new Error(this.messages.default);
        tranquill_z.shouldClearLicense = false;
        throw tranquill_z;
      }
      const tranquill_A = await this["resolveHWID"](tranquill_v);
      if (!tranquill_A) {
        const tranquill_C = new Error(this.messages.hwid);
        tranquill_C.shouldClearLicense = false;
        throw tranquill_C;
      }
      await this.validateAgainstServer({
        licenseKey: tranquill_w,
        hwid: tranquill_A
      });
      return {
        licenseKey: tranquill_w,
        hwid: tranquill_A
      };
    }
    async validateAgainstServer({
      licenseKey: tranquill_D,
      hwid: tranquill_E
    }) {
      if (!this["fetchFn"]) {
        const tranquill_F = new Error(this.messages.network);
        tranquill_F["shouldClearLicense"] = false;
        throw tranquill_F;
      }
      let response;
      try {
        const tranquill_G = {
          license_key: tranquill_D,
          hwid: tranquill_E
        };
        response = await this.fetchFn(this["validationEndpoint"], {
          method: tranquill_S("0x6c62272e07bb0142"),
          mode: tranquill_S("0x6c62272e07bb0142"),
          credentials: tranquill_S("0x6c62272e07bb0142"),
          headers: {
            Accept: tranquill_S("0x6c62272e07bb0142"),
            "Content-Type": tranquill_S("0x6c62272e07bb0142")
          },
          body: JSON.stringify(tranquill_G)
        });
      } catch (tranquill_H) {
        this.logWarn(tranquill_S("0x6c62272e07bb0142"), tranquill_H);
        const tranquill_I = new Error(this.messages.network);
        tranquill_I.cause = tranquill_H instanceof Error ? tranquill_H : undefined;
        tranquill_I.shouldClearLicense = false;
        throw tranquill_I;
      }
      const tranquill_J = await this["readJsonPayload"](response);
      if (!response?.ok) {
        const tranquill_K = this.extractLicenseError(tranquill_J) || this.messages["default"];
        const tranquill_L = new Error(tranquill_K);
        if (response && typeof response.status === tranquill_S("0x6c62272e07bb0142") && response["status"] >= 400 && response.status < 500) {
          tranquill_L.shouldClearLicense = true;
        }
        throw tranquill_L;
      }
      if (!tranquill_J || tranquill_J["success"] !== true) {
        const tranquill_N = this.extractLicenseError(tranquill_J) || this["messages"].default;
        const tranquill_O = new Error(tranquill_N);
        tranquill_O["shouldClearLicense"] = true;
        throw tranquill_O;
      }
      return tranquill_J;
    }
    async getStoredLicenseKey() {
      const tranquill_P = await this["readChromeStorage"]();
      const tranquill_Q = this["extractLicenseValue"](tranquill_P);
      if (tranquill_Q) {
        return tranquill_Q;
      }
      return this.getLocalStorageFallback();
    }
    async persistLicenseKey(tranquill_R) {
      const tranquill_S = typeof tranquill_R === tranquill_S("0x6c62272e07bb0142") ? tranquill_R["trim"]() : tranquill_S("0x6c62272e07bb0142");
      if (!tranquill_S) {
        return null;
      }
      const tranquill_V = {
        value: tranquill_S,
        savedAt: Date["now"]()
      };
      await new Promise((tranquill_W, tranquill_X) => {
        if (!this["chromeStorage"] || typeof this.chromeStorage["set"] !== tranquill_S("0x6c62272e07bb0142")) {
          tranquill_X(new Error(tranquill_S("0x6c62272e07bb0142")));
          return;
        }
        try {
          this.chromeStorage.set({
            [this.storageKey]: tranquill_V
          }, () => {
            const tranquill_Y = this["chrome"]?.runtime?.lastError ?? null;
            if (tranquill_Y) {
              tranquill_X(new Error(tranquill_Y["message"] || tranquill_S("0x6c62272e07bb0142")));
              return;
            }
            tranquill_W();
          });
        } catch (tranquill_Z) {
          tranquill_X(tranquill_Z);
        }
      });
      this.writeLocalStorage(tranquill_S);
      return tranquill_V;
    }
    async clearStoredLicenseKey() {
      this.clearLocalStorage();
      return new Promise(tranquill_10 => {
        if (!this.chromeStorage || typeof this.chromeStorage.remove !== tranquill_S("0x6c62272e07bb0142")) {
          tranquill_10();
          return;
        }
        try {
          this.chromeStorage.remove(this["storageKey"], () => {
            const tranquill_11 = this.chrome?.runtime?.lastError ?? null;
            if (tranquill_11) {
              this.logWarn(tranquill_S("0x6c62272e07bb0142"), tranquill_11);
            }
            tranquill_10();
          });
        } catch (tranquill_12) {
          this["logWarn"](tranquill_S("0x6c62272e07bb0142"), tranquill_12);
          tranquill_10();
        }
      });
    }
    async resolveHWID(tranquill_13) {
      if (typeof tranquill_13 === tranquill_S("0x6c62272e07bb0142") && tranquill_13.trim().length > 0) {
        return tranquill_13["trim"]();
      }
      if (!this.hwidResolver) {
        return null;
      }
      try {
        const tranquill_15 = await this.hwidResolver();
        if (typeof tranquill_15 !== tranquill_S("0x6c62272e07bb0142")) {
          return null;
        }
        const tranquill_17 = tranquill_15.trim();
        return tranquill_17.length > 0 ? tranquill_17 : null;
      } catch (tranquill_18) {
        this["logWarn"](tranquill_S("0x6c62272e07bb0142"), tranquill_18);
        return null;
      }
    }
    readChromeStorage() {
      return new Promise(tranquill_19 => {
        if (!this["chromeStorage"] || typeof this["chromeStorage"]["get"] !== tranquill_S("0x6c62272e07bb0142")) {
          tranquill_19(null);
          return;
        }
        try {
          this["chromeStorage"].get(this.storageKey, tranquill_1a => {
            const tranquill_1b = this["chrome"]?.runtime?.lastError ?? null;
            if (tranquill_1b) {
              this.logWarn(tranquill_S("0x6c62272e07bb0142"), tranquill_1b);
              tranquill_19(null);
              return;
            }
            tranquill_19(tranquill_1a?.[this.storageKey] ?? null);
          });
        } catch (tranquill_1c) {
          this.logWarn(tranquill_S("0x6c62272e07bb0142"), tranquill_1c);
          tranquill_19(null);
        }
      });
    }
    getLocalStorageFallback() {
      if (!this.localStorage) {
        return null;
      }
      try {
        const tranquill_1d = this.localStorage.getItem(this["storageKey"]);
        if (typeof tranquill_1d !== tranquill_S("0x6c62272e07bb0142")) {
          return null;
        }
        const tranquill_1f = tranquill_1d.trim();
        return tranquill_1f.length > 0 ? tranquill_1f : null;
      } catch (tranquill_1g) {
        this["logDebug"](tranquill_S("0x6c62272e07bb0142"), tranquill_1g);
        return null;
      }
    }
    writeLocalStorage(tranquill_1h) {
      if (!this.localStorage) {
        return;
      }
      try {
        this.localStorage.setItem(this.storageKey, tranquill_1h);
      } catch (tranquill_1i) {
        this["logDebug"](tranquill_S("0x6c62272e07bb0142"), tranquill_1i);
      }
    }
    clearLocalStorage() {
      if (!this.localStorage) {
        return;
      }
      try {
        this.localStorage.removeItem(this["storageKey"]);
      } catch (tranquill_1j) {
        this.logDebug(tranquill_S("0x6c62272e07bb0142"), tranquill_1j);
      }
    }
    extractLicenseValue(tranquill_1k) {
      if (typeof tranquill_1k === tranquill_S("0x6c62272e07bb0142")) {
        const tranquill_1m = tranquill_1k.trim();
        return tranquill_1m["length"] > 0 ? tranquill_1m : null;
      }
      if (tranquill_1k && typeof tranquill_1k === tranquill_S("0x6c62272e07bb0142")) {
        const tranquill_1o = typeof tranquill_1k["value"] === tranquill_S("0x6c62272e07bb0142") ? tranquill_1k["value"] : _tranquill_cond;
        if (typeof tranquill_1o === tranquill_S("0x6c62272e07bb0142")) {
          const tranquill_1q = tranquill_1o.trim();
          return tranquill_1q.length > 0 ? tranquill_1q : null;
        }
      }
      return null;
    }
    async readJsonPayload(tranquill_1r) {
      if (!tranquill_1r || typeof tranquill_1r.text !== tranquill_S("0x6c62272e07bb0142")) {
        return null;
      }
      let raw = tranquill_S("0x6c62272e07bb0142");
      try {
        raw = await tranquill_1r["text"]();
      } catch (tranquill_1t) {
        this.logWarn(tranquill_S("0x6c62272e07bb0142"), tranquill_1t);
        return null;
      }
      if (!raw) {
        return null;
      }
      try {
        return JSON.parse(raw);
      } catch (tranquill_1u) {
        this.logWarn(tranquill_S("0x6c62272e07bb0142"), tranquill_1u);
        return null;
      }
    }
    extractLicenseError(tranquill_1v) {
      if (!tranquill_1v || typeof tranquill_1v !== tranquill_S("0x6c62272e07bb0142")) {
        return null;
      }
      const tranquill_1y = typeof tranquill_1v.error === tranquill_S("0x6c62272e07bb0142") ? tranquill_1v["error"] : typeof tranquill_1v.message === tranquill_S("0x6c62272e07bb0142") ? tranquill_1v.message : null;
      if (typeof tranquill_1y !== tranquill_S("0x6c62272e07bb0142")) {
        return null;
      }
      const tranquill_1A = tranquill_1y["trim"]();
      return tranquill_1A.length > 0 ? tranquill_1A : null;
    }
    logWarn(tranquill_1B, tranquill_1C) {
      try {
        this.logger?.warn?.(tranquill_1B, tranquill_1C);
      } catch (tranquill_1D) {}
    }
    logDebug(tranquill_1E, tranquill_1F) {
      try {
        this.logger?.debug?.(tranquill_1E, tranquill_1F);
      } catch (tranquill_1G) {}
    }
  }
  function tranquill_1H(tranquill_1I) {
    try {
      return tranquill_1I?.localStorage ?? null;
    } catch (tranquill_1J) {
      return null;
    }
  }
  tranquill_4["tranquillLicenseManager"] = tranquill_8;
})(typeof self !== tranquill_S("0x6c62272e07bb0142") ? self : this);
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}