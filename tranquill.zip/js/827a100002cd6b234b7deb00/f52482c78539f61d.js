var tranquill_global = typeof self !== "undefined" ? self : globalThis;
if (!tranquill_global.tranquill_runtime_ready) {
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::c882198ca34f17b696c9b80e0eca21ea"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = "tranquill_tranquill_tranquill";
        tranquill_global.tranquill_runtime_ready = true;
}

(function tranquill_init_shard() {
  const a = new Uint8Array([5, 35, 205, 89, 223, 101, 26, 207, 1, 41, 205, 68, 211, 116, 95, 130, 23, 47, 209, 15, 218, 111, 12, 155, 19, 40, 218, 93, 197, 38, 22, 129, 31, 50, 214, 78, 218, 111, 5, 134, 24, 33, 8, 165, 37, 28, 210, 251, 53, 70, 25, 175, 38, 28, 211, 242, 53, 86, 19, 178, 38, 1, 206, 233, 118, 65, 25, 184, 148, 97, 130, 125, 206, 39, 213, 107, 144, 107, 130, 96, 194, 54, 144, 57, 130, 103, 149, 98, 209, 33, 212, 107, 138, 97, 131, 120, 198, 35, 213, 197, 145, 156, 124, 2, 241, 68, 62, 223, 139, 154, 215, 236, 143, 104, 10, 191, 161, 73, 207, 70, 231, 76, 12, 17, 188, 75, 206, 70, 224, 31, 92, 5, 178, 69, 208, 108, 129, 71, 190, 43, 97, 31, 252, 118, 155, 65, 236, 44, 80, 18, 248, 118, 155, 65, 191, 85, 116, 232, 221, 15, 42, 248, 7, 68, 126, 235, 221, 14, 35, 248, 7, 85, 108, 234, 192, 4, 41, 123, 227, 78, 146, 60, 131, 150, 208, 97, 249, 72, 103, 134, 162, 155, 116, 211, 235, 223, 113, 128, 237, 152, 32, 211, 255, 223, 52, 148, 172, 130, 56, 199, 255, 206, 25, 14, 124, 243, 126, 195, 35, 170, 4, 29, 17, 147, 175, 250, 68, 102, 227, 185, 8, 156, 189, 70, 171, 163, 214, 218, 239, 237, 147, 70, 186, 236, 212, 144, 238, 249, 131, 70, 171, 169, 194, 61, 135, 234, 236, 33, 195, 164, 169, 61, 150, 165, 250, 111, 218, 169, 185, 42, 240, 160, 69, 75, 165, 214, 19, 137, 248, 172, 77, 253, 141, 188, 58, 168, 15, 225, 109, 237, 154, 182, 59, 168, 74, 247, 13, 60, 42, 37, 216, 62, 99, 118, 5, 50, 32, 51, 246, 58, 206, 53, 178, 125, 2, 79, 244, 59, 200, 60, 163, 96, 166, 1, 124, 143, 237, 198, 144, 150, 88, 121, 212, 81, 20, 119, 148, 140, 80, 112, 199, 91, 11, 119, 146, 155, 90, 114, 201, 72, 28, 51, 204, 126, 100, 65, 8, 57, 40, 79, 200, 100, 108, 72, 27, 51, 55, 79, 218, 119, 108, 67, 164, 66, 156, 77, 224, 5, 80, 33, 181, 73, 150, 80, 228, 11, 94, 6, 96, 199, 58, 201, 43, 0, 111, 42, 89, 183, 43, 109, 21, 185, 125, 35, 91, 178, 44, 114, 25, 250, 122, 98, 74, 188, 46, 119, 29, 234, 107, 137, 125, 225, 130, 77, 58, 173, 140, 155, 116, 227, 135, 74, 37, 161, 207, 156, 53, 230, 141, 80, 57, 120, 199, 94, 182, 60, 128, 146, 219, 103, 193, 75, 189, 38, 155, 173, 253, 105, 203, 70, 41, 20, 147, 237, 109, 211, 223, 227, 58, 19, 156, 247, 124, 210, 198, 227, 43, 25, 147, 231, 96, 82, 130, 200, 221, 148, 209, 25, 170, 97, 130, 196, 250, 51, 140, 42, 207, 115, 131, 104, 159, 50, 150, 63, 201, 119, 198, 126, 218, 48, 130, 44, 223, 103, 131, 110, 159, 59, 151, 241, 228, 41, 126, 175, 177, 116, 132, 241, 210, 41, 75, 162, 180, 110, 199, 185, 208, 72, 135, 182, 146, 152, 198, 163, 197, 78, 131, 243, 132, 221, 195, 175, 208, 84, 153, 241, 192, 142, 195, 183, 212, 72, 132, 226, 215, 22, 1, 185, 157, 210, 69, 243, 153, 19, 5, 164, 138, 223, 71, 242, 153, 31, 3, 163, 144, 209, 78, 223, 200, 42, 128, 4, 16, 97, 20, 222, 200, 55, 132, 8, 19, 96, 20, 223, 216, 39, 145, 4, 11, 97, 80, 150, 157, 55, 128, 2, 13, 116, 93, 195, 218, 100, 135, 8, 14, 119, 93, 194, 211, 162, 23, 87, 106, 177, 76, 150, 122, 162, 22, 75, 106, 244, 77, 156, 122, 183, 2, 81, 118, 100, 30, 5, 152, 34, 218, 74, 23, 102, 26, 3, 93, 182, 56, 203, 78, 227, 113, 15, 75, 176, 119, 207, 15, 224, 55, 9, 75, 175, 56, 205, 11, 230, 153, 63, 228, 245, 88, 110, 162, 244, 153, 59, 226, 108, 236, 70, 184, 41, 173, 128, 116, 152, 111, 163, 103, 195, 46, 179, 105, 141, 118, 186, 32, 205, 52, 250, 104, 130, 32, 181, 38, 197, 44, 20, 44, 117, 247, 87, 110, 50, 176, 80, 45, 114, 246, 81, 106, 63, 167, 20, 64, 231, 154, 233, 139, 160]);
  const pack = self.tranquill_PACK = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  pack.data.push(a);
  const shard = pack["data"].length - 1;
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 0,
    len: 42,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 42,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 68,
    len: 31,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 99,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 110,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 110,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 116,
    len: 19,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 135,
    len: 20,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 155,
    len: 22,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 177,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 188,
    len: 24,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 212,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 222,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 233,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 253,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 270,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 281,
    len: 15,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 296,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 308,
    len: 14,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 322,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 328,
    len: 24,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 352,
    len: 20,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 372,
    len: 16,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 388,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 394,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 419,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 441,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 460,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 481,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 493,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 519,
    len: 15,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 534,
    len: 29,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 563,
    len: 24,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 587,
    len: 42,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 629,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 649,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 660,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 682,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 693,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 700,
    len: 23,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 723,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 740,
    len: 6,
    kind: 1
  });
})();
log.info(tranquill_S("0x6c62272e07bb0142"));
const typingModel = new TypingModel();
const debuggerManager = new DebuggerManager();
const phantomController = new PhantomController();
const typingSession = new TypingSession({
  debuggerManager,
  typingModel,
  phantomController
});
log.debug(tranquill_S("0x6c62272e07bb0142"));
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const tabId = sender?.tab?.id ?? null;
  log.debug(tranquill_S("0x6c62272e07bb0142"), {
    action: message?.action,
    tabId
  });
  switch (message?.action) {
    case tranquill_S("0x6c62272e07bb0142"):
      {
        (async () => {
          try {
            const incomingText = String(message.text ?? tranquill_S("0x6c62272e07bb0142"));
            const prevHint = typeof message.previousText === tranquill_S("0x6c62272e07bb0142") ? message["previousText"] : null;
            let reset = message.resetProgress === true;
            if (!reset && prevHint !== null) reset = prevHint !== incomingText;
            if (!reset && prevHint === null) {
              const stored = await TextStorage.getSavedText();
              if (stored !== incomingText) reset = true;
            }
            await TextStorage.setSavedText(incomingText);
            const sig = TextStorage["createTextSignature"](incomingText);
            if (reset) {
              await TextStorage.setProgress(0, sig).catch(e => log.warn(tranquill_S("0x6c62272e07bb0142"), e));
            }
            const progress = reset ? 0 : await TextStorage.getProgress(sig).catch(() => 0);
            const settings = await SettingsStorage.getSettings().catch(() => SettingsStorage["defaults"]);
            log.debug(tranquill_S("0x6c62272e07bb0142"), settings);
            typingModel.setWordsPerMinute(settings.typingSpeed);
            typingModel.setHumanized(settings["ghostMode"]);
            await typingSession.start({
              text: incomingText,
              startIndex: progress,
              settings
            });
            log.info(tranquill_S("0x6c62272e07bb0142"), {
              tabId,
              length: incomingText.length,
              reset,
              progress
            });
            sendResponse({
              success: true
            });
          } catch (err) {
            log.error(tranquill_S("0x6c62272e07bb0142"), err);
            typingSession.stop()["catch"](e => log.warn(tranquill_S("0x6c62272e07bb0142"), e));
            sendResponse({
              success: false,
              error: String(err?.message || err)
            });
          }
        })();
        return true;
      }
    case tranquill_S("0x6c62272e07bb0142"):
    case tranquill_S("0x6c62272e07bb0142"):
      {
        log.info(tranquill_S("0x6c62272e07bb0142"), {
          action: message.action
        });
        typingSession.stop().catch(e => log.warn(tranquill_S("0x6c62272e07bb0142"), e));
        sendResponse({
          success: true
        });
        return false;
      }
    case tranquill_S("0x6c62272e07bb0142"):
      {
        log.warn(tranquill_S("0x6c62272e07bb0142"), {
          action: message.action,
          reason: message?.reason ?? null
        });
        typingSession.stop().catch(e => log.warn(tranquill_S("0x6c62272e07bb0142"), e));
        sendResponse({
          success: true
        });
        return false;
      }
    case tranquill_S("0x6c62272e07bb0142"):
      {
        const frameId = typeof sender?.frameId === tranquill_S("0x6c62272e07bb0142") ? sender.frameId : null;
        log["debug"](tranquill_S("0x6c62272e07bb0142"), {
          tabId,
          requestId: message?.requestId ?? null,
          frameId
        });
        if (tabId !== null) {
          typingSession.handlePhantomTrigger(tabId, message?.requestId, message?.key, message?.timeStamp, frameId).catch(e => log.warn(tranquill_S("0x6c62272e07bb0142"), e));
        }
        sendResponse({
          success: true
        });
        return false;
      }
    case tranquill_S("0x6c62272e07bb0142"):
      {
        const frameId = typeof sender?.frameId === tranquill_S("0x6c62272e07bb0142") ? sender.frameId : null;
        log.debug(tranquill_S("0x6c62272e07bb0142"), {
          tabId,
          frameId
        });
        if (tabId !== null) {
          typingSession.handlePhantomBackspace(tabId, frameId).catch(e => log["warn"](tranquill_S("0x6c62272e07bb0142"), e));
        }
        sendResponse({
          success: true
        });
        return false;
      }
    case tranquill_S("0x6c62272e07bb0142"):
      {
        log.info(tranquill_S("0x6c62272e07bb0142"), {
          tabId
        });
        if (tabId !== null) phantomController.markReady(tabId);
        sendResponse({
          success: true
        });
        return false;
      }
    case tranquill_S("0x6c62272e07bb0142"):
      {
        log.debug(tranquill_S("0x6c62272e07bb0142"));
        TextStorage.getSavedText().then(text => sendResponse({
          success: true,
          text
        })).catch(err => sendResponse({
          success: false,
          error: String(err?.message || err)
        }));
        return true;
      }
    case tranquill_S("0x6c62272e07bb0142"):
      {
        log.debug(tranquill_S("0x6c62272e07bb0142"));
        sendResponse({
          success: true,
          isTyping: typingSession.isActive()
        });
        return false;
      }
    default:
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        action: message?.action
      });
      return false;
  }
});
chrome.runtime["onSuspend"].addListener(() => {
  log.info(tranquill_S("0x6c62272e07bb0142"));
  typingSession.stop().catch(e => log.warn(tranquill_S("0x6c62272e07bb0142"), e));
});
chrome["tabs"].onRemoved.addListener(tabId => {
  log.info(tranquill_S("0x6c62272e07bb0142"), {
    tabId
  });
  if (debuggerManager.isAttachedTo(tabId)) {
    typingSession.stop().catch(e => log.warn(tranquill_S("0x6c62272e07bb0142"), e));
  }
});
chrome.tabs.onUpdated.addListener((tabId, info) => {
  log["debug"](tranquill_S("0x6c62272e07bb0142"), {
    tabId,
    status: info?.status
  });
  if (info.status === tranquill_S("0x6c62272e07bb0142") && debuggerManager["isAttachedTo"](tabId)) {
    typingSession.stop().catch(e => log.warn(tranquill_S("0x6c62272e07bb0142"), e));
  }
});
chrome["debugger"].onDetach["addListener"](source => {
  log.warn(tranquill_S("0x6c62272e07bb0142"), {
    tabId: source?.tabId ?? null
  });
  if (!source || typeof source["tabId"] !== tranquill_S("0x6c62272e07bb0142")) return;
  debuggerManager.handleDetached(source.tabId);
  typingSession.handleDebuggerDetached();
});
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}