var tranquill_global = typeof self !== "undefined" ? self : globalThis;
if (!tranquill_global.tranquill_runtime_ready) {
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::c882198ca34f17b696c9b80e0eca21ea"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = "tranquill_tranquill_tranquill";
        tranquill_global.tranquill_runtime_ready = true;
}

"use strict";
(function tranquill_init_shard() {
  const a = new Uint8Array([249, 95, 191, 74, 164, 130, 255, 196, 39, 64, 162, 23, 231, 43, 195, 238, 19, 248, 75, 232, 27, 162, 33, 185, 241, 85, 108, 66, 178, 228, 130, 226, 87, 185, 95, 26, 252, 156, 41, 199, 161, 16, 118, 22, 35, 205, 43, 14, 243, 24, 43, 10, 236, 140, 57, 215, 177, 0, 102, 6, 51, 221, 59, 26, 235, 134, 53, 214, 189, 183, 65, 107, 131, 224, 134, 240, 174, 134, 241, 170, 219, 54, 133, 230, 13, 158, 73, 124, 105, 199, 143, 60, 50, 139, 167, 28, 127, 152, 250, 207, 193, 112, 29, 110, 13, 38, 211, 232, 139, 108, 14, 187, 201, 114, 17, 118, 20, 33, 187, 236, 221, 72, 226, 170, 29, 19, 174, 206, 172, 3, 99, 29, 116, 198, 232, 196, 35, 108, 29, 112, 195, 32, 203, 118, 141, 238, 201, 43, 94, 108, 23, 116, 211, 49, 196, 122, 130, 170, 122, 70, 232, 168, 15, 131, 175, 224, 77, 94, 199, 146, 254, 14, 168, 147, 47, 109, 229, 102, 234, 170, 45, 164, 55, 66, 164, 100, 244, 184, 100, 171, 52, 113, 247, 103, 247, 186, 100, 172, 50, 108, 244, 105, 239, 188, 44, 232, 61, 126, 237, 100, 254, 187, 21, 23, 125, 13, 79, 209, 42, 150, 17, 29, 125, 16, 67, 192, 93, 121, 129, 255, 85, 160, 165, 44, 160, 101, 98, 228, 98, 184, 138, 109, 162, 123, 112, 173, 126, 187, 165, 57, 238, 112, 126, 254, 126, 181, 163, 46, 166, 52, 113, 236, 103, 184, 178, 41, 225, 204, 79, 43, 164, 11, 7, 105, 249, 250, 75, 51, 188, 29, 11, 77, 194, 247, 106, 220, 121, 190, 90, 153, 62, 246, 152, 196, 79, 186, 66, 129, 40, 250, 188, 255, 66, 155, 103, 137, 39, 235, 231, 30, 29, 13, 162, 89, 213, 79, 255, 40, 25, 21, 186, 79, 217, 107, 196, 37, 56, 189, 184, 140, 151, 239, 228, 205, 90, 176, 220, 172, 138, 172, 200, 176, 110, 141, 200, 188, 103, 223, 20, 253, 42, 160, 204, 188, 154, 220, 184, 192, 126, 216, 180, 196, 98, 201, 177, 49, 64, 31, 242, 98, 25, 153, 180, 62, 82, 22, 189, 98, 17, 205, 175, 57, 81, 15, 252, 124, 84, 223, 188, 57, 88, 28, 249, 114, 30, 238, 200, 82, 23, 152, 160, 4, 212, 203, 249, 2, 18, 151, 178, 13, 155, 203, 241, 86, 9, 144, 177, 20, 218, 213, 180, 86, 19, 139, 177, 21, 215, 133, 116, 31, 161, 82, 41, 175, 207, 98, 205, 14, 242, 213, 131, 175, 223, 185, 153, 168, 69, 182, 85, 254, 99, 58, 65, 162, 5, 103, 146, 49, 209, 112, 6, 107, 8, 53, 14, 3, 255, 28, 92, 223, 190, 209, 6, 27, 247, 228, 84, 199, 182, 169, 94, 246, 95, 225, 132, 175, 154, 84, 48, 149, 251, 151, 109, 5, 77, 39, 174, 192, 196, 255, 100, 68, 86, 46, 184, 203, 136, 253, 110, 68, 80, 34, 166, 193, 158, 228, 101, 1, 4, 45, 164, 214, 196, 195, 92, 45, 96, 243, 23, 54, 76, 169, 206, 115, 232, 204, 109, 87, 178, 21, 40, 249, 158, 227, 80, 178, 89, 31, 251, 90, 32, 197, 162, 159, 20, 176, 145, 43, 206, 233, 84, 9, 105, 200, 14, 211, 48, 13, 10, 50, 3, 184, 91, 60, 222, 235, 168, 161, 96, 75, 128, 69, 8, 35, 148, 214, 77, 102, 199, 83, 26, 59, 169, 146, 241, 150, 244, 65, 175, 20, 119, 144, 242, 199, 165, 158, 253, 154, 248, 77, 219, 224, 131, 100, 6, 179, 231, 119, 129, 83, 79, 4, 225, 48, 202, 83, 188, 202, 177, 82, 117, 23, 226, 220, 33, 74, 121, 174, 14, 119, 125, 233, 78, 97, 28, 157, 34, 69, 52, 237, 78, 47, 49, 184, 10, 117, 113, 238, 109, 73, 49, 175, 100, 77, 66, 169, 39, 136, 203, 241, 109, 12, 66, 171, 43, 152, 130, 228, 110, 69, 81, 160, 98, 136, 142, 243, 107, 79, 78, 229, 10, 187, 162, 193, 137, 37, 85, 179, 72, 59, 240, 145, 96, 78, 22, 250, 116, 31, 205, 167, 33, 92, 89, 243, 97, 5, 213, 160, 50, 73, 24, 244, 244, 17, 93, 179, 188, 211, 0, 171, 249, 16, 75, 235, 166, 203, 30, 227, 244, 18, 65, 240, 157, 238, 141, 166, 94, 123, 178, 217, 130, 57, 202, 176, 91, 123, 170, 40, 173, 206, 245, 50, 170, 204, 226, 100, 237, 13, 129, 238, 152, 188, 92, 169, 86, 253, 225, 37, 124, 82, 162, 244, 146, 242, 71, 169, 79, 242, 7, 228, 47, 242, 3, 110, 93, 190, 213, 213, 153, 121, 44, 144, 94, 49, 110, 205, 167, 119, 37, 4, 112, 216, 8, 16, 52, 5, 205, 87, 124, 71, 16, 37, 48, 31, 244, 117, 92, 111, 15, 43, 67, 61, 151, 175, 161, 75, 191, 74, 205, 62, 170, 157, 155, 123, 191, 94, 201, 38, 179, 157, 140, 157, 183, 49, 146, 216, 240, 121, 80, 133, 128, 62, 143, 220, 247, 117, 112, 128, 166, 53, 146, 218, 224, 215, 42, 38, 117, 5, 118, 103, 56, 149, 30, 35, 123, 247, 68, 101, 126, 190, 22, 52, 123, 185, 66, 110, 63, 175, 22, 41, 114, 248, 85, 108, 59, 126, 11, 153, 184, 37, 133, 130, 167, 98, 13, 140, 166, 39, 202, 196, 228, 122, 81, 142, 171, 121, 211, 4, 89, 244, 94, 211, 134, 180, 152, 25, 78, 241, 5, 219, 211, 180, 203, 27, 71, 248, 92, 211, 213, 178, 197, 30, 65, 238, 88, 216, 208, 177, 156, 26, 78, 241, 10, 222, 208, 181, 203, 73, 78, 165, 19, 128, 197, 30, 149, 40, 65, 147, 66, 119, 129, 85, 136, 63, 68, 200, 74, 34, 129, 6, 138, 54, 77, 145, 66, 36, 135, 8, 143, 48, 91, 197, 30, 127, 141, 7, 223, 50, 68, 196, 30, 34, 213, 9, 222, 51, 69, 222, 17, 52, 49, 98, 55, 86, 188, 181, 232, 150, 122, 127, 32, 83, 231, 189, 189, 150, 41, 125, 41, 90, 190, 181, 187, 144, 39, 120, 47, 76, 230, 190, 235, 155, 123, 47, 46, 1, 187, 191, 239, 198, 126, 40, 33, 85, 241, 230, 171, 100, 115, 14, 35, 233, 164, 209, 227, 47, 110, 25, 38, 178, 172, 132, 227, 124, 108, 16, 47, 235, 164, 130, 229, 114, 105, 22, 57, 189, 254, 215, 227, 121, 60, 19, 37, 187, 174, 217, 181, 123, 106, 23, 32, 164, 247, 146, 151, 64, 29, 48, 26, 151, 194, 112, 220, 93, 10, 53, 65, 159, 151, 112, 143, 95, 3, 60, 24, 151, 145, 118, 129, 90, 5, 42, 26, 153, 203, 112, 136, 90, 3, 50, 79, 150, 203, 33, 143, 89, 2, 60, 87, 196, 129, 194, 81, 108, 141, 79, 134, 51, 77, 137, 76, 123, 136, 20, 142, 102, 77, 218, 78, 114, 129, 77, 134, 96, 75, 212, 75, 116, 151, 29, 138, 101, 74, 223, 75, 118, 221, 28, 221, 49, 72, 221, 78, 32, 220, 2, 213, 112, 245, 190, 251, 146, 120, 105, 36, 82, 190, 163, 236, 151, 35, 97, 113, 82, 237, 161, 229, 158, 122, 105, 119, 84, 227, 164, 227, 136, 42, 100, 38, 86, 232, 166, 176, 193, 122, 99, 33, 6, 235, 243, 176, 195, 53, 58, 103, 56, 15, 114, 127, 181, 216, 173, 191, 115, 18, 101, 122, 238, 208, 248, 191, 32, 16, 108, 115, 183, 216, 254, 185, 46, 21, 106, 101, 228, 210, 164, 189, 116, 71, 60, 122, 179, 128, 254, 190, 119, 25, 63, 43, 248, 139, 238, 171, 156, 193, 12, 166, 75, 30, 204, 224, 129, 214, 9, 253, 67, 75, 204, 179, 131, 223, 0, 164, 75, 77, 202, 189, 134, 217, 22, 244, 71, 31, 206, 176, 138, 136, 13, 252, 74, 23, 202, 182, 215, 140, 91, 235, 24, 93, 150, 109, 80, 217, 27, 58, 143, 25, 221, 112, 71, 220, 64, 50, 218, 25, 142, 114, 78, 213, 25, 58, 220, 31, 128, 119, 72, 195, 74, 50, 136, 25, 222, 37, 29, 142, 28, 101, 140, 26, 143, 32, 76, 141, 86, 105, 204, 137, 250, 191, 238, 4, 45, 96, 46, 194, 231, 168, 235, 95, 37, 53, 46, 145, 229, 161, 226, 6, 45, 51, 40, 159, 224, 167, 244, 83, 35, 99, 122, 159, 178, 165, 184, 1, 112, 54, 35, 195, 225, 165, 239, 73, 126, 35, 252, 203, 182, 187, 113, 28, 105, 123, 183, 214, 161, 190, 42, 20, 60, 123, 228, 212, 168, 183, 115, 28, 58, 125, 234, 209, 174, 161, 113, 17, 58, 45, 235, 208, 171, 188, 118, 21, 104, 122, 228, 209, 252, 184, 60, 79, 42, 111, 216, 133, 72, 98, 15, 90, 136, 36, 197, 146, 77, 57, 7, 15, 136, 119, 199, 155, 68, 96, 15, 9, 142, 121, 194, 157, 82, 54, 7, 95, 139, 120, 199, 153, 30, 96, 0, 93, 133, 36, 144, 152, 77, 47, 92, 25, 176, 216, 3, 101, 236, 3, 29, 34, 253, 192, 93, 101, 237, 14, 67, 38, 175, 147, 75, 58, 173, 171, 156, 193, 88, 246, 65, 30, 155, 227, 214, 222, 92, 253, 22, 79, 193, 231, 209, 221, 12, 166, 69, 24, 206, 181, 129, 216, 22, 253, 70, 31, 200, 188, 208, 219, 95, 244, 65, 79, 205, 225, 209, 141, 91, 235, 24, 93]);
  const pack = self["tranquill_PACK"] = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  pack.data["push"](a);
  const shard = pack.data.length - 1;
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 0,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 6,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 12,
    len: 3,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 15,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 19,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 24,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 29,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 35,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 41,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 47,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 51,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 57,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 63,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 69,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 74,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 79,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 85,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 94,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 100,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 106,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 112,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 118,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 127,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 132,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 137,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 143,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 149,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 155,
    len: 3,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 158,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 169,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 173,
    len: 39,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 212,
    len: 14,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 226,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 230,
    len: 36,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 266,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 285,
    len: 23,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 308,
    len: 19,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 327,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 335,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 339,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 343,
    len: 8,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 351,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 355,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 359,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 363,
    len: 30,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 393,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 397,
    len: 29,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 426,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 427,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 427,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 433,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 440,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 444,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 450,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 451,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 457,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 464,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 472,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 480,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 487,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 492,
    len: 35,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 527,
    len: 7,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 534,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 541,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 547,
    len: 7,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 554,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 561,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 568,
    len: 2,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 570,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 576,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 592,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 598,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 604,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 610,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 616,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 616,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 627,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 633,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 637,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 658,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 662,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 694,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 698,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 720,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 740,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 746,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 757,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 761,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 769,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 776,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 781,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 787,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 791,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 797,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 809,
    len: 3,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 812,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 828,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 832,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 851,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 873,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 881,
    len: 24,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 905,
    len: 21,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 926,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 973,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1020,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1067,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 1114,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 1161,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1208,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1255,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1302,
    len: 47,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1349,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1396,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1443,
    len: 47,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1490,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1537,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1558,
    len: 47,
    kind: 1
  });
})();
const TRANQUILL_LOG_LEVEL_PRIORITY = Object.freeze({
  silent: 0,
  error: 1,
  warn: 2,
  info: 3,
  debug: 4
});
self.TRANQUILL_LOG_LEVEL = tranquill_S("0x6c62272e07bb0142");
const normalizeLogLevel = (value, {
  allowSilent = false
} = {}) => {
  if (typeof value !== tranquill_S("0x6c62272e07bb0142")) return null;
  const lowered = value.toLowerCase();
  if (lowered === tranquill_S("0x6c62272e07bb0142")) return tranquill_S("0x6c62272e07bb0142");
  if (lowered === tranquill_S("0x6c62272e07bb0142")) return tranquill_S("0x6c62272e07bb0142");
  if (lowered === tranquill_S("0x6c62272e07bb0142") && allowSilent) return tranquill_S("0x6c62272e07bb0142");
  if (Object.prototype.hasOwnProperty.call(TRANQUILL_LOG_LEVEL_PRIORITY, lowered)) {
    return lowered;
  }
  return null;
};
const getCurrentLogLevel = () => {
  const current = normalizeLogLevel(self["TRANQUILL_LOG_LEVEL"], {
    allowSilent: true
  });
  return current || tranquill_S("0x6c62272e07bb0142");
};
const shouldEmitLevel = level => {
  const normalized = normalizeLogLevel(level) || tranquill_S("0x6c62272e07bb0142");
  if (normalized === tranquill_S("0x6c62272e07bb0142")) return false;
  const current = getCurrentLogLevel();
  if (current === tranquill_S("0x6c62272e07bb0142")) return false;
  return TRANQUILL_LOG_LEVEL_PRIORITY[normalized] <= TRANQUILL_LOG_LEVEL_PRIORITY[current];
};
const applyGlobalLogLevel = level => {
  const normalized = normalizeLogLevel(level, {
    allowSilent: true
  });
  if (!normalized) return null;
  const current = getCurrentLogLevel();
  if (current === normalized) return {
    previous: current,
    next: current,
    changed: false
  };
  self.TRANQUILL_LOG_LEVEL = normalized;
  return {
    previous: current,
    next: normalized,
    changed: true
  };
};
const tranquillLogSubscribers = new Set();
const deserializeArg = payload => {
  if (!payload || typeof payload !== tranquill_S("0x6c62272e07bb0142")) return payload;
  switch (payload.kind) {
    case tranquill_S("0x6c62272e07bb0142"):
      {
        const err = new Error(payload["message"]);
        err.name = payload.name || tranquill_S("0x6c62272e07bb0142");
        if (payload["stack"]) err.stack = payload.stack;
        return err;
      }
    case tranquill_S("0x6c62272e07bb0142"):
    case tranquill_S("0x6c62272e07bb0142"):
      return payload.value;
    case tranquill_S("0x6c62272e07bb0142"):
      return payload.value;
    default:
      return payload.value;
  }
};
const serializeArgForPort = value => {
  if (!value || typeof value !== tranquill_S("0x6c62272e07bb0142")) {
    if (typeof value === tranquill_S("0x6c62272e07bb0142")) return {
      kind: tranquill_S("0x6c62272e07bb0142"),
      value
    };
    return {
      kind: tranquill_S("0x6c62272e07bb0142"),
      value
    };
  }
  if (value["kind"] && Object.prototype.hasOwnProperty["call"](value, tranquill_S("0x6c62272e07bb0142"))) {
    return value;
  }
  if (value instanceof Error) {
    return {
      kind: tranquill_S("0x6c62272e07bb0142"),
      name: value["name"],
      message: value.message,
      stack: value.stack || null
    };
  }
  try {
    return {
      kind: tranquill_S("0x6c62272e07bb0142"),
      value: JSON["parse"](JSON["stringify"](value))
    };
  } catch (err) {
    return {
      kind: tranquill_S("0x6c62272e07bb0142"),
      value: String(value)
    };
  }
};
const emitLog = (level, args, meta = {}, originalArgs = null) => {
  const normalizedLevel = typeof level === tranquill_S("0x6c62272e07bb0142") ? level.toLowerCase() : tranquill_S("0x6c62272e07bb0142");
  if (!shouldEmitLevel(normalizedLevel)) return;
  const finalArgs = Array["isArray"](args) ? args : [];
  const consoleFn = console?.[normalizedLevel] || console?.log;
  try {
    consoleFn?.call(console, tranquill_S("0x6c62272e07bb0142"), ...finalArgs);
  } catch (err) {
    if (shouldEmitLevel(tranquill_S("0x6c62272e07bb0142"))) {
      console?.warn?.(tranquill_S("0x6c62272e07bb0142"), err);
    }
  }
  const payload = {
    level: normalizedLevel,
    args: Array.isArray(originalArgs) ? originalArgs["map"](item => serializeArgForPort(item)) : finalArgs.map(item => serializeArgForPort(item)),
    meta: {
      source: meta["source"] || tranquill_S("0x6c62272e07bb0142"),
      timestamp: meta.timestamp || Date.now()
    }
  };
  tranquillLogSubscribers.forEach(port => {
    try {
      port["postMessage"](payload);
    } catch (err) {
      try {
        port["disconnect"]();
      } catch (_) {}
      tranquillLogSubscribers["delete"](port);
      if (shouldEmitLevel(tranquill_S("0x6c62272e07bb0142"))) {
        console?.warn?.(tranquill_S("0x6c62272e07bb0142"), err);
      }
    }
  });
};
self["__tranquillDirectLog"] = (level, args, meta) => {
  emitLog(level, args, meta);
};
const TRANQUILL_HWID_STORAGE_KEY = tranquill_S("0x6c62272e07bb0142");
const TRANQUILL_HWID_SALT_KEY = tranquill_S("0x6c62272e07bb0142");
const TRANQUILL_HWID_SESSION_KEY = tranquill_S("0x6c62272e07bb0142");
const STABLE_DIGEST_FALLBACK_SIZE = 32;
const STABLE_SALT_HEX_LENGTH = 32;
let tranquillHWIDPromise = null;
let tranquillHWIDValue = null;
const readStorageValue = (area, key) => new Promise(resolve => {
  if (!area || typeof area.get !== tranquill_S("0x6c62272e07bb0142")) {
    resolve(null);
    return;
  }
  try {
    area["get"](key, result => {
      const err = chrome.runtime?.lastError ?? null;
      if (err) {
        emitLog(tranquill_S("0x6c62272e07bb0142"), [`storage get failed for key "${key}"`, err]);
        resolve(null);
        return;
      }
      resolve(result?.[key] ?? null);
    });
  } catch (error) {
    emitLog(tranquill_S("0x6c62272e07bb0142"), [`storage get threw for key "${key}"`, error]);
    resolve(null);
  }
});
const setStorageValue = (area, key, value) => new Promise(resolve => {
  if (!area || typeof area.set !== tranquill_S("0x6c62272e07bb0142")) {
    resolve(false);
    return;
  }
  try {
    area.set({
      [key]: value
    }, () => {
      const err = chrome["runtime"]?.lastError ?? null;
      if (err) {
        emitLog(tranquill_S("0x6c62272e07bb0142"), [`storage set failed for key "${key}"`, err]);
        resolve(false);
        return;
      }
      resolve(true);
    });
  } catch (error) {
    emitLog(tranquill_S("0x6c62272e07bb0142"), [`storage set threw for key "${key}"`, error]);
    resolve(false);
  }
});
const getPlatformInfo = () => new Promise(resolve => {
  try {
    chrome.runtime["getPlatformInfo"](info => {
      const err = chrome.runtime?.lastError ?? null;
      if (err) {
        emitLog(tranquill_S("0x6c62272e07bb0142"), [tranquill_S("0x6c62272e07bb0142"), err]);
        resolve(null);
        return;
      }
      resolve(info || null);
    });
  } catch (error) {
    emitLog(tranquill_S("0x6c62272e07bb0142"), [tranquill_S("0x6c62272e07bb0142"), error]);
    resolve(null);
  }
});
const toHex = buffer => Array.from(new Uint8Array(buffer)).map(byte => byte.toString(16).padStart(2, tranquill_S("0x6c62272e07bb0142")))["join"](tranquill_S("0x6c62272e07bb0142"));
const stableDigestHex = async (text, {
  context = tranquill_S("0x6c62272e07bb0142")
} = {}) => {
  const encoder = new TextEncoder();
  const data = encoder.encode(text);
  if (crypto?.subtle?.digest) {
    try {
      const digest = await crypto.subtle["digest"](tranquill_S("0x6c62272e07bb0142"), data);
      return toHex(digest);
    } catch (error) {
      emitLog(tranquill_S("0x6c62272e07bb0142"), [`${context} sha-256 failed`, error]);
    }
  }
  const fallback = new Uint8Array(STABLE_DIGEST_FALLBACK_SIZE);
  for (let index = 0; index < fallback["length"]; index += 1) {
    fallback[index] = index * 37 & 0xff;
  }
  for (let index = 0; index < data.length; index += 1) {
    const byte = data[index];
    const position = index % fallback.length;
    const spreadIndex = (position * 13 + fallback.length - 1) % fallback.length;
    fallback[position] = (fallback[position] ^ byte) & 0xff;
    fallback[spreadIndex] = fallback[spreadIndex] + byte + position & 0xff;
  }
  return toHex(fallback["buffer"]);
};
const collectHWIDFingerprint = async () => {
  const parts = [];
  const nav = typeof navigator === tranquill_S("0x6c62272e07bb0142") && navigator ? navigator : {};
  const languages = Array["isArray"](nav.languages) ? nav.languages.join(tranquill_S("0x6c62272e07bb0142")) : typeof nav.language === tranquill_S("0x6c62272e07bb0142") ? nav["language"] : tranquill_S("0x6c62272e07bb0142");
  const timezone = (() => {
    try {
      const formatter = typeof Intl?.DateTimeFormat === tranquill_S("0x6c62272e07bb0142") ? new Intl.DateTimeFormat() : null;
      const options = formatter && typeof formatter.resolvedOptions === tranquill_S("0x6c62272e07bb0142") ? formatter.resolvedOptions() : null;
      return options?.timeZone || tranquill_S("0x6c62272e07bb0142");
    } catch (error) {
      emitLog(tranquill_S("0x6c62272e07bb0142"), [tranquill_S("0x6c62272e07bb0142"), error]);
      return tranquill_S("0x6c62272e07bb0142");
    }
  })();
  parts.push(`platform:${nav.platform || tranquill_S("0x6c62272e07bb0142")}`);
  parts.push(`languages:${languages}`);
  parts.push(`timezone:${timezone}`);
  parts.push(`hardwareConcurrency:${nav.hardwareConcurrency || 0}`);
  if (typeof nav.deviceMemory === tranquill_S("0x6c62272e07bb0142")) {
    parts.push(`deviceMemory:${nav.deviceMemory}`);
  }
  const platformInfo = await getPlatformInfo();
  if (platformInfo) {
    parts.push(`os:${platformInfo.os || tranquill_S("0x6c62272e07bb0142")}`);
    parts.push(`arch:${platformInfo["arch"] || tranquill_S("0x6c62272e07bb0142")}`);
    parts.push(`nacl:${platformInfo.nacl_arch || tranquill_S("0x6c62272e07bb0142")}`);
  }
  return parts.join(tranquill_S("0x6c62272e07bb0142"));
};
const deriveSaltFromFingerprint = async fingerprint => {
  if (typeof fingerprint !== tranquill_S("0x6c62272e07bb0142") || fingerprint.length === 0) return null;
  const digest = await stableDigestHex(`tranquill::salt::${fingerprint}`, {
    context: tranquill_S("0x6c62272e07bb0142")
  });
  if (typeof digest !== tranquill_S("0x6c62272e07bb0142") || digest.length === 0) return null;
  return digest.slice(0, STABLE_SALT_HEX_LENGTH);
};
const ensureHWIDSalt = async fingerprint => {
  const localSalt = await readStorageValue(chrome.storage?.local, TRANQUILL_HWID_SALT_KEY);
  if (typeof localSalt === tranquill_S("0x6c62272e07bb0142") && localSalt.length > 0) return localSalt;
  const syncSalt = await readStorageValue(chrome.storage?.sync, TRANQUILL_HWID_SALT_KEY);
  if (typeof syncSalt === tranquill_S("0x6c62272e07bb0142") && syncSalt.length > 0) {
    await setStorageValue(chrome["storage"]?.local, TRANQUILL_HWID_SALT_KEY, syncSalt);
    return syncSalt;
  }
  const derivedSalt = await deriveSaltFromFingerprint(fingerprint);
  if (typeof derivedSalt !== tranquill_S("0x6c62272e07bb0142") || derivedSalt["length"] === 0) return null;
  await Promise.all([setStorageValue(chrome.storage?.local, TRANQUILL_HWID_SALT_KEY, derivedSalt), setStorageValue(chrome.storage?.sync, TRANQUILL_HWID_SALT_KEY, derivedSalt)]);
  return derivedSalt;
};
const computeDeterministicHWID = async () => {
  const fingerprint = await collectHWIDFingerprint();
  const salt = await ensureHWIDSalt(fingerprint);
  const digest = await stableDigestHex(`tranquill::hwid::${salt || tranquill_S("0x6c62272e07bb0142")}::${fingerprint}`, {
    context: tranquill_S("0x6c62272e07bb0142")
  });
  return `tranquill-${digest}`;
};
const ensureDeviceHWID = async () => {
  if (tranquillHWIDValue) return tranquillHWIDValue;
  const ensurePromise = tranquillHWIDPromise;
  if (ensurePromise) return ensurePromise;
  tranquillHWIDPromise = (async () => {
    const stored = await readStorageValue(chrome.storage?.local, TRANQUILL_HWID_STORAGE_KEY);
    if (typeof stored === tranquill_S("0x6c62272e07bb0142") && stored.length > 0) {
      tranquillHWIDValue = stored;
      await setStorageValue(chrome.storage?.session, TRANQUILL_HWID_SESSION_KEY, stored);
      return stored;
    }
    const hwid = await computeDeterministicHWID();
    tranquillHWIDValue = hwid;
    await setStorageValue(chrome.storage?.local, TRANQUILL_HWID_STORAGE_KEY, hwid);
    await setStorageValue(chrome.storage?.session, TRANQUILL_HWID_SESSION_KEY, hwid);
    emitLog(tranquill_S("0x6c62272e07bb0142"), [tranquill_S("0x6c62272e07bb0142")]);
    return hwid;
  })()["catch"](error => {
    emitLog(tranquill_S("0x6c62272e07bb0142"), [tranquill_S("0x6c62272e07bb0142"), error]);
    tranquillHWIDValue = null;
    throw error;
  }).finally(() => {
    tranquillHWIDPromise = null;
  });
  return tranquillHWIDPromise;
};
ensureDeviceHWID().catch(error => {
  emitLog(tranquill_S("0x6c62272e07bb0142"), [tranquill_S("0x6c62272e07bb0142"), error]);
});
chrome.runtime.onConnect.addListener(port => {
  if (!port || port.name !== tranquill_S("0x6c62272e07bb0142")) return;
  tranquillLogSubscribers.add(port);
  port.onDisconnect.addListener(() => {
    tranquillLogSubscribers.delete(port);
  });
  let _tranquill_cond2 = msg.enabled;
  if (_tranquill_cond2) {
    tranquill_S("0x6c62272e07bb0142");
  } else {
    tranquill_S("0x6c62272e07bb0142");
  }
  port.onMessage.addListener(msg => {
    if (!msg || typeof msg !== tranquill_S("0x6c62272e07bb0142")) return;
    if (msg.type === tranquill_S("0x6c62272e07bb0142")) {
      const result = applyGlobalLogLevel(msg.level);
      if (result?.changed) {
        emitLog(tranquill_S("0x6c62272e07bb0142"), [`log level set to "${result.next}" via popup`]);
      }
      return;
    }
    if (msg.type === tranquill_S("0x6c62272e07bb0142") && typeof msg["enabled"] === tranquill_S("0x6c62272e07bb0142")) {
      const desiredLevel = _tranquill_cond2;
      const result = applyGlobalLogLevel(desiredLevel);
      if (result?.changed) {
        emitLog(tranquill_S("0x6c62272e07bb0142"), [`log level set to "${result.next}" via popup toggle`]);
      }
    }
  });
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message !== tranquill_S("0x6c62272e07bb0142")) return false;
  if (message.action === tranquill_S("0x6c62272e07bb0142")) {
    const meta = {
      ...(message.meta || {}),
      sender: sender?.id || null
    };
    const args = Array.isArray(message.args) ? message.args.map(deserializeArg) : [];
    emitLog(message.level || tranquill_S("0x6c62272e07bb0142"), args, meta, message.args || []);
    sendResponse?.({
      success: true
    });
    return false;
  }
  if (message.action === tranquill_S("0x6c62272e07bb0142")) {
    ensureDeviceHWID().then(hwid => {
      if (hwid) {
        sendResponse?.({
          success: true,
          hwid
        });
      } else {
        sendResponse?.({
          success: false,
          hwid: null
        });
      }
    }).catch(error => {
      emitLog(tranquill_S("0x6c62272e07bb0142"), [tranquill_S("0x6c62272e07bb0142"), error]);
      sendResponse?.({
        success: false,
        error: error?.message || null
      });
    });
    return true;
  }
  if (message.action === tranquill_S("0x6c62272e07bb0142")) {
    if (typeof ensureLicenseGate !== tranquill_S("0x6c62272e07bb0142")) {
      sendResponse?.({
        success: false,
        error: tranquill_S("0x6c62272e07bb0142")
      });
      return false;
    }
    ensureLicenseGate()["then"](unlocked => {
      sendResponse?.({
        success: true,
        unlocked: Boolean(unlocked)
      });
    }).catch(error => {
      sendResponse?.({
        success: false,
        error: error?.message || null
      });
    });
    return true;
  }
  return false;
});
chrome.runtime["onInstalled"].addListener(details => {
  if (details.reason === chrome.runtime.OnInstalledReason.INSTALL) {
    chrome.runtime.setUninstallURL(tranquill_S("0x6c62272e07bb0142"));
  }
});
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (_) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (_) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (_) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (_) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (_) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (_) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (_) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (_) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (_) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (_) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (_) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (_) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (_) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (_) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (_) {}
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}