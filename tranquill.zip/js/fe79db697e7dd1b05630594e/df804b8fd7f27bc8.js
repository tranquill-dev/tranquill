const tranquill_global = typeof self !== "undefined" ? self : globalThis;
if (!tranquill_global.tranquill_runtime_ready) {
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::cd312c1cae0d84219e6e1a7a094b17ad"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = "tranquill_tranquill_tranquill";
        tranquill_global.tranquill_runtime_ready = true;
}

(function tranquill_0() {
  const tranquill_1 = new Uint8Array([206, 146, 69, 104, 154, 39, 195, 43, 88, 96, 4, 44, 150, 54, 247, 56, 75, 100, 21, 100, 154, 33, 155, 55, 20, 190, 88, 117, 211, 249, 223, 59, 5, 138, 75, 102, 215, 232, 151, 55, 18, 159, 80, 148, 130, 91, 235, 87, 64, 156, 44, 208, 128, 92, 234, 113, 68, 141, 55, 134, 130, 109, 255, 82, 110, 157, 126, 153, 137, 79, 241, 91, 66, 157, 4, 151, 49, 30, 105, 76, 56, 201, 47, 216, 101, 30, 104, 24, 53, 218, 62, 157, 114, 11, 111, 92, 87, 57, 200, 32, 148, 251, 15, 231, 19, 57, 196, 38, 134, 238, 15, 212, 71, 40, 203, 54, 155, 249, 14, 126, 78, 49, 23, 189, 140, 246, 208, 58, 74, 39, 22, 187, 136, 251, 199, 126, 237, 93, 242, 52, 174, 159, 181, 115, 169, 92, 245, 53, 168, 155, 184, 100, 237, 31, 96, 102, 59, 220, 34, 33, 124, 91, 97, 97, 58, 218, 38, 44, 46, 29, 100, 109, 34, 222, 33, 0, 62, 207, 87, 195, 252, 8, 144, 68, 51, 204, 76, 192, 247, 8, 166, 1, 47, 204, 65, 204, 254, 9, 182, 25, 235, 118, 245, 219, 172, 49, 242, 26, 230, 96, 231, 207, 140, 39, 187, 8, 232, 97, 254, 217, 136, 49, 183, 29, 175, 52, 215, 5, 122, 226, 158, 158, 141, 60, 222, 5, 103, 252, 158, 134, 232, 114, 141, 81, 103, 191, 210, 140, 228, 119, 184, 74, 36, 169, 205, 197, 186, 60, 214, 64, 43, 240, 158, 147, 238, 121, 137, 12, 103, 225, 128, 197, 252, 22, 222, 5, 103, 252, 158, 197, 167, 60, 151, 67, 103, 244, 159, 128, 235, 53, 222, 87, 34, 168, 203, 151, 233, 60, 152, 68, 43, 175, 219, 222, 141, 60, 222, 5, 103, 252, 158, 197, 167, 127, 145, 75, 52, 168, 158, 151, 167, 33, 222, 64, 43, 242, 217, 128, 243, 94, 145, 80, 41, 184, 215, 139, 224, 95, 146, 76, 34, 178, 202, 183, 226, 127, 138, 13, 110, 231, 180, 197, 167, 60, 222, 5, 103, 252, 158, 134, 232, 114, 141, 81, 103, 164, 158, 216, 167, 81, 159, 81, 47, 242, 204, 138, 242, 114, 154, 13, 53, 242, 210, 128, 225, 104, 222, 14, 103, 174, 144, 146, 238, 120, 138, 77, 104, 238, 151, 222, 141, 60, 222, 5, 103, 252, 158, 197, 167, 127, 145, 75, 52, 168, 158, 156, 167, 33, 222, 104, 38, 168, 214, 203, 245, 115, 139, 75, 35, 244, 204, 203, 243, 115, 142, 5, 108, 252, 243, 132, 243, 116, 208, 72, 46, 178, 150, 151, 169, 116, 155, 76, 32, 180, 202, 202, 181, 48, 222, 23, 119, 245, 151, 222, 141, 60, 222, 5, 103, 252, 158, 197, 167, 127, 145, 75, 52, 168, 158, 140, 233, 117, 138, 5, 122, 252, 197, 197, 229, 105, 156, 71, 43, 185, 205, 223, 243, 110, 139, 64, 107, 252, 221, 132, 233, 127, 155, 73, 38, 190, 210, 128, 189, 104, 140, 80, 34, 240, 158, 134, 235, 117, 155, 75, 51, 132, 132, 157, 171, 60, 157, 73, 46, 185, 208, 145, 222, 38, 135, 9, 103, 190, 203, 145, 243, 115, 144, 31, 119, 240, 158, 135, 242, 104, 138, 74, 41, 175, 132, 212, 167, 97, 197, 47, 103, 252, 158, 197, 167, 60, 222, 5, 33, 179, 204, 197, 175, 127, 145, 75, 52, 168, 158, 145, 167, 115, 152, 5, 28, 254, 211, 138, 242, 111, 155, 65, 40, 171, 208, 199, 171, 62, 147, 74, 50, 175, 219, 144, 247, 62, 210, 7, 36, 176, 215, 134, 236, 62, 163, 12, 103, 185, 210, 203, 227, 117, 141, 85, 38, 168, 221, 141, 194, 106, 155, 75, 51, 244, 208, 128, 240, 60, 179, 74, 50, 175, 219, 160, 241, 121, 144, 81, 111, 168, 146, 197, 238, 114, 151, 81, 110, 245, 133, 239, 167, 60, 222, 5, 103, 252, 158, 197, 243, 110, 135, 5, 60, 252, 219, 137, 169, 122, 145, 70, 50, 175, 150, 158, 167, 108, 140, 64, 49, 185, 208, 145, 212, 127, 140, 74, 43, 176, 132, 197, 243, 110, 139, 64, 103, 161, 151, 222, 167, 97, 222, 70, 38, 168, 221, 141, 167, 103, 222, 64, 43, 242, 216, 138, 228, 105, 141, 13, 110, 231, 158, 152, 141, 60, 222, 5, 103, 252, 158, 197, 167, 117, 152, 5, 111, 170, 215, 128, 240, 35, 208, 67, 40, 191, 203, 150, 174, 60, 136, 76, 34, 171, 144, 131, 232, 127, 139, 86, 111, 245, 133, 239, 167, 60, 222, 5, 103, 252, 158, 197, 245, 121, 138, 80, 53, 178, 158, 145, 245, 105, 155, 30, 77, 252, 158, 197, 167, 60, 222, 88, 124, 214, 180, 197, 167, 60, 222, 5, 103, 191, 209, 139, 244, 104, 222, 86, 34, 176, 234, 138, 194, 114, 154, 5, 122, 252, 150, 129, 232, 127, 210, 5, 34, 176, 151, 197, 186, 34, 222, 94, 77, 252, 158, 197, 167, 60, 222, 5, 103, 191, 209, 139, 244, 104, 222, 86, 103, 225, 158, 129, 232, 127, 208, 66, 34, 168, 237, 128, 235, 121, 157, 81, 46, 179, 208, 218, 169, 52, 215, 30, 103, 181, 216, 197, 175, 61, 141, 5, 59, 160, 158, 196, 226, 112, 215, 5, 53, 185, 202, 144, 245, 114, 197, 47, 103, 252, 158, 197, 167, 60, 222, 5, 36, 179, 208, 150, 243, 60, 140, 68, 41, 187, 219, 197, 186, 60, 154, 74, 36, 242, 221, 151, 226, 125, 138, 64, 21, 189, 208, 130, 226, 52, 215, 30, 77, 252, 158, 197, 167, 60, 222, 5, 103, 174, 223, 139, 224, 121, 208, 86, 34, 176, 219, 134, 243, 82, 145, 65, 34, 159, 209, 139, 243, 121, 144, 81, 52, 244, 219, 137, 174, 39, 222, 87, 38, 178, 217, 128, 169, 127, 145, 73, 43, 189, 206, 150, 226, 52, 152, 68, 43, 175, 219, 204, 188, 22, 222, 5, 103, 252, 158, 197, 167, 60, 141, 11, 53, 185, 211, 138, 241, 121, 191, 73, 43, 142, 223, 139, 224, 121, 141, 13, 110, 231, 158, 150, 169, 125, 154, 65, 21, 189, 208, 130, 226, 52, 140, 68, 41, 187, 219, 204, 188, 22, 222, 5, 103, 252, 158, 197, 250, 39, 244, 47, 103, 252, 158, 197, 167, 60, 138, 87, 62, 252, 197, 239, 167, 60, 222, 5, 103, 252, 158, 197, 168, 51, 222, 98, 40, 179, 217, 137, 226, 60, 186, 74, 36, 175, 158, 140, 225, 110, 159, 72, 34, 214, 158, 197, 167, 60, 222, 5, 103, 252, 221, 138, 233, 111, 138, 5, 46, 186, 204, 132, 234, 121, 222, 24, 103, 184, 209, 134, 242, 113, 155, 75, 51, 242, 207, 144, 226, 110, 135, 118, 34, 176, 219, 134, 243, 115, 140, 13, 96, 181, 216, 151, 230, 113, 155, 11, 35, 179, 221, 150, 170, 104, 155, 93, 51, 185, 200, 128, 233, 104, 138, 68, 53, 187, 219, 145, 170, 117, 152, 87, 38, 177, 219, 201, 167, 117, 152, 87, 38, 177, 219, 203, 227, 115, 157, 86, 106, 168, 219, 157, 243, 121, 136, 64, 41, 168, 202, 132, 245, 123, 155, 81, 96, 245, 133, 239, 167, 60, 222, 5, 103, 252, 158, 197, 238, 122, 222, 13, 46, 186, 204, 132, 234, 121, 193, 11, 36, 179, 208, 145, 226, 114, 138, 114, 46, 178, 218, 138, 240, 35, 208, 65, 40, 191, 203, 136, 226, 114, 138, 12, 103, 167, 180, 197, 167, 60, 222, 5, 103, 252, 158, 197, 167, 127, 145, 75, 52, 168, 158, 146, 238, 114, 222, 24, 103, 181, 216, 151, 230, 113, 155, 11, 36, 179, 208, 145, 226, 114, 138, 114, 46, 178, 218, 138, 240, 48, 222, 65, 40, 191, 158, 216, 167, 107, 151, 75, 105, 184, 209, 134, 242, 113, 155, 75, 51, 231, 180, 197, 167, 60, 222, 5, 103, 252, 158, 197, 167, 127, 145, 75, 52, 168, 158, 145, 230, 110, 153, 64, 51, 252, 131, 197, 227, 115, 157, 11, 54, 169, 219, 151, 254, 79, 155, 73, 34, 191, 202, 138, 245, 52, 217, 126, 36, 179, 208, 145, 226, 114, 138, 64, 35, 181, 202, 132, 229, 112, 155, 24, 101, 168, 204, 144, 226, 62, 163, 2, 110, 252, 194, 153, 167, 120, 145, 70, 105, 190, 209, 129, 254, 39, 244, 5, 103, 252, 158, 197, 167, 60, 222, 5, 103, 181, 216, 197, 175, 127, 146, 76, 36, 183, 248, 138, 228, 105, 141, 13, 51, 189, 204, 130, 226, 104, 210, 5, 48, 181, 208, 204, 174, 60, 133, 5, 52, 185, 210, 177, 232, 89, 144, 65, 111, 184, 209, 134, 171, 60, 138, 68, 53, 187, 219, 145, 174, 39, 222, 87, 34, 168, 203, 151, 233, 60, 133, 5, 52, 169, 221, 134, 226, 111, 141, 31, 51, 174, 203, 128, 171, 60, 157, 81, 63, 230, 156, 129, 232, 127, 141, 8, 46, 186, 204, 132, 234, 121, 220, 5, 58, 231, 158, 152, 141, 60, 222, 5, 103, 252, 158, 197, 167, 97, 244, 5, 103, 252, 158, 197, 167, 60, 222, 10, 104, 252, 249, 128, 233, 121, 140, 76, 36, 214, 158, 197, 167, 60, 222, 5, 103, 252, 221, 138, 233, 111, 138, 5, 34, 184, 158, 216, 167, 120, 145, 70, 50, 177, 219, 139, 243, 50, 143, 80, 34, 174, 199, 182, 226, 112, 155, 70, 51, 179, 204, 205, 160, 71, 157, 74, 41, 168, 219, 139, 243, 121, 154, 76, 51, 189, 220, 137, 226, 33, 220, 81, 53, 169, 219, 199, 218, 48, 222, 65, 46, 170, 229, 151, 232, 112, 155, 24, 101, 168, 219, 157, 243, 126, 145, 93, 101, 129, 146, 197, 243, 121, 134, 81, 38, 174, 219, 132, 171, 60, 151, 75, 55, 169, 202, 190, 243, 101, 142, 64, 122, 254, 202, 128, 255, 104, 220, 120, 96, 245, 133, 239, 167, 60, 222, 5, 103, 252, 158, 197, 238, 122, 222, 13, 36, 176, 215, 134, 236, 90, 145, 70, 50, 175, 150, 128, 227, 48, 222, 82, 46, 178, 218, 138, 240, 53, 215, 5, 53, 185, 202, 144, 245, 114, 222, 94, 103, 175, 203, 134, 228, 121, 141, 86, 125, 168, 204, 144, 226, 48, 222, 70, 51, 164, 132, 199, 226, 120, 151, 81, 38, 190, 210, 128, 165, 60, 131, 30, 77, 252, 158, 197, 167, 60, 222, 5, 103, 174, 219, 145, 242, 110, 144, 5, 60, 252, 205, 144, 228, 127, 155, 86, 52, 230, 216, 132, 235, 111, 155, 5, 58, 231, 180, 197, 167, 60, 222, 5, 103, 161, 158, 134, 230, 104, 157, 77, 103, 244, 219, 204, 167, 103, 222, 87, 34, 168, 203, 151, 233, 60, 133, 5, 52, 169, 221, 134, 226, 111, 141, 31, 33, 189, 210, 150, 226, 48, 222, 64, 53, 174, 209, 151, 189, 60, 155, 26, 105, 177, 219, 150, 244, 125, 153, 64, 103, 161, 133, 197, 250, 22, 222, 5, 103, 252, 195, 204, 175, 53, 197, 21, 66, 190, 244, 110, 154, 245, 238, 34, 65, 177, 236, 114, 150, 228, 165, 108, 41, 35, 242, 149, 98, 34, 164, 86, 103, 36, 255, 154, 114, 113, 240, 92, 35, 43, 228, 150, 117, 75, 168, 202, 243, 136, 234, 13, 180, 15, 171, 199, 229, 154, 254, 45, 162, 70, 185, 201, 228, 131, 232, 41, 180, 74, 172, 136, 245, 154, 238, 11, 163, 92, 190, 229, 234, 24, 61, 166, 168, 223, 122, 161, 251, 3, 56, 164, 140, 210, 105, 243, 238, 25, 60, 164, 189, 34, 187, 132, 107, 223, 59, 80, 183, 24, 165, 149, 106, 200, 125, 127, 187, 18, 144, 130, 123, 197, 97]);
  const tranquill_2 = self["tranquill_PACK"] = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  tranquill_2["data"]["push"](tranquill_1);
  const tranquill_3 = tranquill_2["data"]["length"] - 1;
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 0,
    len: 3,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 3,
    len: 19,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 22,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 43,
    len: 31,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 74,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 96,
    len: 23,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 119,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 136,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 153,
    len: 22,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 175,
    len: 23,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 198,
    len: 26,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 224,
    len: 1643,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1867,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1883,
    len: 22,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1905,
    len: 34,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1939,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1961,
    len: 22,
    kind: 1
  });
})();
class tranquill_4 {
  constructor() {
    this.attachedTabId = null;
    this.protocolVersion = tranquill_S("0x6c62272e07bb0142");
  }
  isAttached() {
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      attachedTabId: this.attachedTabId
    });
    return this.attachedTabId !== null;
  }
  isAttachedTo(tranquill_5) {
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      tabId: tranquill_5,
      attachedTabId: this.attachedTabId
    });
    return this["attachedTabId"] === tranquill_5;
  }
  async getActiveTabId() {
    log.debug(tranquill_S("0x6c62272e07bb0142"));
    const tranquill_6 = await ChromeAsync.tabsQuery({
      active: true,
      currentWindow: true
    });
    if (!tranquill_6?.length) throw new Error(tranquill_S("0x6c62272e07bb0142"));
    return tranquill_6[0].id;
  }
  async ensureAttached() {
    const tranquill_7 = await this.getActiveTabId();
    log["debug"](tranquill_S("0x6c62272e07bb0142"), {
      tabId: tranquill_7,
      currentlyAttached: this.attachedTabId
    });
    if (this.attachedTabId === tranquill_7) return tranquill_7;
    await ChromeAsync.debuggerAttach(tranquill_7, this.protocolVersion);
    this["attachedTabId"] = tranquill_7;
    log["info"](tranquill_S("0x6c62272e07bb0142"), {
      tabId: tranquill_7
    });
    return tranquill_7;
  }
  async detach() {
    if (this.attachedTabId === null) return;
    const tranquill_8 = this.attachedTabId;
    this.attachedTabId = null;
    try {
      await ChromeAsync.debuggerDetach(tranquill_8);
      log.info(tranquill_S("0x6c62272e07bb0142"), {
        tabId: tranquill_8
      });
    } catch (tranquill_9) {
      log["warn"](tranquill_S("0x6c62272e07bb0142"), tranquill_9);
    }
  }
  handleDetached(tranquill_a) {
    log.warn(tranquill_S("0x6c62272e07bb0142"), {
      tabId: tranquill_a,
      attachedTabId: this.attachedTabId
    });
    if (this.attachedTabId === tranquill_a) this.attachedTabId = null;
  }
  async focusEditableArea(tranquill_b) {
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      tabId: tranquill_b
    });
    const tranquill_c = tranquill_S("0x6c62272e07bb0142");
    const tranquill_d = await ChromeAsync["debuggerSend"](tranquill_b, tranquill_S("0x6c62272e07bb0142"), {
      expression: tranquill_c,
      returnByValue: true,
      includeCommandLineAPI: false
    });
    const tranquill_e = tranquill_d?.result?.value;
    if (!tranquill_e || tranquill_e.success !== true) throw new Error(tranquill_S("0x6c62272e07bb0142"));
    log["debug"](tranquill_S("0x6c62272e07bb0142"), {
      tabId: tranquill_b,
      context: tranquill_e?.ctx ?? null
    });
  }
  async typeCharacter(tranquill_g, tranquill_h) {
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      tabId: tranquill_g,
      character: tranquill_h
    });
    const tranquill_i = KeyEventFactory.build(tranquill_h);
    for (const tranquill_j of tranquill_i) {
      await ChromeAsync["debuggerSend"](tranquill_g, tranquill_S("0x6c62272e07bb0142"), tranquill_j);
    }
  }
}
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}