const tranquill_global = typeof self !== "undefined" ? self : globalThis;
if (!tranquill_global.tranquill_runtime_ready) {
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::cd312c1cae0d84219e6e1a7a094b17ad"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = "tranquill_tranquill_tranquill";
        tranquill_global.tranquill_runtime_ready = true;
}

(function tranquill_0() {
  const tranquill_1 = new Uint8Array([114, 113, 136, 132, 133, 138, 156, 146, 151, 128, 147, 144, 131, 135, 150, 128, 151, 147, 151, 153, 158, 136, 153, 142, 155, 156, 128, 144, 134, 130, 151, 155, 137, 130, 169, 185, 164, 169, 177, 180, 187, 173, 189, 189, 186, 188, 166, 187, 186, 190, 162, 164, 164, 163, 167, 167, 162, 167, 183, 168, 175, 175, 161, 170, 43, 45, 86, 85, 81, 76, 84, 86, 78, 89, 82, 82, 83, 64, 82, 69, 84, 84, 87, 84, 95, 74, 76, 83, 80, 64, 77, 79, 70, 66, 68, 64, 80, 65, 108, 123, 103, 111, 127, 121, 109, 127, 127, 99, 116, 103, 107, 72, 65, 81, 56, 140, 133, 149, 244, 64, 73, 89, 48, 132, 141, 157, 236, 88, 81, 65, 40, 156, 149, 133, 228, 80, 89, 174, 82, 235, 111, 187, 20, 229, 107, 0, 153, 158, 79, 221, 74, 30, 7, 20, 69, 195, 212, 8, 152, 6, 89, 56, 178, 15, 80, 211, 101, 155, 196, 6, 175, 64, 82, 223, 121, 138, 128, 86, 187, 64, 86, 150, 105, 150, 148, 31, 179, 72, 34, 96, 158, 48, 211, 105, 68, 110, 67, 51, 143, 58, 208, 105, 69, 103, 67, 41, 153, 105, 194, 108, 88, 108, 2, 36, 147, 105, 209, 117, 68, 103, 10, 46, 141, 199, 191, 28, 96, 0, 226, 211, 53, 148, 191, 4, 98, 29, 229, 218, 114, 199, 174, 14, 97, 29, 228, 211, 250, 6, 245, 130, 43, 138, 32, 81, 246, 13, 226, 134, 42, 217, 112, 69, 248, 3, 252, 106, 22, 54, 181, 63, 220, 113, 160, 105, 29, 60, 180, 45, 219, 121, 229, 44, 24, 39, 165, 45, 156, 59, 34, 190, 73, 52, 100, 239, 147, 32, 32, 169, 86, 113, 33, 234, 136, 49, 32, 235, 92, 117, 104, 231, 159, 48, 187, 236, 51, 227, 127, 43, 255, 166, 190, 36, 251, 48, 87, 152, 24, 116, 144, 84, 93, 141, 247, 16, 63, 111, 164, 240, 102, 57, 226, 227, 63, 120, 185, 228, 125, 47, 229, 176, 111, 34, 165, 247, 110, 56, 226, 234, 111, 108, 183, 234, 99, 71, 94, 204, 9, 157, 128, 92, 211, 86, 84, 207, 9, 156, 137, 92, 205, 82, 85, 215, 5, 151, 199, 29, 195, 71, 78, 202, 5, 12, 235, 212, 84, 200, 172, 24, 251, 170, 115, 85, 191, 237, 63, 219, 234, 161, 102, 82, 189, 227, 38, 146, 228, 172, 50, 93, 170, 235, 62, 158, 239, 40, 243, 208, 60, 204, 180, 28, 50, 53, 244, 213, 55, 152, 184, 30, 103, 20, 255, 145, 60, 215, 175, 81, 112, 29, 187, 208, 49, 204, 178, 7, 115, 12, 254, 213, 182, 16, 236, 145, 242, 215, 160, 31, 171, 23, 233, 154, 166, 202, 168, 94, 162, 1, 193, 125, 204, 100, 27, 35, 92, 33, 218, 107, 204, 45, 16, 54, 14, 34, 199, 223, 81, 20, 174, 24, 140, 219, 123, 140, 68, 0, 168, 3, 197, 193, 101, 220, 76, 27, 187, 76, 137, 218, 115, 220, 121, 95, 114, 192, 32, 137, 52, 83, 33, 91, 117, 199, 38, 211, 96, 21, 104, 83, 108, 97, 236, 61, 191, 96, 173, 112, 224, 105, 247, 46, 240, 44, 182, 102, 224, 32, 250, 38, 189, 48, 181, 108, 228, 101, 181, 101, 255, 232, 178, 121, 229, 240, 96, 165, 36, 61, 203, 163, 146, 16, 221, 121, 76, 128, 0, 174, 155, 15, 148, 126, 69, 202, 17, 180, 159, 5, 208, 38, 35, 229, 82, 244, 105, 165, 134, 188, 43, 235, 28, 225, 124, 188, 149, 187, 34, 172, 79, 240, 118, 191, 149, 186, 43, 102, 241, 62, 14, 162, 54, 242, 111, 24, 247, 7, 171, 223, 59, 137, 123, 21, 247, 10, 171, 217, 32, 200, 107, 21, 182, 15, 190, 217, 58, 243, 18, 66, 53, 176, 208, 5, 114, 183, 19, 69, 52, 182, 212, 8, 32, 248, 25, 0, 38, 190, 217, 1, 108, 254, 13, 69, 96, 177, 214, 9, 108, 58, 34, 144, 79, 10, 15, 23, 125, 219, 131, 194, 174, 6, 4, 0, 121, 218, 208, 146, 244, 13, 12, 28, 121, 128, 131, 212, 189, 0, 15, 186, 80, 97, 143, 227, 134, 39, 28, 226, 83, 122, 146, 235, 153, 58, 70, 175, 28, 51, 154, 235, 156, 63, 215, 137, 198, 184, 29, 73, 18, 124, 145, 131, 199, 180, 1, 76, 13, 109, 212, 232, 121, 123, 166, 123, 191, 177, 103, 238, 104, 103, 162, 62, 169, 244, 227, 44, 188, 48, 36, 224, 96, 73, 39, 173, 59, 146, 110, 163, 98, 84, 40, 173, 38, 147, 100, 163, 99, 73, 44, 182, 55, 220, 125, 226, 97, 87, 129, 200, 137, 247, 69, 15, 69, 121, 133, 193, 155, 242, 17, 6, 73, 48, 157, 135, 3, 234, 209, 71, 216, 62, 68, 146, 5, 250, 202, 86, 194, 54, 68, 150, 31, 242, 195, 69, 200, 41, 52, 230, 41, 244, 116, 189, 125, 225, 33, 224, 57, 239, 101, 167, 117, 225, 51, 233, 59, 234, 98, 184, 121, 162, 52, 82, 245, 58, 58, 150, 50, 246, 64, 20, 24, 62, 149, 213, 196, 244, 94, 1, 87, 45, 152, 199, 217, 233, 95, 11, 87, 41, 130, 207, 208, 250, 85, 20, 252, 168, 34, 41, 184, 239, 110, 39, 255, 180, 38, 55, 8, 165, 182, 112, 223, 253, 197, 148, 13, 170, 31, 82, 65, 68, 194, 129, 34, 196, 154, 86, 213, 2, 55, 74, 120, 198, 240, 134, 133, 11, 49, 95, 126, 215, 235, 130, 181, 33, 43, 74, 100, 198, 2, 50, 216, 63, 198, 117, 20, 49, 1, 35, 215, 37, 218, 127, 13, 120, 17, 122, 202, 37, 211, 104, 13, 49, 28, 53, 205, 113, 211, 121, 18, 127, 29, 45, 213, 52, 214, 125, 28, 117, 206, 138, 20, 135, 10, 77, 216, 9, 202, 155, 5, 140, 61, 74, 212, 91, 223, 129, 1, 140, 12, 2, 211, 72, 215, 142, 16, 141, 227, 136, 123, 135, 39, 79, 183, 122, 234, 142, 110, 129, 54, 84, 179, 74, 214, 142, 126, 122, 107, 178, 212, 62, 44, 254, 90, 111, 109, 183, 154, 36, 44, 231, 19, 108, 122, 243, 220, 43, 42, 255, 31, 110, 157, 240, 149, 207, 89, 55, 89, 50, 148, 246, 128, 201, 72, 44, 93, 2, 172, 250, 155, 211, 89, 170, 25, 194, 198, 110, 222, 14, 72, 187, 19, 204, 218, 110, 145, 13, 7, 174, 24, 197, 209, 58, 215, 2, 1, 182, 20, 199, 72, 238, 30, 227, 140, 169, 210, 237, 76, 255, 15, 232, 216, 163, 205, 191, 87, 244, 90, 189, 131, 44, 131, 107, 69, 191, 2, 168, 153, 62, 132, 108, 94, 242, 3, 248, 151, 62, 131, 116, 229, 40, 237, 87, 161, 111, 161, 217, 230, 52, 233, 73, 245, 99, 163, 148, 229, 44, 233, 77, 176, 15, 121, 153, 36, 203, 62, 85, 42, 15, 125, 153, 36, 159, 52, 64, 98, 30, 100, 139, 62, 218, 53, 40, 63, 192, 112, 236, 248, 12, 28, 194, 76, 84, 201, 3, 144, 158, 2, 215, 3, 71, 196, 17, 141, 131, 3, 221, 3, 85, 205, 19, 136, 132, 28, 209, 64, 82, 187, 234, 51, 149, 255, 173, 127, 104, 178, 236, 38, 147, 238, 182, 123, 88, 137, 227, 49, 144, 248, 178, 115, 88, 174, 196, 203, 12, 132, 0, 12, 192, 10, 214, 194, 14, 129, 7, 19, 204, 73, 209, 131, 3, 133, 0, 10, 203, 83, 148, 197, 12, 131, 24, 6, 201, 243, 106, 147, 178, 220, 46, 84, 254, 82, 120, 154, 176, 217, 41, 75, 242, 17, 127, 219, 183, 219, 41, 75, 242, 6, 121, 147, 243, 212, 59, 82, 255, 23, 126, 138, 191, 51, 146, 83, 233, 117, 129, 210, 170, 41, 128, 84, 238, 110, 204, 218, 184, 32, 130, 81, 233, 113, 192, 153, 191, 104, 193, 92, 251, 104, 205, 63, 236, 183, 19, 123, 171, 251, 157, 45, 229, 181, 22, 124, 180, 247, 222, 42, 164, 166, 15, 96, 167, 243, 206, 60, 225, 178, 88, 102, 149, 63, 130, 184, 118, 226, 77, 107, 144, 37, 175, 183, 68, 248, 75, 122, 129, 69, 183, 237, 62, 190, 100, 39, 245, 112, 242, 235, 53, 179, 239, 6, 100, 33, 181, 216, 116, 123, 239, 30, 96, 61, 168, 159, 54, 122, 244, 30, 112, 43, 186, 204, 32, 40, 253, 30, 125, 36, 31, 250, 236, 45, 213, 186, 184, 105, 89, 242, 228, 56, 220, 161, 226, 104, 28, 231, 227, 47, 209, 243, 164, 109, 16, 255]);
  const tranquill_2 = self["tranquill_PACK"] = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  tranquill_2["data"].push(tranquill_1);
  const tranquill_3 = tranquill_2.data.length - 1;
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 0,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 2,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 3,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 4,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 5,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 6,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 7,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 8,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 9,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 10,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 11,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 12,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 13,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 14,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 15,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 16,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 17,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 18,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 19,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 20,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 21,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 22,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 23,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 24,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 25,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 26,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 27,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 28,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 29,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 30,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 31,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 32,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 33,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 34,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 35,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 36,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 37,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 38,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 39,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 40,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 41,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 42,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 43,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 44,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 45,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 46,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 47,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 48,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 49,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 50,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 51,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 52,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 53,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 54,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 55,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 56,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 57,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 58,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 59,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 60,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 61,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 62,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 63,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 64,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 65,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 66,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 67,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 68,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 69,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 70,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 71,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 72,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 73,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 74,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 75,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 76,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 77,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 78,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 79,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 80,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 81,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 82,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 83,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 84,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 85,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 86,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 87,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 88,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 89,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 90,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 91,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 92,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 93,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 94,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 95,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 96,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 97,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 98,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 99,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 100,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 101,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 102,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 103,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 104,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 105,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 106,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 107,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 108,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 109,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 110,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 111,
    len: 26,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 137,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 145,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 151,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 157,
    len: 0,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 157,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 161,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 161,
    len: 27,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 188,
    len: 35,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 223,
    len: 23,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 246,
    len: 19,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 265,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 286,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 312,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 319,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 323,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 330,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 334,
    len: 29,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 363,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 391,
    len: 7,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 398,
    len: 25,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 423,
    len: 35,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 458,
    len: 18,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 476,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 493,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 518,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 537,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 562,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 566,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 566,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 574,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 575,
    len: 20,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 595,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 596,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 621,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 628,
    len: 23,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 651,
    len: 32,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 683,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 683,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 687,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 713,
    len: 23,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 736,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 753,
    len: 14,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 767,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 774,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 800,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 817,
    len: 23,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 840,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 865,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 872,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 898,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 910,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 920,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 926,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 931,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 952,
    len: 40,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 992,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1020,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1039,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1064,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1085,
    len: 27,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1112,
    len: 18,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1130,
    len: 22,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1152,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1173,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1195,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1202,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1230,
    len: 25,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1255,
    len: 31,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1286,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1287,
    len: 33,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1320,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1352,
    len: 27,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1379,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1398,
    len: 13,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1411,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1439,
    len: 26,
    kind: 1
  });
})();
const tranquill_4 = Object.freeze({
  a: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  b: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  c: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  d: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  e: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  f: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  g: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  h: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  i: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  j: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  k: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  l: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  m: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  n: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  o: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  p: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  q: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  r: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  s: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  t: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  u: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  v: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  w: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  x: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  y: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  z: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")]
});
const tranquill_5 = tranquill_S("0x6c62272e07bb0142");
const tranquill_6 = tranquill_S("0x6c62272e07bb0142");
const tranquill_7 = tranquill_8 => {
  if (!Array.isArray(tranquill_8) || tranquill_8.length === 0) return null;
  const tranquill_9 = Math.floor(Math.random() * tranquill_8.length);
  return tranquill_8[tranquill_9];
};
const tranquill_a = tranquill_b => {
  if (!tranquill_b || typeof tranquill_b !== tranquill_S("0x6c62272e07bb0142")) return null;
  const tranquill_e = tranquill_b.charAt(0);
  if (!tranquill_6.test(tranquill_e)) return null;
  const tranquill_f = tranquill_e.toLowerCase();
  const tranquill_g = (tranquill_4[tranquill_f] || []).filter(tranquill_h => typeof tranquill_h === tranquill_S("0x6c62272e07bb0142") && tranquill_h.toLowerCase() !== tranquill_f);
  let candidate = null;
  if (tranquill_g.length && Math.random() < 0.75) candidate = tranquill_7(tranquill_g);
  if (!candidate) {
    const tranquill_j = tranquill_5.replace(tranquill_f, tranquill_S("0x6c62272e07bb0142"));
    if (!tranquill_j.length) return null;
    candidate = tranquill_j["charAt"](Math.floor(Math.random() * tranquill_j.length));
  }
  if (!candidate) return null;
  if (tranquill_e === tranquill_e.toUpperCase()) candidate = candidate.toUpperCase();
  if (candidate["toLowerCase"]() === tranquill_f) return null;
  return candidate;
};
class tranquill_k {
  constructor({
    debuggerManager: tranquill_l,
    typingModel: tranquill_m,
    phantomController: tranquill_n
  }) {
    this["debuggerManager"] = tranquill_l;
    this.typingModel = tranquill_m;
    this.phantomController = tranquill_n;
    this.isRunning = false;
    this.activeTabId = null;
    this.plan = null;
    this.delayController = null;
    this.ghostModeEnabled = true;
    this.ghostRevisions = [];
    this.mode = tranquill_S("0x6c62272e07bb0142");
    this["sourceText"] = tranquill_S("0x6c62272e07bb0142");
    this.lastOutputCharacter = null;
    this.textSignature = null;
    this.currentIndex = 0;
    this.totalCharacters = 0;
    this["_phantomQueue"] = Promise.resolve();
    this._finalized = false;
  }
  isActive() {
    return this.isRunning;
  }
  async start({
    text: tranquill_o,
    startIndex: tranquill_p = 0,
    settings: tranquill_q = {}
  }) {
    if (!tranquill_o || !String(tranquill_o).trim()) throw new Error(tranquill_S("0x6c62272e07bb0142"));
    if (this.isRunning) throw new Error(tranquill_S("0x6c62272e07bb0142"));
    log["info"](tranquill_S("0x6c62272e07bb0142"), {
      requestedStartIndex: tranquill_p,
      textLength: tranquill_o?.length ?? 0,
      phantomMode: tranquill_q?.phantomMode === true
    });
    let idx = Math.min(Math.max(tranquill_p, 0), tranquill_o.length);
    if (idx >= tranquill_o.length) {
      idx = 0;
      await TextStorage.clearProgress().catch(tranquill_s => log["warn"](tranquill_S("0x6c62272e07bb0142"), tranquill_s));
    }
    const tranquill_t = await this.debuggerManager.ensureAttached();
    this.activeTabId = tranquill_t;
    try {
      await this.debuggerManager["focusEditableArea"](tranquill_t);
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        tabId: tranquill_t
      });
    } catch (tranquill_u) {
      await this.debuggerManager.detach();
      this.activeTabId = null;
      log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_u);
      throw tranquill_u;
    }
    this["mode"] = tranquill_q.phantomMode === true ? tranquill_S("0x6c62272e07bb0142") : tranquill_S("0x6c62272e07bb0142");
    this.ghostModeEnabled = tranquill_q["ghostMode"] !== false && this.mode !== tranquill_S("0x6c62272e07bb0142");
    this["sourceText"] = String(tranquill_o);
    this["textSignature"] = TextStorage.createTextSignature(this["sourceText"]);
    this["_finalized"] = false;
    this._phantomQueue = Promise.resolve();
    const tranquill_v = new TypingPlan(this["sourceText"], this.typingModel, idx);
    this.plan = tranquill_v;
    this.totalCharacters = tranquill_v.length;
    this.currentIndex = tranquill_v["currentIndex"];
    this.lastOutputCharacter = idx > 0 ? this.sourceText[idx - 1] : null;
    this["ghostRevisions"] = this.ghostModeEnabled ? new RevisionPlanner(this.sourceText, this.typingModel, idx).build() : [];
    this.delayController = this.mode === tranquill_S("0x6c62272e07bb0142") ? new DelayController() : null;
    await TextStorage.setProgress(this.currentIndex, this.textSignature).catch(tranquill_w => log["warn"](tranquill_S("0x6c62272e07bb0142"), tranquill_w));
    this.isRunning = true;
    this.#broadcastTyping(true);
    log.info(tranquill_S("0x6c62272e07bb0142"), {
      mode: this.mode,
      tabId: tranquill_t,
      startingIndex: this.currentIndex,
      totalCharacters: this.totalCharacters
    });
    if (this.mode === tranquill_S("0x6c62272e07bb0142")) {
      await this.phantomController.waitUntilReady(tranquill_t);
      const tranquill_x = await this.phantomController.setActive(tranquill_t, true);
      if (!tranquill_x) {
        log.error(tranquill_S("0x6c62272e07bb0142"), {
          tabId: tranquill_t
        });
        await this.finalize({
          completed: false,
          detachDebugger: true
        });
        throw new Error(tranquill_S("0x6c62272e07bb0142"));
      }
      log["info"](tranquill_S("0x6c62272e07bb0142"), {
        tabId: tranquill_t
      });
      return;
    }
    (async () => {
      let completed = false;
      try {
        completed = await this.#runAuto(tranquill_v);
      } catch (tranquill_z) {
        log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_z);
      } finally {
        await this.finalize({
          completed,
          detachDebugger: true
        });
      }
    })();
  }
  async #runAuto(tranquill_A) {
    const tranquill_B = this["delayController"];
    if (!tranquill_A || !tranquill_B) return false;
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      remaining: Math.max(0, tranquill_A.length - tranquill_A.currentIndex)
    });
    while (this["isRunning"] && tranquill_A.hasNext()) {
      const tranquill_E = tranquill_A.peek();
      if (!tranquill_E) break;
      await this.#maybeInjectTypo(tranquill_E);
      if (!this.isRunning || this.activeTabId === null) return false;
      await tranquill_B.wait(tranquill_E.delay);
      if (!this.isRunning || this.activeTabId === null) return false;
      await this["debuggerManager"].typeCharacter(this.activeTabId, tranquill_E["character"]);
      this.lastOutputCharacter = tranquill_E.character;
      tranquill_A["advance"]();
      this.currentIndex = tranquill_A.currentIndex;
      await TextStorage["setProgress"](this.currentIndex, this.textSignature)["catch"](tranquill_G => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_G));
      await this.#maybeGhost(tranquill_A.currentIndex);
    }
    log["info"](tranquill_S("0x6c62272e07bb0142"), {
      finished: tranquill_A.hasNext() === false,
      currentIndex: this.currentIndex
    });
    return tranquill_A.hasNext() === false;
  }
  async #maybeGhost(tranquill_H) {
    if (!this.ghostModeEnabled || !this.ghostRevisions?.length) return;
    while (this.ghostRevisions.length && this.ghostRevisions[0].triggerIndex <= tranquill_H) {
      const tranquill_I = this["ghostRevisions"].shift();
      await this.#performGhost(tranquill_I);
      if (!this["isRunning"]) return;
    }
  }
  async #maybeInjectTypo(tranquill_J) {
    if (!this.ghostModeEnabled || this.mode !== tranquill_S("0x6c62272e07bb0142") || !this.delayController || !tranquill_J || !tranquill_6.test(tranquill_J.character || tranquill_S("0x6c62272e07bb0142")) || this["activeTabId"] === null) return false;
    const tranquill_L = 0.05;
    if (Math["random"]() >= tranquill_L) return false;
    const tranquill_M = tranquill_a(tranquill_J["character"]);
    if (!tranquill_M) return false;
    const tranquill_O = this.delayController;
    const tranquill_P = Number.isFinite(tranquill_J.delay) ? tranquill_J.delay : typeof this.typingModel?.baseDelay === tranquill_S("0x6c62272e07bb0142") ? this.typingModel.baseDelay() : 120;
    const tranquill_Q = Math.max(155, Math["round"](tranquill_P * 0.35 + Math.random() * 130));
    if (tranquill_Q > 0) {
      await tranquill_O.wait(tranquill_Q);
      if (!this.isRunning || this["activeTabId"] === null) return true;
    }
    await this.debuggerManager.typeCharacter(this["activeTabId"], tranquill_M);
    this.lastOutputCharacter = tranquill_M;
    const tranquill_R = Math.max(170, Math.round(tranquill_P * 0.25 + Math.random() * 95));
    await tranquill_O.wait(tranquill_R);
    if (!this.isRunning || this.activeTabId === null) return true;
    await this.debuggerManager.typeCharacter(this.activeTabId, tranquill_S("0x6c62272e07bb0142"));
    const tranquill_S = tranquill_J["index"] > 0 ? tranquill_J.index - 1 : -1;
    const tranquill_T = tranquill_S >= 0 && tranquill_S < this.sourceText.length ? this.sourceText[tranquill_S] : null;
    this.lastOutputCharacter = tranquill_T || null;
    const tranquill_U = Math["max"](30, Math.round(tranquill_P * 0.3 + Math.random() * 45));
    await tranquill_O.wait(tranquill_U);
    if (!this.isRunning || this.activeTabId === null) return true;
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      index: tranquill_J.index,
      intended: tranquill_J.character,
      injected: tranquill_M
    });
    return true;
  }
  async #performGhost(tranquill_V) {
    if (!tranquill_V || !tranquill_V.segmentText || !this.delayController || this.activeTabId === null) return;
    if (tranquill_V.pauseBefore > 0) {
      await this["delayController"].wait(tranquill_V["pauseBefore"]);
      if (!this.isRunning) return;
    }
    const tranquill_X = Array.from(tranquill_V.segmentText);
    for (let tranquill_Y = 0; tranquill_Y < tranquill_X.length; tranquill_Y++) {
      const tranquill_10 = Array["isArray"](tranquill_V.backspaceDelays) ? tranquill_V.backspaceDelays[tranquill_Y] || 0 : 0;
      if (tranquill_10 > 0) {
        await this["delayController"].wait(tranquill_10);
        if (!this.isRunning) return;
      }
      await this.debuggerManager["typeCharacter"](this.activeTabId, tranquill_S("0x6c62272e07bb0142"));
    }
    this.lastOutputCharacter = tranquill_V.previousCharacter || null;
    if (!this.isRunning) return;
    if (tranquill_V["pauseAfter"] > 0) {
      await this.delayController["wait"](tranquill_V.pauseAfter);
      if (!this.isRunning) return;
    }
    for (let tranquill_11 = 0; tranquill_11 < tranquill_X["length"]; tranquill_11++) {
      const tranquill_13 = Array.isArray(tranquill_V.retypeDelays) ? tranquill_V.retypeDelays[tranquill_11] || 0 : 0;
      if (tranquill_13 > 0) {
        await this.delayController["wait"](tranquill_13);
        if (!this["isRunning"]) return;
      }
      const tranquill_14 = tranquill_X[tranquill_11];
      await this["debuggerManager"].typeCharacter(this.activeTabId, tranquill_14);
      this.lastOutputCharacter = tranquill_14;
    }
  }
  async finalize({
    completed: tranquill_15 = false,
    detachDebugger: tranquill_16 = true
  } = {}) {
    if (this._finalized) return;
    this._finalized = true;
    log["info"](tranquill_S("0x6c62272e07bb0142"), {
      completed: tranquill_15,
      detachDebugger: tranquill_16,
      tabId: this.activeTabId,
      mode: this.mode,
      currentIndex: this.currentIndex
    });
    const tranquill_17 = this.delayController;
    this.delayController = null;
    if (tranquill_17) tranquill_17.cancel();
    const tranquill_18 = this.mode === tranquill_S("0x6c62272e07bb0142");
    const tranquill_19 = this.activeTabId;
    if (tranquill_18 && tranquill_19 !== null) {
      try {
        await this.phantomController.setActive(tranquill_19, false);
      } catch (tranquill_1a) {
        log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_1a);
      }
    }
    this.activeTabId = null;
    if (tranquill_16 && tranquill_19 !== null) {
      try {
        await this.debuggerManager["detach"]();
      } catch (tranquill_1b) {
        log["warn"](tranquill_S("0x6c62272e07bb0142"), tranquill_1b);
      }
    }
    const tranquill_1c = this["isRunning"];
    this["isRunning"] = false;
    this.plan = null;
    this["ghostRevisions"] = [];
    this.sourceText = tranquill_S("0x6c62272e07bb0142");
    this.lastOutputCharacter = null;
    this.mode = tranquill_S("0x6c62272e07bb0142");
    this._phantomQueue = Promise.resolve();
    if (tranquill_15) {
      await TextStorage["clearProgress"]().catch(tranquill_1d => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_1d));
      this.currentIndex = 0;
      this.totalCharacters = 0;
    } else if (this.totalCharacters > 0) {
      await TextStorage.setProgress(this["currentIndex"], this.textSignature).catch(tranquill_1e => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_1e));
    }
    this.textSignature = null;
    if (tranquill_1c) this.#broadcastTyping(false);
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      clearedProgress: tranquill_15,
      textSignature: this["textSignature"]
    });
  }
  async stop() {
    if (this._finalized && !this["isRunning"]) return;
    this.isRunning = false;
    log.info(tranquill_S("0x6c62272e07bb0142"), {
      currentIndex: this.currentIndex,
      tabId: this.activeTabId
    });
    if (this.delayController) this.delayController.cancel();
    await this.finalize({
      completed: false,
      detachDebugger: true
    });
  }
  #enqueuePhantom(tranquill_1f) {
    this._phantomQueue = (this._phantomQueue || Promise.resolve())["then"](async () => {
      if (!this.isRunning || this["mode"] !== tranquill_S("0x6c62272e07bb0142")) return;
      log.debug(tranquill_S("0x6c62272e07bb0142"));
      await tranquill_1f();
    })["catch"](tranquill_1g => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_1g));
    return this._phantomQueue;
  }
  handlePhantomTrigger(tranquill_1h, tranquill_1i = null, tranquill_1j = null, tranquill_1k = null, tranquill_1l = null) {
    log["debug"](tranquill_S("0x6c62272e07bb0142"), {
      tabId: tranquill_1h,
      requestId: tranquill_1i,
      key: tranquill_1j,
      timeStamp: tranquill_1k,
      frameId: tranquill_1l
    });
    return this.#enqueuePhantom(() => this.#onPhantomTrigger(tranquill_1h, {
      requestId: tranquill_1i,
      key: tranquill_1j,
      timeStamp: tranquill_1k,
      frameId: tranquill_1l
    }));
  }
  handlePhantomBackspace(tranquill_1m, tranquill_1n = null) {
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      tabId: tranquill_1m,
      frameId: tranquill_1n
    });
    return this.#enqueuePhantom(() => this.#onPhantomBackspace(tranquill_1m, tranquill_1n));
  }
  async #onPhantomTrigger(tranquill_1o, tranquill_1p = {}) {
    if (!this.isRunning || this["mode"] !== tranquill_S("0x6c62272e07bb0142") || this["activeTabId"] !== tranquill_1o) return;
    const tranquill_1q = tranquill_1p?.requestId ?? null;
    const tranquill_1r = tranquill_1p?.key ?? null;
    const tranquill_1s = tranquill_1p?.timeStamp ?? null;
    const tranquill_1t = Number.isInteger(tranquill_1p?.frameId) ? tranquill_1p.frameId : null;
    log["debug"](tranquill_S("0x6c62272e07bb0142"), {
      tabId: tranquill_1o,
      requestId: tranquill_1q,
      hasPlan: Boolean(this["plan"]),
      triggerKey: tranquill_1r,
      triggerTime: tranquill_1s,
      frameId: tranquill_1t
    });
    if (!this.plan || !this["plan"]["hasNext"]()) {
      if (this.plan && !this.plan.hasNext()) await this.finalize({
        completed: true,
        detachDebugger: true
      });
      return;
    }
    const tranquill_1u = this["plan"].peek();
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      requestId: tranquill_1q,
      character: tranquill_1u?.character ?? null,
      currentIndex: this.plan.currentIndex
    });
    const tranquill_1v = tranquill_1u && Number.isFinite(tranquill_1u.delay) ? Math.max(220, Math.min(900, tranquill_1u["delay"] + 160)) : 320;
    const tranquill_1w = KeyEventFactory.build(tranquill_1u["character"]);
    const tranquill_1x = tranquill_1w.filter(tranquill_1y => tranquill_1y?.type === tranquill_S("0x6c62272e07bb0142") && typeof tranquill_1y["key"] === tranquill_S("0x6c62272e07bb0142") && (tranquill_1y["key"].length === 1 || tranquill_1y.key === tranquill_S("0x6c62272e07bb0142"))).map(tranquill_1z => tranquill_1z.key);
    const tranquill_1A = tranquill_1t !== null ? {
      frameId: tranquill_1t
    } : undefined;
    const tranquill_1B = await ChromeAsync["tabsSendMessage"](tranquill_1o, {
      action: tranquill_S("0x6c62272e07bb0142"),
      duration: tranquill_1v,
      character: tranquill_1u.character,
      keys: tranquill_1x,
      requestId: tranquill_1q
    }, tranquill_1A);
    let tranquill_1C = tranquill_1B.success && tranquill_1B["response"]?.accepted;
    let typingError = null;
    if (!tranquill_1C) {
      log.warn(tranquill_S("0x6c62272e07bb0142"), {
        requestId: tranquill_1q,
        error: tranquill_1B["error"] || null,
        frameId: tranquill_1t
      });
    }
    try {
      await this["debuggerManager"].typeCharacter(tranquill_1o, tranquill_1u.character);
    } catch (tranquill_1E) {
      typingError = tranquill_1E;
      log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_1E);
    }
    if (tranquill_1C) {
      const tranquill_1F = await ChromeAsync.tabsSendMessage(tranquill_1o, {
        action: tranquill_S("0x6c62272e07bb0142"),
        requestId: tranquill_1q
      }, tranquill_1A);
      if (!tranquill_1F.success) log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_1F.error);
    } else {
      await ChromeAsync.tabsSendMessage(tranquill_1o, {
        action: tranquill_S("0x6c62272e07bb0142"),
        requestId: tranquill_1q,
        character: tranquill_1u.character
      }, tranquill_1A).catch(tranquill_1G => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_1G));
    }
    if (typingError) {
      log.error(tranquill_S("0x6c62272e07bb0142"), typingError);
      await this.finalize({
        completed: false,
        detachDebugger: true
      });
      return;
    }
    this.plan.advance();
    this.currentIndex = this.plan["currentIndex"];
    this.lastOutputCharacter = tranquill_1u["character"];
    await TextStorage.setProgress(this["currentIndex"], this["textSignature"]).catch(tranquill_1H => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_1H));
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      requestId: tranquill_1q,
      index: this.currentIndex,
      remaining: Math.max(0, this["plan"].length - this.currentIndex)
    });
    if (!this.plan["hasNext"]()) {
      log["info"](tranquill_S("0x6c62272e07bb0142"), {
        tabId: tranquill_1o
      });
      await this["finalize"]({
        completed: true,
        detachDebugger: true
      });
    }
  }
  async #onPhantomBackspace(tranquill_1I, tranquill_1J = null) {
    if (!this.isRunning || this["mode"] !== tranquill_S("0x6c62272e07bb0142") || this.activeTabId !== tranquill_1I) return;
    if (!this.plan) return;
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      tabId: tranquill_1I,
      frameId: tranquill_1J
    });
    const tranquill_1K = tranquill_1J !== null ? {
      frameId: tranquill_1J
    } : undefined;
    const tranquill_1L = await ChromeAsync.tabsSendMessage(tranquill_1I, {
      action: tranquill_S("0x6c62272e07bb0142")
    }, tranquill_1K);
    if (!tranquill_1L["success"]) {
      log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_1L.error);
      return;
    }
    let dispatchError = null;
    try {
      await this.debuggerManager.typeCharacter(tranquill_1I, tranquill_S("0x6c62272e07bb0142"));
    } catch (tranquill_1M) {
      dispatchError = tranquill_1M;
      log["error"](tranquill_S("0x6c62272e07bb0142"), tranquill_1M);
    }
    if (dispatchError) return;
    this["plan"].retreat();
    this.currentIndex = this.plan.currentIndex;
    let _tranquill_cond2 = this.currentIndex > 0;
    if (_tranquill_cond2) {
      this["plan"].text[this["currentIndex"] - 1];
    } else {
      null;
    }
    this["lastOutputCharacter"] = _tranquill_cond2;
    await TextStorage["setProgress"](this.currentIndex, this.textSignature).catch(tranquill_1N => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_1N));
    log.info(tranquill_S("0x6c62272e07bb0142"), {
      tabId: tranquill_1I,
      currentIndex: this["currentIndex"]
    });
  }
  #broadcastTyping(tranquill_1O) {
    try {
      chrome.runtime.sendMessage({
        action: tranquill_S("0x6c62272e07bb0142"),
        isTyping: tranquill_1O
      }, () => {
        const tranquill_1P = chrome.runtime.lastError;
        if (tranquill_1P?.message?.includes(tranquill_S("0x6c62272e07bb0142"))) return;
      });
    } catch (tranquill_1Q) {
      log.debug(tranquill_S("0x6c62272e07bb0142"), tranquill_1Q);
    }
  }
  handleDebuggerDetached() {
    if (this._finalized) return;
    if (this.delayController) {
      this.delayController.cancel();
      this["delayController"] = null;
    }
    this.isRunning = false;
    this.finalize({
      completed: false,
      detachDebugger: false
    }).catch(tranquill_1R => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_1R));
  }
}
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}