const tranquill_global = typeof self !== "undefined" ? self : globalThis;
if (!tranquill_global.tranquill_runtime_ready) {
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::cd312c1cae0d84219e6e1a7a094b17ad"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = "tranquill_tranquill_tranquill";
        tranquill_global.tranquill_runtime_ready = true;
}

(function tranquill_0() {
  const tranquill_1 = new Uint8Array([64, 174, 136, 220, 55, 69, 235, 77, 217, 50, 161, 87, 158, 166, 16, 217, 187, 209, 147, 210, 74, 0, 81, 26, 156, 178, 24, 90, 219, 67, 201, 152, 19, 149, 255, 177, 175, 250, 245, 71, 249, 248, 230, 228, 230, 224, 230, 228, 230, 232, 246, 254, 224, 241, 144, 151, 149, 243, 224, 234, 235, 235, 163, 129, 162, 169, 253, 113, 58, 123, 168, 223, 19, 139, 179, 125, 94, 37, 233, 141, 196, 119, 196, 203, 15, 135, 89, 105, 90, 65, 5, 153, 198, 99, 192, 215, 27, 147, 95, 101, 118, 125, 49, 149, 232, 95, 252, 195, 55, 175, 109, 81, 114, 121, 13, 161, 226, 75, 248, 239, 35, 187, 97, 71, 110, 61, 59, 185, 192, 49, 9, 88, 169, 192, 139, 90, 35, 169, 92, 143, 76, 231, 159, 79, 60, 64, 212, 90, 213, 151, 1, 171, 23, 85, 221, 77, 47, 85, 23, 70, 222, 152, 213, 158, 5, 55, 184, 240, 77, 199, 114, 49, 139, 10, 6, 239, 177, 87, 242, 17, 32, 102, 107, 243, 28, 99, 97, 100, 227, 162, 20, 230, 175, 96, 239, 132, 222, 156, 109, 247, 10, 80, 50, 163, 253, 85, 216, 40, 200, 111, 153, 102, 246, 43, 199, 35, 184, 102, 240, 26, 249, 117, 228, 63, 176, 114, 231, 122, 174, 112, 196, 42, 216, 194, 176, 56, 125, 239, 114, 159, 187, 59, 176, 185, 209, 148, 183, 123, 53, 82, 50, 185, 254, 179, 164, 130, 41, 107, 87, 102, 251, 188, 99, 44, 214, 201, 144, 83, 251, 234, 75, 139, 98, 117, 247, 92, 58, 6, 19, 142, 109, 191, 1, 92, 214, 88, 184, 90, 27, 205, 95, 190, 215, 13, 159, 147, 186, 173, 239, 68, 98, 94, 11, 150, 181, 182, 57, 175, 248, 187, 48, 112, 217, 96, 160, 99, 43, 218, 123, 149, 163, 230, 244, 114, 22, 20, 85, 227, 113, 240, 153, 163, 49]);
  const tranquill_2 = self.tranquill_PACK = self["tranquill_PACK"] || {
    idx: new Map(),
    data: []
  };
  tranquill_2.data["push"](tranquill_1);
  const tranquill_3 = tranquill_2.data.length - 1;
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 0,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 5,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 10,
    len: 3,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 13,
    len: 3,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 16,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 25,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 34,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 35,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 40,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 41,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 42,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 43,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 44,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 45,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 46,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 47,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 48,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 49,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 50,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 51,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 52,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 53,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 54,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 55,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 56,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 57,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 58,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 59,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 60,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 61,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 62,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 63,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 69,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 75,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 81,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 87,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 93,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 99,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 105,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 111,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 117,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 123,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 128,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 133,
    len: 11,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 144,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 156,
    len: 9,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 165,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 174,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 179,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 184,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 190,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 195,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 204,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 232,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 233,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 234,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 243,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 252,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 262,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 266,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 271,
    len: 10,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 281,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 286,
    len: 9,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 295,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 305,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 309,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 314,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 319,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 324,
    len: 9,
    kind: 1
  });
})();
const tranquill_4 = (() => {
  const tranquill_5 = Object.freeze({
    "\n": {
      key: tranquill_S("0x6c62272e07bb0142"),
      code: tranquill_S("0x6c62272e07bb0142"),
      windowsVirtualKeyCode: 13,
      nativeVirtualKeyCode: 13
    },
    "\t": {
      key: tranquill_S("0x6c62272e07bb0142"),
      code: tranquill_S("0x6c62272e07bb0142"),
      windowsVirtualKeyCode: 9,
      nativeVirtualKeyCode: 9
    },
    "\b": {
      key: tranquill_S("0x6c62272e07bb0142"),
      code: tranquill_S("0x6c62272e07bb0142"),
      windowsVirtualKeyCode: 8,
      nativeVirtualKeyCode: 8
    },
    " ": {
      key: tranquill_S("0x6c62272e07bb0142"),
      code: tranquill_S("0x6c62272e07bb0142"),
      text: tranquill_S("0x6c62272e07bb0142"),
      unmodifiedText: tranquill_S("0x6c62272e07bb0142"),
      windowsVirtualKeyCode: 32,
      nativeVirtualKeyCode: 32,
      macCharCode: 32
    }
  });
  const tranquill_6 = Object.freeze({
    "!": tranquill_S("0x6c62272e07bb0142"),
    "@": tranquill_S("0x6c62272e07bb0142"),
    "#": tranquill_S("0x6c62272e07bb0142"),
    $: tranquill_S("0x6c62272e07bb0142"),
    "%": tranquill_S("0x6c62272e07bb0142"),
    "^": tranquill_S("0x6c62272e07bb0142"),
    "&": tranquill_S("0x6c62272e07bb0142"),
    "*": tranquill_S("0x6c62272e07bb0142"),
    "(": tranquill_S("0x6c62272e07bb0142"),
    ")": tranquill_S("0x6c62272e07bb0142"),
    _: tranquill_S("0x6c62272e07bb0142"),
    "+": tranquill_S("0x6c62272e07bb0142"),
    "{": tranquill_S("0x6c62272e07bb0142"),
    "}": tranquill_S("0x6c62272e07bb0142"),
    "|": tranquill_S("0x6c62272e07bb0142"),
    ":": tranquill_S("0x6c62272e07bb0142"),
    '"': tranquill_S("0x6c62272e07bb0142"),
    "<": tranquill_S("0x6c62272e07bb0142"),
    ">": tranquill_S("0x6c62272e07bb0142"),
    "?": tranquill_S("0x6c62272e07bb0142"),
    "~": tranquill_S("0x6c62272e07bb0142")
  });
  const tranquill_7 = Object.freeze({
    1: tranquill_S("0x6c62272e07bb0142"),
    2: tranquill_S("0x6c62272e07bb0142"),
    3: tranquill_S("0x6c62272e07bb0142"),
    4: tranquill_S("0x6c62272e07bb0142"),
    5: tranquill_S("0x6c62272e07bb0142"),
    6: tranquill_S("0x6c62272e07bb0142"),
    7: tranquill_S("0x6c62272e07bb0142"),
    8: tranquill_S("0x6c62272e07bb0142"),
    9: tranquill_S("0x6c62272e07bb0142"),
    0: tranquill_S("0x6c62272e07bb0142"),
    "-": tranquill_S("0x6c62272e07bb0142"),
    "=": tranquill_S("0x6c62272e07bb0142"),
    "[": tranquill_S("0x6c62272e07bb0142"),
    "]": tranquill_S("0x6c62272e07bb0142"),
    "\\": tranquill_S("0x6c62272e07bb0142"),
    ";": tranquill_S("0x6c62272e07bb0142"),
    "'": tranquill_S("0x6c62272e07bb0142"),
    ",": tranquill_S("0x6c62272e07bb0142"),
    ".": tranquill_S("0x6c62272e07bb0142"),
    "/": tranquill_S("0x6c62272e07bb0142"),
    "`": tranquill_S("0x6c62272e07bb0142")
  });
  function tranquill_8(tranquill_9) {
    return !!(tranquill_9 && tranquill_S("0x6c62272e07bb0142").test(tranquill_9));
  }
  function tranquill_a(tranquill_b) {
    if (tranquill_6[tranquill_b]) return tranquill_6[tranquill_b];
    if (tranquill_b.length === 1 && tranquill_b >= tranquill_S("0x6c62272e07bb0142") && tranquill_b <= tranquill_S("0x6c62272e07bb0142")) return tranquill_b.toLowerCase();
    return tranquill_b;
  }
  function tranquill_c(tranquill_d) {
    if (!tranquill_d) return 0;
    const tranquill_f = {
      "-": 189,
      "=": 187,
      "[": 219,
      "]": 221,
      "\\": 220,
      ";": 186,
      "'": 222,
      ",": 188,
      ".": 190,
      "/": 191,
      "`": 192
    };
    if (tranquill_f[tranquill_d]) return tranquill_f[tranquill_d];
    if (tranquill_S("0x6c62272e07bb0142").test(tranquill_d)) return tranquill_d.charCodeAt(0);
    return tranquill_d.toUpperCase().charCodeAt(0);
  }
  function tranquill_g(tranquill_h) {
    if (!tranquill_h) return undefined;
    if (tranquill_7[tranquill_h]) return tranquill_7[tranquill_h];
    if (tranquill_S("0x6c62272e07bb0142")["test"](tranquill_h)) return `Key${tranquill_h["toUpperCase"]()}`;
    return undefined;
  }
  function tranquill_j(tranquill_k, tranquill_l) {
    return {
      type: tranquill_k,
      ...tranquill_l
    };
  }
  function tranquill_m(tranquill_n) {
    return tranquill_5[tranquill_n] || null;
  }
  function tranquill_o(tranquill_p) {
    const tranquill_q = [];
    const tranquill_r = tranquill_m(tranquill_p);
    if (tranquill_r) {
      const tranquill_s = {
        key: tranquill_r.key,
        code: tranquill_r.code,
        windowsVirtualKeyCode: tranquill_r["windowsVirtualKeyCode"],
        nativeVirtualKeyCode: tranquill_r["nativeVirtualKeyCode"]
      };
      tranquill_q.push(tranquill_j(tranquill_S("0x6c62272e07bb0142"), tranquill_s));
      if (tranquill_r.text) tranquill_q.push(tranquill_j(tranquill_S("0x6c62272e07bb0142"), {
        ...tranquill_s,
        key: tranquill_r.key,
        text: tranquill_r.text,
        unmodifiedText: tranquill_r["text"]
      }));
      tranquill_q.push(tranquill_j(tranquill_S("0x6c62272e07bb0142"), tranquill_s));
      return tranquill_q;
    }
    const tranquill_t = tranquill_8(tranquill_p);
    const tranquill_u = tranquill_t ? tranquill_a(tranquill_p) : tranquill_p;
    const tranquill_v = tranquill_c(tranquill_u);
    const tranquill_w = tranquill_g(tranquill_u);
    if (tranquill_t) tranquill_q["push"](tranquill_j(tranquill_S("0x6c62272e07bb0142"), {
      key: tranquill_S("0x6c62272e07bb0142"),
      code: tranquill_S("0x6c62272e07bb0142"),
      windowsVirtualKeyCode: 16,
      nativeVirtualKeyCode: 16
    }));
    const tranquill_x = {
      key: tranquill_p,
      code: tranquill_w,
      windowsVirtualKeyCode: tranquill_v,
      nativeVirtualKeyCode: tranquill_v
    };
    tranquill_q.push(tranquill_j(tranquill_S("0x6c62272e07bb0142"), tranquill_x));
    tranquill_q["push"](tranquill_j(tranquill_S("0x6c62272e07bb0142"), {
      ...tranquill_x,
      text: tranquill_p,
      unmodifiedText: tranquill_u
    }));
    tranquill_q["push"](tranquill_j(tranquill_S("0x6c62272e07bb0142"), tranquill_x));
    if (tranquill_t) tranquill_q.push(tranquill_j(tranquill_S("0x6c62272e07bb0142"), {
      key: tranquill_S("0x6c62272e07bb0142"),
      code: tranquill_S("0x6c62272e07bb0142"),
      windowsVirtualKeyCode: 16,
      nativeVirtualKeyCode: 16
    }));
    return tranquill_q;
  }
  return {
    build: tranquill_o
  };
})();
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}