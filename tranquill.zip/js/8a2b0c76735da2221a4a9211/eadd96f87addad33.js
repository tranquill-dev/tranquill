var tranquill_runtime_exports = (() => {
        const tranquill_global = typeof self !== "undefined" ? self : globalThis;
        if (tranquill_global.tranquill_runtime_ready) {
                return {
                        tranquill_S: tranquill_global.tranquill_S,
                        tranquill_RN: tranquill_global.tranquill_RN,
                        tranquill_next: tranquill_global.tranquill_next,
                        tranquill_signature: tranquill_global.tranquill_signature,
                        tranquill_seed: tranquill_global.tranquill_seed,
                };
        }
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::457f0536cb00f0db9dec4c0cbf422f54"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        const exports = {
                tranquill_S,
                tranquill_RN,
                tranquill_next,
                tranquill_signature: "tranquill_tranquill_tranquill",
                tranquill_seed: tranquill_global.tranquill_seed,
        };
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = exports.tranquill_signature;
        tranquill_global.tranquill_seed = exports.tranquill_seed;
        tranquill_global.tranquill_runtime_ready = true;
        if (typeof tranquill_global === "object" && tranquill_global) {
                try {
                        tranquill_global.tranquill_runtime = exports;
                } catch (error) {
                        // ignore assignment issues in restricted environments
                }
        }
        if (typeof window !== "undefined") {
                window.tranquill_S = tranquill_S;
                window.tranquill_RN = tranquill_RN;
                window.tranquill_next = tranquill_next;
        }
        if (typeof global !== "undefined") {
                global.tranquill_S = tranquill_S;
                global.tranquill_RN = tranquill_RN;
                global.tranquill_next = tranquill_next;
        }
        return exports;
})();

(function tranquill_0() {
  const tranquill_1 = new Uint8Array([134, 147, 151, 80, 156, 149, 128, 6, 130, 153, 151, 77, 144, 132, 197, 75, 148, 159, 139, 6, 153, 159, 150, 82, 144, 152, 128, 84, 134, 214, 140, 72, 156, 130, 140, 71, 153, 159, 159, 79, 155, 145, 139, 9, 95, 105, 145, 23, 15, 115, 154, 3, 92, 105, 144, 30, 15, 99, 144, 30, 92, 116, 141, 5, 76, 116, 154, 20, 215, 181, 166, 214, 205, 179, 177, 128, 211, 191, 166, 203, 193, 162, 244, 210, 193, 179, 177, 201, 210, 181, 176, 128, 201, 181, 167, 211, 197, 183, 177, 196, 35, 6, 181, 195, 3, 30, 183, 222, 57, 0, 212, 120, 37, 213, 201, 107, 162, 253, 211, 173, 164, 184, 208, 186, 191, 255, 210, 173, 163, 235, 128, 174, 177, 241, 204, 17, 183, 243, 33, 22, 151, 235, 35, 11, 173, 245, 115, 17, 166, 230, 39, 11, 173, 245, 32, 16, 198, 132, 6, 10, 216, 212, 28, 1, 204, 135, 6, 11, 209, 212, 28, 16, 222, 134, 27, 1, 219, 246, 81, 116, 7, 241, 113, 108, 5, 236, 75, 114, 224, 18, 204, 230, 179, 7, 197, 226, 246, 20, 131, 229, 231, 7, 209, 226, 179, 0, 194, 255, 255, 19, 209, 243, 90, 62, 22, 106, 125, 51, 9, 115, 71, 45, 82, 163, 199, 97, 71, 150, 203, 98, 75, 172, 213, 71, 5, 203, 49, 27, 1, 197, 52, 71, 20, 132, 51, 81, 0, 209, 36, 71, 5, 193, 37, 56, 17, 180, 37, 100, 21, 186, 32, 56, 0, 251, 51, 42, 12, 183, 48, 47, 179, 16, 237, 144, 166, 38, 251, 146, 187, 28, 229, 184, 223, 198, 191, 173, 157, 219, 168, 168, 200, 204, 190, 173, 216, 205, 138, 176, 116, 112, 159, 242, 125, 99, 130, 190, 126, 102, 117, 138, 244, 156, 113, 141, 248, 166, 119, 139, 242, 149, 96, 144, 229, 93, 22, 250, 238, 90, 239, 186, 238, 204, 235, 189, 226, 130, 235, 160, 230, 197, 248, 183, 253, 130, 237, 183, 236, 199, 246, 164, 234, 198, 203, 194, 10, 212, 207, 197, 6, 154, 207, 216, 2, 221, 220, 207, 25, 154, 221, 203, 2, 214, 163, 246, 2, 160, 167, 241, 14, 140, 178, 253, 8, 189, 163, 255, 0, 171, 35, 23, 80, 48, 40, 16, 16, 102, 241, 48, 20, 97, 253, 126, 2, 111, 243, 53, 19, 126, 241, 61, 5, 46, 226, 59, 17, 123, 245, 45, 20, 12, 207, 141, 25, 8, 200, 129, 87, 30, 198, 143, 28, 15, 215, 141, 20, 25, 135, 138, 22, 21, 203, 245, 117, 116, 227, 241, 114, 120, 206, 234, 115, 97, 232, 235, 105, 71, 232, 228, 121, 108, 102, 36, 167, 114, 98, 35, 171, 60, 117, 35, 168, 104, 115, 34, 178, 60, 100, 41, 167, 120, 111, 83, 60, 208, 26, 85, 47, 193, 45, 96, 60, 220, 61, 50, 30, 66, 52, 50, 81, 64, 36, 51, 4, 87, 50, 54, 20, 86, 97, 49, 16, 68, 36, 38, 81, 70, 36, 58, 5, 176, 86, 51, 183, 174, 67, 46, 141, 176, 96, 51, 130, 163, 70, 52, 136, 237, 120, 135, 136, 162, 122, 151, 137, 247, 109, 129, 140, 231, 108, 210, 140, 251, 120, 155, 150, 229, 40, 129, 140, 227, 124, 135, 139, 111, 73, 130, 118, 116, 67, 134, 114, 126, 7, 135, 114, 105, 84, 139, 112, 127, 7, 139, 116, 110, 78, 133, 121, 194, 26, 14, 171, 217, 2, 5, 255, 195, 26, 19, 175, 213, 1, 4, 255, 194, 10, 3, 186, 217, 25, 5, 187, 139, 79, 19, 171, 223, 31, 16, 182, 222, 8, 64, 172, 213, 28, 19, 182, 223, 1, 163, 161, 79, 181, 240, 186, 78, 229, 163, 160, 83, 181, 181, 187, 68, 229, 182, 180, 73, 169, 57, 76, 95, 125, 63, 72, 80, 50, 59, 72, 89, 30, 6, 82, 18, 77, 19, 91, 22, 8, 0, 29, 22, 12, 16, 29, 16, 8, 31, 82, 20, 8, 22, 26, 175, 188, 94, 27, 190, 186, 31, 26, 171, 186, 17, 126, 108, 5, 20, 127, 106, 247, 44, 59, 248, 164, 55, 58, 168, 234, 57, 34, 225, 227, 57, 32, 225, 235, 54, 116, 238, 229, 49, 56, 85, 146, 227, 82, 86, 144, 228, 85, 17, 147, 228, 83, 80, 148, 233, 66, 85, 67, 119, 48, 80, 72, 112]);
  const tranquill_2 = self.tranquill_PACK = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  tranquill_2.data.push(tranquill_1);
  const tranquill_3 = tranquill_2["data"].length - 1;
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 0,
    len: 42,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 42,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 68,
    len: 31,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 99,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 110,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 116,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 135,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 155,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 177,
    len: 11,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 188,
    len: 24,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 212,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 222,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 233,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 253,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 270,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 281,
    len: 15,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 296,
    len: 12,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 308,
    len: 14,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 322,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 328,
    len: 24,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 352,
    len: 20,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 372,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 388,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 394,
    len: 25,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 419,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 441,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 460,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 481,
    len: 12,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 493,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 519,
    len: 15,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 534,
    len: 29,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 563,
    len: 24,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 587,
    len: 42,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 629,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 649,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 660,
    len: 22,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 682,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 693,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 700,
    len: 23,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 723,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 740,
    len: 6,
    kind: 1
  });
})();
log.info(tranquill_S("0x6c62272e07bb0142"));
const tranquill_4 = new TypingModel();
const tranquill_5 = new DebuggerManager();
const tranquill_6 = new PhantomController();
const tranquill_7 = new TypingSession({
  debuggerManager: tranquill_5,
  typingModel: tranquill_4,
  phantomController: tranquill_6
});
log.debug(tranquill_S("0x6c62272e07bb0142"));
let _tranquill_cond = typeof tranquill_9?.frameId === tranquill_S("0x6c62272e07bb0142");
if (_tranquill_cond) {
  tranquill_9.frameId;
} else {
  null;
}
chrome.runtime.onMessage.addListener((tranquill_8, tranquill_9, tranquill_a) => {
  const tranquill_b = tranquill_9?.tab?.id ?? null;
  log["debug"](tranquill_S("0x6c62272e07bb0142"), {
    action: tranquill_8?.action,
    tabId: tranquill_b
  });
  switch (tranquill_8?.action) {
    case tranquill_S("0x6c62272e07bb0142"):
      {
        (async () => {
          try {
            const tranquill_c = String(tranquill_8.text ?? "");
            const tranquill_d = typeof tranquill_8.previousText === tranquill_S("0x6c62272e07bb0142") ? tranquill_8.previousText : null;
            let reset = tranquill_8.resetProgress === true;
            if (!reset && tranquill_d !== null) reset = tranquill_d !== tranquill_c;
            if (!reset && tranquill_d === null) {
              const tranquill_e = await TextStorage["getSavedText"]();
              if (tranquill_e !== tranquill_c) reset = true;
            }
            await TextStorage["setSavedText"](tranquill_c);
            const tranquill_f = TextStorage.createTextSignature(tranquill_c);
            if (reset) {
              await TextStorage.setProgress(0, tranquill_f)["catch"](tranquill_g => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_g));
            }
            const tranquill_h = reset ? 0 : await TextStorage.getProgress(tranquill_f).catch(() => 0);
            const tranquill_i = await SettingsStorage.getSettings().catch(() => SettingsStorage["defaults"]);
            log.debug(tranquill_S("0x6c62272e07bb0142"), tranquill_i);
            tranquill_4.setWordsPerMinute(tranquill_i.typingSpeed);
            tranquill_4["setHumanized"](tranquill_i["ghostMode"]);
            await tranquill_7.start({
              text: tranquill_c,
              startIndex: tranquill_h,
              settings: tranquill_i
            });
            log.info(tranquill_S("0x6c62272e07bb0142"), {
              tabId: tranquill_b,
              length: tranquill_c["length"],
              reset,
              progress: tranquill_h
            });
            tranquill_a({
              success: true
            });
          } catch (tranquill_j) {
            log["error"](tranquill_S("0x6c62272e07bb0142"), tranquill_j);
            tranquill_7.stop().catch(tranquill_k => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_k));
            tranquill_a({
              success: false,
              error: String(tranquill_j?.message || tranquill_j)
            });
          }
        })();
        return true;
      }
    case tranquill_S("0x6c62272e07bb0142"):
    case tranquill_S("0x6c62272e07bb0142"):
      {
        log.info(tranquill_S("0x6c62272e07bb0142"), {
          action: tranquill_8["action"]
        });
        tranquill_7.stop().catch(tranquill_l => log["warn"](tranquill_S("0x6c62272e07bb0142"), tranquill_l));
        tranquill_a({
          success: true
        });
        return false;
      }
    case tranquill_S("0x6c62272e07bb0142"):
      {
        log.warn(tranquill_S("0x6c62272e07bb0142"), {
          action: tranquill_8["action"],
          reason: tranquill_8?.reason ?? null
        });
        tranquill_7.stop()["catch"](tranquill_m => log["warn"](tranquill_S("0x6c62272e07bb0142"), tranquill_m));
        tranquill_a({
          success: true
        });
        return false;
      }
    case tranquill_S("0x6c62272e07bb0142"):
      {
        const tranquill_n = typeof tranquill_9?.frameId === tranquill_S("0x6c62272e07bb0142") ? tranquill_9.frameId : null;
        log.debug(tranquill_S("0x6c62272e07bb0142"), {
          tabId: tranquill_b,
          requestId: tranquill_8?.requestId ?? null,
          frameId: tranquill_n
        });
        if (tranquill_b !== null) {
          tranquill_7["handlePhantomTrigger"](tranquill_b, tranquill_8?.requestId, tranquill_8?.key, tranquill_8?.timeStamp, tranquill_n).catch(tranquill_o => log["warn"](tranquill_S("0x6c62272e07bb0142"), tranquill_o));
        }
        tranquill_a({
          success: true
        });
        return false;
      }
    case tranquill_S("0x6c62272e07bb0142"):
      {
        const tranquill_p = _tranquill_cond;
        log.debug(tranquill_S("0x6c62272e07bb0142"), {
          tabId: tranquill_b,
          frameId: tranquill_p
        });
        if (tranquill_b !== null) {
          tranquill_7.handlePhantomBackspace(tranquill_b, tranquill_p)["catch"](tranquill_q => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_q));
        }
        tranquill_a({
          success: true
        });
        return false;
      }
    case tranquill_S("0x6c62272e07bb0142"):
      {
        log.info(tranquill_S("0x6c62272e07bb0142"), {
          tabId: tranquill_b
        });
        if (tranquill_b !== null) tranquill_6.markReady(tranquill_b);
        tranquill_a({
          success: true
        });
        return false;
      }
    case tranquill_S("0x6c62272e07bb0142"):
      {
        log["debug"](tranquill_S("0x6c62272e07bb0142"));
        TextStorage.getSavedText()["then"](tranquill_r => tranquill_a({
          success: true,
          text: tranquill_r
        })).catch(tranquill_s => tranquill_a({
          success: false,
          error: String(tranquill_s?.message || tranquill_s)
        }));
        return true;
      }
    case tranquill_S("0x6c62272e07bb0142"):
      {
        log["debug"](tranquill_S("0x6c62272e07bb0142"));
        tranquill_a({
          success: true,
          isTyping: tranquill_7.isActive()
        });
        return false;
      }
    default:
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        action: tranquill_8?.action
      });
      return false;
  }
});
chrome.runtime["onSuspend"].addListener(() => {
  log["info"](tranquill_S("0x6c62272e07bb0142"));
  tranquill_7["stop"]().catch(tranquill_t => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_t));
});
chrome["tabs"].onRemoved["addListener"](tranquill_u => {
  log.info(tranquill_S("0x6c62272e07bb0142"), {
    tabId: tranquill_u
  });
  if (tranquill_5.isAttachedTo(tranquill_u)) {
    tranquill_7["stop"]().catch(tranquill_v => log["warn"](tranquill_S("0x6c62272e07bb0142"), tranquill_v));
  }
});
chrome["tabs"].onUpdated.addListener((tranquill_w, tranquill_x) => {
  log.debug(tranquill_S("0x6c62272e07bb0142"), {
    tabId: tranquill_w,
    status: tranquill_x?.status
  });
  if (tranquill_x["status"] === tranquill_S("0x6c62272e07bb0142") && tranquill_5.isAttachedTo(tranquill_w)) {
    tranquill_7.stop().catch(tranquill_y => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_y));
  }
});
chrome["debugger"]["onDetach"].addListener(tranquill_z => {
  log["warn"](tranquill_S("0x6c62272e07bb0142"), {
    tabId: tranquill_z?.tabId ?? null
  });
  if (!tranquill_z || typeof tranquill_z.tabId !== tranquill_S("0x6c62272e07bb0142")) return;
  tranquill_5.handleDetached(tranquill_z.tabId);
  tranquill_7["handleDebuggerDetached"]();
});
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}