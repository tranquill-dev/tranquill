var tranquill_runtime_exports = (() => {
        const tranquill_global = typeof self !== "undefined" ? self : globalThis;
        if (tranquill_global.tranquill_runtime_ready) {
                return {
                        tranquill_S: tranquill_global.tranquill_S,
                        tranquill_RN: tranquill_global.tranquill_RN,
                        tranquill_next: tranquill_global.tranquill_next,
                        tranquill_signature: tranquill_global.tranquill_signature,
                        tranquill_seed: tranquill_global.tranquill_seed,
                };
        }
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::457f0536cb00f0db9dec4c0cbf422f54"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        const exports = {
                tranquill_S,
                tranquill_RN,
                tranquill_next,
                tranquill_signature: "tranquill_tranquill_tranquill",
                tranquill_seed: tranquill_global.tranquill_seed,
        };
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = exports.tranquill_signature;
        tranquill_global.tranquill_seed = exports.tranquill_seed;
        tranquill_global.tranquill_runtime_ready = true;
        if (typeof tranquill_global === "object" && tranquill_global) {
                try {
                        tranquill_global.tranquill_runtime = exports;
                } catch (error) {
                        // ignore assignment issues in restricted environments
                }
        }
        if (typeof window !== "undefined") {
                window.tranquill_S = tranquill_S;
                window.tranquill_RN = tranquill_RN;
                window.tranquill_next = tranquill_next;
        }
        if (typeof global !== "undefined") {
                global.tranquill_S = tranquill_S;
                global.tranquill_RN = tranquill_RN;
                global.tranquill_next = tranquill_next;
        }
        return exports;
})();

"use strict";
(function tranquill_0() {
  const tranquill_1 = new Uint8Array([186, 143, 213, 179, 167, 146, 188, 16, 77, 189, 161, 3, 164, 159, 159, 163, 69, 156, 180, 169, 69, 204, 164, 184, 182, 101, 0, 165, 181, 165, 208, 138, 172, 184, 205, 159, 110, 48, 146, 130, 115, 145, 228, 190, 152, 140, 249, 131, 101, 188, 148, 143, 126, 32, 130, 146, 99, 129, 244, 174, 136, 156, 233, 151, 121, 34, 142, 155, 111, 234, 151, 13, 250, 253, 193, 92, 198, 241, 246, 231, 9, 82, 254, 235, 31, 219, 127, 18, 240, 194, 121, 18, 235, 206, 228, 72, 21, 229, 249, 91, 194, 224, 183, 215, 206, 246, 208, 100, 33, 169, 205, 119, 202, 226, 187, 207, 215, 241, 188, 88, 245, 215, 165, 94, 245, 204, 169, 207, 58, 165, 222, 220, 43, 22, 140, 59, 60, 45, 79, 24, 56, 33, 89, 59, 223, 138, 50, 38, 204, 45, 69, 28, 40, 48, 86, 59, 208, 192, 57, 118, 128, 51, 12, 115, 135, 59, 14, 110, 175, 19, 112, 166, 239, 222, 61, 71, 24, 235, 56, 64, 16, 233, 37, 104, 89, 233, 38, 82, 89, 230, 38, 91, 10, 234, 37, 80, 89, 225, 32, 70, 9, 228, 61, 86, 17, 165, 47, 84, 16, 233, 44, 81, 86, 39, 7, 100, 76, 33, 16, 63, 82, 45, 7, 121, 64, 48, 90, 233, 47, 86, 10, 176, 243, 85, 63, 181, 244, 93, 61, 168, 220, 20, 61, 171, 230, 20, 33, 171, 243, 64, 113, 160, 232, 71, 33, 165, 245, 87, 57, 228, 231, 85, 56, 168, 228, 80, 162, 252, 231, 176, 167, 251, 239, 178, 186, 202, 227, 168, 191, 237, 227, 150, 129, 199, 194, 145, 203, 212, 135, 148, 204, 220, 133, 137, 253, 208, 159, 140, 218, 208, 161, 178, 240, 241, 186, 132, 213, 193, 100, 170, 129, 102, 97, 173, 137, 100, 124, 156, 133, 126, 121, 187, 133, 64, 71, 145, 164, 248, 14, 160, 200, 234, 18, 161, 197, 253, 10, 200, 245, 233, 22, 220, 233, 200, 254, 208, 248, 218, 226, 209, 245, 237, 26, 216, 229, 217, 38, 236, 217, 197, 34, 208, 221, 204, 3, 77, 203, 218, 0, 94, 210, 156, 6, 66, 217, 211, 79, 94, 218, 200, 29, 69, 218, 202, 14, 64, 159, 218, 14, 69, 211, 217, 11, 51, 80, 134, 15, 47, 33, 174, 41, 57, 34, 189, 48, 127, 36, 161, 59, 48, 109, 189, 56, 43, 63, 166, 56, 41, 44, 163, 125, 43, 37, 189, 56, 40, 88, 0, 230, 179, 26, 23, 251, 42, 93, 72, 72, 75, 32, 63, 4, 3, 241, 28, 26, 56, 111, 15, 22, 46, 60, 127, 147, 206, 126, 98, 128, 116, 3, 26, 115, 110, 26, 31, 65, 63, 153, 121, 83, 35, 152, 116, 121, 55, 129, 113, 107, 43, 128, 124, 93, 106, 115, 90, 71, 115, 118, 85, 166, 3, 70, 86, 46, 49, 81, 44, 45, 52, 24, 52, 39, 112, 74, 37, 59, 63, 84, 54, 45, 112, 76, 41, 37, 53, 66, 47, 38, 53, 24, 38, 39, 34, 24, 8, 31, 25, 124, 178, 69, 92, 181, 168, 92, 89, 171, 28, 5, 172, 177, 5, 0, 184, 204, 139, 171, 179, 203, 158, 105, 112, 153, 132, 112, 117, 151, 32, 57, 144, 141, 57, 60, 140, 251, 226, 139, 150, 226, 231, 137, 162, 128, 20, 113, 153, 157, 7, 215, 157, 198, 222, 191, 185, 238, 246, 235, 234, 235, 243, 248, 175, 252, 238, 234, 194, 155, 239, 247, 209, 236, 64, 29, 237, 241, 83, 230, 206, 151, 227, 251, 221, 216, 124, 41, 209, 197, 111, 228, 219, 213, 248, 140, 232, 245, 219, 201, 255, 232, 207, 35, 126, 206, 210, 48, 221, 143, 98, 222, 163, 184, 33, 164, 164, 184, 119, 133, 144, 148, 19, 237, 160, 184, 57, 168, 181, 188, 35, 168, 163, 42, 153, 95, 38, 227, 157, 60, 224, 224, 152, 117, 248, 234, 220, 60, 226, 236, 136, 60, 237, 233, 149, 47, 233, 165, 152, 48, 250, 236, 159, 48, 172, 205, 171, 28, 200, 246, 181, 99, 10, 203, 183, 218, 212, 163, 130, 252, 255, 247, 147, 231, 226, 226, 144, 179, 246, 226, 137, 255, 229, 241, 133, 95, 72, 154, 68, 90, 79, 146, 70, 71, 23, 151, 69, 76, 23, 136, 94, 89, 95, 154, 71, 66, 96, 55, 87, 78, 118, 93, 235, 234, 114, 65, 233, 210, 91, 88, 235, 242, 41, 59, 246, 74, 51, 4, 228, 117, 37, 3, 229, 86, 171, 202, 214, 185, 172, 196, 215, 166, 149, 16, 149, 165, 181, 192, 154, 188, 168, 221, 183, 89, 136, 168, 143, 81, 26, 166, 131, 71, 148, 207, 17, 163, 145, 200, 25, 161, 140, 241, 31, 170, 137, 226, 242, 143, 132, 74, 104, 138, 131, 66, 106, 151, 177, 78, 114, 179, 161, 98, 66, 128, 191, 117, 128, 212, 147, 133, 208, 188, 182, 169, 229, 233, 161, 191, 224, 188, 162, 173, 253, 240, 161, 168, 216, 5, 93, 201, 221, 2, 85, 203, 192, 50, 82, 212, 217, 5, 89, 235, 197, 20, 89, 201, 223, 18, 214, 164, 78, 162, 196, 184, 79, 175, 148, 128, 75, 188, 182, 154, 77, 249, 191, 136, 92, 188, 248, 156, 70, 184, 174, 136, 65, 181, 185, 139, 68, 188, 59, 37, 183, 17, 32, 107, 236, 78, 39, 35, 162, 15, 34, 36, 170, 13, 63, 127, 160, 2, 124, 80, 212, 33, 190, 74, 200, 111, 179, 29, 202, 107, 232, 28, 200, 61, 238, 79, 194, 104, 233, 70, 205, 59, 232, 76, 205, 111, 165, 75, 201, 54, 235, 76, 195, 58, 238, 29, 194, 62, 191, 27, 207, 56, 185, 80, 144, 125, 3, 71, 178, 109, 25, 91, 252, 96, 78, 89, 248, 59, 79, 91, 174, 61, 28, 81, 251, 58, 21, 94, 168, 59, 31, 94, 252, 118, 78, 80, 165, 104, 30, 8, 251, 106, 28, 89, 175, 60, 76, 8, 254, 109, 3, 3, 238, 114, 118, 3, 28, 104, 106, 77, 17, 63, 104, 73, 74, 62, 106, 31, 76, 109, 96, 74, 75, 100, 111, 25, 74, 110, 111, 77, 7, 109, 107, 28, 78, 100, 109, 21, 75, 56, 107, 30, 29, 57, 57, 26, 16, 114, 50, 95, 37, 97, 20, 203, 63, 125, 90, 198, 104, 127, 94, 157, 105, 125, 8, 155, 58, 119, 93, 156, 51, 120, 14, 157, 57, 120, 90, 208, 60, 118, 89, 153, 105, 125, 10, 158, 109, 44, 10, 205, 110, 123, 8, 205, 37, 37, 72, 148, 16, 101, 250, 142, 12, 43, 247, 217, 14, 47, 172, 216, 12, 121, 170, 139, 6, 44, 173, 130, 9, 127, 172, 136, 9, 43, 225, 223, 12, 115, 253, 222, 6, 44, 173, 219, 10, 46, 170, 143, 91, 121, 171, 148, 84, 57, 71, 3, 118, 169, 93, 31, 56, 164, 10, 29, 60, 255, 11, 31, 106, 249, 88, 21, 63, 254, 81, 26, 108, 255, 91, 26, 56, 178, 93, 75, 59, 252, 15, 26, 97, 164, 93, 76, 107, 254, 13, 75, 63, 175, 71, 71, 42, 182, 178, 71, 88, 172, 174, 9, 85, 251, 172, 13, 14, 250, 174, 91, 8, 169, 164, 14, 15, 160, 171, 93, 14, 170, 171, 9, 67, 160, 164, 90, 92, 249, 165, 94, 95, 250, 172, 13, 92, 168, 171, 89, 10, 182, 246, 27, 121, 61, 40, 119, 99, 33, 102, 122, 52, 35, 98, 33, 53, 33, 52, 39, 102, 43, 97, 32, 111, 36, 50, 33, 101, 36, 102, 108, 96, 118, 52, 34, 100, 32, 98, 114, 102, 37, 102, 32, 51, 38, 51, 34, 121, 121, 116, 40, 172, 185, 38, 50, 176, 247, 43, 101, 178, 243, 112, 100, 176, 165, 118, 55, 186, 240, 113, 62, 181, 163, 112, 52, 181, 247, 61, 55, 182, 243, 37, 52, 186, 243, 42, 52, 187, 240, 119, 99, 179, 162, 35, 40, 232, 229, 155, 223, 10, 213, 129, 195, 68, 216, 214, 193, 64, 131, 215, 195, 22, 133, 132, 201, 67, 130, 141, 198, 16, 131, 135, 198, 68, 206, 133, 147, 20, 217, 209, 193, 16, 216, 211, 196, 16, 212, 133, 194, 64, 216, 155, 155, 86, 202, 206, 155, 132, 208, 210, 213, 137, 135, 208, 209, 210, 134, 210, 135, 212, 213, 216, 210, 211, 220, 215, 129, 210, 214, 215, 213, 159, 130, 208, 133, 130, 215, 132, 131, 137, 214, 129, 141, 130, 220, 214, 130, 213, 202, 138, 199, 189, 249, 236, 179, 167, 229, 162, 190, 240, 231, 166, 229, 241, 229, 240, 227, 162, 239, 165, 228, 171, 224, 246, 229, 161, 224, 162, 168, 163, 177, 160, 225, 245, 224, 162, 178, 246, 228, 243, 230, 162, 182, 245, 183, 189, 189, 176, 108, 232, 253, 98, 118, 244, 179, 111, 33, 246, 183, 52, 32, 244, 225, 50, 115, 254, 180, 53, 122, 241, 231, 52, 112, 241, 179, 121, 114, 243, 235, 110, 118, 160, 225, 96, 122, 163, 182, 111, 39, 167, 235, 97, 108, 172, 161, 245, 230, 46, 184, 191, 173, 114, 239, 189, 241, 124, 184, 191, 173, 42, 189, 232, 250, 101, 179, 168, 40, 172, 185, 32, 53, 177, 247, 32, 49, 182, 160, 119, 53, 177, 162, 43, 96, 183, 163, 118, 48, 176, 244, 43, 99, 177, 245, 61, 54, 181, 175, 119, 48, 228, 240, 116, 62, 178, 175, 113, 55, 183, 164, 119, 40, 232, 229]);
  const tranquill_2 = self["tranquill_PACK"] = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  tranquill_2.data.push(tranquill_1);
  const tranquill_3 = tranquill_2.data.length - 1;
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 0,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 6,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 12,
    len: 3,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 15,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 19,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 24,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 29,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 35,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 41,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 47,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 51,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 57,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 63,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 69,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 74,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 79,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 85,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 94,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 100,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 106,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 112,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 118,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 127,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 132,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 137,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 143,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 149,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 155,
    len: 3,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 158,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 169,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 173,
    len: 39,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 212,
    len: 14,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 226,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 230,
    len: 36,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 266,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 285,
    len: 23,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 308,
    len: 19,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 327,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 335,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 339,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 343,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 351,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 355,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 359,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 363,
    len: 30,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 393,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 397,
    len: 29,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 426,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 427,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 433,
    len: 7,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 440,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 444,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 450,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 451,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 457,
    len: 7,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 464,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 472,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 480,
    len: 7,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 487,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 492,
    len: 35,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 527,
    len: 7,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 534,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 541,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 547,
    len: 7,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 554,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 561,
    len: 7,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 568,
    len: 2,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 570,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 576,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 592,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 598,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 604,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 610,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 616,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 627,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 633,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 637,
    len: 21,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 658,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 662,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 694,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 698,
    len: 22,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 720,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 740,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 746,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 757,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 761,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 769,
    len: 7,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 776,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 781,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 787,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 791,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 797,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 809,
    len: 3,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 812,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 828,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 832,
    len: 19,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 851,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 873,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 881,
    len: 24,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 905,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 926,
    len: 47,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 973,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1020,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1067,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1114,
    len: 47,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1161,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1208,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1255,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1302,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1349,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1396,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1443,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1490,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1537,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1558,
    len: 47,
    kind: 1
  });
})();
const tranquill_4 = Object.freeze({
  silent: 0,
  error: 1,
  warn: 2,
  info: 3,
  debug: 4
});
self.TRANQUILL_LOG_LEVEL = tranquill_S("0x6c62272e07bb0142");
const tranquill_5 = (tranquill_6, {
  allowSilent: tranquill_7 = false
} = {}) => {
  if (typeof tranquill_6 !== tranquill_S("0x6c62272e07bb0142")) return null;
  const tranquill_9 = tranquill_6.toLowerCase();
  if (tranquill_9 === tranquill_S("0x6c62272e07bb0142")) return tranquill_S("0x6c62272e07bb0142");
  if (tranquill_9 === tranquill_S("0x6c62272e07bb0142")) return tranquill_S("0x6c62272e07bb0142");
  if (tranquill_9 === tranquill_S("0x6c62272e07bb0142") && tranquill_7) return tranquill_S("0x6c62272e07bb0142");
  if (Object.prototype.hasOwnProperty.call(tranquill_4, tranquill_9)) {
    return tranquill_9;
  }
  return null;
};
const tranquill_a = () => {
  const tranquill_b = tranquill_5(self.TRANQUILL_LOG_LEVEL, {
    allowSilent: true
  });
  return tranquill_b || tranquill_S("0x6c62272e07bb0142");
};
const tranquill_c = tranquill_d => {
  const tranquill_e = tranquill_5(tranquill_d) || tranquill_S("0x6c62272e07bb0142");
  if (tranquill_e === tranquill_S("0x6c62272e07bb0142")) return false;
  const tranquill_f = tranquill_a();
  if (tranquill_f === tranquill_S("0x6c62272e07bb0142")) return false;
  return tranquill_4[tranquill_e] <= tranquill_4[tranquill_f];
};
const tranquill_g = tranquill_h => {
  const tranquill_i = tranquill_5(tranquill_h, {
    allowSilent: true
  });
  if (!tranquill_i) return null;
  const tranquill_k = tranquill_a();
  if (tranquill_k === tranquill_i) return {
    previous: tranquill_k,
    next: tranquill_k,
    changed: false
  };
  self.TRANQUILL_LOG_LEVEL = tranquill_i;
  return {
    previous: tranquill_k,
    next: tranquill_i,
    changed: true
  };
};
const tranquill_l = new Set();
const tranquill_m = tranquill_n => {
  if (!tranquill_n || typeof tranquill_n !== tranquill_S("0x6c62272e07bb0142")) return tranquill_n;
  switch (tranquill_n.kind) {
    case tranquill_S("0x6c62272e07bb0142"):
      {
        const tranquill_q = new Error(tranquill_n.message);
        tranquill_q.name = tranquill_n.name || tranquill_S("0x6c62272e07bb0142");
        if (tranquill_n["stack"]) tranquill_q["stack"] = tranquill_n.stack;
        return tranquill_q;
      }
    case tranquill_S("0x6c62272e07bb0142"):
    case tranquill_S("0x6c62272e07bb0142"):
      return tranquill_n.value;
    case tranquill_S("0x6c62272e07bb0142"):
      return tranquill_n.value;
    default:
      return tranquill_n["value"];
  }
};
const tranquill_r = tranquill_s => {
  if (!tranquill_s || typeof tranquill_s !== tranquill_S("0x6c62272e07bb0142")) {
    if (typeof tranquill_s === tranquill_S("0x6c62272e07bb0142")) return {
      kind: tranquill_S("0x6c62272e07bb0142"),
      value: tranquill_s
    };
    return {
      kind: tranquill_S("0x6c62272e07bb0142"),
      value: tranquill_s
    };
  }
  if (tranquill_s["kind"] && Object.prototype.hasOwnProperty.call(tranquill_s, tranquill_S("0x6c62272e07bb0142"))) {
    return tranquill_s;
  }
  if (tranquill_s instanceof Error) {
    return {
      kind: tranquill_S("0x6c62272e07bb0142"),
      name: tranquill_s.name,
      message: tranquill_s.message,
      stack: tranquill_s.stack || null
    };
  }
  try {
    return {
      kind: tranquill_S("0x6c62272e07bb0142"),
      value: JSON.parse(JSON["stringify"](tranquill_s))
    };
  } catch (tranquill_w) {
    return {
      kind: tranquill_S("0x6c62272e07bb0142"),
      value: String(tranquill_s)
    };
  }
};
const tranquill_x = (tranquill_y, tranquill_z, tranquill_A = {}, tranquill_B = null) => {
  const tranquill_C = typeof tranquill_y === tranquill_S("0x6c62272e07bb0142") ? tranquill_y.toLowerCase() : tranquill_S("0x6c62272e07bb0142");
  if (!tranquill_c(tranquill_C)) return;
  const tranquill_E = Array.isArray(tranquill_z) ? tranquill_z : [];
  const tranquill_F = console?.[tranquill_C] || console?.log;
  try {
    tranquill_F?.call(console, tranquill_S("0x6c62272e07bb0142"), ...tranquill_E);
  } catch (tranquill_G) {
    if (tranquill_c(tranquill_S("0x6c62272e07bb0142"))) {
      console?.warn?.(tranquill_S("0x6c62272e07bb0142"), tranquill_G);
    }
  }
  const tranquill_H = {
    level: tranquill_C,
    args: Array["isArray"](tranquill_B) ? tranquill_B["map"](tranquill_I => tranquill_r(tranquill_I)) : tranquill_E["map"](tranquill_J => tranquill_r(tranquill_J)),
    meta: {
      source: tranquill_A["source"] || tranquill_S("0x6c62272e07bb0142"),
      timestamp: tranquill_A["timestamp"] || Date["now"]()
    }
  };
  tranquill_l.forEach(tranquill_K => {
    try {
      tranquill_K["postMessage"](tranquill_H);
    } catch (tranquill_L) {
      try {
        tranquill_K.disconnect();
      } catch (tranquill_M) {}
      tranquill_l.delete(tranquill_K);
      if (tranquill_c(tranquill_S("0x6c62272e07bb0142"))) {
        console?.warn?.(tranquill_S("0x6c62272e07bb0142"), tranquill_L);
      }
    }
  });
};
self.__tranquillDirectLog = (tranquill_N, tranquill_O, tranquill_P) => {
  tranquill_x(tranquill_N, tranquill_O, tranquill_P);
};
const tranquill_Q = tranquill_S("0x6c62272e07bb0142");
const tranquill_R = tranquill_S("0x6c62272e07bb0142");
const tranquill_T = tranquill_S("0x6c62272e07bb0142");
const tranquill_U = 32;
const tranquill_V = 32;
let tranquillHWIDPromise = null;
let tranquillHWIDValue = null;
const tranquill_W = (tranquill_X, tranquill_Y) => new Promise(tranquill_Z => {
  if (!tranquill_X || typeof tranquill_X["get"] !== tranquill_S("0x6c62272e07bb0142")) {
    tranquill_Z(null);
    return;
  }
  try {
    tranquill_X.get(tranquill_Y, tranquill_11 => {
      const tranquill_12 = chrome["runtime"]?.lastError ?? null;
      if (tranquill_12) {
        tranquill_x(tranquill_S("0x6c62272e07bb0142"), [`storage get failed for key "${tranquill_Y}"`, tranquill_12]);
        tranquill_Z(null);
        return;
      }
      tranquill_Z(tranquill_11?.[tranquill_Y] ?? null);
    });
  } catch (tranquill_13) {
    tranquill_x(tranquill_S("0x6c62272e07bb0142"), [`storage get threw for key "${tranquill_Y}"`, tranquill_13]);
    tranquill_Z(null);
  }
});
const tranquill_14 = (tranquill_15, tranquill_16, tranquill_17) => new Promise(tranquill_18 => {
  if (!tranquill_15 || typeof tranquill_15.set !== tranquill_S("0x6c62272e07bb0142")) {
    tranquill_18(false);
    return;
  }
  try {
    tranquill_15.set({
      [tranquill_16]: tranquill_17
    }, () => {
      const tranquill_1a = chrome.runtime?.lastError ?? null;
      if (tranquill_1a) {
        tranquill_x(tranquill_S("0x6c62272e07bb0142"), [`storage set failed for key "${tranquill_16}"`, tranquill_1a]);
        tranquill_18(false);
        return;
      }
      tranquill_18(true);
    });
  } catch (tranquill_1b) {
    tranquill_x(tranquill_S("0x6c62272e07bb0142"), [`storage set threw for key "${tranquill_16}"`, tranquill_1b]);
    tranquill_18(false);
  }
});
const tranquill_1c = () => new Promise(tranquill_1d => {
  try {
    chrome.runtime.getPlatformInfo(tranquill_1e => {
      const tranquill_1f = chrome.runtime?.lastError ?? null;
      if (tranquill_1f) {
        tranquill_x(tranquill_S("0x6c62272e07bb0142"), [tranquill_S("0x6c62272e07bb0142"), tranquill_1f]);
        tranquill_1d(null);
        return;
      }
      tranquill_1d(tranquill_1e || null);
    });
  } catch (tranquill_1g) {
    tranquill_x(tranquill_S("0x6c62272e07bb0142"), [tranquill_S("0x6c62272e07bb0142"), tranquill_1g]);
    tranquill_1d(null);
  }
});
const tranquill_1h = tranquill_1i => Array.from(new Uint8Array(tranquill_1i)).map(tranquill_1j => tranquill_1j.toString(16).padStart(2, tranquill_S("0x6c62272e07bb0142")))["join"]("");
const tranquill_1k = async (tranquill_1l, {
  context: tranquill_1m = tranquill_S("0x6c62272e07bb0142")
} = {}) => {
  const tranquill_1n = new TextEncoder();
  const tranquill_1o = tranquill_1n["encode"](tranquill_1l);
  if (crypto?.subtle?.digest) {
    try {
      const tranquill_1p = await crypto["subtle"].digest(tranquill_S("0x6c62272e07bb0142"), tranquill_1o);
      return tranquill_1h(tranquill_1p);
    } catch (tranquill_1q) {
      tranquill_x(tranquill_S("0x6c62272e07bb0142"), [`${tranquill_1m} sha-256 failed`, tranquill_1q]);
    }
  }
  const tranquill_1r = new Uint8Array(tranquill_U);
  for (let index = 0; index < tranquill_1r["length"]; index += 1) {
    tranquill_1r[index] = index * 37 & 0xff;
  }
  for (let index = 0; index < tranquill_1o["length"]; index += 1) {
    const tranquill_1s = tranquill_1o[index];
    const tranquill_1t = index % tranquill_1r["length"];
    const tranquill_1u = (tranquill_1t * 13 + tranquill_1r.length - 1) % tranquill_1r["length"];
    tranquill_1r[tranquill_1t] = (tranquill_1r[tranquill_1t] ^ tranquill_1s) & 0xff;
    tranquill_1r[tranquill_1u] = tranquill_1r[tranquill_1u] + tranquill_1s + tranquill_1t & 0xff;
  }
  return tranquill_1h(tranquill_1r.buffer);
};
const tranquill_1v = async () => {
  const tranquill_1w = [];
  const tranquill_1x = typeof navigator === tranquill_S("0x6c62272e07bb0142") && navigator ? navigator : {};
  const tranquill_1y = Array.isArray(tranquill_1x["languages"]) ? tranquill_1x.languages["join"](tranquill_S("0x6c62272e07bb0142")) : typeof tranquill_1x.language === tranquill_S("0x6c62272e07bb0142") ? tranquill_1x["language"] : tranquill_S("0x6c62272e07bb0142");
  const tranquill_1z = (() => {
    try {
      const tranquill_1A = typeof Intl?.DateTimeFormat === tranquill_S("0x6c62272e07bb0142") ? new Intl.DateTimeFormat() : null;
      const tranquill_1B = tranquill_1A && typeof tranquill_1A.resolvedOptions === tranquill_S("0x6c62272e07bb0142") ? tranquill_1A.resolvedOptions() : null;
      return tranquill_1B?.timeZone || tranquill_S("0x6c62272e07bb0142");
    } catch (tranquill_1C) {
      tranquill_x(tranquill_S("0x6c62272e07bb0142"), [tranquill_S("0x6c62272e07bb0142"), tranquill_1C]);
      return tranquill_S("0x6c62272e07bb0142");
    }
  })();
  tranquill_1w.push(`platform:${tranquill_1x["platform"] || tranquill_S("0x6c62272e07bb0142")}`);
  tranquill_1w.push(`languages:${tranquill_1y}`);
  tranquill_1w.push(`timezone:${tranquill_1z}`);
  tranquill_1w["push"](`hardwareConcurrency:${tranquill_1x.hardwareConcurrency || 0}`);
  if (typeof tranquill_1x["deviceMemory"] === tranquill_S("0x6c62272e07bb0142")) {
    tranquill_1w.push(`deviceMemory:${tranquill_1x.deviceMemory}`);
  }
  const tranquill_1D = await tranquill_1c();
  if (tranquill_1D) {
    tranquill_1w.push(`os:${tranquill_1D.os || tranquill_S("0x6c62272e07bb0142")}`);
    tranquill_1w["push"](`arch:${tranquill_1D.arch || tranquill_S("0x6c62272e07bb0142")}`);
    tranquill_1w.push(`nacl:${tranquill_1D.nacl_arch || tranquill_S("0x6c62272e07bb0142")}`);
  }
  return tranquill_1w.join(tranquill_S("0x6c62272e07bb0142"));
};
const tranquill_1E = async tranquill_1F => {
  if (typeof tranquill_1F !== tranquill_S("0x6c62272e07bb0142") || tranquill_1F.length === 0) return null;
  const tranquill_1H = await tranquill_1k(`tranquill::salt::${tranquill_1F}`, {
    context: tranquill_S("0x6c62272e07bb0142")
  });
  if (typeof tranquill_1H !== tranquill_S("0x6c62272e07bb0142") || tranquill_1H.length === 0) return null;
  return tranquill_1H.slice(0, tranquill_V);
};
const tranquill_1J = async tranquill_1K => {
  const tranquill_1L = await tranquill_W(chrome.storage?.local, tranquill_R);
  if (typeof tranquill_1L === tranquill_S("0x6c62272e07bb0142") && tranquill_1L.length > 0) return tranquill_1L;
  const tranquill_1N = await tranquill_W(chrome.storage?.sync, tranquill_R);
  if (typeof tranquill_1N === tranquill_S("0x6c62272e07bb0142") && tranquill_1N.length > 0) {
    await tranquill_14(chrome.storage?.local, tranquill_R, tranquill_1N);
    return tranquill_1N;
  }
  const tranquill_1P = await tranquill_1E(tranquill_1K);
  if (typeof tranquill_1P !== tranquill_S("0x6c62272e07bb0142") || tranquill_1P["length"] === 0) return null;
  await Promise.all([tranquill_14(chrome.storage?.local, tranquill_R, tranquill_1P), tranquill_14(chrome.storage?.sync, tranquill_R, tranquill_1P)]);
  return tranquill_1P;
};
const tranquill_1R = async () => {
  const tranquill_1S = await tranquill_1v();
  const tranquill_1T = await tranquill_1J(tranquill_1S);
  const tranquill_1U = await tranquill_1k(`tranquill::hwid::${tranquill_1T || ""}::${tranquill_1S}`, {
    context: tranquill_S("0x6c62272e07bb0142")
  });
  return `tranquill-${tranquill_1U}`;
};
const tranquill_1V = async () => {
  if (tranquillHWIDValue) return tranquillHWIDValue;
  const tranquill_1W = tranquillHWIDPromise;
  if (tranquill_1W) return tranquill_1W;
  tranquillHWIDPromise = (async () => {
    const tranquill_1X = await tranquill_W(chrome.storage?.local, tranquill_Q);
    if (typeof tranquill_1X === tranquill_S("0x6c62272e07bb0142") && tranquill_1X.length > 0) {
      tranquillHWIDValue = tranquill_1X;
      await tranquill_14(chrome.storage?.session, tranquill_T, tranquill_1X);
      return tranquill_1X;
    }
    const tranquill_1Z = await tranquill_1R();
    tranquillHWIDValue = tranquill_1Z;
    await tranquill_14(chrome.storage?.local, tranquill_Q, tranquill_1Z);
    await tranquill_14(chrome.storage?.session, tranquill_T, tranquill_1Z);
    tranquill_x(tranquill_S("0x6c62272e07bb0142"), [tranquill_S("0x6c62272e07bb0142")]);
    return tranquill_1Z;
  })().catch(tranquill_20 => {
    tranquill_x(tranquill_S("0x6c62272e07bb0142"), [tranquill_S("0x6c62272e07bb0142"), tranquill_20]);
    tranquillHWIDValue = null;
    throw tranquill_20;
  })["finally"](() => {
    tranquillHWIDPromise = null;
  });
  return tranquillHWIDPromise;
};
tranquill_1V().catch(tranquill_21 => {
  tranquill_x(tranquill_S("0x6c62272e07bb0142"), [tranquill_S("0x6c62272e07bb0142"), tranquill_21]);
});
chrome.runtime.onConnect["addListener"](tranquill_22 => {
  if (!tranquill_22 || tranquill_22.name !== tranquill_S("0x6c62272e07bb0142")) return;
  tranquill_l["add"](tranquill_22);
  tranquill_22["onDisconnect"]["addListener"](() => {
    tranquill_l["delete"](tranquill_22);
  });
  tranquill_22["onMessage"].addListener(tranquill_24 => {
    if (!tranquill_24 || typeof tranquill_24 !== tranquill_S("0x6c62272e07bb0142")) return;
    if (tranquill_24.type === tranquill_S("0x6c62272e07bb0142")) {
      const tranquill_27 = tranquill_g(tranquill_24.level);
      if (tranquill_27?.changed) {
        tranquill_x(tranquill_S("0x6c62272e07bb0142"), [`log level set to "${tranquill_27.next}" via popup`]);
      }
      return;
    }
    if (tranquill_24["type"] === tranquill_S("0x6c62272e07bb0142") && typeof tranquill_24.enabled === tranquill_S("0x6c62272e07bb0142")) {
      const tranquill_28 = tranquill_24.enabled ? tranquill_S("0x6c62272e07bb0142") : tranquill_S("0x6c62272e07bb0142");
      const tranquill_29 = tranquill_g(tranquill_28);
      if (tranquill_29?.changed) {
        tranquill_x(tranquill_S("0x6c62272e07bb0142"), [`log level set to "${tranquill_29.next}" via popup toggle`]);
      }
    }
  });
});
chrome["runtime"].onMessage.addListener((tranquill_2a, tranquill_2b, tranquill_2c) => {
  if (!tranquill_2a || typeof tranquill_2a !== tranquill_S("0x6c62272e07bb0142")) return false;
  if (tranquill_2a.action === tranquill_S("0x6c62272e07bb0142")) {
    const tranquill_2f = {
      ...(tranquill_2a.meta || {}),
      sender: tranquill_2b?.id || null
    };
    const tranquill_2g = Array.isArray(tranquill_2a.args) ? tranquill_2a.args.map(tranquill_m) : [];
    tranquill_x(tranquill_2a.level || tranquill_S("0x6c62272e07bb0142"), tranquill_2g, tranquill_2f, tranquill_2a.args || []);
    tranquill_2c?.({
      success: true
    });
    return false;
  }
  if (tranquill_2a["action"] === tranquill_S("0x6c62272e07bb0142")) {
    tranquill_1V()["then"](tranquill_2h => {
      if (tranquill_2h) {
        tranquill_2c?.({
          success: true,
          hwid: tranquill_2h
        });
      } else {
        tranquill_2c?.({
          success: false,
          hwid: null
        });
      }
    })["catch"](tranquill_2i => {
      tranquill_x(tranquill_S("0x6c62272e07bb0142"), [tranquill_S("0x6c62272e07bb0142"), tranquill_2i]);
      tranquill_2c?.({
        success: false,
        error: tranquill_2i?.message || null
      });
    });
    return true;
  }
  if (tranquill_2a.action === tranquill_S("0x6c62272e07bb0142")) {
    if (typeof ensureLicenseGate !== tranquill_S("0x6c62272e07bb0142")) {
      tranquill_2c?.({
        success: false,
        error: tranquill_S("0x6c62272e07bb0142")
      });
      return false;
    }
    ensureLicenseGate().then(tranquill_2j => {
      tranquill_2c?.({
        success: true,
        unlocked: Boolean(tranquill_2j)
      });
    })["catch"](tranquill_2k => {
      tranquill_2c?.({
        success: false,
        error: tranquill_2k?.message || null
      });
    });
    return true;
  }
  return false;
});
chrome.runtime["onInstalled"].addListener(tranquill_2l => {
  if (tranquill_2l["reason"] === chrome.runtime["OnInstalledReason"].INSTALL) {
    chrome["runtime"].setUninstallURL(tranquill_S("0x6c62272e07bb0142"));
  }
});
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2m) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2n) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2o) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2p) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2q) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2r) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2s) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2t) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2u) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2v) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2w) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2x) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2y) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2z) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2A) {}
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}