const tranquill_global = typeof self !== "undefined" ? self : globalThis;
if (!tranquill_global.tranquill_runtime_ready) {
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::cd312c1cae0d84219e6e1a7a094b17ad"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = "tranquill_tranquill_tranquill";
        tranquill_global.tranquill_runtime_ready = true;
}

(function tranquill_0() {
  const tranquill_1 = new Uint8Array([120, 199, 179, 172, 34, 25, 208, 224, 120, 202, 170, 171, 43, 13, 179, 79, 94, 162, 70, 153, 181, 193, 196, 200, 64, 23, 133, 74, 91, 202, 73, 156, 151, 234, 233, 252, 74, 57, 173, 80, 103, 242, 112, 131, 171, 238, 237, 200, 118, 61, 151, 100, 249, 235, 157, 113, 243, 234, 132, 106, 184, 155, 37, 120, 242, 124, 49, 116, 139, 30, 108, 39, 25, 111, 201, 100, 227, 153, 69, 136, 143, 234, 152, 91, 67, 6, 21, 0, 158, 213, 5, 205, 12, 31, 208, 97, 24, 101, 27, 50, 223, 31, 193, 122, 30, 109, 18, 48, 130, 34, 218, 103, 1, 109, 25, 60, 214, 41, 149, 61, 31, 105, 1, 33, 197, 34, 210, 102, 76, 124, 20, 50, 201, 101, 17, 166, 223, 94, 221, 240, 21, 87, 145, 45, 210, 153, 80, 22, 13, 159, 74, 195, 228, 85, 129, 223, 18, 161, 90, 165, 217, 242, 157, 223, 3, 186, 92, 173, 208, 240, 192, 235, 18, 161, 125, 169, 195, 225, 135, 226, 16, 166, 14, 228, 196, 240, 154, 248, 30, 187, 73, 191, 151, 229, 143, 235, 18, 252, 137, 25, 229, 135, 243, 210, 182, 64, 137, 8, 254, 129, 251, 219, 180, 29, 189, 25, 229, 160, 255, 200, 165, 90, 180, 27, 226, 211, 252, 221, 184, 95, 191, 24, 237, 127, 241, 85, 23, 52, 162, 18, 237, 110, 234, 83, 31, 61, 160, 79, 217, 127, 241, 114, 27, 46, 177, 8, 208, 125, 246, 1, 12, 63, 182, 14, 210, 108, 224, 69, 65, 171, 45, 177, 59, 224, 126, 246, 65, 186, 54, 183, 51, 233, 124, 171, 97, 175, 47, 160, 1, 235, 109, 241, 123, 160, 62, 182, 164, 177, 10, 169, 94, 250, 217, 238, 164, 160, 17, 175, 86, 243, 219, 179, 132, 181, 8, 184, 100, 241, 202, 233, 158, 186, 25, 174, 23, 242, 223, 244, 155, 177, 26, 8, 82, 144, 244, 114, 153, 195, 179, 8, 67, 139, 242, 122, 144, 193, 238, 40, 86, 146, 229, 72, 146, 208, 180, 50, 89, 131, 243, 59, 132, 209, 163, 56, 82, 151, 243, 98, 54, 78, 232, 152, 125, 157, 175, 97, 50, 93, 249, 178, 124, 148, 168, 67, 60, 86, 240, 148, 97, 218, 191, 94, 61, 73, 232, 131, 102, 153, 168, 84, 55, 195, 148, 189, 92, 185, 95, 238, 155, 192, 144, 174, 77, 147, 94, 231, 156, 226, 158, 165, 68, 181, 67, 167, 129, 254, 152, 189, 8, 163, 69, 232, 154, 228, 61, 181, 209, 51, 199, 254, 2, 116, 62, 177, 194, 34, 237, 255, 11, 115, 28, 191, 201, 43, 203, 226, 69, 110, 0, 185, 209, 46, 207, 252, 12, 125, 11, 180, 144, 125, 16, 113, 10, 39, 219, 34, 205, 35, 6, 105, 23, 42, 208, 55, 129, 147, 67, 173, 27, 73, 136, 126, 220, 205, 85, 181, 6, 68, 131, 107, 240, 191, 80, 184, 3, 85, 131, 187, 205, 237, 221, 37, 15, 63, 94, 225, 200, 243, 221, 33, 8, 57, 87, 249, 194, 39, 23, 97, 235, 40, 223, 61, 244, 125, 80, 121, 163, 48, 144, 48, 243, 125, 9, 125, 168, 218, 11, 94, 181, 85, 195, 130, 42, 128, 76, 70, 253, 77, 140, 137, 49, 135, 17, 65, 249, 77, 244, 70, 98, 142, 123, 142, 190, 17, 174, 1, 122, 198, 99, 193, 185, 10, 180, 88, 99, 11, 49, 245, 121, 209, 122, 166, 62, 85, 54, 224, 110, 211, 57, 163, 56, 12, 32, 238, 99, 26, 200, 38, 2, 96, 3, 117, 197, 25, 204, 53, 19, 74, 2, 124, 194, 59, 194, 62, 26, 108, 31, 50, 213, 40, 206, 58, 19, 76, 1, 119, 219, 44, 195, 38, 5, 237, 111, 205, 77, 176, 220, 167, 114, 79, 166, 236, 33, 136, 175, 177, 106, 82, 171, 231, 52, 219, 230, 172, 118, 78, 187, 10, 15, 19, 94, 206, 194, 32, 184, 152, 98, 218, 115, 75, 165, 83, 174, 128, 127, 215, 120, 94, 246, 16, 181, 141, 120, 212, 120, 46, 59, 39, 98, 234, 246, 10, 153, 66, 70, 238, 94, 142, 200, 55, 158, 71, 77, 186, 69, 140, 143, 61, 157, 70, 8, 249, 89, 130, 134, 61, 148, 71, 206, 132, 221, 146, 6, 203, 65, 24, 151, 3, 192, 1, 128, 178, 3, 143, 87, 120, 192, 21, 151, 249, 24, 212, 74, 123, 226, 34, 44, 185, 37, 249, 249, 126, 249, 62, 236, 175, 53, 176, 77, 167, 33, 189, 55, 236, 114, 250, 62, 160, 52, 170, 53, 162, 119, 252, 106, 182, 58, 167, 126, 225, 121, 224, 125, 169, 48, 173, 140, 207, 85, 208, 141, 195, 91, 192, 74, 11, 143, 12, 170, 219, 69, 192, 80, 5, 166, 25, 155, 199, 81, 137, 88, 3, 153, 5, 156, 195, 86, 194, 160, 193, 52, 192, 103, 9, 224, 12, 135, 217, 42, 192, 125, 7, 201, 25, 182, 197, 62, 2, 90, 100, 238, 97, 159, 109, 182, 43, 27, 97, 237, 101, 159, 109, 177, 33, 79, 121, 235, 106, 156, 62, 120, 191, 214, 39, 130, 116, 5, 224, 11, 168, 199, 32, 159, 117, 16, 246, 79, 123, 91, 35, 14, 163, 184, 246, 214, 110, 66, 61, 5, 169, 191, 252, 247, 83, 217, 70, 55, 92, 184, 147, 119, 221, 255, 90, 58, 89, 169, 132, 51, 153, 229, 69, 35, 81, 173, 143, 63, 200, 147, 64, 220, 90, 87, 157, 22, 154, 157, 86, 214, 35, 11, 192, 125, 203, 135, 29, 177, 64, 4, 193, 127, 206, 192, 12, 21, 173, 217, 59, 207, 230, 10, 124, 75, 163, 200, 54, 196, 225, 3, 107, 75, 170, 216, 59, 210, 231, 3, 34, 75, 164, 196, 60, 210, 237, 3, 102, 8, 175, 204, 141, 87, 149, 8, 95, 128, 193, 243, 105, 170, 243, 249, 132, 144, 6, 123, 64, 71, 203, 187, 136, 131, 2, 47, 94, 80, 215, 187, 152, 150, 19, 41, 95, 71, 214, 81, 220, 168, 199, 36, 94, 236, 16, 105, 158, 164, 212, 32, 10, 242, 7, 117, 218, 154, 75, 145, 195, 94, 153, 70, 143, 5, 131, 192, 187, 243, 172, 186, 78, 241, 232, 237, 131, 177, 160, 169, 74, 165, 246, 250, 159, 177, 160, 169, 84, 178, 230, 228, 150, 244, 167, 157, 173, 134, 162, 68, 251, 64, 194, 136, 188, 128, 184, 67, 239, 71, 177, 158, 163, 157, 161, 93, 237, 80, 170, 205, 166, 155, 165, 13, 250, 81, 226, 153, 167, 134, 180, 73, 96, 164, 200, 254, 154, 239, 27, 185, 19, 177, 217, 248, 128, 232, 15, 190, 86, 165, 98, 122, 132, 14, 129, 191, 13, 214, 75, 59, 158, 3, 146, 190, 13, 209, 65, 111, 153, 11, 138, 188, 94, 220, 221, 184, 95, 191, 24, 177, 135, 245, 156, 184, 93, 179, 8, 248, 146, 246, 213, 171, 86, 250, 15, 244, 135, 238, 213, 191, 84, 169, 92, 225, 146, 253, 217, 75, 75, 30, 68, 193, 129, 216, 146, 72, 68, 5, 79, 206, 52, 168, 173, 107, 253, 108, 53, 33, 114, 124, 253, 254, 184, 160, 51, 224, 141, 224, 129, 250, 87, 171, 82, 189, 211, 234, 133, 250, 87, 170, 91, 200, 154, 142, 151, 12, 93, 66, 20, 204, 157, 136, 158, 20, 87, 209, 2, 136, 165, 4, 141, 76, 114, 201, 77, 136, 167, 4, 201, 72, 121, 219, 21, 171, 131, 1, 222, 120, 68, 133, 31, 175, 131, 1, 223, 113, 26, 204, 25, 172, 150, 10, 220, 122, 83, 98, 52, 227, 222, 110, 98, 163, 12, 98, 36, 230, 218, 39, 155, 129, 29, 201, 140, 114, 252, 164, 86, 57, 175, 227, 210, 120, 248, 164, 86, 56, 166, 189, 155, 126, 251, 177, 93, 59, 173, 244, 187, 189, 250, 247, 55, 107, 58, 37, 187, 173, 255, 243, 126, 47, 19, 219, 17, 106, 210, 29, 15, 116, 137, 55, 100, 149, 240, 209, 37, 79, 136, 27, 106, 159, 225, 208]);
  const tranquill_2 = self.tranquill_PACK = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  tranquill_2.data.push(tranquill_1);
  const tranquill_3 = tranquill_2.data["length"] - 1;
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 0,
    len: 14,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 14,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 20,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 26,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 32,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 38,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 44,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 50,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 54,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 58,
    len: 3,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 61,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 66,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 72,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 73,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 78,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 84,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 90,
    len: 3,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 93,
    len: 41,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 134,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 140,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 147,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 155,
    len: 43,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 198,
    len: 34,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 232,
    len: 36,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 268,
    len: 28,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 296,
    len: 35,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 331,
    len: 36,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 367,
    len: 34,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 401,
    len: 33,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 434,
    len: 34,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 468,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 484,
    len: 23,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 507,
    len: 18,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 525,
    len: 20,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 545,
    len: 21,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 566,
    len: 18,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 584,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 605,
    len: 36,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 641,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 646,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 667,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 673,
    len: 22,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 695,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 701,
    len: 27,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 728,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 733,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 738,
    len: 16,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 754,
    len: 10,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 764,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 768,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 796,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 800,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 828,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 847,
    len: 23,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 870,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 887,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 904,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 926,
    len: 13,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 939,
    len: 15,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 954,
    len: 34,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 988,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 995,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 999,
    len: 25,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1024,
    len: 18,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1042,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1049,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1053,
    len: 27,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1080,
    len: 37,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1117,
    len: 18,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1135,
    len: 23,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1158,
    len: 34,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1192,
    len: 13,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1205,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1211,
    len: 9,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1220,
    len: 16,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1236,
    len: 14,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1250,
    len: 16,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1266,
    len: 24,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1290,
    len: 13,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1303,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1307,
    len: 24,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1331,
    len: 13,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1344,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1351,
    len: 16,
    kind: 1
  });
})();
(function () {
  const tranquill_4 = tranquill_S("0x6c62272e07bb0142");
  const tranquill_5 = 60;
  const tranquill_6 = 200;
  const tranquill_7 = Object.freeze({
    key: tranquill_S("0x6c62272e07bb0142"),
    code: tranquill_S("0x6c62272e07bb0142"),
    altKey: false,
    ctrlKey: false,
    metaKey: false,
    shiftKey: false
  });
  const tranquill_8 = tranquill_9 => {
    if (tranquill_9 && typeof tranquill_9 === tranquill_S("0x6c62272e07bb0142")) {
      const tranquill_b = typeof tranquill_9.key === tranquill_S("0x6c62272e07bb0142") && tranquill_9.key.length > 0 ? tranquill_9.key : tranquill_7.key;
      const tranquill_c = typeof tranquill_9.code === tranquill_S("0x6c62272e07bb0142") && tranquill_9["code"].length > 0 ? tranquill_9["code"] : tranquill_b;
      return {
        key: tranquill_b,
        code: tranquill_c,
        altKey: tranquill_9["altKey"] === true,
        ctrlKey: tranquill_9["ctrlKey"] === true,
        metaKey: tranquill_9.metaKey === true,
        shiftKey: tranquill_9.shiftKey === true
      };
    }
    if (typeof tranquill_9 === tranquill_S("0x6c62272e07bb0142") && tranquill_9.trim().length > 0) {
      const tranquill_e = tranquill_9["trim"]();
      return {
        key: tranquill_e,
        code: tranquill_e,
        altKey: false,
        ctrlKey: false,
        metaKey: false,
        shiftKey: false
      };
    }
    return {
      ...tranquill_7
    };
  };
  const tranquill_f = tranquill_g => {
    const tranquill_h = tranquill_8(tranquill_g);
    const tranquill_i = [];
    if (tranquill_h.ctrlKey) tranquill_i["push"](tranquill_S("0x6c62272e07bb0142"));
    if (tranquill_h.metaKey) tranquill_i["push"](tranquill_S("0x6c62272e07bb0142"));
    if (tranquill_h.altKey) tranquill_i.push(tranquill_S("0x6c62272e07bb0142"));
    if (tranquill_h["shiftKey"]) tranquill_i.push(tranquill_S("0x6c62272e07bb0142"));
    let base = tranquill_h.key;
    if (typeof base !== tranquill_S("0x6c62272e07bb0142") || base.length === 0) {
      base = tranquill_h.code;
    }
    if (base === tranquill_S("0x6c62272e07bb0142")) base = tranquill_S("0x6c62272e07bb0142");
    if (typeof base === tranquill_S("0x6c62272e07bb0142") && base.length === 1) {
      base = base.toUpperCase();
    }
    if (typeof base === tranquill_S("0x6c62272e07bb0142") && base.length > 1) {
      base = `${base.charAt(0).toUpperCase()}${base.slice(1)}`;
    }
    tranquill_i["push"](base);
    return tranquill_i.join(tranquill_S("0x6c62272e07bb0142"));
  };
  const tranquill_j = tranquill_k => tranquill_8({
    key: tranquill_k.key,
    code: tranquill_k.code,
    altKey: tranquill_k.altKey,
    ctrlKey: tranquill_k.ctrlKey,
    metaKey: tranquill_k.metaKey,
    shiftKey: tranquill_k.shiftKey
  });
  class tranquill_l {
    static get defaults() {
      return {
        typingSpeed: 120,
        phantomMode: false,
        abortKey: tranquill_8(tranquill_7)
      };
    }
    static normalize(tranquill_m) {
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        rawSettings: tranquill_m
      });
      const tranquill_n = tranquill_l.defaults;
      const tranquill_o = {
        ...tranquill_n,
        abortKey: tranquill_8(tranquill_n.abortKey)
      };
      if (tranquill_m && typeof tranquill_m === tranquill_S("0x6c62272e07bb0142")) {
        const tranquill_q = Number.parseInt(tranquill_m["typingSpeed"], 10);
        if (Number["isFinite"](tranquill_q)) {
          tranquill_o["typingSpeed"] = Math.min(tranquill_6, Math.max(tranquill_5, tranquill_q));
        }
        if (typeof tranquill_m.phantomMode === tranquill_S("0x6c62272e07bb0142")) {
          tranquill_o.phantomMode = tranquill_m.phantomMode;
        }
        if (Object.prototype.hasOwnProperty["call"](tranquill_m, tranquill_S("0x6c62272e07bb0142"))) {
          tranquill_o.abortKey = tranquill_8(tranquill_m["abortKey"]);
        }
      }
      return tranquill_o;
    }
    static getSettings() {
      log.debug(tranquill_S("0x6c62272e07bb0142"));
      return new Promise((tranquill_r, tranquill_s) => {
        chrome["storage"]["local"].get(tranquill_4, tranquill_t => {
          if (chrome.runtime["lastError"]) {
            const tranquill_u = new Error(chrome.runtime.lastError.message);
            log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_u);
            tranquill_s(tranquill_u);
            return;
          }
          const tranquill_v = tranquill_t[tranquill_4];
          const tranquill_w = tranquill_l.normalize(tranquill_v);
          log.debug(tranquill_S("0x6c62272e07bb0142"), tranquill_w);
          tranquill_r(tranquill_w);
        });
      });
    }
    static saveSettings(tranquill_x) {
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        settings: tranquill_x
      });
      const tranquill_y = tranquill_l.normalize(tranquill_x);
      return new Promise((tranquill_z, tranquill_A) => {
        chrome.storage.local.set({
          [tranquill_4]: tranquill_y
        }, () => {
          if (chrome.runtime["lastError"]) {
            const tranquill_B = new Error(chrome.runtime["lastError"].message);
            log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_B);
            tranquill_A(tranquill_B);
            return;
          }
          log.debug(tranquill_S("0x6c62272e07bb0142"), tranquill_y);
          tranquill_z(tranquill_y);
        });
      });
    }
  }
  class tranquill_C {
    constructor(tranquill_D) {
      this.documentRef = tranquill_D;
      this.slider = null;
      this.sliderValue = null;
      this.phantomToggle = null;
      this.abortKeyButton = null;
      this.abortKeyValue = null;
      this.abortKeyHint = null;
      this.backButton = null;
      this.currentSettings = tranquill_l.defaults;
      this["isRestored"] = false;
      this.isCapturingAbortKey = false;
      this.abortKeyCaptureHandler = null;
      this.abortKeyBlurHandler = null;
      log["debug"](tranquill_S("0x6c62272e07bb0142"));
    }
    async init() {
      log.debug(tranquill_S("0x6c62272e07bb0142"));
      this["cacheElements"]();
      this["registerEventListeners"]();
      await this.restoreSettings();
      log["info"](tranquill_S("0x6c62272e07bb0142"));
    }
    cacheElements() {
      this.slider = this.documentRef["querySelector"](tranquill_S("0x6c62272e07bb0142"));
      this.sliderValue = this.documentRef.querySelector(tranquill_S("0x6c62272e07bb0142"));
      this["phantomToggle"] = this.documentRef.querySelector(tranquill_S("0x6c62272e07bb0142"));
      this.abortKeyButton = this.documentRef.querySelector(tranquill_S("0x6c62272e07bb0142"));
      if (this["abortKeyButton"]) {
        this.abortKeyValue = this.abortKeyButton["querySelector"](tranquill_S("0x6c62272e07bb0142"));
        this.abortKeyHint = this["abortKeyButton"]["querySelector"](tranquill_S("0x6c62272e07bb0142"));
      } else {
        this.abortKeyValue = null;
        this["abortKeyHint"] = null;
      }
      this.backButton = this.documentRef.querySelector(tranquill_S("0x6c62272e07bb0142"));
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        hasSlider: Boolean(this.slider),
        hasPhantomToggle: Boolean(this.phantomToggle),
        hasAbortKeyButton: Boolean(this.abortKeyButton)
      });
    }
    registerEventListeners() {
      if (this["slider"]) {
        this.slider.addEventListener(tranquill_S("0x6c62272e07bb0142"), () => {
          const tranquill_E = this["sanitizeTypingSpeed"](this.slider["value"]);
          this.updateSliderDisplay(tranquill_E);
          log["debug"](tranquill_S("0x6c62272e07bb0142"), {
            sanitized: tranquill_E
          });
        });
        this.slider.addEventListener(tranquill_S("0x6c62272e07bb0142"), async () => {
          const tranquill_F = this.sanitizeTypingSpeed(this["slider"].value);
          this.slider.value = String(tranquill_F);
          log.debug(tranquill_S("0x6c62272e07bb0142"), {
            sanitized: tranquill_F
          });
          await this["persistSettings"]({
            typingSpeed: tranquill_F
          });
        });
      }
      if (this.phantomToggle) {
        this.phantomToggle.addEventListener(tranquill_S("0x6c62272e07bb0142"), async () => {
          const tranquill_G = this.phantomToggle.checked;
          log.debug(tranquill_S("0x6c62272e07bb0142"), {
            isEnabled: tranquill_G
          });
          tranquill_13(tranquill_G);
          await this.persistSettings({
            phantomMode: tranquill_G
          });
        });
      }
      if (this.abortKeyButton) {
        this.abortKeyButton.addEventListener(tranquill_S("0x6c62272e07bb0142"), () => {
          this.startAbortKeyCapture();
        });
      }
      if (this["backButton"]) {
        this.backButton.addEventListener(tranquill_S("0x6c62272e07bb0142"), () => {
          const tranquill_H = new URL(chrome.runtime.getURL(tranquill_S("0x6c62272e07bb0142")));
          tranquill_H.searchParams.set(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
          window.location.href = tranquill_H.toString();
          log.info(tranquill_S("0x6c62272e07bb0142"), {
            transition: tranquill_S("0x6c62272e07bb0142")
          });
        });
      }
    }
    sanitizeTypingSpeed(tranquill_I) {
      const tranquill_J = Number["parseInt"](tranquill_I, 10);
      if (!Number.isFinite(tranquill_J)) {
        log.debug(tranquill_S("0x6c62272e07bb0142"), {
          value: tranquill_I,
          fallback: this["currentSettings"]["typingSpeed"]
        });
        return this.currentSettings.typingSpeed;
      }
      const tranquill_K = Math.min(tranquill_6, Math.max(tranquill_5, tranquill_J));
      log["debug"](tranquill_S("0x6c62272e07bb0142"), {
        value: tranquill_I,
        sanitized: tranquill_K
      });
      return tranquill_K;
    }
    async restoreSettings() {
      try {
        this.currentSettings = await tranquill_l.getSettings();
      } catch (tranquill_L) {
        log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_L);
        this.currentSettings = tranquill_l.defaults;
      }
      this.isRestored = true;
      this.applySettingsToUI();
      log["debug"](tranquill_S("0x6c62272e07bb0142"), this.currentSettings);
      tranquill_13(this.currentSettings.phantomMode);
    }
    applySettingsToUI() {
      const {
        typingSpeed: tranquill_M,
        phantomMode: tranquill_N,
        abortKey: tranquill_O
      } = this.currentSettings;
      log["debug"](tranquill_S("0x6c62272e07bb0142"), this["currentSettings"]);
      if (this.slider) {
        this.slider.value = String(tranquill_M);
        this["updateSliderDisplay"](tranquill_M);
      }
      if (this.phantomToggle) {
        this["phantomToggle"].checked = Boolean(tranquill_N);
      }
      this.updateAbortKeyDisplay(tranquill_O);
    }
    updateSliderDisplay(tranquill_P) {
      if (this["sliderValue"]) {
        this.sliderValue["textContent"] = `${tranquill_P} WPM`;
        log["debug"](tranquill_S("0x6c62272e07bb0142"), {
          value: tranquill_P
        });
      }
    }
    updateAbortKeyDisplay(tranquill_Q = this.currentSettings["abortKey"]) {
      if (!this["abortKeyButton"]) return;
      const tranquill_R = tranquill_f(tranquill_Q);
      if (this.abortKeyValue) {
        this.abortKeyValue.textContent = tranquill_R;
      } else {
        this.abortKeyButton["textContent"] = tranquill_R;
      }
      if (this.abortKeyHint) {
        this.abortKeyHint.textContent = this.isCapturingAbortKey ? tranquill_S("0x6c62272e07bb0142") : tranquill_S("0x6c62272e07bb0142");
      }
      this["abortKeyButton"]["classList"].toggle(tranquill_S("0x6c62272e07bb0142"), this.isCapturingAbortKey);
    }
    startAbortKeyCapture() {
      if (!this.abortKeyButton) return;
      if (this.isCapturingAbortKey) {
        this.stopAbortKeyCapture({
          cancelled: true
        });
        return;
      }
      this.isCapturingAbortKey = true;
      this.updateAbortKeyDisplay();
      this["abortKeyCaptureHandler"] = tranquill_S => {
        this.handleAbortKeyCapture(tranquill_S);
      };
      window.addEventListener(tranquill_S("0x6c62272e07bb0142"), this.abortKeyCaptureHandler, true);
      this.abortKeyBlurHandler = () => {
        this.stopAbortKeyCapture({
          cancelled: true
        });
      };
      window["addEventListener"](tranquill_S("0x6c62272e07bb0142"), this["abortKeyBlurHandler"]);
      log.info(tranquill_S("0x6c62272e07bb0142"));
    }
    handleAbortKeyCapture(tranquill_T) {
      if (!this.isCapturingAbortKey) return;
      tranquill_T["preventDefault"]();
      tranquill_T.stopPropagation();
      if (tranquill_T.repeat) return;
      const tranquill_U = tranquill_j(tranquill_T);
      log["info"](tranquill_S("0x6c62272e07bb0142"), {
        binding: tranquill_U
      });
      this.stopAbortKeyCapture();
      this.updateAbortKeyDisplay(tranquill_U);
      this.persistSettings({
        abortKey: tranquill_U
      });
    }
    stopAbortKeyCapture({
      cancelled: tranquill_V = false
    } = {}) {
      if (!this.isCapturingAbortKey) return;
      this.isCapturingAbortKey = false;
      if (this.abortKeyCaptureHandler) {
        window.removeEventListener(tranquill_S("0x6c62272e07bb0142"), this["abortKeyCaptureHandler"], true);
        this.abortKeyCaptureHandler = null;
      }
      if (this["abortKeyBlurHandler"]) {
        window.removeEventListener(tranquill_S("0x6c62272e07bb0142"), this.abortKeyBlurHandler);
        this.abortKeyBlurHandler = null;
      }
      this.updateAbortKeyDisplay();
      if (tranquill_V) {
        log["debug"](tranquill_S("0x6c62272e07bb0142"));
      }
    }
    async persistSettings(tranquill_W) {
      if (!this.isRestored) {
        log.debug(tranquill_S("0x6c62272e07bb0142"));
        return;
      }
      const tranquill_X = {
        ...this.currentSettings,
        ...tranquill_W
      };
      try {
        this.currentSettings = await tranquill_l.saveSettings(tranquill_X);
        this.applySettingsToUI();
        log.info(tranquill_S("0x6c62272e07bb0142"), tranquill_W);
      } catch (tranquill_Y) {
        log["error"](tranquill_S("0x6c62272e07bb0142"), tranquill_Y);
      }
    }
  }
  function tranquill_Z() {
    const tranquill_10 = new tranquill_C(document);
    tranquill_10.init().catch(tranquill_11 => {
      log["error"](tranquill_S("0x6c62272e07bb0142"), tranquill_11);
    });
    const tranquill_12 = document["querySelector"](tranquill_S("0x6c62272e07bb0142"));
    let cText = tranquill_12.innerText;
    cText = cText.replace(tranquill_S("0x6c62272e07bb0142"), new Date()["getFullYear"]()).replace(tranquill_S("0x6c62272e07bb0142"), chrome.runtime["getManifest"]()["version"]);
    tranquill_12.innerText = cText;
  }
  function tranquill_13(tranquill_14) {
    document.querySelectorAll(tranquill_S("0x6c62272e07bb0142")).forEach(tranquill_15 => {
      if (tranquill_14) {
        if (!tranquill_15.classList["contains"](tranquill_S("0x6c62272e07bb0142")) && !tranquill_15["classList"].contains(tranquill_S("0x6c62272e07bb0142"))) {
          tranquill_15.classList.add(tranquill_S("0x6c62272e07bb0142"));
          tranquill_15.setAttribute(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
        }
      } else {
        tranquill_15.classList.remove(tranquill_S("0x6c62272e07bb0142"));
        tranquill_15.removeAttribute(tranquill_S("0x6c62272e07bb0142"));
      }
    });
  }
  if (document.readyState === tranquill_S("0x6c62272e07bb0142")) {
    document.addEventListener(tranquill_S("0x6c62272e07bb0142"), tranquill_Z);
  } else {
    tranquill_Z();
  }
})();
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}