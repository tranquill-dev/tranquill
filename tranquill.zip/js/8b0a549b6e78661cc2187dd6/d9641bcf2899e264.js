const tranquill_global = typeof self !== "undefined" ? self : globalThis;
if (!tranquill_global.tranquill_runtime_ready) {
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::cd312c1cae0d84219e6e1a7a094b17ad"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = "tranquill_tranquill_tranquill";
        tranquill_global.tranquill_runtime_ready = true;
}

(function tranquill_0() {
  const tranquill_1 = new Uint8Array([69, 157, 37, 187, 59, 236, 96, 252, 115, 174, 61, 243, 96, 238, 120, 234, 127, 172, 34, 172, 119, 233, 116, 240, 92, 139, 254, 191, 34, 250, 187, 248, 106, 184, 230, 247, 121, 228, 175, 227, 103, 189, 228, 170, 110, 224, 184, 236, 109, 167, 227, 185, 42, 251, 164, 184, 118, 72, 175, 64, 38, 196, 232, 129, 52, 28, 236, 89, 54, 218, 229, 137, 106, 72, 184, 71, 50, 220, 172, 131, 122, 11, 169, 65, 32, 205, 172, 132, 118, 17, 226, 15, 34, 1, 237, 119, 114, 13, 170, 54, 96, 85, 174, 106, 98, 0, 173, 48, 103, 85, 230, 125, 39, 13, 167, 59, 34, 79, 253, 125, 39, 18, 171, 42, 49, 68, 252, 54, 39, 49, 162, 61, 38, 82, 235, 56, 115, 19, 183, 120, 38, 70, 239, 113, 105, 79, 254, 171, 128, 52, 134, 251, 140, 115, 199, 233, 212, 119, 141, 235, 148, 114, 219, 163, 201, 57, 140, 174, 153, 120, 220, 188, 128, 51, 140, 248, 137, 116, 204, 238, 201, 51, 140, 224, 148, 126, 207, 167, 197, 37, 199, 174, 176, 123, 204, 175, 211, 50, 201, 250, 146, 110, 137, 175, 199, 54, 128, 224, 206, 137, 89, 121, 133, 252, 156, 62, 77, 190, 65, 86, 196, 254, 132, 40, 65, 188, 94, 110, 196, 255, 140, 37, 69, 181, 72, 121, 196, 231, 131, 42, 82, 179, 68, 103, 133, 240, 129, 46, 222, 165, 44, 178, 53, 68, 213, 84, 244, 158, 45, 158, 59, 78, 196, 85, 36, 217, 62, 175, 62, 27, 120, 239, 111, 200, 127, 173, 37, 29, 120, 239, 218, 218, 212, 202, 93, 24, 86, 14, 155, 216, 207, 200, 90, 2, 201, 78, 55, 200, 66, 140, 237, 14, 202, 68, 49, 217, 74, 248, 163, 61, 251, 126, 97, 231, 61, 246, 164, 49, 225, 227, 183, 191, 247, 104, 117, 101, 49, 224, 190, 164, 230, 98, 105, 103, 209, 59, 229, 108, 19, 97, 163, 100, 212, 60, 246, 124, 9, 63, 161, 59, 210, 39, 246, 4, 241, 10, 7, 143, 51, 208, 193, 7, 255, 22, 16, 158, 50, 205, 101, 34, 172, 39, 48, 2, 188, 6, 187, 192, 102, 192, 51, 29, 160, 6, 189, 203, 102, 214, 246, 72, 214, 84, 131, 141, 145, 156, 193, 80, 249, 21, 129, 147, 131, 156, 195, 28, 241, 124, 205, 149, 151, 213, 192, 85, 215, 70, 132, 146, 131, 213, 223, 89, 213, 64, 132, 142, 129, 145, 141, 89, 200, 80, 128, 153, 138, 129, 222, 60, 164, 170, 103, 230, 101, 35, 41, 99, 123, 254, 165, 118, 199, 104, 208, 51, 128, 32, 146, 110, 232, 41, 210, 45, 146, 32, 144, 34, 224, 64, 158, 43, 134, 105, 147, 107, 198, 122, 215, 44, 146, 105, 138, 106, 208, 41, 205, 55, 150, 42, 155, 113, 198, 41, 216, 39, 144, 45, 156, 99, 214, 98, 158, 39, 153, 44, 147, 103, 219, 125, 229, 161, 254, 186, 57, 113, 112, 108, 255, 161, 107, 79, 20, 175, 45, 157, 157, 234, 108, 91, 152, 194, 153, 216, 20, 18, 69, 10, 128, 145, 11, 80, 209, 29, 219, 140, 3, 137, 144, 82, 238, 242, 162, 114, 189, 192, 74, 179, 118, 4, 3, 154, 126, 190, 62, 125, 250, 120, 236, 244, 63, 185, 42, 168, 99, 14, 177, 93, 38, 201, 249, 159, 123, 33, 240, 64, 35, 211, 226, 150, 115, 92, 188, 90, 52, 217, 254, 128, 114, 92, 166, 82, 59, 213, 244, 146, 99, 21, 191, 93, 119, 218, 241, 154, 123, 25, 180, 27, 47, 139, 195, 110, 106, 76, 139, 44, 55, 164, 130, 102, 122, 80, 142, 37, 63, 217, 214, 111, 59, 80, 140, 41, 47, 144, 195, 108, 114, 67, 135, 96, 55, 150, 197, 105, 117, 25, 133, 33, 47, 156, 31, 195, 128, 91, 217, 17, 9, 158, 24, 215, 5, 65, 30, 90, 217, 145, 144, 140, 31, 65, 49, 198, 255, 126, 253, 16, 60, 86, 13, 124, 176, 134, 209, 174, 36, 45, 123, 208, 62, 212, 48, 81, 104, 23, 53, 196, 50, 212, 58, 18, 119, 88, 97, 195, 61, 214, 36, 4, 117, 20, 121, 159, 124, 232, 57, 20, 125, 11, 112, 145, 40, 202, 44, 81, 125, 31, 116, 216, 50, 150, 234, 12, 20, 134, 9, 197, 145, 66, 212, 20, 20, 149, 90, 217, 222, 82, 200, 64, 29, 142, 25, 197, 223, 84, 223, 64, 26, 130, 3, 142, 122, 180, 106, 216, 15, 241, 45, 16, 77, 172, 69, 153, 13, 233, 59, 28, 79, 179, 125, 153, 20, 238, 52, 22, 66, 171, 56, 223, 0, 233, 52, 28, 69, 89, 207, 36, 138, 32, 132, 37, 220, 99, 129, 48, 134, 32, 142, 102, 195, 44, 213, 55, 137, 34, 144, 112, 193, 96, 205, 107, 200, 28, 141, 96, 201, 127, 196, 101, 156, 62, 152, 37, 201, 107, 192, 44, 134, 98, 83, 119, 44, 23, 149, 37, 37, 210, 84, 99, 80, 10, 81, 16, 220, 218, 141, 194, 72, 81, 211, 107, 63, 97, 241, 62, 3, 137, 48, 245, 199, 192, 25, 253, 120, 34, 121, 56, 244, 242, 165, 234, 96, 115, 220, 203, 11, 177, 6, 13, 131, 118, 219, 216, 27, 171, 88, 15, 220, 112, 192, 216, 67, 242, 16, 26, 220, 112, 199, 238, 230, 88, 35, 172, 188, 158, 43, 231, 253, 73, 41, 176, 226, 214, 110, 235, 235, 95, 35, 172, 0, 127, 80, 120, 194, 165, 150, 240, 9, 100, 65, 114, 222, 251, 222, 171, 5, 101, 90, 127, 192, 179, 54, 221, 194, 78, 244, 7, 4, 198, 51, 218, 209, 94, 238, 89, 6, 153, 53, 193, 209, 6, 183, 17, 19, 153, 53, 198, 208, 111, 96, 104, 18, 53, 38, 96, 217, 116, 113, 98, 14, 107, 110, 59, 213, 117, 106, 111, 16, 35, 203, 51, 77, 134, 9, 233, 139, 14, 194, 40, 92, 140, 21, 183, 195, 75, 206, 62, 74, 134, 9, 97, 138, 238, 171, 51, 86, 175, 230, 71, 115, 23, 223, 50, 54, 80, 23, 112, 107, 56, 158, 20, 16, 108, 58, 60, 119, 10, 210, 48, 46, 75, 25, 60, 111, 0, 210, 44, 34, 87, 94, 105, 105, 4, 200, 61, 46, 73, 31, 126, 107, 0, 190, 70, 174, 218, 75, 131, 105, 18, 137, 94, 129, 155, 109, 165, 85, 63, 197, 66, 179, 215, 73, 155, 114, 28, 197, 84, 189, 210, 73, 151, 120, 75, 163, 217, 228, 142, 228, 17, 166, 83, 148, 214, 249, 138, 227, 29, 134, 86, 178, 221, 228, 140, 244, 105, 116, 2, 50, 191, 49, 66, 185, 21, 190, 203, 51, 214, 48, 28, 249, 21, 170, 220, 120, 205, 107, 1, 250, 241, 13, 31, 38, 182, 214, 202, 97, 234, 17, 11, 158, 160, 40, 221, 1, 196, 219, 78, 220, 23, 89, 106, 209, 61, 214, 99, 91, 126, 88, 52, 145, 61, 194, 116, 16, 101, 3, 41, 146, 52, 20, 75, 83, 232, 196, 197, 133, 46, 20, 51, 187, 98, 113, 191, 97, 162, 180, 54, 172, 101, 163, 97, 208, 138, 224, 170, 74, 17, 103, 251, 144, 136, 43, 173, 94, 208, 176, 239, 144, 22, 226, 230, 85, 215, 164, 192, 75, 28, 158, 7, 144, 201, 89, 219, 87, 24, 158, 16, 211, 16, 127, 133, 20, 203, 170, 66, 200, 12, 123, 133, 3]);
  const tranquill_2 = self.tranquill_PACK = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  tranquill_2["data"].push(tranquill_1);
  const tranquill_3 = tranquill_2.data.length - 1;
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 0,
    len: 24,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 24,
    len: 31,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 55,
    len: 36,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 91,
    len: 55,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 146,
    len: 63,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 209,
    len: 39,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 248,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 264,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 280,
    len: 14,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 294,
    len: 13,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 307,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 319,
    len: 14,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 333,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 353,
    len: 15,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 368,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 372,
    len: 16,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 388,
    len: 49,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 437,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 443,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 448,
    len: 60,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 508,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 518,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 528,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 537,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 546,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 550,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 561,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 571,
    len: 44,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 615,
    len: 43,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 658,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 668,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 678,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 684,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 684,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 693,
    len: 45,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 738,
    len: 30,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 768,
    len: 33,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 801,
    len: 45,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 846,
    len: 10,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 856,
    len: 9,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 865,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 869,
    len: 11,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 880,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 889,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 915,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 936,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 958,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 984,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1006,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1027,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1027,
    len: 8,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1035,
    len: 43,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1078,
    len: 31,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1109,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1131,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1136,
    len: 19,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1155,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1165,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1170,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1176,
    len: 19,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1195,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1205,
    len: 11,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1216,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1221,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1231,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1241,
    len: 13,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1254,
    len: 13,
    kind: 1
  });
})();
(function () {
  "use strict";

  const tranquill_4 = tranquill_S("0x6c62272e07bb0142");
  const tranquill_5 = 900;
  const tranquill_6 = 600;
  const tranquill_7 = 900;
  const tranquill_8 = 320;
  const tranquill_9 = 460;
  const tranquill_a = 320;
  const tranquill_b = tranquill_S("0x6c62272e07bb0142");
  const tranquill_c = tranquill_S("0x6c62272e07bb0142");
  const tranquill_d = tranquill_S("0x6c62272e07bb0142");
  const tranquill_e = tranquill_S("0x6c62272e07bb0142");
  const tranquill_f = 250;
  const tranquill_g = 20;
  const tranquill_h = self?.log ?? console;
  const tranquill_i = self?.tranquillLicenseManager;
  const tranquill_j = tranquill_i ? new tranquill_i({
    storageKey: tranquill_4,
    logger: tranquill_h,
    chrome: self?.chrome ?? null,
    hwidResolver: tranquill_1n,
    defaultErrorMessage: tranquill_c,
    networkErrorMessage: tranquill_d,
    hwidErrorMessage: tranquill_e
  }) : null;
  if (!tranquill_j) {
    tranquill_h?.error?.(tranquill_S("0x6c62272e07bb0142"));
    return;
  }
  const tranquill_l = {
    isLoading: false,
    isUnlocked: false,
    originalButtonLabel: null
  };
  document.addEventListener(tranquill_S("0x6c62272e07bb0142"), () => {
    const tranquill_m = document.querySelector(tranquill_S("0x6c62272e07bb0142"));
    const tranquill_n = document["querySelector"](tranquill_S("0x6c62272e07bb0142"));
    const tranquill_o = document["querySelector"](tranquill_S("0x6c62272e07bb0142"));
    const tranquill_p = document["querySelector"](tranquill_S("0x6c62272e07bb0142"));
    const tranquill_q = document.querySelector(tranquill_S("0x6c62272e07bb0142"));
    const tranquill_r = document.querySelector(tranquill_S("0x6c62272e07bb0142"));
    const tranquill_s = tranquill_o?.querySelector(tranquill_S("0x6c62272e07bb0142"));
    const tranquill_t = tranquill_s?.querySelector(tranquill_S("0x6c62272e07bb0142"));
    const tranquill_u = document.querySelector(tranquill_S("0x6c62272e07bb0142"));
    if (!tranquill_m || !tranquill_n || !tranquill_o || !tranquill_p || !tranquill_s || !tranquill_t) {
      tranquill_h?.warn?.(tranquill_S("0x6c62272e07bb0142"));
      return;
    }
    tranquill_l.originalButtonLabel = tranquill_t.textContent;
    tranquill_o.addEventListener(tranquill_S("0x6c62272e07bb0142"), tranquill_B => {
      tranquill_B.preventDefault();
      void tranquill_S({
        root: tranquill_m,
        container: tranquill_n,
        input: tranquill_p,
        inputGroup: tranquill_r,
        errorEl: tranquill_q,
        button: tranquill_s,
        buttonLabel: tranquill_t,
        successEl: tranquill_u
      });
    });
    tranquill_p.addEventListener(tranquill_S("0x6c62272e07bb0142"), () => {
      tranquill_1e({
        inputGroup: tranquill_r,
        errorEl: tranquill_q
      });
    });
    if (!tranquill_u) {
      tranquill_h?.warn?.(tranquill_S("0x6c62272e07bb0142"));
    }
    void tranquill_D({
      root: tranquill_m,
      container: tranquill_n,
      input: tranquill_p,
      inputGroup: tranquill_r,
      errorEl: tranquill_q,
      button: tranquill_s,
      buttonLabel: tranquill_t,
      successEl: tranquill_u
    });
  });
  async function tranquill_D({
    root: tranquill_E,
    container: tranquill_F,
    input: tranquill_G,
    inputGroup: tranquill_H,
    errorEl: tranquill_I,
    button: tranquill_J,
    buttonLabel: tranquill_K,
    successEl: tranquill_L
  }) {
    let storedLicense = null;
    try {
      storedLicense = await tranquill_j["getStoredLicenseKey"]();
      tranquill_F.classList.remove(tranquill_S("0x6c62272e07bb0142"));
      if (!storedLicense) {
        tranquill_F["classList"].remove(tranquill_S("0x6c62272e07bb0142"));
        tranquill_l.isLoading = false;
        tranquill_l.isUnlocked = false;
        if (tranquill_G) {
          tranquill_G.disabled = false;
          requestAnimationFrame(() => {
            try {
              tranquill_G.focus();
            } catch (tranquill_M) {}
          });
        }
        if (tranquill_J) {
          tranquill_J.disabled = false;
          tranquill_J.removeAttribute(tranquill_S("0x6c62272e07bb0142"));
        }
        if (tranquill_K) {
          tranquill_K["textContent"] = tranquill_l.originalButtonLabel;
        }
        return;
      }
      tranquill_l["isUnlocked"] = false;
      tranquill_l.isLoading = true;
      if (tranquill_G) {
        tranquill_G.value = storedLicense;
        tranquill_G["disabled"] = true;
      }
      if (tranquill_J) {
        tranquill_J.disabled = true;
        tranquill_J.setAttribute(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      }
      if (tranquill_K) {
        tranquill_K.textContent = tranquill_S("0x6c62272e07bb0142");
      }
      tranquill_F.classList.add(tranquill_S("0x6c62272e07bb0142"));
      try {
        await tranquill_1h(storedLicense);
        tranquill_l.isUnlocked = true;
        await tranquill_1W();
        await tranquill_1S({
          root: tranquill_E,
          container: tranquill_F,
          successEl: tranquill_L
        });
        return;
      } catch (tranquill_N) {
        tranquill_h?.warn?.(tranquill_S("0x6c62272e07bb0142"), tranquill_N);
        throw tranquill_N;
      }
    } catch (tranquill_O) {
      tranquill_h?.warn?.(tranquill_S("0x6c62272e07bb0142"), tranquill_O);
      tranquill_F.classList["remove"](tranquill_S("0x6c62272e07bb0142"));
      tranquill_F.classList.remove(tranquill_S("0x6c62272e07bb0142"));
      const tranquill_P = Boolean(tranquill_O && typeof tranquill_O === tranquill_S("0x6c62272e07bb0142") && tranquill_O.shouldClearLicense);
      if (tranquill_P) {
        await tranquill_j["clearStoredLicenseKey"]();
      }
      if (tranquill_G) {
        tranquill_G.disabled = false;
        if (tranquill_P) {
          tranquill_G["value"] = tranquill_S("0x6c62272e07bb0142");
        } else if (storedLicense) {
          tranquill_G.value = storedLicense;
        }
        requestAnimationFrame(() => {
          try {
            tranquill_G.focus();
          } catch (tranquill_R) {}
        });
      }
      if (tranquill_J) {
        tranquill_J.disabled = false;
        tranquill_J.removeAttribute(tranquill_S("0x6c62272e07bb0142"));
      }
      if (tranquill_K) {
        tranquill_K.textContent = tranquill_l.originalButtonLabel;
      }
      tranquill_l.isLoading = false;
      tranquill_l["isUnlocked"] = false;
      tranquill_1a({
        message: tranquill_O?.message || tranquill_S("0x6c62272e07bb0142"),
        inputGroup: tranquill_H,
        errorEl: tranquill_I
      });
    }
  }
  async function tranquill_S({
    root: tranquill_T,
    container: tranquill_U,
    input: tranquill_V,
    inputGroup: tranquill_W,
    errorEl: tranquill_X,
    button: tranquill_Y,
    buttonLabel: tranquill_Z,
    successEl: tranquill_10
  }) {
    if (tranquill_l.isLoading) {
      return;
    }
    const tranquill_11 = tranquill_V.value["trim"]();
    if (!tranquill_11) {
      tranquill_1a({
        message: tranquill_S("0x6c62272e07bb0142"),
        inputGroup: tranquill_W,
        errorEl: tranquill_X
      });
      return;
    }
    tranquill_1e({
      inputGroup: tranquill_W,
      errorEl: tranquill_X
    });
    tranquill_14({
      container: tranquill_U,
      button: tranquill_Y,
      buttonLabel: tranquill_Z,
      input: tranquill_V,
      isLoading: true
    });
    try {
      await tranquill_1h(tranquill_11);
      await tranquill_j.persistLicenseKey(tranquill_11);
      await tranquill_1r();
      tranquill_l.isUnlocked = true;
      await tranquill_1W();
      await tranquill_1S({
        root: tranquill_T,
        container: tranquill_U,
        successEl: tranquill_10
      });
    } catch (tranquill_13) {
      tranquill_h?.warn?.(tranquill_S("0x6c62272e07bb0142"), tranquill_13?.message || tranquill_13);
      tranquill_l.isUnlocked = false;
      tranquill_1a({
        message: tranquill_13?.message || tranquill_S("0x6c62272e07bb0142"),
        inputGroup: tranquill_W,
        errorEl: tranquill_X
      });
    } finally {
      if (!tranquill_l.isUnlocked) {
        tranquill_14({
          container: tranquill_U,
          button: tranquill_Y,
          buttonLabel: tranquill_Z,
          input: tranquill_V,
          isLoading: false
        });
      }
    }
  }
  function tranquill_14({
    container: tranquill_15,
    button: tranquill_16,
    buttonLabel: tranquill_17,
    input: tranquill_18,
    isLoading: tranquill_19
  }) {
    tranquill_l["isLoading"] = tranquill_19;
    tranquill_15.classList.toggle(tranquill_S("0x6c62272e07bb0142"), tranquill_19);
    tranquill_16.disabled = Boolean(tranquill_19);
    tranquill_18["disabled"] = Boolean(tranquill_19);
    if (tranquill_19) {
      tranquill_16["setAttribute"](tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      tranquill_17.textContent = tranquill_S("0x6c62272e07bb0142");
    } else {
      tranquill_16.removeAttribute(tranquill_S("0x6c62272e07bb0142"));
      tranquill_17["textContent"] = tranquill_l["originalButtonLabel"];
    }
  }
  function tranquill_1a({
    message: tranquill_1b,
    inputGroup: tranquill_1c,
    errorEl: tranquill_1d
  }) {
    if (tranquill_1c) {
      tranquill_1c.classList.add(tranquill_S("0x6c62272e07bb0142"));
    }
    if (tranquill_1d) {
      tranquill_1d.classList.replace(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      tranquill_1d["textContent"] = tranquill_1b;
    }
  }
  function tranquill_1e({
    inputGroup: tranquill_1f,
    errorEl: tranquill_1g
  }) {
    if (tranquill_1f) {
      tranquill_1f["classList"].remove(tranquill_S("0x6c62272e07bb0142"));
    }
    if (tranquill_1g) {
      tranquill_1g.classList.replace(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      tranquill_1g.textContent = tranquill_S("0x6c62272e07bb0142");
    }
  }
  async function tranquill_1h(tranquill_1i) {
    const tranquill_1j = tranquill_1i.trim();
    const tranquill_1k = tranquill_5 + Math.floor(Math.random() * tranquill_6);
    const tranquill_1l = tranquill_1I(tranquill_1k);
    try {
      await tranquill_j.validateLicenseKey(tranquill_1j);
      return true;
    } catch (tranquill_1m) {
      if (tranquill_1m instanceof Error) {
        throw tranquill_1m;
      }
      throw new Error(tranquill_c);
    } finally {
      await tranquill_1l;
    }
  }
  function tranquill_1n() {
    const tranquill_1o = window?.tranquillPollHWID;
    if (typeof tranquill_1o !== tranquill_S("0x6c62272e07bb0142")) {
      tranquill_h?.warn?.(tranquill_S("0x6c62272e07bb0142"));
      return Promise.resolve(null);
    }
    return tranquill_1o({
      interval: tranquill_f,
      attempts: tranquill_g
    })["catch"](tranquill_1q => {
      tranquill_h?.warn?.(tranquill_S("0x6c62272e07bb0142"), tranquill_1q);
      return null;
    });
  }
  function tranquill_1r() {
    return new Promise(tranquill_1s => {
      if (!chrome?.runtime?.sendMessage) {
        tranquill_1s();
        return;
      }
      try {
        chrome.runtime["sendMessage"]({
          action: tranquill_S("0x6c62272e07bb0142")
        }, () => tranquill_1s());
      } catch (tranquill_1t) {
        tranquill_1s();
      }
    });
  }
  async function tranquill_1u() {
    tranquill_1y(tranquill_S("0x6c62272e07bb0142"));
    try {
      await tranquill_1F();
    } catch (tranquill_1v) {}
    await tranquill_1I(250);
    const tranquill_1w = new URL(tranquill_S("0x6c62272e07bb0142"), window.location.href);
    tranquill_1w.searchParams.set(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
    try {
      window["location"].replace(tranquill_1w.toString());
    } catch (tranquill_1x) {
      window.location.href = tranquill_1w.toString();
    }
  }
  function tranquill_1y(tranquill_1z) {
    if (typeof tranquill_1z !== tranquill_S("0x6c62272e07bb0142")) {
      return;
    }
    const tranquill_1B = tranquill_1z.trim();
    if (!tranquill_1B) {
      return;
    }
    try {
      const tranquill_1D = window?.sessionStorage;
      tranquill_1D?.setItem?.(tranquill_b, tranquill_1B);
    } catch (tranquill_1E) {}
  }
  function tranquill_1F() {
    if (!chrome?.action?.setPopup) {
      return Promise.resolve();
    }
    return new Promise(tranquill_1G => {
      try {
        chrome.action.setPopup({
          popup: tranquill_S("0x6c62272e07bb0142")
        }, () => tranquill_1G());
      } catch (tranquill_1H) {
        tranquill_1G();
      }
    });
  }
  function tranquill_1I(tranquill_1J) {
    return new Promise(tranquill_1K => {
      setTimeout(tranquill_1K, tranquill_1J);
    });
  }
  function tranquill_1L({
    container: tranquill_1M,
    successEl: tranquill_1N
  }) {
    if (!tranquill_1M) {
      return Promise.resolve();
    }
    tranquill_1M.classList["add"](tranquill_S("0x6c62272e07bb0142"));
    if (tranquill_1N) {
      tranquill_1N.setAttribute(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
    }
    return tranquill_1X(tranquill_1M, tranquill_8);
  }
  function tranquill_1P(tranquill_1Q) {
    if (!tranquill_1Q) {
      return Promise.resolve();
    }
    tranquill_1Q.classList["add"](tranquill_S("0x6c62272e07bb0142"));
    return tranquill_1X(tranquill_1Q, tranquill_9);
  }
  async function tranquill_1S({
    root: tranquill_1T,
    container: tranquill_1U,
    successEl: tranquill_1V
  }) {
    if (tranquill_1U) {
      tranquill_1U.classList.remove(tranquill_S("0x6c62272e07bb0142"));
    }
    await tranquill_1L({
      container: tranquill_1U,
      successEl: tranquill_1V
    });
    await tranquill_1I(tranquill_7);
    await tranquill_1P(tranquill_1T);
    await tranquill_1u();
  }
  function tranquill_1W() {
    return tranquill_1I(tranquill_a);
  }
  function tranquill_1X(tranquill_1Y, tranquill_1Z) {
    return new Promise(tranquill_20 => {
      if (!tranquill_1Y) {
        tranquill_20();
        return;
      }
      let resolved = false;
      const tranquill_22 = () => {
        if (resolved) {
          return;
        }
        resolved = true;
        tranquill_1Y.removeEventListener(tranquill_S("0x6c62272e07bb0142"), tranquill_22);
        tranquill_20();
      };
      tranquill_1Y.addEventListener(tranquill_S("0x6c62272e07bb0142"), tranquill_22);
      const tranquill_23 = Number.isFinite(tranquill_1Z) ? tranquill_1Z : 400;
      setTimeout(tranquill_22, tranquill_23);
    });
  }
})();
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}