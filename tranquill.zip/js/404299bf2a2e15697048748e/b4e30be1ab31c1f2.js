const tranquill_global = typeof self !== "undefined" ? self : globalThis;
if (!tranquill_global.tranquill_runtime_ready) {
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::16fd2ce4be226d9f78b1905b71de3935"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = "tranquill_tranquill_tranquill";
        tranquill_global.tranquill_runtime_ready = true;
}

(function tranquill_0() {
  const tranquill_1 = new Uint8Array([83, 241, 34, 87, 87, 246, 46, 25, 80, 250, 49, 80, 83, 237, 99, 88, 79, 235, 38, 88, 71, 224, 99, 80, 77, 240, 55, 80, 66, 245, 42, 67, 70, 253, 99, 80, 77, 185, 37, 75, 66, 244, 38, 20, 230, 101, 0, 16, 225, 105, 45, 11, 224, 112, 11, 10, 250, 86, 11, 5, 234, 125, 89, 83, 232, 117, 93, 84, 228, 59, 74, 84, 231, 111, 76, 85, 253, 59, 90, 88, 251, 114, 89, 79, 169, 114, 71, 82, 253, 114, 72, 87, 224, 97, 64, 85, 238, 27, 179, 221, 65, 121, 241, 199, 95, 90, 253, 221, 76, 96, 246, 206, 75, 202, 201, 12, 251, 255, 223, 208, 79, 150, 253, 229, 89, 228, 164, 1, 195, 232, 178, 178, 124, 19, 193, 175, 111, 196, 230, 165, 219, 217, 245, 206, 96, 47, 221, 211, 115, 165, 194, 203, 178, 176, 128, 207, 165, 189, 128, 198, 169, 170, 196, 205, 174, 163, 128, 209, 176, 160, 193, 208, 165, 160, 173, 199, 12, 186, 176, 212, 167, 73, 134, 180, 186, 90, 185, 203, 24, 182, 164, 216, 115, 253, 146, 128, 110, 238, 105, 113, 135, 129, 124, 88, 141, 138, 96, 105, 206, 153, 117, 95, 216, 155, 104, 101, 198, 155, 63, 244, 146, 152, 58, 189, 138, 146, 126, 238, 155, 147, 58, 189, 159, 159, 49, 239, 138, 221, 51, 248, 141, 142, 63, 250, 155, 125, 82, 83, 98, 104, 16, 87, 117, 101, 16, 76, 98, 121, 67, 79, 117, 120, 34, 41, 12, 89, 55, 35, 204, 205, 60, 54, 131, 201, 43, 59, 131, 210, 60, 39, 221, 209, 43, 38, 79, 187, 97, 75, 90, 146, 107, 64, 16, 171, 190, 27, 5, 233, 186, 12, 8, 233, 189, 6, 16, 173, 241, 15, 16, 160, 189, 12, 21, 52, 156, 218, 44, 33, 222, 222, 59, 44, 222, 217, 49, 52, 154, 149, 42, 61, 140, 208, 41, 20, 191, 187, 17, 20, 29, 245, 184, 18, 17, 227, 35, 191, 205, 15, 54, 253, 201, 24, 59, 253, 193, 21, 35, 179, 197, 24, 98, 181, 195, 19, 38, 177, 203, 19, 37, 253, 196, 28, 43, 177, 199, 25, 234, 146, 132, 237, 229, 152, 157, 248, 237, 221, 230, 243, 214, 200, 188, 154, 212, 178, 182, 154, 192, 186, 180, 148, 154, 163, 178, 146, 212, 167, 181, 158, 154, 161, 191, 130, 207, 182, 169, 135, 155, 33, 170, 135, 159, 38, 166, 201, 152, 61, 170, 157, 142, 105, 185, 140, 152, 44, 191, 145, 115, 114, 150, 144, 99, 113, 149, 139, 105, 108, 198, 150, 111, 111, 131, 144, 38, 103, 158, 146, 111, 112, 131, 134, 143, 252, 118, 144, 148, 224, 111, 143, 163, 44, 134, 142, 179, 47, 133, 149, 185, 50, 219, 153, 174, 44, 159, 142, 179, 56, 118, 153, 73, 168, 99, 152, 85, 154, 115, 142, 83, 174, 38, 152, 77, 162, 118, 155, 67, 175, 61, 203, 86, 163, 103, 133, 82, 164, 107, 203, 79, 165, 103, 136, 82, 162, 112, 142, 107, 231, 84, 86, 126, 230, 72, 100, 110, 240, 78, 80, 59, 226, 90, 92, 111, 252, 85, 82, 59, 243, 84, 71, 59, 244, 88, 65, 114, 227, 94, 21, 105, 240, 74, 64, 126, 230, 79, 42, 4, 21, 53, 63, 5, 9, 7, 47, 19, 15, 51, 122, 31, 30, 58, 63, 243, 92, 196, 229, 246, 65, 212, 253, 254, 91, 208, 181, 231, 93, 214, 251, 227, 90, 218, 181, 227, 71, 222, 242, 240, 80, 197, 55, 116, 6, 18, 51, 115, 10, 92, 51, 110, 14, 27, 32, 121, 21, 92, 33, 125, 11, 16, 37, 125, 4, 23, 103, 104, 14, 17, 34, 115, 18, 8, 248, 43, 193, 199, 227, 55, 216, 164, 145, 89, 164, 183, 134, 66, 238, 182, 130, 89, 175, 163, 130, 86, 166, 206, 131, 255, 165, 202, 132, 243, 159, 204, 130, 249, 172, 219, 153, 154, 60, 117, 145, 153, 57, 60, 137, 147, 125, 111, 152, 146, 57, 60, 141, 148, 60, 114, 137, 147, 48, 60, 137, 142, 52, 123, 154, 153, 47, 154, 117, 109, 136, 141, 120, 185, 69, 152, 38, 177, 78, 143, 120, 189, 76, 153, 176, 135, 177, 109, 129, 150, 179, 101, 151, 172, 207, 253, 100, 155, 94, 63, 106, 95, 74, 46, 47, 90, 71, 43, 97, 94, 64, 39, 47, 94, 93, 35, 104, 77, 74, 56, 84, 163, 213, 73, 101, 178, 215, 65, 115, 55, 153, 90, 58, 33, 156, 88, 50, 118, 134, 79, 59, 34, 157, 83, 33, 63, 150, 22, 55, 55, 150, 93, 38, 38, 148, 85, 48, 95, 145, 254, 44, 66, 130, 23, 59, 122, 24, 1, 62, 120, 16, 86, 36, 111, 25, 2, 63, 115, 3, 31, 52, 54, 28, 19, 46, 114, 24, 1, 57, 15, 216, 206, 50, 62, 201, 204, 58, 40, 16, 233, 47, 3, 20, 233, 38, 76, 19, 249, 39, 25, 7, 232, 98, 24, 16, 229, 37, 11, 7, 254, 98, 8, 23, 233, 98, 24, 13, 172, 32, 13, 1, 231, 49, 28, 3, 239, 39, 222, 108, 99, 205, 196, 103, 106, 137, 221, 97, 108, 199, 217, 102, 96, 137, 207, 104, 110, 194, 222, 121, 108, 202, 200, 189, 202, 12, 172, 185, 205, 0, 128, 172, 193, 6, 177, 189, 195, 14, 167, 173, 199, 202, 175, 182, 197, 192, 224, 182, 197, 212, 165, 165, 212, 205, 174, 163, 128, 207, 165, 189, 196, 203, 183, 170, 173, 199, 12, 186, 176, 212, 176, 88, 152, 184, 160, 88, 185, 203, 24, 182, 164, 216, 243, 111, 54, 149, 157, 116, 44, 182, 153, 116, 57, 129, 138, 103, 40, 142, 158, 199, 100, 108, 133, 221, 91, 96, 153, 204, 85, 123, 146, 200, 124, 154, 136, 119, 107, 140, 141, 117, 99, 219, 134, 126, 98, 148, 150, 126, 109, 149, 148, 110, 112, 97, 191, 220, 82, 122, 163, 198, 79, 113, 102, 12, 5, 105, 103, 28, 6, 106, 124, 22, 27, 52, 112, 20, 5, 109, 108, 43, 94, 134, 49, 34, 91, 135, 53, 105, 80, 140, 52, 38, 64, 140, 59, 39, 66, 156, 38, 48, 136, 85, 47, 60, 158, 24, 26, 105, 60, 28, 29, 101, 2, 1, 28, 111, 45, 82, 92, 50, 54, 65, 90, 51, 127, 71, 87, 54, 49, 67, 80, 58, 127, 71, 86, 57, 56, 255, 12, 206, 234, 251, 11, 194, 215, 234, 16, 238, 231, 251, 13, 217, 225, 63, 124, 14, 26, 59, 123, 2, 84, 46, 119, 27, 29, 57, 117, 27, 29, 32, 122, 79, 7, 59, 117, 27, 17, 111, 119, 7, 21, 33, 115, 10, 16, 210, 82, 35, 244, 214, 85, 47, 201, 219, 84, 54, 242, 199, 78, 43, 249, 241, 78, 35, 232, 214, 237, 99, 157, 213, 232, 104, 155, 217, 253, 105, 216, 221, 240, 108, 150, 217, 247, 96, 216, 222, 225, 99, 140, 197, 253, 121, 145, 206, 184, 126, 140, 204, 234, 121, 173, 199, 12, 186, 176, 212, 167, 73, 134, 180, 186, 90, 175, 215, 222, 177, 171, 208, 210, 255, 172, 198, 209, 171, 183, 218, 203, 182, 188, 159, 218, 177, 187, 159, 203, 182, 178, 218, 208, 170, 171, 128, 179, 57, 159, 155, 175, 32, 136, 90, 117, 119, 147, 70, 111, 106, 152, 14, 126, 109, 159, 14, 118, 106, 136, 80, 114, 109, 156, 138, 219, 168, 189, 155, 204, 174, 188, 203, 200, 163, 185, 133, 204, 164, 181, 203, 203, 178, 182, 159, 208, 174, 172, 130, 219, 235, 171, 159, 217, 185, 172, 76, 254, 125, 88, 72, 249, 113, 101, 69, 248, 104, 94, 89, 226, 117, 85, 121, 248, 120, 53, 77, 5, 123, 48, 70, 3, 119, 37, 71, 64, 115, 40, 66, 14, 119, 47, 78, 64, 112, 57, 77, 20, 107, 37, 87, 9, 96, 96, 70, 14, 103, 228, 252, 202, 3, 235, 246, 211, 22, 227, 241, 43, 12, 6, 234, 55, 22, 27, 225, 127, 7, 28, 230, 13, 113, 124, 23, 9, 118, 112, 42, 4, 119, 105, 17, 24, 109, 116, 26, 63, 120, 126, 18, 14, 105, 124, 26, 24, 12, 192, 160, 55, 9, 146, 190, 43, 3, 198, 165, 55, 25, 219, 174, 114, 15, 211, 174, 57, 30, 194, 172, 49, 8, 146, 186, 59, 3, 214, 162, 37, 176, 240, 193, 214, 180, 247, 205, 235, 185, 246, 212, 208, 165, 236, 201, 219, 129, 250, 207, 202, 180, 195, 193, 51, 247, 198, 202, 53, 251, 211, 203, 118, 255, 222, 206, 56, 251, 217, 194, 118, 252, 207, 193, 34, 231, 211, 219, 63, 236, 150, 206, 52, 224, 196, 219, 125, 193, 204, 103, 121, 198, 192, 41, 126, 208, 195, 125, 101, 204, 217, 96, 110, 137, 204, 107, 98, 219, 217, 108, 105, 65, 74, 47, 122, 84, 82, 150, 239, 123, 73, 138, 245, 102, 66, 194, 224, 109, 78, 157, 245, 109, 37, 223, 68, 105, 55, 200, 33, 188, 5, 86, 49, 188, 10, 87, 51, 172, 23, 63, 216, 14, 62, 59, 223, 2, 112, 44, 223, 1, 36, 42, 222, 27, 112, 60, 211, 29, 57, 63, 196, 79, 34, 42, 209, 11, 41, 0, 234, 113, 12, 4, 237, 125, 33, 31, 236, 100, 7, 30, 246, 66, 7, 17, 230, 105]);
  const tranquill_2 = self["tranquill_PACK"] = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  tranquill_2.data["push"](tranquill_1);
  const tranquill_3 = tranquill_2["data"].length - 1;
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 0,
    len: 43,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 43,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 62,
    len: 35,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 97,
    len: 2,
    kind: 2
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 99,
    len: 14,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 113,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 119,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 125,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 131,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 137,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 143,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 149,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 174,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 180,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 180,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 186,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 186,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 192,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 192,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 198,
    len: 0,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 198,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 206,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 217,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 245,
    len: 17,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 262,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 267,
    len: 17,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 284,
    len: 8,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 292,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 313,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 333,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 338,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 344,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 376,
    len: 9,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 385,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 390,
    len: 26,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 416,
    len: 19,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 435,
    len: 25,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 460,
    len: 7,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 467,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 486,
    len: 38,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 524,
    len: 39,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 563,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 580,
    len: 27,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 607,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 639,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 646,
    len: 16,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 662,
    len: 14,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 676,
    len: 30,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 706,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 711,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 723,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 732,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 737,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 759,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 768,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 796,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 802,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 828,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 837,
    len: 39,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 876,
    len: 25,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 901,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 917,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 942,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 948,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 954,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 960,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 961,
    len: 15,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 976,
    len: 15,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 991,
    len: 20,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1011,
    len: 9,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1020,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1037,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1057,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1063,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1074,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1095,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1111,
    len: 32,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1143,
    len: 21,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1164,
    len: 34,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1198,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1204,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1210,
    len: 29,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1239,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1246,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1267,
    len: 32,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1299,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1318,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1350,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1359,
    len: 13,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1372,
    len: 25,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1397,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1429,
    len: 21,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1450,
    len: 34,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1484,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1509,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1514,
    len: 15,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1529,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1536,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1547,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1575,
    len: 19,
    kind: 1
  });
})();
let _tranquill_cond = typeof tranquill_o.code === tranquill_S("0x6c62272e07bb0142");
if (_tranquill_cond) {
  tranquill_o.code;
} else {
  tranquill_S("0x6c62272e07bb0142");
}
let _tranquill_cond2 = typeof abortBinding.code === tranquill_S("0x6c62272e07bb0142") && abortBinding.code.length > 0;
if (_tranquill_cond2) {
  abortBinding.code;
} else {
  tranquill_S("0x6c62272e07bb0142");
}
(() => {
  if (window["__tranquillPhantomInitialized"]) {
    log["debug"](tranquill_S("0x6c62272e07bb0142"));
    chrome.runtime?.sendMessage?.({
      action: tranquill_S("0x6c62272e07bb0142")
    });
    return;
  }
  window.__tranquillPhantomInitialized = true;
  log.info(tranquill_S("0x6c62272e07bb0142"));
  const tranquill_4 = 320;
  const tranquill_5 = 200;
  const tranquill_6 = tranquill_RN("0x6c62272e07bb0142");
  const tranquill_7 = 480;
  const tranquill_8 = 600;
  const tranquill_9 = tranquill_S("0x6c62272e07bb0142");
  const tranquill_a = Object.freeze({
    key: tranquill_S("0x6c62272e07bb0142"),
    code: tranquill_S("0x6c62272e07bb0142"),
    altKey: false,
    ctrlKey: false,
    metaKey: false,
    shiftKey: false
  });
  let abortBinding = {
    ...tranquill_a
  };
  let isActive = false;
  let suppressionTimer = null;
  let suppressionActive = false;
  let currentSyntheticCharacter = null;
  let activeRequest = null;
  let tranquill_b = 0;
  const tranquill_c = [];
  let allowSyntheticBackspace = false;
  let syntheticBackspaceTimer = null;
  const tranquill_d = {
    enqueued: 0,
    completed: 0,
    backspaces: 0,
    aborted: 0
  };
  const tranquill_e = tranquill_f => {
    if (tranquill_f && typeof tranquill_f === tranquill_S("0x6c62272e07bb0142")) {
      const tranquill_h = typeof tranquill_f.key === tranquill_S("0x6c62272e07bb0142") && tranquill_f.key["length"] > 0 ? tranquill_f["key"] : tranquill_a.key;
      const tranquill_i = typeof tranquill_f.code === tranquill_S("0x6c62272e07bb0142") && tranquill_f["code"].length > 0 ? tranquill_f["code"] : tranquill_h;
      return {
        key: tranquill_h,
        code: tranquill_i,
        altKey: tranquill_f.altKey === true,
        ctrlKey: tranquill_f["ctrlKey"] === true,
        metaKey: tranquill_f.metaKey === true,
        shiftKey: tranquill_f["shiftKey"] === true
      };
    }
    if (typeof tranquill_f === tranquill_S("0x6c62272e07bb0142") && tranquill_f.trim().length > 0) {
      const tranquill_k = tranquill_f.trim();
      return {
        key: tranquill_k,
        code: tranquill_k,
        altKey: false,
        ctrlKey: false,
        metaKey: false,
        shiftKey: false
      };
    }
    return {
      ...tranquill_a
    };
  };
  const tranquill_l = tranquill_m => {
    abortBinding = tranquill_e(tranquill_m);
    log.debug(tranquill_S("0x6c62272e07bb0142"), abortBinding);
  };
  const tranquill_n = tranquill_o => {
    if (!tranquill_o || !abortBinding) return false;
    const tranquill_q = _tranquill_cond;
    const tranquill_r = typeof tranquill_o.key === tranquill_S("0x6c62272e07bb0142") ? tranquill_o.key : tranquill_S("0x6c62272e07bb0142");
    const tranquill_s = _tranquill_cond2;
    const tranquill_t = typeof abortBinding.key === tranquill_S("0x6c62272e07bb0142") && abortBinding.key.length > 0 ? abortBinding["key"] : tranquill_S("0x6c62272e07bb0142");
    const tranquill_u = tranquill_s ? tranquill_s === tranquill_q : tranquill_t === tranquill_r;
    if (!tranquill_u) return false;
    return tranquill_o["altKey"] === Boolean(abortBinding.altKey) && tranquill_o.ctrlKey === Boolean(abortBinding.ctrlKey) && tranquill_o["metaKey"] === Boolean(abortBinding.metaKey) && tranquill_o.shiftKey === Boolean(abortBinding.shiftKey);
  };
  const tranquill_w = (tranquill_x = tranquill_S("0x6c62272e07bb0142")) => {
    try {
      chrome["runtime"]?.sendMessage?.({
        action: tranquill_S("0x6c62272e07bb0142"),
        reason: tranquill_x
      });
    } catch (tranquill_y) {
      log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_y);
    }
  };
  const tranquill_z = tranquill_A => {
    if (!tranquill_n(tranquill_A)) return false;
    if (tranquill_A.repeat) return true;
    log.info(tranquill_S("0x6c62272e07bb0142"), {
      key: tranquill_A.key ?? null,
      code: tranquill_A.code ?? null,
      isActive
    });
    tranquill_c["length"] = 0;
    if (isActive) {
      tranquill_P(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      tranquill_T();
    }
    tranquill_w(tranquill_S("0x6c62272e07bb0142"));
    return true;
  };
  const tranquill_B = () => {
    try {
      chrome.storage?.local?.get?.(tranquill_9, tranquill_C => {
        const tranquill_D = chrome.runtime?.lastError ?? null;
        if (tranquill_D) {
          log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_D);
          tranquill_l(tranquill_a);
          return;
        }
        const tranquill_E = tranquill_C?.[tranquill_9] ?? null;
        tranquill_l(tranquill_E?.abortKey);
      });
    } catch (tranquill_F) {
      log["warn"](tranquill_S("0x6c62272e07bb0142"), tranquill_F);
      tranquill_l(tranquill_a);
    }
  };
  tranquill_B();
  chrome.storage?.onChanged?.addListener?.((tranquill_G, tranquill_H) => {
    if (tranquill_H !== tranquill_S("0x6c62272e07bb0142")) return;
    if (!tranquill_G || typeof tranquill_G !== tranquill_S("0x6c62272e07bb0142")) return;
    const tranquill_K = tranquill_G[tranquill_9];
    if (!tranquill_K) return;
    try {
      tranquill_l(tranquill_K.newValue?.abortKey);
    } catch (tranquill_M) {
      log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_M);
    }
  });
  const tranquill_N = () => {
    if (suppressionTimer !== null) {
      clearTimeout(suppressionTimer);
      suppressionTimer = null;
    }
  };
  const tranquill_O = () => {
    if (syntheticBackspaceTimer !== null) {
      clearTimeout(syntheticBackspaceTimer);
      syntheticBackspaceTimer = null;
    }
    allowSyntheticBackspace = false;
  };
  const tranquill_P = (tranquill_Q, tranquill_R) => {
    if (activeRequest?.fallbackTimer) {
      clearTimeout(activeRequest.fallbackTimer);
      activeRequest["fallbackTimer"] = null;
    }
    const tranquill_S = activeRequest ? activeRequest.id : null;
    tranquill_N();
    suppressionActive = false;
    currentSyntheticCharacter = null;
    tranquill_O();
    if (activeRequest && tranquill_Q === tranquill_S("0x6c62272e07bb0142")) tranquill_d.completed += 1;
    if (tranquill_Q === tranquill_S("0x6c62272e07bb0142")) tranquill_d["aborted"] += 1;
    log["debug"](tranquill_S("0x6c62272e07bb0142"), {
      requestId: tranquill_S,
      status: tranquill_Q,
      reason: tranquill_R,
      queueLength: tranquill_c.length
    });
    activeRequest = null;
    tranquill_Y();
  };
  const tranquill_T = () => {
    tranquill_c.length = 0;
    activeRequest = null;
    tranquill_N();
    suppressionActive = false;
    currentSyntheticCharacter = null;
    tranquill_O();
    log["debug"](tranquill_S("0x6c62272e07bb0142"));
  };
  const tranquill_U = (tranquill_V, tranquill_W) => {
    const tranquill_X = Number.isFinite(tranquill_V) && tranquill_V > 0 ? tranquill_V : tranquill_4;
    tranquill_N();
    suppressionActive = true;
    suppressionTimer = window.setTimeout(() => {
      suppressionTimer = null;
      suppressionActive = false;
      log.warn(tranquill_S("0x6c62272e07bb0142"), {
        requestId: tranquill_W ?? null,
        queueLength: tranquill_c.length
      });
      tranquill_P(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
    }, tranquill_X + tranquill_5);
  };
  const tranquill_Y = () => {
    if (!isActive) {
      log["debug"](tranquill_S("0x6c62272e07bb0142"));
      return;
    }
    if (activeRequest) {
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        requestId: activeRequest["id"],
        queueLength: tranquill_c.length
      });
      return;
    }
    if (tranquill_c.length === 0) {
      log.debug(tranquill_S("0x6c62272e07bb0142"));
      return;
    }
    const tranquill_Z = tranquill_c["shift"]();
    activeRequest = tranquill_Z;
    tranquill_U(tranquill_4, tranquill_Z.id);
    tranquill_d.enqueued += 1;
    log["debug"](tranquill_S("0x6c62272e07bb0142"), {
      requestId: tranquill_Z["id"],
      queueLength: tranquill_c.length
    });
    tranquill_Z.fallbackTimer = window.setTimeout(() => {
      log.warn(tranquill_S("0x6c62272e07bb0142"), {
        requestId: tranquill_Z["id"]
      });
      tranquill_P(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
    }, tranquill_6);
    try {
      chrome.runtime?.sendMessage?.({
        action: tranquill_S("0x6c62272e07bb0142"),
        requestId: tranquill_Z.id,
        key: tranquill_Z.key,
        timeStamp: tranquill_Z.timeStamp
      });
    } catch (tranquill_10) {
      log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_10);
      tranquill_P(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
    }
  };
  const tranquill_11 = tranquill_12 => {
    if (!isActive) return false;
    if (tranquill_12["isComposing"]) return false;
    if (tranquill_12["ctrlKey"] || tranquill_12.metaKey || tranquill_12["altKey"]) return false;
    if (tranquill_12.key === tranquill_S("0x6c62272e07bb0142")) return true;
    if (tranquill_12.key.length === 1) return true;
    if (tranquill_12.key === tranquill_S("0x6c62272e07bb0142")) return true;
    return false;
  };
  const tranquill_13 = tranquill_14 => {
    const tranquill_15 = {
      id: ++tranquill_b,
      key: tranquill_14.key,
      timeStamp: tranquill_14["timeStamp"] ?? null,
      createdAt: Date.now(),
      expectedKeys: [],
      fallbackTimer: null
    };
    tranquill_c["push"](tranquill_15);
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      requestId: tranquill_15.id,
      queueLength: tranquill_c.length,
      suppressionActive,
      activeRequest: activeRequest ? activeRequest.id : null
    });
    tranquill_Y();
  };
  const tranquill_17 = tranquill_18 => {
    if (tranquill_z(tranquill_18)) return;
    if (!tranquill_11(tranquill_18)) return;
    if (allowSyntheticBackspace && tranquill_18.key === tranquill_S("0x6c62272e07bb0142")) {
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        queueLength: tranquill_c.length
      });
      tranquill_O();
      return;
    }
    if (activeRequest?.expectedKeys?.length) {
      const tranquill_19 = activeRequest.expectedKeys[0];
      if (typeof tranquill_19 === tranquill_S("0x6c62272e07bb0142") && tranquill_18.key === tranquill_19) {
        activeRequest.expectedKeys["shift"]();
        log.debug(tranquill_S("0x6c62272e07bb0142"), {
          requestId: activeRequest.id,
          key: tranquill_18.key,
          remaining: activeRequest["expectedKeys"].length
        });
        return;
      }
    }
    if (tranquill_18.key === tranquill_S("0x6c62272e07bb0142")) {
      tranquill_18.preventDefault();
      tranquill_18["stopImmediatePropagation"]?.();
      tranquill_18["stopPropagation"]();
      if (tranquill_c.length > 0) {
        const tranquill_1b = tranquill_c.pop();
        log.debug(tranquill_S("0x6c62272e07bb0142"), {
          removedRequest: tranquill_1b?.id ?? null,
          queueLength: tranquill_c["length"]
        });
        return;
      }
      tranquill_d["backspaces"] += 1;
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        activeRequest: activeRequest ? activeRequest.id : null
      });
      chrome.runtime?.sendMessage?.({
        action: tranquill_S("0x6c62272e07bb0142")
      });
      return;
    }
    if (tranquill_18["repeat"]) {
      tranquill_18.preventDefault();
      tranquill_18.stopImmediatePropagation?.();
      tranquill_18["stopPropagation"]();
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        key: tranquill_18.key
      });
      return;
    }
    tranquill_18.preventDefault();
    tranquill_18.stopImmediatePropagation?.();
    tranquill_18.stopPropagation();
    tranquill_13(tranquill_18);
  };
  const tranquill_1c = tranquill_1d => {
    if (!isActive || tranquill_1d.isComposing) return;
    if (typeof tranquill_1d["inputType"] === tranquill_S("0x6c62272e07bb0142") && tranquill_1d["inputType"].startsWith(tranquill_S("0x6c62272e07bb0142"))) return;
    const tranquill_1e = (() => {
      if (typeof tranquill_1d.data === tranquill_S("0x6c62272e07bb0142") && tranquill_1d.data.length > 0) {
        return tranquill_1d.data === currentSyntheticCharacter;
      }
      if (currentSyntheticCharacter === tranquill_S("0x6c62272e07bb0142")) {
        return tranquill_1d.inputType === tranquill_S("0x6c62272e07bb0142") || tranquill_1d.inputType === tranquill_S("0x6c62272e07bb0142");
      }
      return false;
    })();
    const tranquill_1f = suppressionActive && !activeRequest && tranquill_c.length === 0 && currentSyntheticCharacter === null;
    if (tranquill_1e || tranquill_1f) {
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        reason: tranquill_1e ? tranquill_S("0x6c62272e07bb0142") : tranquill_S("0x6c62272e07bb0142"),
        inputType: tranquill_1d.inputType,
        requestId: activeRequest ? activeRequest.id : null
      });
      currentSyntheticCharacter = null;
      return;
    }
    log["debug"](tranquill_S("0x6c62272e07bb0142"), {
      inputType: tranquill_1d["inputType"],
      data: tranquill_1d.data,
      suppressionActive,
      activeRequest: activeRequest ? activeRequest.id : null
    });
    tranquill_1d.preventDefault();
    tranquill_1d["stopImmediatePropagation"]?.();
    tranquill_1d.stopPropagation();
  };
  chrome.runtime.onMessage.addListener((tranquill_1g, tranquill_1h, tranquill_1i) => {
    if (!tranquill_1g || typeof tranquill_1g !== tranquill_S("0x6c62272e07bb0142")) {
      tranquill_1i?.({
        success: false
      });
      return false;
    }
    if (tranquill_1g.action === tranquill_S("0x6c62272e07bb0142")) {
      log["debug"](tranquill_S("0x6c62272e07bb0142"));
      tranquill_1i?.({
        success: true,
        pong: true
      });
      return false;
    }
    if (tranquill_1g.action === tranquill_S("0x6c62272e07bb0142")) {
      isActive = !!tranquill_1g.active;
      log.info(tranquill_S("0x6c62272e07bb0142"), {
        isActive
      });
      if (!isActive) {
        tranquill_T();
      } else {
        tranquill_Y();
      }
      tranquill_1i?.({
        success: true
      });
      return false;
    }
    if (tranquill_1g.action === tranquill_S("0x6c62272e07bb0142")) {
      if (!activeRequest || tranquill_1g.requestId !== activeRequest.id) {
        log.warn(tranquill_S("0x6c62272e07bb0142"), {
          requestId: tranquill_1g.requestId ?? null,
          activeRequest: activeRequest ? activeRequest.id : null
        });
        tranquill_1i?.({
          success: false,
          accepted: false
        });
        return false;
      }
      activeRequest.expectedKeys = Array.isArray(tranquill_1g.keys) ? tranquill_1g.keys.filter(tranquill_1l => typeof tranquill_1l === tranquill_S("0x6c62272e07bb0142") && tranquill_1l["length"] > 0) : [];
      currentSyntheticCharacter = typeof tranquill_1g["character"] === tranquill_S("0x6c62272e07bb0142") ? tranquill_1g.character : null;
      tranquill_U(Number(tranquill_1g["duration"]), activeRequest.id);
      if (activeRequest.fallbackTimer) {
        clearTimeout(activeRequest.fallbackTimer);
      }
      const tranquill_1n = Math.max(tranquill_4, Number(tranquill_1g["duration"]) || tranquill_4);
      activeRequest.fallbackTimer = window["setTimeout"](() => {
        log["warn"](tranquill_S("0x6c62272e07bb0142"), {
          requestId: activeRequest?.id ?? null
        });
        tranquill_P(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      }, tranquill_1n + tranquill_7);
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        requestId: activeRequest.id,
        expectedKeys: activeRequest.expectedKeys,
        character: currentSyntheticCharacter
      });
      tranquill_1i?.({
        success: true,
        accepted: true
      });
      return false;
    }
    if (tranquill_1g["action"] === tranquill_S("0x6c62272e07bb0142")) {
      if (!activeRequest || tranquill_1g["requestId"] !== activeRequest.id) {
        log.warn(tranquill_S("0x6c62272e07bb0142"), {
          requestId: tranquill_1g.requestId ?? null,
          activeRequest: activeRequest ? activeRequest["id"] : null
        });
        tranquill_1i?.({
          success: false
        });
        return false;
      }
      tranquill_P(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      tranquill_1i?.({
        success: true
      });
      return false;
    }
    if (tranquill_1g.action === tranquill_S("0x6c62272e07bb0142")) {
      tranquill_O();
      allowSyntheticBackspace = true;
      const tranquill_1o = Math["max"](tranquill_8, Number(tranquill_1g.duration) || 0);
      syntheticBackspaceTimer = window.setTimeout(tranquill_O, tranquill_1o + tranquill_7);
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        windowMs: tranquill_1o
      });
      tranquill_1i?.({
        success: true
      });
      return false;
    }
    if (tranquill_1g.action === tranquill_S("0x6c62272e07bb0142")) {
      if (!activeRequest || tranquill_1g.requestId !== activeRequest["id"]) {
        log.warn(tranquill_S("0x6c62272e07bb0142"), {
          requestId: tranquill_1g.requestId ?? null,
          activeRequest: activeRequest ? activeRequest["id"] : null
        });
        tranquill_1i?.({
          success: false
        });
        return false;
      }
      log["warn"](tranquill_S("0x6c62272e07bb0142"), {
        requestId: activeRequest["id"],
        character: tranquill_1g.character ?? null
      });
      tranquill_P(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      tranquill_1i?.({
        success: true
      });
      return false;
    }
    tranquill_1i?.({
      success: false
    });
    return false;
  });
  window.addEventListener(tranquill_S("0x6c62272e07bb0142"), tranquill_17, true);
  window.addEventListener(tranquill_S("0x6c62272e07bb0142"), tranquill_1c, true);
  log.info(tranquill_S("0x6c62272e07bb0142"), tranquill_d);
  chrome["runtime"]?.sendMessage?.({
    action: tranquill_S("0x6c62272e07bb0142")
  });
})();
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}