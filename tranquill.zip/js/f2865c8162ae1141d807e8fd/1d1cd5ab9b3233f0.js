const tranquill_global = typeof self !== "undefined" ? self : globalThis;
if (!tranquill_global.tranquill_runtime_ready) {
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::cd312c1cae0d84219e6e1a7a094b17ad"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = "tranquill_tranquill_tranquill";
        tranquill_global.tranquill_runtime_ready = true;
}

(function tranquill_0() {
  const tranquill_1 = new Uint8Array([91, 219, 173, 179, 1, 29, 250, 165, 95, 209, 173, 174, 13, 12, 191, 232, 73, 215, 177, 229, 4, 23, 236, 241, 77, 208, 186, 183, 27, 94, 246, 235, 65, 202, 182, 164, 4, 23, 229, 236, 70, 217, 154, 81, 69, 246, 64, 143, 213, 44, 139, 91, 70, 246, 65, 134, 213, 60, 129, 70, 70, 235, 92, 157, 150, 43, 139, 76, 36, 229, 188, 255, 126, 163, 235, 233, 32, 239, 188, 226, 114, 178, 174, 187, 50, 227, 171, 224, 97, 165, 234, 233, 58, 229, 189, 250, 118, 167, 235, 87, 107, 188, 20, 144, 139, 100, 214, 77, 113, 186, 101, 168, 175, 10, 184, 123, 105, 13, 225, 4, 175, 136, 34, 211, 116, 15, 224, 4, 168, 219, 114, 199, 122, 1, 254, 252, 247, 105, 78, 187, 151, 49, 140, 230, 237, 111, 28, 188, 166, 60, 136, 230, 237, 111, 79, 13, 254, 242, 57, 215, 160, 226, 99, 28, 244, 241, 57, 214, 169, 226, 99, 13, 230, 240, 36, 220, 163, 37, 185, 110, 102, 226, 89, 182, 164, 63, 163, 104, 45, 66, 202, 93, 190, 151, 3, 153, 59, 68, 133, 94, 234, 151, 23, 153, 126, 80, 196, 68, 242, 131, 23, 136, 199, 158, 132, 129, 32, 83, 91, 88, 218, 141, 217, 19, 197, 152, 12, 230, 9, 91, 192, 28, 215, 222, 109, 217, 146, 66, 169, 23, 87, 222, 124, 150, 144, 8, 168, 3, 71, 222, 109, 211, 134, 231, 81, 50, 156, 123, 149, 252, 89, 231, 64, 125, 138, 53, 140, 241, 73, 240, 152, 32, 111, 201, 77, 86, 57, 11, 144, 44, 103, 147, 23, 212, 222, 70, 149, 9, 9, 131, 0, 222, 223, 70, 208, 31, 135, 200, 66, 211, 82, 74, 139, 0, 143, 198, 72, 197, 168, 250, 238, 247, 108, 61, 34, 13, 170, 251, 232, 254, 125, 32, 44, 117, 148, 21, 103, 50, 34, 226, 120, 239, 102, 165, 52, 225, 38, 248, 112, 230, 117, 175, 43, 225, 32, 239, 122, 228, 123, 188, 60, 165, 70, 10, 140, 55, 130, 205, 64, 185, 66, 16, 132, 62, 145, 199, 95, 185, 80, 3, 132, 53, 110, 6, 180, 11, 170, 193, 120, 231, 127, 13, 190, 22, 174, 207, 118, 192, 238, 55, 90, 91, 165, 112, 255, 174, 119, 81, 187, 233, 59, 223, 237, 167, 117, 84, 188, 246, 55, 156, 234, 230, 100, 90, 190, 243, 51, 140, 251, 1, 55, 11, 118, 197, 240, 199, 248, 19, 62, 9, 115, 194, 239, 203, 187, 20, 127, 12, 121, 216, 243, 38, 141, 126, 66, 226, 74, 178, 175, 57, 139, 107, 73, 248, 81, 141, 137, 55, 129, 102, 185, 148, 177, 107, 253, 83, 253, 101, 170, 147, 190, 113, 236, 82, 228, 101, 187, 153, 177, 97, 240, 202, 68, 210, 185, 12, 151, 3, 78, 249, 68, 222, 158, 219, 78, 68, 175, 27, 193, 134, 127, 218, 84, 81, 169, 31, 132, 144, 58, 216, 64, 66, 191, 15, 193, 128, 127, 211, 85, 99, 102, 73, 158, 61, 51, 148, 228, 99, 80, 73, 171, 48, 54, 142, 119, 61, 14, 174, 55, 50, 204, 254, 118, 39, 27, 168, 51, 119, 218, 187, 115, 43, 14, 178, 41, 117, 158, 232, 115, 51, 10, 174, 52, 146, 129, 8, 217, 73, 75, 204, 29, 131, 207, 13, 221, 84, 92, 193, 31, 130, 207, 1, 219, 83, 70, 207, 22, 47, 50, 8, 244, 116, 106, 67, 224, 46, 50, 21, 240, 120, 105, 66, 224, 47, 34, 5, 229, 116, 113, 67, 164, 102, 103, 21, 244, 114, 119, 86, 169, 51, 32, 70, 243, 120, 116, 85, 169, 50, 41, 82, 193, 117, 30, 193, 26, 180, 142, 82, 192, 105, 30, 132, 27, 190, 142, 71, 212, 115, 2, 10, 100, 37, 28, 204, 32, 106, 147, 8, 96, 35, 243, 38, 88, 57, 224, 115, 145, 125, 229, 32, 23, 61, 161, 112, 215, 123, 229, 63, 88, 63, 165, 118, 41, 199, 6, 63, 232, 22, 192, 190, 41, 195, 0, 34, 190, 102, 108, 231, 127, 160, 36, 92, 177, 65, 183, 135, 112, 209, 57, 73, 168, 88, 240, 137, 106, 152, 56, 70, 254, 87, 246, 129, 114, 218, 170, 149, 115, 25, 232, 82, 52, 158, 171, 146, 114, 31, 236, 95, 35, 218, 206, 151, 186, 187, 5, 80]);
  const tranquill_2 = self.tranquill_PACK = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  tranquill_2["data"]["push"](tranquill_1);
  const tranquill_3 = tranquill_2["data"].length - 1;
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 0,
    len: 42,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 42,
    len: 26,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 68,
    len: 31,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 99,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 110,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 110,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 116,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 135,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 155,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 177,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 188,
    len: 24,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 212,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 222,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 233,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 253,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 270,
    len: 11,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 281,
    len: 15,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 296,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 308,
    len: 14,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 322,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 328,
    len: 24,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 352,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 372,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 388,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 394,
    len: 25,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 419,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 441,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 460,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 481,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 493,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 519,
    len: 15,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 534,
    len: 29,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 563,
    len: 24,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 587,
    len: 42,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 629,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 649,
    len: 11,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 660,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 682,
    len: 11,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 693,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 700,
    len: 23,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 723,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 740,
    len: 6,
    kind: 1
  });
})();
log.info(tranquill_S("0x6c62272e07bb0142"));
const tranquill_4 = new TypingModel();
const tranquill_5 = new DebuggerManager();
const tranquill_6 = new PhantomController();
const tranquill_7 = new TypingSession({
  debuggerManager: tranquill_5,
  typingModel: tranquill_4,
  phantomController: tranquill_6
});
log.debug(tranquill_S("0x6c62272e07bb0142"));
chrome.runtime.onMessage["addListener"]((tranquill_8, tranquill_9, tranquill_a) => {
  const tranquill_b = tranquill_9?.tab?.id ?? null;
  log["debug"](tranquill_S("0x6c62272e07bb0142"), {
    action: tranquill_8?.action,
    tabId: tranquill_b
  });
  switch (tranquill_8?.action) {
    case tranquill_S("0x6c62272e07bb0142"):
      {
        (async () => {
          try {
            const tranquill_c = String(tranquill_8.text ?? tranquill_S("0x6c62272e07bb0142"));
            const tranquill_d = typeof tranquill_8.previousText === tranquill_S("0x6c62272e07bb0142") ? tranquill_8.previousText : null;
            let reset = tranquill_8["resetProgress"] === true;
            if (!reset && tranquill_d !== null) reset = tranquill_d !== tranquill_c;
            if (!reset && tranquill_d === null) {
              const tranquill_e = await TextStorage.getSavedText();
              if (tranquill_e !== tranquill_c) reset = true;
            }
            await TextStorage.setSavedText(tranquill_c);
            const tranquill_f = TextStorage.createTextSignature(tranquill_c);
            if (reset) {
              await TextStorage.setProgress(0, tranquill_f).catch(tranquill_g => log["warn"](tranquill_S("0x6c62272e07bb0142"), tranquill_g));
            }
            const tranquill_h = reset ? 0 : await TextStorage["getProgress"](tranquill_f)["catch"](() => 0);
            const tranquill_i = await SettingsStorage.getSettings()["catch"](() => SettingsStorage["defaults"]);
            log.debug(tranquill_S("0x6c62272e07bb0142"), tranquill_i);
            tranquill_4.setWordsPerMinute(tranquill_i.typingSpeed);
            tranquill_4.setHumanized(tranquill_i.ghostMode);
            await tranquill_7.start({
              text: tranquill_c,
              startIndex: tranquill_h,
              settings: tranquill_i
            });
            log.info(tranquill_S("0x6c62272e07bb0142"), {
              tabId: tranquill_b,
              length: tranquill_c.length,
              reset,
              progress: tranquill_h
            });
            tranquill_a({
              success: true
            });
          } catch (tranquill_j) {
            log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_j);
            tranquill_7.stop().catch(tranquill_k => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_k));
            tranquill_a({
              success: false,
              error: String(tranquill_j?.message || tranquill_j)
            });
          }
        })();
        return true;
      }
    case tranquill_S("0x6c62272e07bb0142"):
    case tranquill_S("0x6c62272e07bb0142"):
      {
        log["info"](tranquill_S("0x6c62272e07bb0142"), {
          action: tranquill_8.action
        });
        tranquill_7.stop().catch(tranquill_l => log["warn"](tranquill_S("0x6c62272e07bb0142"), tranquill_l));
        tranquill_a({
          success: true
        });
        return false;
      }
    case tranquill_S("0x6c62272e07bb0142"):
      {
        log.warn(tranquill_S("0x6c62272e07bb0142"), {
          action: tranquill_8["action"],
          reason: tranquill_8?.reason ?? null
        });
        tranquill_7.stop()["catch"](tranquill_m => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_m));
        tranquill_a({
          success: true
        });
        return false;
      }
    case tranquill_S("0x6c62272e07bb0142"):
      {
        const tranquill_n = typeof tranquill_9?.frameId === tranquill_S("0x6c62272e07bb0142") ? tranquill_9.frameId : null;
        log.debug(tranquill_S("0x6c62272e07bb0142"), {
          tabId: tranquill_b,
          requestId: tranquill_8?.requestId ?? null,
          frameId: tranquill_n
        });
        if (tranquill_b !== null) {
          tranquill_7.handlePhantomTrigger(tranquill_b, tranquill_8?.requestId, tranquill_8?.key, tranquill_8?.timeStamp, tranquill_n).catch(tranquill_o => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_o));
        }
        tranquill_a({
          success: true
        });
        return false;
      }
    case tranquill_S("0x6c62272e07bb0142"):
      {
        const tranquill_p = typeof tranquill_9?.frameId === tranquill_S("0x6c62272e07bb0142") ? tranquill_9["frameId"] : null;
        log.debug(tranquill_S("0x6c62272e07bb0142"), {
          tabId: tranquill_b,
          frameId: tranquill_p
        });
        if (tranquill_b !== null) {
          tranquill_7["handlePhantomBackspace"](tranquill_b, tranquill_p).catch(tranquill_q => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_q));
        }
        tranquill_a({
          success: true
        });
        return false;
      }
    case tranquill_S("0x6c62272e07bb0142"):
      {
        log["info"](tranquill_S("0x6c62272e07bb0142"), {
          tabId: tranquill_b
        });
        if (tranquill_b !== null) tranquill_6.markReady(tranquill_b);
        tranquill_a({
          success: true
        });
        return false;
      }
    case tranquill_S("0x6c62272e07bb0142"):
      {
        log.debug(tranquill_S("0x6c62272e07bb0142"));
        TextStorage["getSavedText"]().then(tranquill_r => tranquill_a({
          success: true,
          text: tranquill_r
        })).catch(tranquill_s => tranquill_a({
          success: false,
          error: String(tranquill_s?.message || tranquill_s)
        }));
        return true;
      }
    case tranquill_S("0x6c62272e07bb0142"):
      {
        log.debug(tranquill_S("0x6c62272e07bb0142"));
        tranquill_a({
          success: true,
          isTyping: tranquill_7["isActive"]()
        });
        return false;
      }
    default:
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        action: tranquill_8?.action
      });
      return false;
  }
});
chrome.runtime.onSuspend.addListener(() => {
  log.info(tranquill_S("0x6c62272e07bb0142"));
  tranquill_7["stop"]().catch(tranquill_t => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_t));
});
chrome.tabs.onRemoved.addListener(tranquill_u => {
  log.info(tranquill_S("0x6c62272e07bb0142"), {
    tabId: tranquill_u
  });
  if (tranquill_5.isAttachedTo(tranquill_u)) {
    tranquill_7.stop().catch(tranquill_v => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_v));
  }
});
chrome.tabs.onUpdated["addListener"]((tranquill_w, tranquill_x) => {
  log["debug"](tranquill_S("0x6c62272e07bb0142"), {
    tabId: tranquill_w,
    status: tranquill_x?.status
  });
  if (tranquill_x.status === tranquill_S("0x6c62272e07bb0142") && tranquill_5["isAttachedTo"](tranquill_w)) {
    tranquill_7["stop"]()["catch"](tranquill_y => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_y));
  }
});
chrome.debugger.onDetach.addListener(tranquill_z => {
  log.warn(tranquill_S("0x6c62272e07bb0142"), {
    tabId: tranquill_z?.tabId ?? null
  });
  if (!tranquill_z || typeof tranquill_z.tabId !== tranquill_S("0x6c62272e07bb0142")) return;
  tranquill_5["handleDetached"](tranquill_z.tabId);
  tranquill_7.handleDebuggerDetached();
});
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}