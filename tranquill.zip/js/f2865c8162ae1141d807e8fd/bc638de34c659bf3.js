const tranquill_global = typeof self !== "undefined" ? self : globalThis;
if (!tranquill_global.tranquill_runtime_ready) {
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::cd312c1cae0d84219e6e1a7a094b17ad"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = "tranquill_tranquill_tranquill";
        tranquill_global.tranquill_runtime_ready = true;
}

"use strict";
(function tranquill_0() {
  const tranquill_1 = new Uint8Array([119, 215, 215, 208, 42, 10, 141, 48, 71, 210, 80, 99, 159, 223, 29, 158, 149, 230, 171, 134, 157, 202, 197, 87, 137, 205, 150, 196, 74, 148, 0, 28, 215, 73, 221, 146, 182, 182, 253, 79, 107, 168, 60, 8, 251, 117, 225, 190, 181, 6, 203, 162, 166, 166, 237, 127, 123, 184, 44, 56, 235, 101, 241, 170, 169, 164, 241, 102, 127, 37, 183, 139, 19, 114, 126, 132, 176, 16, 137, 90, 89, 84, 225, 150, 143, 68, 223, 132, 25, 157, 25, 68, 194, 81, 85, 152, 159, 26, 136, 75, 79, 0, 61, 60, 131, 214, 105, 172, 147, 54, 180, 127, 103, 58, 57, 44, 186, 233, 99, 184, 227, 62, 186, 126, 35, 229, 118, 112, 106, 35, 39, 163, 228, 54, 10, 82, 179, 20, 151, 110, 91, 216, 65, 6, 15, 12, 45, 219, 220, 28, 133, 154, 67, 193, 86, 8, 8, 202, 50, 198, 2, 74, 199, 3, 197, 130, 5, 222, 45, 42, 184, 20, 76, 45, 109, 77, 1, 216, 40, 138, 73, 26, 117, 98, 64, 218, 54, 152, 0, 21, 118, 81, 19, 217, 53, 154, 0, 18, 112, 76, 16, 215, 45, 156, 72, 86, 127, 94, 9, 218, 60, 155, 203, 151, 157, 143, 17, 81, 74, 20, 207, 157, 157, 146, 29, 64, 211, 1, 169, 185, 155, 208, 133, 122, 238, 149, 66, 50, 172, 200, 170, 59, 236, 139, 80, 123, 176, 203, 133, 111, 160, 128, 94, 40, 176, 197, 131, 120, 232, 196, 81, 58, 169, 200, 146, 127, 113, 68, 109, 209, 52, 131, 37, 19, 105, 114, 105, 201, 44, 149, 41, 55, 82, 127, 72, 130, 251, 222, 190, 71, 188, 22, 252, 154, 205, 218, 166, 95, 170, 26, 216, 161, 192, 251, 131, 87, 165, 11, 175, 218, 51, 207, 106, 29, 251, 13, 183, 236, 55, 215, 114, 11, 247, 41, 140, 225, 22, 37, 78, 210, 231, 119, 146, 19, 170, 64, 90, 178, 234, 68, 78, 222, 6, 85, 94, 194, 23, 135, 130, 3, 218, 80, 74, 194, 26, 84, 126, 238, 54, 104, 66, 234, 50, 65, 75, 91, 20, 151, 136, 136, 205, 17, 78, 84, 6, 158, 199, 136, 197, 69, 85, 83, 5, 135, 134, 150, 128, 87, 70, 83, 12, 148, 131, 10, 152, 244, 44, 224, 97, 184, 48, 182, 34, 235, 105, 176, 100, 183, 34, 191, 109, 235, 97, 228, 127, 176, 33, 166, 44, 245, 36, 228, 101, 171, 33, 167, 103, 61, 62, 5, 69, 234, 227, 1, 133, 74, 41, 160, 56, 253, 57, 107, 231, 127, 39, 104, 101, 116, 235, 190, 147, 178, 203, 200, 145, 239, 24, 207, 91, 104, 146, 21, 130, 45, 220, 135, 31, 154, 14, 91, 222, 87, 212, 143, 23, 146, 6, 83, 214, 95, 214, 178, 113, 187, 12, 107, 180, 250, 198, 181, 175, 57, 213, 113, 83, 117, 22, 52, 218, 45, 220, 48, 72, 124, 0, 63, 150, 47, 214, 48, 78, 112, 30, 53, 128, 54, 221, 117, 26, 127, 28, 34, 218, 17, 228, 89, 126, 129, 149, 86, 172, 91, 76, 147, 152, 92, 143, 197, 66, 133, 74, 137, 28, 29, 208, 66, 219, 149, 177, 114, 248, 79, 104, 183, 172, 120, 139, 241, 118, 161, 78, 167, 35, 224, 234, 125, 250, 37, 180, 250, 185, 124, 99, 230, 100, 175, 26, 213, 64, 61, 50, 177, 40, 213, 38, 162, 109, 16, 117, 167, 58, 205, 71, 26, 25, 12, 154, 201, 93, 128, 151, 2, 128, 83, 91, 30, 29, 24, 134, 205, 81, 148, 171, 62, 140, 71, 87, 51, 239, 25, 255, 192, 15, 250, 122, 23, 210, 98, 123, 120, 33, 191, 168, 100, 231, 112, 61, 124, 200, 151, 29, 187, 8, 1, 252, 79, 228, 165, 84, 191, 8, 79, 209, 106, 204, 149, 17, 188, 3, 209, 89, 73, 234, 205, 42, 79, 169, 8, 35, 151, 227, 140, 42, 77, 165, 24, 106, 130, 224, 197, 57, 70, 236, 8, 102, 149, 229, 207, 38, 3, 132, 59, 74, 167, 39, 245, 117, 101, 18, 255, 232, 107, 186, 10, 14, 128, 46, 219, 213, 93, 251, 24, 65, 137, 59, 193, 205, 90, 232, 13, 178, 96, 28, 103, 247, 39, 212, 37, 170, 63, 17, 102, 225, 127, 206, 61, 180, 119, 28, 100, 207, 128, 189, 188, 3, 86, 238, 3, 208, 147, 50, 193, 40, 122, 235, 3, 200, 248, 123, 236, 161, 226, 124, 238, 150, 52, 187, 47, 117, 96, 18, 212, 216, 39, 220, 21, 153, 221, 102, 180, 90, 132, 16, 236, 167, 89, 205, 154, 129, 10, 199, 130, 145, 140, 201, 78, 71, 133, 15, 155, 216, 64, 200, 83, 26, 157, 49, 149, 209, 186, 58, 248, 146, 228, 76, 243, 87, 35, 132, 49, 138, 209, 72, 233, 110, 1, 164, 25, 189, 239, 99, 251, 7, 43, 143, 49, 47, 206, 227, 196, 58, 25, 181, 1, 47, 218, 231, 220, 35, 25, 162, 53, 61, 91, 230, 112, 122, 147, 164, 45, 10, 84, 251, 116, 125, 159, 132, 40, 44, 95, 230, 114, 106, 71, 220, 68, 1, 149, 0, 133, 204, 101, 216, 65, 31, 135, 2, 135, 154, 78, 208, 86, 31, 201, 4, 140, 219, 95, 208, 75, 22, 136, 19, 142, 223, 228, 141, 161, 48, 191, 3, 186, 47, 248, 139, 180, 46, 189, 76, 252, 108, 224, 215, 182, 35, 227, 163, 148, 187, 85, 168, 77, 237, 151, 239, 140, 173, 4, 168, 77, 176, 151, 188, 216, 164, 6, 251, 73, 228, 198, 180, 142, 241, 28, 249, 77, 182, 202, 189, 222, 241, 3, 172, 76, 181, 195, 187, 143, 173, 85, 227, 16, 167, 240, 103, 8, 102, 251, 62, 94, 36, 188, 127, 30, 55, 251, 62, 3, 36, 239, 43, 23, 53, 168, 58, 87, 117, 231, 125, 66, 47, 168, 107, 83, 33, 230, 122, 21, 54, 172, 57, 81, 119, 233, 122, 70, 53, 176, 99, 20, 129, 54, 25, 119, 10, 111, 207, 53, 205, 46, 15, 38, 10, 111, 146, 53, 158, 122, 6, 36, 89, 107, 198, 100, 150, 44, 83, 62, 13, 61, 149, 105, 150, 42, 15, 38, 89, 59, 194, 103, 202, 125, 0, 40, 65, 50, 133, 46, 9, 102, 184, 37, 80, 48, 250, 98, 17, 112, 233, 37, 80, 109, 250, 49, 69, 121, 235, 118, 84, 57, 171, 57, 19, 44, 241, 116, 84, 61, 250, 97, 21, 125, 191, 121, 4, 109, 170, 52, 20, 127, 233, 110, 13, 122, 127, 216, 119, 9, 116, 1, 33, 203, 51, 192, 97, 88, 116, 1, 124, 203, 96, 148, 104, 90, 39, 5, 40, 154, 104, 194, 61, 64, 115, 85, 45, 204, 103, 149, 111, 88, 117, 7, 47, 150, 102, 151, 110, 9, 63, 92, 107, 140, 43, 68, 90, 135, 114, 18, 152, 192, 51, 82, 11, 135, 114, 79, 152, 147, 103, 91, 9, 212, 118, 27, 201, 155, 49, 14, 19, 211, 33, 74, 205, 155, 103, 9, 4, 128, 117, 74, 205, 196, 50, 10, 9, 204, 47, 88, 93, 122, 213, 43, 214, 35, 3, 105, 17, 98, 195, 122, 214, 35, 94, 105, 66, 54, 202, 120, 133, 39, 10, 56, 74, 96, 159, 98, 133, 38, 13, 111, 22, 54, 158, 117, 215, 35, 14, 60, 64, 50, 206, 127, 157, 126, 73, 234, 205, 82, 76, 225, 148, 132, 14, 166, 213, 68, 29, 225, 148, 217, 14, 245, 129, 77, 31, 178, 144, 141, 95, 253, 215, 24, 5, 224, 146, 222, 83, 160, 128, 24, 31, 189, 197, 132, 12, 162, 128, 68, 31, 170, 201, 206, 59, 28, 35, 221, 48, 197, 117, 31, 119, 4, 53, 140, 48, 197, 40, 31, 36, 80, 60, 142, 99, 193, 124, 78, 44, 6, 105, 148, 54, 148, 45, 31, 45, 4, 58, 223, 48, 198, 42, 25, 45, 3, 61, 138, 123, 152, 63, 72, 239, 176, 238, 67, 182, 230, 172, 4, 247, 166, 191, 67, 182, 187, 172, 87, 163, 175, 189, 16, 178, 239, 253, 95, 245, 250, 167, 17, 185, 190, 255, 0, 240, 169, 189, 71, 229, 235, 251, 87, 163, 249, 190, 8, 235, 172, 25, 190, 129, 255, 146, 231, 87, 189, 85, 166, 151, 174, 146, 231, 10, 189, 6, 242, 158, 172, 193, 227, 94, 236, 14, 164, 203, 182, 147, 182, 86, 233, 3, 242, 150, 255, 147, 231, 8, 235, 0, 242, 205, 161, 217, 186, 29, 166, 177, 238, 0, 173, 232, 184, 66, 234, 169, 248, 81, 173, 232, 229, 66, 185, 253, 241, 83, 254, 236, 177, 19, 177, 171, 164, 73, 251, 237, 226, 71, 185, 251, 167, 81, 174, 190, 178, 22, 235, 170, 242, 87, 230, 181, 242, 247, 64, 255, 145, 252, 153, 169, 83, 187, 88, 233, 192, 252, 153, 244, 83, 232, 12, 224, 194, 175, 157, 160, 2, 224, 90, 181, 216, 161, 156, 160, 81, 234, 15, 233, 197, 255, 200, 246, 81, 238, 93, 181, 197, 183, 196, 227, 58, 174, 124, 220, 101, 162, 105, 77, 117, 227, 116, 218, 103, 243, 62, 75, 114, 177, 99, 210, 39, 59, 28, 35, 131, 55, 194, 45, 78, 33, 11, 110, 141, 48, 197, 116, 77, 35, 3, 111, 216, 103, 195, 116, 76, 113, 86, 58, 148, 96, 194, 125, 24, 34, 4, 60, 223, 108, 199, 41, 75, 34, 84, 58, 141, 123, 152, 63]);
  const tranquill_2 = self.tranquill_PACK = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  tranquill_2.data["push"](tranquill_1);
  const tranquill_3 = tranquill_2["data"].length - 1;
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 0,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 6,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 12,
    len: 3,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 15,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 19,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 24,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 29,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 35,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 41,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 47,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 51,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 57,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 63,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 69,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 74,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 79,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 85,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 94,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 100,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 106,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 112,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 118,
    len: 9,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 127,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 132,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 137,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 143,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 149,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 155,
    len: 3,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 158,
    len: 11,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 169,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 173,
    len: 39,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 212,
    len: 14,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 226,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 230,
    len: 36,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 266,
    len: 19,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 285,
    len: 23,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 308,
    len: 19,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 327,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 335,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 339,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 343,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 351,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 355,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 359,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 363,
    len: 30,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 393,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 397,
    len: 29,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 426,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 427,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 427,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 433,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 440,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 444,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 450,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 451,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 457,
    len: 7,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 464,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 472,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 480,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 487,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 492,
    len: 35,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 527,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 534,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 541,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 547,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 554,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 561,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 568,
    len: 2,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 570,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 576,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 592,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 598,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 604,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 610,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 616,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 616,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 627,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 633,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 637,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 658,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 662,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 694,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 698,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 720,
    len: 20,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 740,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 746,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 757,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 761,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 769,
    len: 7,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 776,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 781,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 787,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 791,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 797,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 809,
    len: 3,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 812,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 828,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 832,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 851,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 873,
    len: 8,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 881,
    len: 24,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 905,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 926,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 973,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1020,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1067,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1114,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1161,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1208,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1255,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1302,
    len: 47,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1349,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1396,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1443,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1490,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1537,
    len: 21,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1558,
    len: 47,
    kind: 1
  });
})();
const tranquill_4 = Object["freeze"]({
  silent: 0,
  error: 1,
  warn: 2,
  info: 3,
  debug: 4
});
self.TRANQUILL_LOG_LEVEL = tranquill_S("0x6c62272e07bb0142");
const tranquill_5 = (tranquill_6, {
  allowSilent: tranquill_7 = false
} = {}) => {
  if (typeof tranquill_6 !== tranquill_S("0x6c62272e07bb0142")) return null;
  const tranquill_9 = tranquill_6.toLowerCase();
  if (tranquill_9 === tranquill_S("0x6c62272e07bb0142")) return tranquill_S("0x6c62272e07bb0142");
  if (tranquill_9 === tranquill_S("0x6c62272e07bb0142")) return tranquill_S("0x6c62272e07bb0142");
  if (tranquill_9 === tranquill_S("0x6c62272e07bb0142") && tranquill_7) return tranquill_S("0x6c62272e07bb0142");
  if (Object.prototype.hasOwnProperty.call(tranquill_4, tranquill_9)) {
    return tranquill_9;
  }
  return null;
};
const tranquill_a = () => {
  const tranquill_b = tranquill_5(self["TRANQUILL_LOG_LEVEL"], {
    allowSilent: true
  });
  return tranquill_b || tranquill_S("0x6c62272e07bb0142");
};
const tranquill_c = tranquill_d => {
  const tranquill_e = tranquill_5(tranquill_d) || tranquill_S("0x6c62272e07bb0142");
  if (tranquill_e === tranquill_S("0x6c62272e07bb0142")) return false;
  const tranquill_f = tranquill_a();
  if (tranquill_f === tranquill_S("0x6c62272e07bb0142")) return false;
  return tranquill_4[tranquill_e] <= tranquill_4[tranquill_f];
};
const tranquill_g = tranquill_h => {
  const tranquill_i = tranquill_5(tranquill_h, {
    allowSilent: true
  });
  if (!tranquill_i) return null;
  const tranquill_k = tranquill_a();
  if (tranquill_k === tranquill_i) return {
    previous: tranquill_k,
    next: tranquill_k,
    changed: false
  };
  self.TRANQUILL_LOG_LEVEL = tranquill_i;
  return {
    previous: tranquill_k,
    next: tranquill_i,
    changed: true
  };
};
const tranquill_l = new Set();
const tranquill_m = tranquill_n => {
  if (!tranquill_n || typeof tranquill_n !== tranquill_S("0x6c62272e07bb0142")) return tranquill_n;
  switch (tranquill_n.kind) {
    case tranquill_S("0x6c62272e07bb0142"):
      {
        const tranquill_q = new Error(tranquill_n["message"]);
        tranquill_q.name = tranquill_n["name"] || tranquill_S("0x6c62272e07bb0142");
        if (tranquill_n.stack) tranquill_q.stack = tranquill_n.stack;
        return tranquill_q;
      }
    case tranquill_S("0x6c62272e07bb0142"):
    case tranquill_S("0x6c62272e07bb0142"):
      return tranquill_n["value"];
    case tranquill_S("0x6c62272e07bb0142"):
      return tranquill_n["value"];
    default:
      return tranquill_n["value"];
  }
};
const tranquill_r = tranquill_s => {
  if (!tranquill_s || typeof tranquill_s !== tranquill_S("0x6c62272e07bb0142")) {
    if (typeof tranquill_s === tranquill_S("0x6c62272e07bb0142")) return {
      kind: tranquill_S("0x6c62272e07bb0142"),
      value: tranquill_s
    };
    return {
      kind: tranquill_S("0x6c62272e07bb0142"),
      value: tranquill_s
    };
  }
  if (tranquill_s.kind && Object.prototype.hasOwnProperty.call(tranquill_s, tranquill_S("0x6c62272e07bb0142"))) {
    return tranquill_s;
  }
  if (tranquill_s instanceof Error) {
    return {
      kind: tranquill_S("0x6c62272e07bb0142"),
      name: tranquill_s.name,
      message: tranquill_s.message,
      stack: tranquill_s["stack"] || null
    };
  }
  try {
    return {
      kind: tranquill_S("0x6c62272e07bb0142"),
      value: JSON["parse"](JSON["stringify"](tranquill_s))
    };
  } catch (tranquill_w) {
    return {
      kind: tranquill_S("0x6c62272e07bb0142"),
      value: String(tranquill_s)
    };
  }
};
const tranquill_x = (tranquill_y, tranquill_z, tranquill_A = {}, tranquill_B = null) => {
  const tranquill_C = typeof tranquill_y === tranquill_S("0x6c62272e07bb0142") ? tranquill_y["toLowerCase"]() : tranquill_S("0x6c62272e07bb0142");
  if (!tranquill_c(tranquill_C)) return;
  const tranquill_E = Array.isArray(tranquill_z) ? tranquill_z : [];
  const tranquill_F = console?.[tranquill_C] || console?.log;
  try {
    tranquill_F?.call(console, tranquill_S("0x6c62272e07bb0142"), ...tranquill_E);
  } catch (tranquill_G) {
    if (tranquill_c(tranquill_S("0x6c62272e07bb0142"))) {
      console?.warn?.(tranquill_S("0x6c62272e07bb0142"), tranquill_G);
    }
  }
  const tranquill_H = {
    level: tranquill_C,
    args: Array.isArray(tranquill_B) ? tranquill_B.map(tranquill_I => tranquill_r(tranquill_I)) : tranquill_E.map(tranquill_J => tranquill_r(tranquill_J)),
    meta: {
      source: tranquill_A.source || tranquill_S("0x6c62272e07bb0142"),
      timestamp: tranquill_A.timestamp || Date.now()
    }
  };
  tranquill_l.forEach(tranquill_K => {
    try {
      tranquill_K["postMessage"](tranquill_H);
    } catch (tranquill_L) {
      try {
        tranquill_K.disconnect();
      } catch (tranquill_M) {}
      tranquill_l.delete(tranquill_K);
      if (tranquill_c(tranquill_S("0x6c62272e07bb0142"))) {
        console?.warn?.(tranquill_S("0x6c62272e07bb0142"), tranquill_L);
      }
    }
  });
};
self.__tranquillDirectLog = (tranquill_N, tranquill_O, tranquill_P) => {
  tranquill_x(tranquill_N, tranquill_O, tranquill_P);
};
const tranquill_Q = tranquill_S("0x6c62272e07bb0142");
const tranquill_R = tranquill_S("0x6c62272e07bb0142");
const tranquill_S = tranquill_S("0x6c62272e07bb0142");
const tranquill_T = 32;
const tranquill_U = 32;
let tranquillHWIDPromise = null;
let tranquillHWIDValue = null;
const tranquill_V = (tranquill_W, tranquill_X) => new Promise(tranquill_Y => {
  if (!tranquill_W || typeof tranquill_W.get !== tranquill_S("0x6c62272e07bb0142")) {
    tranquill_Y(null);
    return;
  }
  try {
    tranquill_W.get(tranquill_X, tranquill_10 => {
      const tranquill_11 = chrome.runtime?.lastError ?? null;
      if (tranquill_11) {
        tranquill_x(tranquill_S("0x6c62272e07bb0142"), [`storage get failed for key "${tranquill_X}"`, tranquill_11]);
        tranquill_Y(null);
        return;
      }
      tranquill_Y(tranquill_10?.[tranquill_X] ?? null);
    });
  } catch (tranquill_12) {
    tranquill_x(tranquill_S("0x6c62272e07bb0142"), [`storage get threw for key "${tranquill_X}"`, tranquill_12]);
    tranquill_Y(null);
  }
});
const tranquill_13 = (tranquill_14, tranquill_15, tranquill_16) => new Promise(tranquill_17 => {
  if (!tranquill_14 || typeof tranquill_14.set !== tranquill_S("0x6c62272e07bb0142")) {
    tranquill_17(false);
    return;
  }
  try {
    tranquill_14.set({
      [tranquill_15]: tranquill_16
    }, () => {
      const tranquill_19 = chrome["runtime"]?.lastError ?? null;
      if (tranquill_19) {
        tranquill_x(tranquill_S("0x6c62272e07bb0142"), [`storage set failed for key "${tranquill_15}"`, tranquill_19]);
        tranquill_17(false);
        return;
      }
      tranquill_17(true);
    });
  } catch (tranquill_1a) {
    tranquill_x(tranquill_S("0x6c62272e07bb0142"), [`storage set threw for key "${tranquill_15}"`, tranquill_1a]);
    tranquill_17(false);
  }
});
const tranquill_1b = () => new Promise(tranquill_1c => {
  try {
    chrome.runtime.getPlatformInfo(tranquill_1d => {
      const tranquill_1e = chrome.runtime?.lastError ?? null;
      if (tranquill_1e) {
        tranquill_x(tranquill_S("0x6c62272e07bb0142"), [tranquill_S("0x6c62272e07bb0142"), tranquill_1e]);
        tranquill_1c(null);
        return;
      }
      tranquill_1c(tranquill_1d || null);
    });
  } catch (tranquill_1f) {
    tranquill_x(tranquill_S("0x6c62272e07bb0142"), [tranquill_S("0x6c62272e07bb0142"), tranquill_1f]);
    tranquill_1c(null);
  }
});
const tranquill_1g = tranquill_1h => Array.from(new Uint8Array(tranquill_1h)).map(tranquill_1i => tranquill_1i.toString(16)["padStart"](2, tranquill_S("0x6c62272e07bb0142"))).join(tranquill_S("0x6c62272e07bb0142"));
const tranquill_1j = async (tranquill_1k, {
  context: tranquill_1l = tranquill_S("0x6c62272e07bb0142")
} = {}) => {
  const tranquill_1m = new TextEncoder();
  const tranquill_1n = tranquill_1m.encode(tranquill_1k);
  if (crypto?.subtle?.digest) {
    try {
      const tranquill_1o = await crypto.subtle.digest(tranquill_S("0x6c62272e07bb0142"), tranquill_1n);
      return tranquill_1g(tranquill_1o);
    } catch (tranquill_1p) {
      tranquill_x(tranquill_S("0x6c62272e07bb0142"), [`${tranquill_1l} sha-256 failed`, tranquill_1p]);
    }
  }
  const tranquill_1q = new Uint8Array(tranquill_T);
  for (let index = 0; index < tranquill_1q.length; index += 1) {
    tranquill_1q[index] = index * 37 & 0xff;
  }
  for (let index = 0; index < tranquill_1n.length; index += 1) {
    const tranquill_1r = tranquill_1n[index];
    const tranquill_1s = index % tranquill_1q.length;
    const tranquill_1t = (tranquill_1s * 13 + tranquill_1q.length - 1) % tranquill_1q.length;
    tranquill_1q[tranquill_1s] = (tranquill_1q[tranquill_1s] ^ tranquill_1r) & 0xff;
    tranquill_1q[tranquill_1t] = tranquill_1q[tranquill_1t] + tranquill_1r + tranquill_1s & 0xff;
  }
  return tranquill_1g(tranquill_1q["buffer"]);
};
const tranquill_1u = async () => {
  const tranquill_1v = [];
  const tranquill_1w = typeof navigator === tranquill_S("0x6c62272e07bb0142") && navigator ? navigator : {};
  const tranquill_1x = Array["isArray"](tranquill_1w.languages) ? tranquill_1w.languages.join(tranquill_S("0x6c62272e07bb0142")) : typeof tranquill_1w.language === tranquill_S("0x6c62272e07bb0142") ? tranquill_1w["language"] : tranquill_S("0x6c62272e07bb0142");
  const tranquill_1y = (() => {
    try {
      const tranquill_1z = typeof Intl?.DateTimeFormat === tranquill_S("0x6c62272e07bb0142") ? new Intl.DateTimeFormat() : null;
      const tranquill_1A = tranquill_1z && typeof tranquill_1z.resolvedOptions === tranquill_S("0x6c62272e07bb0142") ? tranquill_1z["resolvedOptions"]() : null;
      return tranquill_1A?.timeZone || tranquill_S("0x6c62272e07bb0142");
    } catch (tranquill_1B) {
      tranquill_x(tranquill_S("0x6c62272e07bb0142"), [tranquill_S("0x6c62272e07bb0142"), tranquill_1B]);
      return tranquill_S("0x6c62272e07bb0142");
    }
  })();
  tranquill_1v["push"](`platform:${tranquill_1w.platform || tranquill_S("0x6c62272e07bb0142")}`);
  tranquill_1v.push(`languages:${tranquill_1x}`);
  tranquill_1v.push(`timezone:${tranquill_1y}`);
  tranquill_1v.push(`hardwareConcurrency:${tranquill_1w["hardwareConcurrency"] || 0}`);
  if (typeof tranquill_1w.deviceMemory === tranquill_S("0x6c62272e07bb0142")) {
    tranquill_1v.push(`deviceMemory:${tranquill_1w.deviceMemory}`);
  }
  const tranquill_1C = await tranquill_1b();
  if (tranquill_1C) {
    tranquill_1v.push(`os:${tranquill_1C.os || tranquill_S("0x6c62272e07bb0142")}`);
    tranquill_1v.push(`arch:${tranquill_1C.arch || tranquill_S("0x6c62272e07bb0142")}`);
    tranquill_1v["push"](`nacl:${tranquill_1C.nacl_arch || tranquill_S("0x6c62272e07bb0142")}`);
  }
  return tranquill_1v.join(tranquill_S("0x6c62272e07bb0142"));
};
const tranquill_1D = async tranquill_1E => {
  if (typeof tranquill_1E !== tranquill_S("0x6c62272e07bb0142") || tranquill_1E.length === 0) return null;
  const tranquill_1G = await tranquill_1j(`tranquill::salt::${tranquill_1E}`, {
    context: tranquill_S("0x6c62272e07bb0142")
  });
  if (typeof tranquill_1G !== tranquill_S("0x6c62272e07bb0142") || tranquill_1G.length === 0) return null;
  return tranquill_1G["slice"](0, tranquill_U);
};
const tranquill_1I = async tranquill_1J => {
  const tranquill_1K = await tranquill_V(chrome.storage?.local, tranquill_R);
  if (typeof tranquill_1K === tranquill_S("0x6c62272e07bb0142") && tranquill_1K["length"] > 0) return tranquill_1K;
  const tranquill_1M = await tranquill_V(chrome.storage?.sync, tranquill_R);
  if (typeof tranquill_1M === tranquill_S("0x6c62272e07bb0142") && tranquill_1M.length > 0) {
    await tranquill_13(chrome.storage?.local, tranquill_R, tranquill_1M);
    return tranquill_1M;
  }
  const tranquill_1O = await tranquill_1D(tranquill_1J);
  if (typeof tranquill_1O !== tranquill_S("0x6c62272e07bb0142") || tranquill_1O.length === 0) return null;
  await Promise.all([tranquill_13(chrome["storage"]?.local, tranquill_R, tranquill_1O), tranquill_13(chrome.storage?.sync, tranquill_R, tranquill_1O)]);
  return tranquill_1O;
};
const tranquill_1Q = async () => {
  const tranquill_1R = await tranquill_1u();
  const tranquill_1S = await tranquill_1I(tranquill_1R);
  const tranquill_1T = await tranquill_1j(`tranquill::hwid::${tranquill_1S || tranquill_S("0x6c62272e07bb0142")}::${tranquill_1R}`, {
    context: tranquill_S("0x6c62272e07bb0142")
  });
  return `tranquill-${tranquill_1T}`;
};
const tranquill_1U = async () => {
  if (tranquillHWIDValue) return tranquillHWIDValue;
  const tranquill_1V = tranquillHWIDPromise;
  if (tranquill_1V) return tranquill_1V;
  tranquillHWIDPromise = (async () => {
    const tranquill_1W = await tranquill_V(chrome["storage"]?.local, tranquill_Q);
    if (typeof tranquill_1W === tranquill_S("0x6c62272e07bb0142") && tranquill_1W.length > 0) {
      tranquillHWIDValue = tranquill_1W;
      await tranquill_13(chrome.storage?.session, tranquill_S, tranquill_1W);
      return tranquill_1W;
    }
    const tranquill_1Y = await tranquill_1Q();
    tranquillHWIDValue = tranquill_1Y;
    await tranquill_13(chrome.storage?.local, tranquill_Q, tranquill_1Y);
    await tranquill_13(chrome.storage?.session, tranquill_S, tranquill_1Y);
    tranquill_x(tranquill_S("0x6c62272e07bb0142"), [tranquill_S("0x6c62272e07bb0142")]);
    return tranquill_1Y;
  })().catch(tranquill_1Z => {
    tranquill_x(tranquill_S("0x6c62272e07bb0142"), [tranquill_S("0x6c62272e07bb0142"), tranquill_1Z]);
    tranquillHWIDValue = null;
    throw tranquill_1Z;
  }).finally(() => {
    tranquillHWIDPromise = null;
  });
  return tranquillHWIDPromise;
};
tranquill_1U()["catch"](tranquill_20 => {
  tranquill_x(tranquill_S("0x6c62272e07bb0142"), [tranquill_S("0x6c62272e07bb0142"), tranquill_20]);
});
chrome.runtime.onConnect.addListener(tranquill_21 => {
  if (!tranquill_21 || tranquill_21.name !== tranquill_S("0x6c62272e07bb0142")) return;
  tranquill_l["add"](tranquill_21);
  tranquill_21.onDisconnect.addListener(() => {
    tranquill_l["delete"](tranquill_21);
  });
  tranquill_21["onMessage"].addListener(tranquill_23 => {
    if (!tranquill_23 || typeof tranquill_23 !== tranquill_S("0x6c62272e07bb0142")) return;
    if (tranquill_23.type === tranquill_S("0x6c62272e07bb0142")) {
      const tranquill_26 = tranquill_g(tranquill_23.level);
      if (tranquill_26?.changed) {
        tranquill_x(tranquill_S("0x6c62272e07bb0142"), [`log level set to "${tranquill_26["next"]}" via popup`]);
      }
      return;
    }
    if (tranquill_23.type === tranquill_S("0x6c62272e07bb0142") && typeof tranquill_23.enabled === tranquill_S("0x6c62272e07bb0142")) {
      const tranquill_27 = tranquill_23.enabled ? tranquill_S("0x6c62272e07bb0142") : tranquill_S("0x6c62272e07bb0142");
      const tranquill_28 = tranquill_g(tranquill_27);
      if (tranquill_28?.changed) {
        tranquill_x(tranquill_S("0x6c62272e07bb0142"), [`log level set to "${tranquill_28.next}" via popup toggle`]);
      }
    }
  });
});
chrome.runtime.onMessage["addListener"]((tranquill_29, tranquill_2a, tranquill_2b) => {
  if (!tranquill_29 || typeof tranquill_29 !== tranquill_S("0x6c62272e07bb0142")) return false;
  if (tranquill_29["action"] === tranquill_S("0x6c62272e07bb0142")) {
    const tranquill_2e = {
      ...(tranquill_29["meta"] || {}),
      sender: tranquill_2a?.id || null
    };
    const tranquill_2f = Array.isArray(tranquill_29.args) ? tranquill_29.args.map(tranquill_m) : [];
    tranquill_x(tranquill_29["level"] || tranquill_S("0x6c62272e07bb0142"), tranquill_2f, tranquill_2e, tranquill_29.args || []);
    tranquill_2b?.({
      success: true
    });
    return false;
  }
  if (tranquill_29["action"] === tranquill_S("0x6c62272e07bb0142")) {
    tranquill_1U()["then"](tranquill_2g => {
      if (tranquill_2g) {
        tranquill_2b?.({
          success: true,
          hwid: tranquill_2g
        });
      } else {
        tranquill_2b?.({
          success: false,
          hwid: null
        });
      }
    }).catch(tranquill_2h => {
      tranquill_x(tranquill_S("0x6c62272e07bb0142"), [tranquill_S("0x6c62272e07bb0142"), tranquill_2h]);
      tranquill_2b?.({
        success: false,
        error: tranquill_2h?.message || null
      });
    });
    return true;
  }
  if (tranquill_29.action === tranquill_S("0x6c62272e07bb0142")) {
    if (typeof ensureLicenseGate !== tranquill_S("0x6c62272e07bb0142")) {
      tranquill_2b?.({
        success: false,
        error: tranquill_S("0x6c62272e07bb0142")
      });
      return false;
    }
    ensureLicenseGate().then(tranquill_2i => {
      tranquill_2b?.({
        success: true,
        unlocked: Boolean(tranquill_2i)
      });
    }).catch(tranquill_2j => {
      tranquill_2b?.({
        success: false,
        error: tranquill_2j?.message || null
      });
    });
    return true;
  }
  return false;
});
chrome.runtime.onInstalled["addListener"](tranquill_2k => {
  if (tranquill_2k.reason === chrome.runtime.OnInstalledReason.INSTALL) {
    chrome.runtime.setUninstallURL(tranquill_S("0x6c62272e07bb0142"));
  }
});
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2l) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2m) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2n) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2o) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2p) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2q) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2r) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2s) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2t) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2u) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2v) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2w) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2x) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2y) {}
try {
  importScripts(tranquill_S("0x6c62272e07bb0142"));
} catch (tranquill_2z) {}
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}