const tranquill_global = typeof self !== "undefined" ? self : globalThis;
if (!tranquill_global.tranquill_runtime_ready) {
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::16fd2ce4be226d9f78b1905b71de3935"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = "tranquill_tranquill_tranquill";
        tranquill_global.tranquill_runtime_ready = true;
}

(function tranquill_0() {
  const tranquill_1 = new Uint8Array([60, 160, 216, 80, 38, 190, 251, 92, 60, 173, 193, 87, 47, 170, 123, 32, 125, 82, 78, 54, 113, 174, 247, 92, 68, 184, 69, 61, 96, 90, 73, 43, 19, 221, 242, 32, 14, 206, 21, 95, 116, 34, 8, 76, 47, 193, 14, 60, 50, 210, 19, 67, 2, 59, 25, 94, 0, 58, 4, 83, 209, 27, 104, 129, 6, 60, 241, 243, 144, 14, 236, 224, 81, 39, 188, 181, 15, 17, 13, 231, 172, 26, 16, 244, 7, 105, 38, 20, 26, 122, 69, 180, 37, 31, 253, 216, 12, 37, 246, 203, 11, 31, 236, 195, 10, 45, 255, 201, 86, 34, 247, 222, 21, 45, 244, 197, 2, 41, 184, 132, 11, 41, 236, 216, 17, 34, 255, 223, 88, 60, 249, 203, 29, 101, 169, 169, 204, 206, 165, 191, 217, 58, 180, 217, 222, 52, 181, 210, 74, 188, 186, 199, 99, 182, 177, 223, 187, 24, 202, 229, 176, 11, 205, 223, 170, 3, 204, 237, 185, 9, 144, 235, 187, 24, 237, 233, 170, 24, 215, 226, 185, 31, 158, 164, 173, 9, 202, 248, 183, 2, 217, 255, 254, 28, 223, 235, 187, 69, 177, 166, 54, 151, 139, 173, 37, 144, 177, 183, 45, 145, 131, 164, 39, 205, 133, 166, 54, 176, 135, 183, 54, 138, 140, 164, 49, 195, 132, 162, 43, 143, 135, 167, 165, 8, 98, 185, 159, 3, 113, 190, 165, 25, 121, 191, 151, 10, 115, 227, 145, 8, 98, 158, 147, 25, 98, 164, 152, 10, 101, 237, 132, 8, 101, 162, 154, 27, 115, 169, 1, 148, 70, 37, 59, 159, 85, 34, 1, 133, 93, 35, 51, 150, 87, 127, 33, 144, 68, 52, 1, 148, 70, 37, 59, 159, 85, 34, 96, 212, 103, 101, 90, 223, 116, 98, 96, 197, 124, 99, 82, 214, 118, 63, 64, 208, 101, 116, 96, 212, 103, 101, 90, 223, 116, 98, 19, 215, 114, 120, 95, 212, 119, 4, 117, 3, 4, 62, 126, 16, 3, 4, 100, 24, 2, 54, 119, 18, 94, 36, 113, 1, 21, 4, 117, 3, 4, 62, 126, 16, 3, 119, 99, 2, 19, 52, 117, 4, 3, 42, 73, 173, 56, 16, 66, 190, 63, 41, 77, 190, 41, 58, 67, 183, 56, 11, 67, 181, 32, 28, 94, 249, 47, 22, 66, 170, 56, 11, 89, 186, 56, 28, 72, 219, 49, 28, 192, 225, 58, 15, 199, 216, 53, 15, 209, 203, 59, 6, 192, 250, 59, 4, 216, 237, 38, 70, 221, 230, 61, 28, 148, 251, 32, 9, 198, 252, 253, 210, 58, 227, 199, 217, 41, 228, 254, 214, 41, 242, 237, 216, 32, 227, 220, 216, 34, 251, 203, 197, 110, 254, 192, 222, 58, 254, 207, 219, 39, 237, 203, 211, 208, 226, 59, 133, 138, 248, 48, 150, 141, 188, 45, 157, 151, 245, 59, 131, 29, 254, 118, 89, 71, 228, 125, 74, 64, 160, 96, 65, 90, 233, 118, 95, 108, 210, 101, 76, 95, 248, 118, 59, 170, 6, 13, 101, 168, 20, 78, 97, 175, 24, 13, 97, 175, 18, 71, 121, 165, 103, 88, 154, 127, 40, 80, 134, 32, 61, 31, 130, 55, 48, 31, 139, 39, 61, 70, 134, 60, 66, 110, 127, 73, 13, 102, 99, 22, 24, 41, 103, 1, 21, 41, 104, 13, 31, 116, 96, 5, 21, 76, 89, 113, 126, 3, 81, 109, 33, 22, 30, 105, 54, 27, 30, 106, 58, 12, 71, 171, 94, 64, 249, 241, 68, 75, 234, 246, 0, 71, 236, 230, 70, 8, 239, 240, 89, 81, 226, 235, 26, 199, 157, 246, 32, 204, 142, 241, 25, 195, 142, 231, 10, 205, 135, 246, 59, 205, 133, 238, 44, 208, 201, 225, 40, 193, 129, 231, 12, 206, 140, 239, 44, 204, 157, 241, 213, 234, 236, 209, 200, 128, 142, 135, 191, 186, 133, 148, 184, 243, 152, 159, 162, 183, 142, 129, 235, 186, 133, 131, 190, 167, 202, 72, 40, 174, 206, 69, 188, 239, 187, 158, 134, 228, 168, 153, 207, 249, 163, 131, 139, 239, 189, 202, 140, 226, 174, 132, 136, 239, 182, 148, 84, 178, 178, 153, 142, 20, 159, 178, 170, 19, 147, 252, 179, 19, 154, 185, 254, 8, 145, 187, 185, 16, 155, 252, 189, 20, 159, 178, 185, 25, 154, 134, 241, 236, 158, 142, 139, 12, 33, 99, 131, 92, 102, 171, 66, 95, 40, 188, 72, 92, 114, 188, 9, 68, 115, 161, 75, 98, 117, 87, 73, 101, 110, 66, 78, 121, 105, 108, 224, 78, 68, 5, 144, 66, 33, 63, 155, 81, 38, 118, 151, 87, 54, 61, 213, 84, 32, 34, 129, 89, 59, 118, 150, 90, 60, 53, 158, 83, 49, 76, 128, 110, 36, 5, 180, 120, 28, 2, 188, 108, 16, 34, 172, 102, 28, 24, 178, 69, 5, 19, 176, 114, 85, 16, 180, 122, 25, 20, 180, 117, 30, 36, 220, 89, 52, 35, 212, 77, 56, 3, 196, 71, 52, 57, 218, 100, 45, 50, 216, 83, 202, 19, 133, 254, 233, 22, 204, 230, 227, 82, 128, 253, 237, 22, 204, 225, 233, 6, 152, 251, 226, 21, 159, 252, 230, 251, 215, 198, 237, 232, 208, 143, 241, 234, 208, 219, 236, 253, 198, 203, 255, 66, 78, 254, 231, 97, 91, 230, 234, 91, 80, 245, 237, 102, 81, 199, 215, 157, 1, 76, 176, 188, 20, 76, 241, 187, 29, 65, 181, 173, 3, 8, 181, 161, 2, 88, 189, 169, 8, 227, 145, 182, 176, 192, 195, 178, 173, 202, 195, 184, 166, 202, 163, 130, 233, 173, 139, 206, 244, 161, 192, 141, 232, 175, 142, 137, 229, 213, 218, 50, 235, 207, 209, 33, 236, 139, 212, 35, 230, 196, 214, 40, 251, 139, 221, 51, 235, 210, 208, 40, 178, 139, 211, 47, 236, 210, 218, 40, 246, 200, 216, 128, 192, 114, 97, 132, 210, 101, 125, 196, 138, 122, 119, 176, 185, 64, 66, 242, 189, 87, 79, 242, 181, 83, 70, 166, 163, 64, 83, 242, 165, 70, 87, 160, 162, 87, 82, 13, 139, 195, 59, 56, 201, 199, 44, 53, 201, 207, 40, 60, 157, 217, 59, 41, 141, 90, 50, 168, 83, 94, 32, 191, 71, 114, 176, 76, 127, 126, 241, 78, 74, 60, 245, 89, 71, 60, 253, 93, 78, 104, 235, 78, 91, 60, 253, 93, 80, 127, 251, 80, 82, 121, 250, 85, 216, 247, 110, 76, 206, 241, 78, 64, 201, 241, 116, 75, 218, 246, 61, 86, 214, 236, 109, 85, 216, 225, 38, 5, 211, 234, 105, 5, 207, 224, 110, 81, 210, 247, 120, 65, 36, 187, 227, 10, 30, 176, 240, 13, 87, 174, 242, 12, 4, 183, 228, 10, 18, 186, 234, 51, 165, 222, 201, 54, 236, 198, 195, 114, 191, 211, 218, 55, 236, 193, 201, 38, 184, 219, 194, 53, 191, 228, 226, 235, 207, 199, 231, 162, 215, 205, 163, 235, 205, 203, 247, 235, 194, 206, 234, 248, 198, 130, 240, 231, 215, 214, 234, 236, 196, 209, 163, 242, 194, 197, 230, 243, 78, 79, 168, 185, 68, 73, 190, 240, 65, 84, 163, 182, 168, 7, 214, 191, 161, 3, 177, 136, 143, 172, 185, 151, 133, 176, 183, 32, 210, 11, 117, 122, 200, 0, 102, 125, 140, 1, 113, 122, 200, 1, 111, 140, 197, 189, 99, 136, 194, 177, 32, 136, 194, 187, 106, 144, 200, 77, 101, 163, 85, 88, 42, 167, 66, 85, 42, 163, 87, 88, 110, 163, 73, 87, 98, 176, 83, 77, 105, 163, 84, 9, 104, 180, 83, 77, 104, 170, 10, 64, 110, 183, 70, 70, 107, 161, 67, 94, 61, 54, 78, 18, 43, 54, 92, 94, 45, 51, 74, 91, 71, 238, 38, 89, 72, 197, 47, 52, 82, 206, 60, 51, 22, 207, 43, 52, 82, 207, 53, 109, 95, 201, 40, 33, 89, 204, 62, 36, 55, 244, 31, 7, 123, 226, 31, 21, 55, 228, 26, 3, 50, 19, 102, 254, 13, 22, 103, 248, 203, 43, 226, 199, 224, 10, 219, 225, 225, 16, 227, 235, 238, 0, 202, 224]);
  const tranquill_2 = self.tranquill_PACK = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  tranquill_2.data.push(tranquill_1);
  const tranquill_3 = tranquill_2.data.length - 1;
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 0,
    len: 14,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 14,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 20,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 26,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 32,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 38,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 44,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 50,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 54,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 58,
    len: 3,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 61,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 66,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 72,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 73,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 78,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 84,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 90,
    len: 3,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 93,
    len: 41,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 134,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 140,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 147,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 155,
    len: 43,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 198,
    len: 34,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 232,
    len: 36,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 268,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 296,
    len: 35,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 331,
    len: 36,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 367,
    len: 34,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 401,
    len: 33,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 434,
    len: 34,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 468,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 484,
    len: 23,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 507,
    len: 18,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 525,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 545,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 566,
    len: 18,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 584,
    len: 21,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 605,
    len: 36,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 641,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 646,
    len: 21,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 667,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 673,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 695,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 701,
    len: 27,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 728,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 733,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 738,
    len: 16,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 754,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 764,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 768,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 796,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 800,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 828,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 847,
    len: 23,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 870,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 887,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 904,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 926,
    len: 13,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 939,
    len: 15,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 954,
    len: 34,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 988,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 995,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 999,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1024,
    len: 18,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1042,
    len: 7,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1049,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1053,
    len: 27,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1080,
    len: 37,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1117,
    len: 18,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1135,
    len: 23,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1158,
    len: 34,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1192,
    len: 13,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1205,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1211,
    len: 9,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1220,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1236,
    len: 14,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1250,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1266,
    len: 24,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1290,
    len: 13,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1303,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1307,
    len: 24,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1331,
    len: 13,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1344,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1351,
    len: 16,
    kind: 1
  });
})();
let _tranquill_cond = typeof tranquill_9["key"] === tranquill_S("0x6c62272e07bb0142") && tranquill_9["key"]["length"] > 0;
if (_tranquill_cond) {
  tranquill_9.key;
} else {
  tranquill_7.key;
}
(function () {
  const tranquill_4 = tranquill_S("0x6c62272e07bb0142");
  const tranquill_5 = 60;
  const tranquill_6 = 200;
  const tranquill_7 = Object.freeze({
    key: tranquill_S("0x6c62272e07bb0142"),
    code: tranquill_S("0x6c62272e07bb0142"),
    altKey: false,
    ctrlKey: false,
    metaKey: false,
    shiftKey: false
  });
  const tranquill_8 = tranquill_9 => {
    if (tranquill_9 && typeof tranquill_9 === tranquill_S("0x6c62272e07bb0142")) {
      const tranquill_b = _tranquill_cond;
      const tranquill_c = typeof tranquill_9.code === tranquill_S("0x6c62272e07bb0142") && tranquill_9.code.length > 0 ? tranquill_9.code : tranquill_b;
      return {
        key: tranquill_b,
        code: tranquill_c,
        altKey: tranquill_9.altKey === true,
        ctrlKey: tranquill_9["ctrlKey"] === true,
        metaKey: tranquill_9.metaKey === true,
        shiftKey: tranquill_9.shiftKey === true
      };
    }
    if (typeof tranquill_9 === tranquill_S("0x6c62272e07bb0142") && tranquill_9.trim().length > 0) {
      const tranquill_e = tranquill_9.trim();
      return {
        key: tranquill_e,
        code: tranquill_e,
        altKey: false,
        ctrlKey: false,
        metaKey: false,
        shiftKey: false
      };
    }
    return {
      ...tranquill_7
    };
  };
  const tranquill_f = tranquill_g => {
    const tranquill_h = tranquill_8(tranquill_g);
    const tranquill_i = [];
    if (tranquill_h.ctrlKey) tranquill_i.push(tranquill_S("0x6c62272e07bb0142"));
    if (tranquill_h.metaKey) tranquill_i.push(tranquill_S("0x6c62272e07bb0142"));
    if (tranquill_h.altKey) tranquill_i.push(tranquill_S("0x6c62272e07bb0142"));
    if (tranquill_h["shiftKey"]) tranquill_i.push(tranquill_S("0x6c62272e07bb0142"));
    let base = tranquill_h.key;
    if (typeof base !== tranquill_S("0x6c62272e07bb0142") || base.length === 0) {
      base = tranquill_h.code;
    }
    if (base === tranquill_S("0x6c62272e07bb0142")) base = tranquill_S("0x6c62272e07bb0142");
    if (typeof base === tranquill_S("0x6c62272e07bb0142") && base.length === 1) {
      base = base.toUpperCase();
    }
    if (typeof base === tranquill_S("0x6c62272e07bb0142") && base.length > 1) {
      base = `${base.charAt(0).toUpperCase()}${base.slice(1)}`;
    }
    tranquill_i.push(base);
    return tranquill_i["join"](tranquill_S("0x6c62272e07bb0142"));
  };
  const tranquill_j = tranquill_k => tranquill_8({
    key: tranquill_k.key,
    code: tranquill_k.code,
    altKey: tranquill_k.altKey,
    ctrlKey: tranquill_k.ctrlKey,
    metaKey: tranquill_k.metaKey,
    shiftKey: tranquill_k["shiftKey"]
  });
  class tranquill_l {
    static get defaults() {
      return {
        typingSpeed: 120,
        phantomMode: false,
        abortKey: tranquill_8(tranquill_7)
      };
    }
    static normalize(tranquill_m) {
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        rawSettings: tranquill_m
      });
      const tranquill_n = tranquill_l["defaults"];
      const tranquill_o = {
        ...tranquill_n,
        abortKey: tranquill_8(tranquill_n.abortKey)
      };
      if (tranquill_m && typeof tranquill_m === tranquill_S("0x6c62272e07bb0142")) {
        const tranquill_q = Number.parseInt(tranquill_m["typingSpeed"], 10);
        if (Number.isFinite(tranquill_q)) {
          tranquill_o.typingSpeed = Math.min(tranquill_6, Math.max(tranquill_5, tranquill_q));
        }
        if (typeof tranquill_m.phantomMode === tranquill_S("0x6c62272e07bb0142")) {
          tranquill_o["phantomMode"] = tranquill_m.phantomMode;
        }
        if (Object["prototype"].hasOwnProperty.call(tranquill_m, tranquill_S("0x6c62272e07bb0142"))) {
          tranquill_o["abortKey"] = tranquill_8(tranquill_m.abortKey);
        }
      }
      return tranquill_o;
    }
    static getSettings() {
      log.debug(tranquill_S("0x6c62272e07bb0142"));
      return new Promise((tranquill_r, tranquill_s) => {
        chrome.storage.local["get"](tranquill_4, tranquill_t => {
          if (chrome["runtime"]["lastError"]) {
            const tranquill_u = new Error(chrome.runtime.lastError.message);
            log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_u);
            tranquill_s(tranquill_u);
            return;
          }
          const tranquill_v = tranquill_t[tranquill_4];
          const tranquill_w = tranquill_l.normalize(tranquill_v);
          log.debug(tranquill_S("0x6c62272e07bb0142"), tranquill_w);
          tranquill_r(tranquill_w);
        });
      });
    }
    static saveSettings(tranquill_x) {
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        settings: tranquill_x
      });
      const tranquill_y = tranquill_l.normalize(tranquill_x);
      return new Promise((tranquill_z, tranquill_A) => {
        chrome.storage.local.set({
          [tranquill_4]: tranquill_y
        }, () => {
          if (chrome["runtime"].lastError) {
            const tranquill_B = new Error(chrome.runtime.lastError.message);
            log["error"](tranquill_S("0x6c62272e07bb0142"), tranquill_B);
            tranquill_A(tranquill_B);
            return;
          }
          log.debug(tranquill_S("0x6c62272e07bb0142"), tranquill_y);
          tranquill_z(tranquill_y);
        });
      });
    }
  }
  class tranquill_C {
    constructor(tranquill_D) {
      this.documentRef = tranquill_D;
      this.slider = null;
      this.sliderValue = null;
      this.phantomToggle = null;
      this.abortKeyButton = null;
      this.abortKeyValue = null;
      this.abortKeyHint = null;
      this.backButton = null;
      this.currentSettings = tranquill_l.defaults;
      this.isRestored = false;
      this["isCapturingAbortKey"] = false;
      this.abortKeyCaptureHandler = null;
      this.abortKeyBlurHandler = null;
      log["debug"](tranquill_S("0x6c62272e07bb0142"));
    }
    async init() {
      log.debug(tranquill_S("0x6c62272e07bb0142"));
      this["cacheElements"]();
      this.registerEventListeners();
      await this["restoreSettings"]();
      log.info(tranquill_S("0x6c62272e07bb0142"));
    }
    cacheElements() {
      this.slider = this.documentRef.querySelector(tranquill_S("0x6c62272e07bb0142"));
      this["sliderValue"] = this.documentRef.querySelector(tranquill_S("0x6c62272e07bb0142"));
      this.phantomToggle = this["documentRef"]["querySelector"](tranquill_S("0x6c62272e07bb0142"));
      this["abortKeyButton"] = this.documentRef.querySelector(tranquill_S("0x6c62272e07bb0142"));
      if (this.abortKeyButton) {
        this.abortKeyValue = this.abortKeyButton["querySelector"](tranquill_S("0x6c62272e07bb0142"));
        this.abortKeyHint = this.abortKeyButton.querySelector(tranquill_S("0x6c62272e07bb0142"));
      } else {
        this.abortKeyValue = null;
        this.abortKeyHint = null;
      }
      this.backButton = this.documentRef.querySelector(tranquill_S("0x6c62272e07bb0142"));
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        hasSlider: Boolean(this["slider"]),
        hasPhantomToggle: Boolean(this.phantomToggle),
        hasAbortKeyButton: Boolean(this.abortKeyButton)
      });
    }
    registerEventListeners() {
      if (this.slider) {
        this.slider.addEventListener(tranquill_S("0x6c62272e07bb0142"), () => {
          const tranquill_E = this.sanitizeTypingSpeed(this["slider"].value);
          this.updateSliderDisplay(tranquill_E);
          log.debug(tranquill_S("0x6c62272e07bb0142"), {
            sanitized: tranquill_E
          });
        });
        this.slider["addEventListener"](tranquill_S("0x6c62272e07bb0142"), async () => {
          const tranquill_F = this.sanitizeTypingSpeed(this.slider.value);
          this["slider"].value = String(tranquill_F);
          log.debug(tranquill_S("0x6c62272e07bb0142"), {
            sanitized: tranquill_F
          });
          await this.persistSettings({
            typingSpeed: tranquill_F
          });
        });
      }
      if (this.phantomToggle) {
        this["phantomToggle"].addEventListener(tranquill_S("0x6c62272e07bb0142"), async () => {
          const tranquill_G = this.phantomToggle.checked;
          log["debug"](tranquill_S("0x6c62272e07bb0142"), {
            isEnabled: tranquill_G
          });
          tranquill_13(tranquill_G);
          await this["persistSettings"]({
            phantomMode: tranquill_G
          });
        });
      }
      if (this.abortKeyButton) {
        this.abortKeyButton["addEventListener"](tranquill_S("0x6c62272e07bb0142"), () => {
          this.startAbortKeyCapture();
        });
      }
      if (this.backButton) {
        this.backButton.addEventListener(tranquill_S("0x6c62272e07bb0142"), () => {
          const tranquill_H = new URL(chrome["runtime"].getURL(tranquill_S("0x6c62272e07bb0142")));
          tranquill_H.searchParams["set"](tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
          window["location"].href = tranquill_H.toString();
          log.info(tranquill_S("0x6c62272e07bb0142"), {
            transition: tranquill_S("0x6c62272e07bb0142")
          });
        });
      }
    }
    sanitizeTypingSpeed(tranquill_I) {
      const tranquill_J = Number.parseInt(tranquill_I, 10);
      if (!Number.isFinite(tranquill_J)) {
        log.debug(tranquill_S("0x6c62272e07bb0142"), {
          value: tranquill_I,
          fallback: this.currentSettings["typingSpeed"]
        });
        return this.currentSettings.typingSpeed;
      }
      const tranquill_K = Math.min(tranquill_6, Math.max(tranquill_5, tranquill_J));
      log["debug"](tranquill_S("0x6c62272e07bb0142"), {
        value: tranquill_I,
        sanitized: tranquill_K
      });
      return tranquill_K;
    }
    async restoreSettings() {
      try {
        this.currentSettings = await tranquill_l.getSettings();
      } catch (tranquill_L) {
        log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_L);
        this["currentSettings"] = tranquill_l.defaults;
      }
      this.isRestored = true;
      this.applySettingsToUI();
      log.debug(tranquill_S("0x6c62272e07bb0142"), this.currentSettings);
      tranquill_13(this.currentSettings.phantomMode);
    }
    applySettingsToUI() {
      const {
        typingSpeed: tranquill_M,
        phantomMode: tranquill_N,
        abortKey: tranquill_O
      } = this.currentSettings;
      log.debug(tranquill_S("0x6c62272e07bb0142"), this.currentSettings);
      if (this["slider"]) {
        this.slider.value = String(tranquill_M);
        this.updateSliderDisplay(tranquill_M);
      }
      if (this.phantomToggle) {
        this.phantomToggle.checked = Boolean(tranquill_N);
      }
      this.updateAbortKeyDisplay(tranquill_O);
    }
    updateSliderDisplay(tranquill_P) {
      if (this["sliderValue"]) {
        this.sliderValue.textContent = `${tranquill_P} WPM`;
        log.debug(tranquill_S("0x6c62272e07bb0142"), {
          value: tranquill_P
        });
      }
    }
    updateAbortKeyDisplay(tranquill_Q = this.currentSettings.abortKey) {
      if (!this.abortKeyButton) return;
      const tranquill_R = tranquill_f(tranquill_Q);
      if (this.abortKeyValue) {
        this.abortKeyValue.textContent = tranquill_R;
      } else {
        this.abortKeyButton["textContent"] = tranquill_R;
      }
      if (this["abortKeyHint"]) {
        this["abortKeyHint"]["textContent"] = this.isCapturingAbortKey ? tranquill_S("0x6c62272e07bb0142") : tranquill_S("0x6c62272e07bb0142");
      }
      this.abortKeyButton["classList"].toggle(tranquill_S("0x6c62272e07bb0142"), this["isCapturingAbortKey"]);
    }
    startAbortKeyCapture() {
      if (!this["abortKeyButton"]) return;
      if (this.isCapturingAbortKey) {
        this.stopAbortKeyCapture({
          cancelled: true
        });
        return;
      }
      this.isCapturingAbortKey = true;
      this.updateAbortKeyDisplay();
      this.abortKeyCaptureHandler = tranquill_S => {
        this.handleAbortKeyCapture(tranquill_S);
      };
      window.addEventListener(tranquill_S("0x6c62272e07bb0142"), this.abortKeyCaptureHandler, true);
      this["abortKeyBlurHandler"] = () => {
        this.stopAbortKeyCapture({
          cancelled: true
        });
      };
      window["addEventListener"](tranquill_S("0x6c62272e07bb0142"), this["abortKeyBlurHandler"]);
      log.info(tranquill_S("0x6c62272e07bb0142"));
    }
    handleAbortKeyCapture(tranquill_T) {
      if (!this["isCapturingAbortKey"]) return;
      tranquill_T.preventDefault();
      tranquill_T.stopPropagation();
      if (tranquill_T["repeat"]) return;
      const tranquill_U = tranquill_j(tranquill_T);
      log.info(tranquill_S("0x6c62272e07bb0142"), {
        binding: tranquill_U
      });
      this.stopAbortKeyCapture();
      this.updateAbortKeyDisplay(tranquill_U);
      this.persistSettings({
        abortKey: tranquill_U
      });
    }
    stopAbortKeyCapture({
      cancelled: tranquill_V = false
    } = {}) {
      if (!this.isCapturingAbortKey) return;
      this["isCapturingAbortKey"] = false;
      if (this["abortKeyCaptureHandler"]) {
        window["removeEventListener"](tranquill_S("0x6c62272e07bb0142"), this["abortKeyCaptureHandler"], true);
        this["abortKeyCaptureHandler"] = null;
      }
      if (this.abortKeyBlurHandler) {
        window["removeEventListener"](tranquill_S("0x6c62272e07bb0142"), this["abortKeyBlurHandler"]);
        this["abortKeyBlurHandler"] = null;
      }
      this.updateAbortKeyDisplay();
      if (tranquill_V) {
        log.debug(tranquill_S("0x6c62272e07bb0142"));
      }
    }
    async persistSettings(tranquill_W) {
      if (!this.isRestored) {
        log["debug"](tranquill_S("0x6c62272e07bb0142"));
        return;
      }
      const tranquill_X = {
        ...this.currentSettings,
        ...tranquill_W
      };
      try {
        this.currentSettings = await tranquill_l.saveSettings(tranquill_X);
        this.applySettingsToUI();
        log["info"](tranquill_S("0x6c62272e07bb0142"), tranquill_W);
      } catch (tranquill_Y) {
        log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_Y);
      }
    }
  }
  function tranquill_Z() {
    const tranquill_10 = new tranquill_C(document);
    tranquill_10["init"]().catch(tranquill_11 => {
      log["error"](tranquill_S("0x6c62272e07bb0142"), tranquill_11);
    });
    const tranquill_12 = document.querySelector(tranquill_S("0x6c62272e07bb0142"));
    let cText = tranquill_12.innerText;
    cText = cText["replace"](tranquill_S("0x6c62272e07bb0142"), new Date().getFullYear()).replace(tranquill_S("0x6c62272e07bb0142"), chrome["runtime"].getManifest().version);
    tranquill_12.innerText = cText;
  }
  function tranquill_13(tranquill_14) {
    document["querySelectorAll"](tranquill_S("0x6c62272e07bb0142")).forEach(tranquill_15 => {
      if (tranquill_14) {
        if (!tranquill_15.classList.contains(tranquill_S("0x6c62272e07bb0142")) && !tranquill_15.classList["contains"](tranquill_S("0x6c62272e07bb0142"))) {
          tranquill_15.classList.add(tranquill_S("0x6c62272e07bb0142"));
          tranquill_15.setAttribute(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
        }
      } else {
        tranquill_15.classList.remove(tranquill_S("0x6c62272e07bb0142"));
        tranquill_15.removeAttribute(tranquill_S("0x6c62272e07bb0142"));
      }
    });
  }
  if (document.readyState === tranquill_S("0x6c62272e07bb0142")) {
    document["addEventListener"](tranquill_S("0x6c62272e07bb0142"), tranquill_Z);
  } else {
    tranquill_Z();
  }
})();
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}