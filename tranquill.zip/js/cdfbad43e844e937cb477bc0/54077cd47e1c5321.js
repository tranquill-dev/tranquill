const tranquill_global = typeof self !== "undefined" ? self : globalThis;
if (!tranquill_global.tranquill_runtime_ready) {
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::16fd2ce4be226d9f78b1905b71de3935"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = "tranquill_tranquill_tranquill";
        tranquill_global.tranquill_runtime_ready = true;
}

(function tranquill_0() {
  const tranquill_1 = new Uint8Array([51, 160, 204, 76, 46, 189, 38, 57, 17, 68, 49, 64, 241, 37, 94, 82, 250, 61, 91, 74, 243, 236, 67, 73, 91, 149, 250, 40, 70, 134, 69, 52, 174, 52, 136, 219, 41, 20, 154, 97, 43, 5, 51, 74, 85, 58, 48, 50, 22, 215, 49, 62, 0, 53, 138, 130, 55, 34, 2, 77, 85, 48, 53, 34, 230, 199, 1, 46, 240, 244, 162, 141, 29, 237, 164, 141, 6, 225, 13, 231, 172, 26, 16, 244, 7, 105, 38, 20, 26, 122, 12, 237, 57, 17, 9, 234, 49, 19, 20, 178, 52, 16, 31, 178, 43, 11, 10, 250, 57, 18, 245, 4, 158, 251, 214, 69, 246, 225, 207, 64, 55, 152, 163, 40, 22, 148, 171, 58, 69, 137, 170, 125, 22, 152, 177, 125, 16, 147, 182, 40, 21, 141, 170, 47, 17, 152, 161, 125, 9, 146, 162, 125, 9, 152, 179, 56, 9, 221, 249, 122, 240, 193, 251, 66, 217, 216, 249, 98, 161, 48, 174, 157, 130, 53, 231, 133, 136, 113, 180, 148, 147, 113, 171, 158, 128, 113, 171, 148, 145, 52, 171, 174, 103, 136, 151, 173, 119, 228, 136, 136, 106, 249, 164, 160, 196, 154, 164, 239, 216, 128, 179, 168, 221, 129, 179, 239, 214, 157, 189, 171, 211, 138, 244, 170, 199, 155, 181, 173, 216, 134, 167, 167, 209, 139, 179, 142, 60, 163, 144, 139, 117, 187, 154, 207, 60, 161, 156, 155, 60, 174, 153, 134, 47, 170, 213, 131, 58, 168, 146, 134, 59, 168, 213, 141, 39, 166, 145, 136, 48, 68, 167, 132, 93, 100, 155, 128, 71, 102, 169, 147, 77, 58, 175, 145, 92, 71, 169, 130, 77, 112, 156, 145, 80, 96, 232, 157, 70, 98, 167, 159, 77, 112, 44, 74, 73, 46, 59, 127, 90, 51, 43, 127, 27, 127, 97, 95, 39, 123, 123, 93, 21, 104, 113, 1, 19, 106, 96, 124, 21, 121, 113, 75, 32, 106, 108, 91, 84, 105, 117, 70, 24, 106, 112, 1, 123, 129, 1, 33, 71, 133, 27, 35, 117, 150, 17, 127, 115, 148, 0, 2, 117, 135, 17, 53, 64, 148, 12, 37, 52, 131, 17, 34, 123, 157, 2, 52, 112, 200, 211, 200, 233, 232, 239, 204, 243, 234, 221, 223, 249, 182, 207, 221, 232, 203, 221, 206, 249, 252, 232, 221, 228, 236, 220, 248, 156, 194, 252, 196, 152, 216, 254, 246, 139, 210, 162, 228, 137, 195, 223, 246, 154, 210, 232, 195, 137, 207, 248, 183, 138, 214, 229, 251, 137, 211, 251, 216, 251, 226, 219, 228, 255, 248, 217, 214, 236, 242, 133, 196, 238, 227, 248, 214, 253, 242, 207, 227, 238, 239, 223, 151, 248, 226, 200, 212, 238, 228, 216, 84, 137, 20, 115, 116, 181, 16, 105, 118, 135, 3, 99, 42, 133, 8, 99, 101, 148, 55, 103, 114, 131, 0, 82, 97, 158, 16, 108, 138, 137, 110, 123, 191, 154, 115, 107, 105, 181, 13, 69, 115, 171, 45, 94, 114, 171, 15, 73, 110, 191, 79, 169, 79, 83, 111, 149, 75, 73, 109, 167, 88, 67, 49, 165, 83, 67, 126, 180, 108, 71, 105, 163, 91, 114, 122, 190, 75, 6, 121, 167, 86, 74, 122, 162, 16, 13, 144, 119, 48, 49, 148, 109, 50, 3, 135, 103, 110, 1, 140, 103, 33, 16, 179, 99, 54, 7, 132, 86, 37, 26, 148, 34, 51, 23, 131, 97, 37, 17, 147, 4, 32, 68, 26, 36, 28, 64, 0, 38, 46, 83, 10, 122, 61, 81, 28, 49, 59, 96, 22, 36, 38, 90, 8, 4, 61, 91, 8, 38, 42, 71, 28, 41, 0, 169, 58, 9, 60, 173, 32, 11, 14, 190, 42, 87, 29, 188, 60, 28, 27, 141, 54, 9, 6, 183, 40, 41, 29, 182, 40, 11, 10, 170, 60, 89, 9, 184, 38, 21, 10, 189, 193, 9, 65, 179, 225, 53, 69, 169, 227, 7, 86, 163, 191, 20, 84, 181, 244, 18, 101, 191, 225, 15, 95, 161, 193, 20, 94, 161, 227, 3, 66, 181, 177, 21, 68, 165, 242, 3, 66, 181, 140, 19, 12, 169, 172, 41, 53, 159, 179, 18, 8, 174, 179, 16, 16, 185, 174, 92, 31, 179, 178, 15, 8, 174, 169, 31, 8, 185, 184, 92, 68, 156, 126, 124, 126, 165, 72, 99, 69, 152, 121, 99, 71, 128, 110, 126, 5, 133, 101, 101, 95, 204, 120, 120, 74, 158, 127, 119, 104, 119, 82, 87, 82, 78, 100, 72, 105, 115, 85, 72, 107, 107, 66, 85, 39, 110, 73, 78, 115, 110, 70, 75, 110, 125, 66, 67, 53, 233, 153, 88, 108, 229, 143, 92, 52, 248, 3, 109, 172, 72, 72, 51, 175, 75, 89, 106, 162, 80, 70, 138, 109, 43, 13, 140, 37, 58, 29, 140, 124, 55, 6, 121, 52, 67, 6, 37, 51, 26, 5, 34, 51, 67, 8, 57, 121, 15, 82, 40, 35, 21, 89, 59, 36, 81, 85, 41, 35, 8, 88, 50, 174, 45, 149, 3, 228, 47, 205, 6, 233, 36, 139, 209, 240, 81, 10, 241, 202, 104, 60, 238, 241, 85, 13, 238, 243, 77, 26, 243, 191, 66, 30, 226, 247, 68, 58, 237, 250, 76, 26, 239, 235, 82, 231, 208, 205, 255, 239, 7, 15, 59, 43, 28, 65, 96, 116, 8, 18, 59, 51, 26, 25, 97, 56, 0, 22, 96, 52, 24, 30, 33, 60, 29, 30, 40, 40, 0, 21, 96, 47, 29, 26, 33, 42, 26, 18, 35, 55, 64, 182, 113, 56, 128, 148, 36, 61, 141, 159, 111, 113, 135, 157, 109, 50, 143, 148, 96, 167, 16, 13, 191, 175, 136, 162, 205, 134, 191, 227, 207, 134, 163, 183, 155, 133, 169, 172, 214, 195, 171, 172, 203, 150, 171, 186, 183, 53, 154, 153, 178, 124, 130, 147, 246, 47, 151, 138, 179, 124, 130, 153, 174, 40, 64, 135, 106, 104, 72, 123, 181, 119, 68, 15, 185, 97, 64, 90, 164, 47, 83, 67, 181, 110, 66, 74, 180, 47, 70, 70, 177, 47, 66, 74, 163, 106, 68, 20, 216, 18, 53, 37, 209, 19, 116, 36, 213, 1, 49, 51, 148, 3, 49, 47, 192, 87, 39, 35, 213, 3, 49, 7, 253, 136, 80, 36, 248, 193, 72, 46, 188, 130, 80, 36, 253, 147, 28, 50, 253, 151, 89, 37, 188, 149, 89, 57, 232, 39, 144, 141, 63, 47, 34, 45, 91, 22, 63, 237, 56, 148, 3, 240, 123, 129, 4, 246, 57, 150, 222, 206, 146, 255, 170, 194, 132, 251, 255, 223, 202, 254, 250, 207, 139, 255, 239, 207, 223, 112, 251, 192, 197, 110, 216, 221, 202, 125, 254, 218, 232, 97, 234, 199, 204, 108, 239, 242, 63, 54, 207, 200, 33, 102, 213, 210, 39, 50, 211, 213, 102, 51, 214, 194, 39, 50, 195, 134, 52, 35, 197, 195, 47, 48, 195, 194, 206, 57, 36, 214, 198, 206, 245, 121, 209, 205, 187, 109, 209, 202, 224, 119, 218, 217, 231, 48, 220, 202, 249, 114, 168, 67, 157, 191, 175, 88, 136, 184, 179, 95, 182, 214, 148, 178, 167, 162, 63, 138, 142, 162, 61, 138, 135, 164, 105, 151, 134, 227, 58, 134, 157, 183, 32, 141, 142, 176, 105, 147, 136, 164, 44, 139, 55, 233, 147, 172, 49, 173, 128, 145, 38, 187, 144, 222, 39, 191, 130, 155, 48, 254, 128, 155, 44, 170, 104, 236, 39, 65, 75, 233, 110, 89, 65, 173, 60, 72, 93, 249, 33, 95, 75, 173, 61, 76, 88, 232, 42, 13, 90, 232, 54, 89, 113, 254, 162, 86, 73, 244, 229, 69, 92, 225, 172, 95, 66, 177, 172, 86, 75, 254, 183, 84, 65, 170, 229, 80, 73, 227, 160, 80, 65, 232, 229, 65, 87, 254, 166, 84, 86, 226, 172, 95, 66, 122, 130, 111, 115, 86, 134, 111, 115, 95, 214, 111, 121, 27, 133, 111, 119, 73, 130, 59, 98, 66, 134, 114, 120, 92, 214, 108, 127, 79, 158, 116, 99, 79, 214, 111, 115, 67, 130, 211, 34, 129, 4, 244, 63, 142, 17, 160, 34, 153, 6, 233, 56, 135, 86, 242, 51, 145, 3, 229, 37, 148, 39, 22, 35, 38, 29, 8, 115, 60, 22, 28, 32, 38, 28, 1, 115, 60, 7, 14, 33, 59, 22, 11, 115, 41, 1, 0, 62, 111, 3, 0, 35, 58, 3, 143, 81, 0, 188, 172, 84, 73, 164, 166, 16, 26, 164, 168, 66, 29, 240, 189, 73, 25, 185, 167, 87, 191, 235, 186, 153, 138, 170, 187, 147, 159, 227, 161, 141, 207, 248, 170, 155, 154, 239, 188, 158, 138, 238, 142, 115, 138, 131, 180, 109, 218, 154, 187, 127, 137, 143, 190, 82, 204, 157, 97, 113, 201, 212, 121, 123, 141, 132, 108, 97, 222, 145, 45, 96, 212, 132, 100, 122, 202, 132, 113, 253, 138, 153, 50, 232, 141, 159, 112, 255, 79, 90, 182, 97, 82, 25, 163, 102, 84, 91, 180, 117, 252, 131, 93, 120, 231, 218, 4, 123, 230, 150, 77, 126, 231, 144, 99, 206, 81, 104, 100, 238, 73, 106, 121, 212, 87, 26, 1, 4, 33, 32, 24, 1, 111, 42, 29, 29, 32, 61, 79, 28, 59, 46, 29, 27, 38, 33, 8, 79, 59, 54, 31, 6, 33, 40, 24, 19, 125, 33, 13, 38, 113, 34, 1, 28, 111, 61, 41, 227, 9, 7, 48, 230, 71, 13, 53, 250, 8, 26, 103, 248, 6, 29, 52, 225, 9, 15, 103, 252, 30, 24, 46, 230, 0, 223, 202, 2, 240, 233, 215, 76, 231, 245, 195, 5, 253, 235, 147, 31, 231, 237, 199, 25, 224, 254, 246, 49, 219, 221, 243, 120, 195, 215, 183, 43, 206, 214, 244, 120, 195, 193, 231, 49, 217, 223, 183, 43, 195, 217, 227, 45, 196, 242, 230, 129, 247, 236, 243, 156, 205, 242, 208, 129, 194, 225, 246, 134, 171, 207, 25, 169, 165, 254, 20, 186, 164, 196, 10, 153, 185, 203, 25, 191, 190, 138, 11, 171, 164, 198, 8, 174, 233, 14, 61, 226, 208, 5, 124, 244, 211, 64, 56, 229, 200, 5, 46, 237, 213, 14, 57, 160, 200, 25, 44, 233, 210, 7, 124, 243, 200, 1, 40, 245, 207, 132, 166, 54, 128, 138, 151, 59, 147, 139, 173, 37, 176, 150, 162, 54, 150, 145, 227, 48, 134, 145, 179, 45, 141, 145, 166, 98, 138, 140, 181, 35, 143, 139, 167, 101, 12, 0, 126, 112, 105, 94, 24, 107, 188, 70, 45, 183, 157, 95, 39, 177, 201, 69, 61, 183, 155, 66, 105, 180, 156, 66, 61, 185, 135, 22, 40, 166, 153, 83, 40, 164, 136, 88, 42, 179, 70, 82, 180, 52, 65, 11, 183, 51, 65, 82, 186, 40, 65, 67, 164, 49, 84, 15, 179, 55, 69, 86, 190, 44, 60, 156, 212, 47, 112, 158, 207, 43, 46, 157, 216, 42, 37, 136, 196, 63, 34, 157, 136, 47, 33, 51, 73, 155, 58, 127, 87, 147, 57, 55, 87, 46, 108, 171, 30, 27, 45, 170, 20, 14, 100, 176, 10, 41, 93, 187, 251, 14, 9, 174, 240, 10, 64, 180, 238, 233, 140, 137, 233, 248, 249, 219, 124, 233, 204, 154, 125, 227, 217, 211, 103, 253, 198, 178, 148, 212, 225, 230, 129, 223, 229, 175, 155, 193, 217, 223, 22, 242, 250, 218, 95, 234, 240, 158, 22, 240, 246, 202, 22, 255, 243, 215, 5, 251, 191, 206, 16, 238, 234, 206, 251, 91, 146, 247, 208, 122, 171, 209, 209, 96, 147, 219, 222, 112, 186, 208]);
  const tranquill_2 = self["tranquill_PACK"] = self["tranquill_PACK"] || {
    idx: new Map(),
    data: []
  };
  tranquill_2["data"].push(tranquill_1);
  const tranquill_3 = tranquill_2.data.length - 1;
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 0,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 6,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 11,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 15,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 19,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 24,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 30,
    len: 3,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 33,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 37,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 42,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 47,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 53,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 58,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 63,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 69,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 78,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 84,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 90,
    len: 20,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 110,
    len: 3,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 113,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 120,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 120,
    len: 0,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 120,
    len: 37,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 157,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 168,
    len: 23,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 191,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 196,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 202,
    len: 32,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 234,
    len: 35,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 269,
    len: 33,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 302,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 311,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 343,
    len: 34,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 377,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 377,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 402,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 434,
    len: 33,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 467,
    len: 27,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 494,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 503,
    len: 14,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 517,
    len: 34,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 551,
    len: 35,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 586,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 586,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 618,
    len: 39,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 657,
    len: 40,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 697,
    len: 29,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 726,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 754,
    len: 29,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 783,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 793,
    len: 12,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 805,
    len: 13,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 818,
    len: 13,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 831,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 847,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 858,
    len: 31,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 889,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 894,
    len: 41,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 935,
    len: 18,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 953,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 958,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 958,
    len: 21,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 979,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 998,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1003,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1003,
    len: 28,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1031,
    len: 24,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1055,
    len: 26,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1081,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1086,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1091,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1102,
    len: 18,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1120,
    len: 19,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1139,
    len: 29,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1168,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1173,
    len: 19,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1192,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1202,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1206,
    len: 27,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1233,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1237,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1256,
    len: 28,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1284,
    len: 41,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1325,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1325,
    len: 38,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1363,
    len: 23,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1386,
    len: 33,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1419,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1441,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1463,
    len: 13,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1476,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1498,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1509,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1520,
    len: 15,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1535,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1546,
    len: 29,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1575,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1586,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1614,
    len: 20,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1634,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1662,
    len: 15,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1677,
    len: 24,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1701,
    len: 33,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1734,
    len: 34,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1768,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1773,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1777,
    len: 32,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1809,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1821,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1833,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1845,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1849,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1854,
    len: 10,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1864,
    len: 12,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1876,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1888,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1893,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1905,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1917,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1943,
    len: 16,
    kind: 1
  });
})();
let loggingPort = null;
const tranquill_4 = new Set([tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")]);
const tranquill_5 = tranquill_6 => {
  if (typeof tranquill_6 !== tranquill_S("0x6c62272e07bb0142")) return null;
  const tranquill_8 = tranquill_6.toLowerCase();
  if (tranquill_8 === tranquill_S("0x6c62272e07bb0142")) return tranquill_S("0x6c62272e07bb0142");
  if (tranquill_8 === tranquill_S("0x6c62272e07bb0142")) return tranquill_S("0x6c62272e07bb0142");
  return tranquill_4.has(tranquill_8) ? tranquill_8 : null;
};
const tranquill_9 = tranquill_a => {
  if (!tranquill_a || typeof tranquill_a !== tranquill_S("0x6c62272e07bb0142")) return tranquill_a;
  switch (tranquill_a.kind) {
    case tranquill_S("0x6c62272e07bb0142"):
      {
        const tranquill_d = new Error(tranquill_a.message);
        tranquill_d["name"] = tranquill_a.name || tranquill_S("0x6c62272e07bb0142");
        if (tranquill_a.stack) tranquill_d.stack = tranquill_a["stack"];
        return tranquill_d;
      }
    case tranquill_S("0x6c62272e07bb0142"):
    case tranquill_S("0x6c62272e07bb0142"):
      return tranquill_a.value;
    case tranquill_S("0x6c62272e07bb0142"):
      return tranquill_a.value;
    default:
      return tranquill_a.value;
  }
};
const tranquill_e = tranquill_f => {
  if (typeof tranquill_f !== tranquill_S("0x6c62272e07bb0142")) return null;
  let hash = 0;
  for (let tranquill_h = 0; tranquill_h < tranquill_f.length; tranquill_h++) {
    hash = Math.imul(31, hash) + tranquill_f.charCodeAt(tranquill_h);
    hash |= 0;
  }
  return `${tranquill_f.length}:${(hash >>> 0).toString(16)}`;
};
function tranquill_j() {
  if (loggingPort) return;
  try {
    const tranquill_k = chrome.runtime.connect({
      name: tranquill_S("0x6c62272e07bb0142")
    });
    let _tranquill_cond = tranquill_l?.meta?.timestamp;
    if (_tranquill_cond) {
      new Date(tranquill_l["meta"].timestamp)["toISOString"]();
    } else {
      tranquill_S("0x6c62272e07bb0142");
    }
    tranquill_k["onMessage"].addListener(tranquill_l => {
      const tranquill_m = tranquill_l?.level || tranquill_S("0x6c62272e07bb0142");
      const tranquill_n = Array.isArray(tranquill_l?.args) ? tranquill_l.args["map"](tranquill_9) : [];
      const tranquill_o = tranquill_l?.meta?.source ? tranquill_l.meta.source : tranquill_S("0x6c62272e07bb0142");
      const tranquill_p = _tranquill_cond;
      const tranquill_q = `[${tranquill_o}]${tranquill_p ? ` ${tranquill_p}` : tranquill_S("0x6c62272e07bb0142")}`;
      const tranquill_r = console[tranquill_m] || console.log;
      tranquill_r.call(console, tranquill_q, ...tranquill_n);
    });
    tranquill_k.onDisconnect.addListener(() => {
      loggingPort = null;
    });
    loggingPort = tranquill_k;
    window.tranquillSetLogLevel = tranquill_s => {
      if (!loggingPort) return;
      const tranquill_t = tranquill_5(tranquill_s);
      if (!tranquill_t) {
        log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_s);
        return;
      }
      try {
        loggingPort["postMessage"]({
          type: tranquill_S("0x6c62272e07bb0142"),
          level: tranquill_t
        });
      } catch (tranquill_v) {
        log["warn"](tranquill_S("0x6c62272e07bb0142"), tranquill_v);
      }
    };
    window.tranquillSetDebugLogging = tranquill_w => {
      const tranquill_x = tranquill_w ? tranquill_S("0x6c62272e07bb0142") : tranquill_S("0x6c62272e07bb0142");
      window.tranquillSetLogLevel(tranquill_x);
    };
    log.info(tranquill_S("0x6c62272e07bb0142"));
  } catch (tranquill_y) {
    log["error"](tranquill_S("0x6c62272e07bb0142"), tranquill_y);
  }
}
tranquill_j();
class tranquill_z {
  static getSavedText() {
    log.debug(tranquill_S("0x6c62272e07bb0142"));
    return new Promise((tranquill_A, tranquill_B) => {
      chrome.storage.local.get(tranquill_S("0x6c62272e07bb0142"), tranquill_C => {
        if (chrome["runtime"].lastError) {
          const tranquill_D = new Error(chrome["runtime"].lastError.message);
          log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_D);
          tranquill_B(tranquill_D);
          return;
        }
        log["debug"](tranquill_S("0x6c62272e07bb0142"), {
          length: tranquill_C.savedText?.length ?? 0
        });
        tranquill_A(tranquill_C.savedText || tranquill_S("0x6c62272e07bb0142"));
      });
    });
  }
  static setSavedText(tranquill_E) {
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      length: tranquill_E?.length ?? 0
    });
    return new Promise((tranquill_F, tranquill_G) => {
      chrome["storage"].local.set({
        savedText: tranquill_E
      }, () => {
        if (chrome.runtime.lastError) {
          const tranquill_H = new Error(chrome["runtime"].lastError["message"]);
          log["error"](tranquill_S("0x6c62272e07bb0142"), tranquill_H);
          tranquill_G(tranquill_H);
          return;
        }
        log.debug(tranquill_S("0x6c62272e07bb0142"));
        tranquill_F();
      });
    });
  }
  static clearSavedText() {
    log.debug(tranquill_S("0x6c62272e07bb0142"));
    return new Promise((tranquill_I, tranquill_J) => {
      chrome.storage.local.remove([tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")], () => {
        if (chrome["runtime"].lastError) {
          const tranquill_K = new Error(chrome["runtime"].lastError.message);
          log["error"](tranquill_S("0x6c62272e07bb0142"), tranquill_K);
          tranquill_J(tranquill_K);
          return;
        }
        log["debug"](tranquill_S("0x6c62272e07bb0142"));
        tranquill_I();
      });
    });
  }
  static resetTypingProgress(tranquill_L) {
    const tranquill_M = tranquill_e(String(tranquill_L || tranquill_S("0x6c62272e07bb0142")));
    log["debug"](tranquill_S("0x6c62272e07bb0142"), {
      signature: tranquill_M
    });
    return new Promise((tranquill_N, tranquill_O) => {
      chrome.storage.local.set({
        typingProgress: 0,
        typingProgressSignature: tranquill_M
      }, () => {
        if (chrome.runtime.lastError) {
          const tranquill_P = new Error(chrome.runtime.lastError.message);
          log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_P);
          tranquill_O(tranquill_P);
          return;
        }
        log.debug(tranquill_S("0x6c62272e07bb0142"), {
          signature: tranquill_M
        });
        tranquill_N();
      });
    });
  }
}
class tranquill_Q {
  constructor(tranquill_R) {
    this.documentRef = tranquill_R;
    this["textInput"] = null;
    this["saveButton"] = null;
    this.resetButton = null;
    this.startButton = null;
    this.settingsButton = null;
    this.guideButton = null;
    this.isProcessing = false;
    this.isTyping = false;
    log["debug"](tranquill_S("0x6c62272e07bb0142"));
  }
  async init() {
    log.debug(tranquill_S("0x6c62272e07bb0142"));
    this.cacheElements();
    this["registerListeners"]();
    await this.restoreSavedText();
    await this["syncTypingStatus"]();
    this.updateStartButtonAppearance();
    log.info(tranquill_S("0x6c62272e07bb0142"));
  }
  cacheElements() {
    this.textInput = this.documentRef["getElementById"](tranquill_S("0x6c62272e07bb0142"));
    this["saveButton"] = this.documentRef["querySelector"](tranquill_S("0x6c62272e07bb0142"));
    this.resetButton = this.documentRef.querySelector(tranquill_S("0x6c62272e07bb0142"));
    this.startButton = this["documentRef"].querySelector(tranquill_S("0x6c62272e07bb0142"));
    this["settingsButton"] = this["documentRef"]["querySelector"](tranquill_S("0x6c62272e07bb0142"));
    this.guideButton = this.documentRef.querySelector(tranquill_S("0x6c62272e07bb0142"));
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      hasTextInput: Boolean(this.textInput),
      hasStartButton: Boolean(this["startButton"])
    });
  }
  registerListeners() {
    if (this.guideButton) {
      this["guideButton"]["addEventListener"](tranquill_S("0x6c62272e07bb0142"), tranquill_S => {
        tranquill_S.preventDefault();
        chrome["tabs"]["create"]({
          url: tranquill_S("0x6c62272e07bb0142")
        });
        log.info(tranquill_S("0x6c62272e07bb0142"));
      });
    }
    if (this.saveButton) {
      this.saveButton["addEventListener"](tranquill_S("0x6c62272e07bb0142"), async () => {
        try {
          const tranquill_T = this.textInput?.value || tranquill_S("0x6c62272e07bb0142");
          await tranquill_z.setSavedText(tranquill_T);
          await tranquill_z.resetTypingProgress(tranquill_T);
          log.info(tranquill_S("0x6c62272e07bb0142"), {
            length: this["textInput"]?.value?.length ?? 0,
            progressReset: true
          });
        } catch (tranquill_U) {
          log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_U);
        }
      });
    }
    if (this.resetButton) {
      this.resetButton.addEventListener(tranquill_S("0x6c62272e07bb0142"), async () => {
        if (this.textInput) {
          this.textInput.value = tranquill_S("0x6c62272e07bb0142");
          log.info(tranquill_S("0x6c62272e07bb0142"));
          await this.handlePause();
        }
        try {
          await tranquill_z["clearSavedText"]();
          log.info(tranquill_S("0x6c62272e07bb0142"));
        } catch (tranquill_V) {
          log["error"](tranquill_S("0x6c62272e07bb0142"), tranquill_V);
        }
      });
    }
    if (this.startButton) {
      this.startButton.addEventListener(tranquill_S("0x6c62272e07bb0142"), () => this.handleToggleTyping());
    }
    if (this.textInput) {
      this.textInput.addEventListener(tranquill_S("0x6c62272e07bb0142"), () => {
        this.textInput.classList["remove"](tranquill_S("0x6c62272e07bb0142"));
        log.debug(tranquill_S("0x6c62272e07bb0142"), {
          length: this.textInput.value.length
        });
      });
    }
    chrome.runtime.onMessage.addListener(tranquill_W => {
      if (tranquill_W && tranquill_W.action === tranquill_S("0x6c62272e07bb0142")) {
        this["isTyping"] = Boolean(tranquill_W["isTyping"]);
        this.isProcessing = false;
        this.setStartButtonLoading(false);
        this.updateStartButtonAppearance();
        log.info(tranquill_S("0x6c62272e07bb0142"), {
          isTyping: this["isTyping"]
        });
      }
    });
    if (this.settingsButton) {
      this.settingsButton.addEventListener(tranquill_S("0x6c62272e07bb0142"), () => {
        const tranquill_X = new URL(chrome["runtime"].getURL(tranquill_S("0x6c62272e07bb0142")));
        tranquill_X.searchParams.set(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
        window["location"].href = tranquill_X["toString"]();
        log.info(tranquill_S("0x6c62272e07bb0142"), {
          transition: tranquill_S("0x6c62272e07bb0142")
        });
      });
    }
  }
  async restoreSavedText() {
    try {
      const tranquill_Y = await tranquill_z.getSavedText();
      if (this["textInput"]) {
        this.textInput.value = tranquill_Y;
        log.debug(tranquill_S("0x6c62272e07bb0142"), {
          length: tranquill_Y.length
        });
      }
    } catch (tranquill_Z) {
      log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_Z);
    }
  }
  async handleToggleTyping() {
    if (this.isProcessing) {
      log.debug(tranquill_S("0x6c62272e07bb0142"));
      return;
    }
    if (this.isTyping) {
      await this["handlePause"]();
      return;
    }
    await this["handleStart"]();
  }
  async handleStart() {
    const tranquill_10 = this.textInput ? this.textInput["value"] : tranquill_S("0x6c62272e07bb0142");
    if (!tranquill_10 || tranquill_10["trim"]()["length"] === 0) {
      this.indicateValidationError();
      log.warn(tranquill_S("0x6c62272e07bb0142"));
      return;
    }
    this.isProcessing = true;
    this.setStartButtonLoading(true);
    log.info(tranquill_S("0x6c62272e07bb0142"), {
      length: tranquill_10["length"]
    });
    try {
      const tranquill_12 = await tranquill_z.getSavedText();
      await tranquill_z.setSavedText(tranquill_10);
      const tranquill_13 = tranquill_12 !== tranquill_10;
      await this["sendStartTypingRequest"](tranquill_10, tranquill_13, tranquill_12);
      this.isTyping = true;
      this.updateStartButtonAppearance();
      log.info(tranquill_S("0x6c62272e07bb0142"));
    } catch (tranquill_14) {
      log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_14);
      this.isTyping = false;
      this["updateStartButtonAppearance"]();
    } finally {
      this.isProcessing = false;
      this.setStartButtonLoading(false);
    }
  }
  async handlePause() {
    this.isProcessing = true;
    this.setStartButtonLoading(true);
    log["info"](tranquill_S("0x6c62272e07bb0142"));
    try {
      await this.sendPauseTypingRequest();
      this.isTyping = false;
      this.updateStartButtonAppearance();
      log.info(tranquill_S("0x6c62272e07bb0142"));
    } catch (tranquill_15) {
      log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_15);
    } finally {
      this.isProcessing = false;
      this["setStartButtonLoading"](false);
    }
  }
  indicateValidationError() {
    if (!this.textInput) {
      return;
    }
    this.textInput.classList.add(tranquill_S("0x6c62272e07bb0142"));
    setTimeout(() => this.textInput.classList.remove(tranquill_S("0x6c62272e07bb0142")), 600);
    this.textInput["focus"]();
  }
  setStartButtonLoading(tranquill_16) {
    if (!this.startButton) {
      return;
    }
    this.startButton.disabled = tranquill_16;
    this.startButton.classList.toggle(tranquill_S("0x6c62272e07bb0142"), tranquill_16);
  }
  async sendStartTypingRequest(tranquill_17, tranquill_18 = false, tranquill_19 = null) {
    return new Promise((tranquill_1a, tranquill_1b) => {
      let _tranquill_cond2 = tranquill_1c && tranquill_1c.error;
      if (_tranquill_cond2) {
        tranquill_1c.error;
      } else {
        tranquill_S("0x6c62272e07bb0142");
      }
      chrome.runtime.sendMessage({
        action: tranquill_S("0x6c62272e07bb0142"),
        text: tranquill_17,
        resetProgress: tranquill_18,
        previousText: tranquill_19
      }, tranquill_1c => {
        if (chrome.runtime["lastError"]) {
          tranquill_1b(new Error(chrome.runtime.lastError.message));
          return;
        }
        if (!tranquill_1c || tranquill_1c.success !== true) {
          const tranquill_1e = _tranquill_cond2;
          tranquill_1b(new Error(tranquill_1e));
          return;
        }
        tranquill_1a();
      });
    });
  }
  async sendPauseTypingRequest() {
    return new Promise((tranquill_1f, tranquill_1g) => {
      chrome.runtime.sendMessage({
        action: tranquill_S("0x6c62272e07bb0142")
      }, tranquill_1h => {
        if (chrome.runtime.lastError) {
          tranquill_1g(new Error(chrome.runtime.lastError.message));
          return;
        }
        if (!tranquill_1h || tranquill_1h["success"] !== true) {
          const tranquill_1j = tranquill_1h && tranquill_1h["error"] ? tranquill_1h.error : tranquill_S("0x6c62272e07bb0142");
          tranquill_1g(new Error(tranquill_1j));
          return;
        }
        tranquill_1f();
      });
    });
  }
  async syncTypingStatus() {
    try {
      const tranquill_1k = await this.fetchTypingStatus();
      this["isTyping"] = Boolean(tranquill_1k);
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        isTyping: this["isTyping"]
      });
    } catch (tranquill_1l) {
      log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_1l);
      this.isTyping = false;
    }
  }
  async fetchTypingStatus() {
    return new Promise((tranquill_1m, tranquill_1n) => {
      chrome.runtime.sendMessage({
        action: tranquill_S("0x6c62272e07bb0142")
      }, tranquill_1o => {
        if (chrome.runtime.lastError) {
          const tranquill_1p = new Error(chrome.runtime.lastError.message);
          log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_1p);
          tranquill_1n(tranquill_1p);
          return;
        }
        if (!tranquill_1o || tranquill_1o.success !== true) {
          const tranquill_1r = tranquill_1o && tranquill_1o.error ? tranquill_1o.error : tranquill_S("0x6c62272e07bb0142");
          const tranquill_1s = new Error(tranquill_1r);
          log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_1s);
          tranquill_1n(tranquill_1s);
          return;
        }
        tranquill_1m(Boolean(tranquill_1o.isTyping));
      });
    });
  }
  updateStartButtonAppearance() {
    if (!this["startButton"]) {
      return;
    }
    const tranquill_1t = Boolean(this.isTyping);
    const tranquill_1u = tranquill_1t ? tranquill_S("0x6c62272e07bb0142") : tranquill_S("0x6c62272e07bb0142");
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      isTyping: tranquill_1t
    });
    this.startButton.classList.toggle(tranquill_S("0x6c62272e07bb0142"), !tranquill_1t);
    this.startButton["classList"].toggle(tranquill_S("0x6c62272e07bb0142"), tranquill_1t);
    this.startButton.innerHTML = `<i class="fa fa-${tranquill_1u}"></i>`;
    this.startButton.setAttribute(tranquill_S("0x6c62272e07bb0142"), tranquill_1t ? tranquill_S("0x6c62272e07bb0142") : tranquill_S("0x6c62272e07bb0142"));
    this["startButton"]["setAttribute"](tranquill_S("0x6c62272e07bb0142"), tranquill_1t ? tranquill_S("0x6c62272e07bb0142") : tranquill_S("0x6c62272e07bb0142"));
    this["startButton"]["setAttribute"](tranquill_S("0x6c62272e07bb0142"), tranquill_1t ? tranquill_S("0x6c62272e07bb0142") : tranquill_S("0x6c62272e07bb0142"));
  }
}
function tranquill_1w() {
  const tranquill_1x = new tranquill_Q(document);
  tranquill_1x["init"]()["catch"](tranquill_1y => {
    log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_1y);
  });
}
document.addEventListener(tranquill_S("0x6c62272e07bb0142"), tranquill_1w);
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}