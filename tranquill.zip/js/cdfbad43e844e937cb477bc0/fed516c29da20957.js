const tranquill_global = typeof self !== "undefined" ? self : globalThis;
if (!tranquill_global.tranquill_runtime_ready) {
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::16fd2ce4be226d9f78b1905b71de3935"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = "tranquill_tranquill_tranquill";
        tranquill_global.tranquill_runtime_ready = true;
}

(function tranquill_0() {
  const tranquill_1 = new Uint8Array([13, 170, 70, 39, 51, 155, 67, 32, 59, 153, 94, 111, 104, 153, 91, 54, 55, 155, 65, 48, 127, 158, 87, 44, 96, 190, 43, 51, 94, 143, 46, 52, 86, 141, 51, 123, 5, 145, 58, 47, 91, 136, 49, 38, 18, 149, 45, 32, 81, 146, 54, 53, 86, 142, 49, 100, 25, 51, 127, 92, 9, 127, 120, 93, 91, 103, 60, 69, 25, 97, 117, 85, 5, 51, 104, 91, 29, 103, 60, 95, 21, 112, 121, 93, 15, 118, 60, 88, 25, 106, 50, 15, 123, 152, 29, 55, 107, 212, 26, 54, 57, 204, 94, 42, 123, 217, 29, 48, 62, 204, 22, 61, 62, 212, 23, 59, 123, 214, 13, 61, 62, 203, 27, 42, 104, 221, 12, 118, 62, 232, 18, 61, 127, 203, 27, 120, 106, 202, 7, 120, 127, 223, 31, 49, 112, 150, 254, 194, 105, 164, 198, 210, 37, 163, 199, 128, 61, 231, 205, 194, 61, 162, 219, 202, 32, 169, 204, 135, 48, 168, 220, 213, 105, 163, 204, 209, 32, 164, 204, 135, 32, 163, 204, 201, 61, 174, 207, 206, 44, 181, 135, 135, 25, 171, 204, 198, 58, 162, 137, 211, 59, 190, 137, 198, 46, 166, 192, 201, 103, 149, 108, 220, 153, 160, 105, 219, 145, 162, 116, 243, 216, 162, 113, 205, 157, 160, 107, 203, 216, 163, 121, 192, 153, 169, 125, 220, 216, 187, 118, 207, 142, 175, 113, 194, 153, 172, 116, 203, 86, 50, 127, 94, 125, 19, 70, 120, 124, 9, 126, 114, 115, 25, 87, 121, 108, 142, 77, 35, 54, 140, 75, 35, 39, 159, 12, 33, 45, 138, 75, 35, 30, 141, 255, 38, 89, 143, 189, 34, 95, 143, 228, 36, 94, 149, 69, 87, 34, 56, 14, 85, 56, 62, 70, 93, 36, 41, 6, 116, 228, 94, 11, 50, 230, 68, 13, 122, 227, 82, 17, 123, 232, 220, 7, 48, 234, 198, 1, 120, 225, 199, 22, 58, 246, 167, 158, 64, 241, 236, 156, 90, 247, 164, 155, 71, 226, 252, 134, 4, 245, 251, 157, 92, 226, 136, 212, 47, 251, 195, 214, 53, 253, 139, 218, 51, 236, 210, 215, 40, 253, 133, 207, 251, 176, 157, 215, 242, 251, 159, 205, 244, 179, 130, 203, 242, 253, 148, 205, 226, 246, 85, 63, 160, 195, 80, 56, 168, 193, 77, 16, 225, 193, 78, 42, 168, 195, 1, 24, 136, 141, 72, 62, 225, 192, 72, 62, 178, 196, 79, 42, 225, 223, 68, 60, 180, 196, 83, 40, 165, 141, 68, 33, 164, 192, 68, 35, 181, 222, 160, 11, 209, 179, 186, 10, 175, 144, 150, 171, 178, 173, 1, 36, 116, 152, 4, 35, 124, 154, 25, 11, 53, 154, 26, 49, 124, 152, 85, 3, 92, 214, 28, 37, 53, 155, 28, 37, 102, 159, 27, 49, 53, 130, 29, 51, 53, 133, 0, 53, 118, 147, 6, 37, 53, 144, 16, 51, 113, 148, 20, 53, 126, 214, 16, 58, 112, 155, 16, 56, 97, 121, 14, 157, 110, 101, 30, 211, 120, 99, 14, 35, 32, 7, 95, 37, 50, 78, 90, 36, 52, 80, 151, 184, 36, 28, 135, 164, 54, 72, 73, 110, 97, 93, 5, 126, 125, 79, 81, 20, 85, 245, 34, 42, 91, 172, 48, 2, 90, 167, 52, 139, 179, 111, 58, 121, 30, 6, 60, 107, 87, 3, 61, 109, 116, 244, 125, 65, 65, 241, 122, 73, 67, 236, 82, 0, 92, 244, 96, 82, 74, 228, 47, 76, 70, 227, 106, 78, 92, 229, 47, 86, 78, 236, 102, 68, 78, 244, 102, 79, 65, 160, 105, 65, 70, 236, 106, 68, 211, 70, 218, 51, 230, 67, 221, 59, 228, 94, 245, 114, 238, 83, 193, 62, 237, 86, 136, 38, 231, 18, 193, 60, 225, 70, 193, 51, 228, 91, 210, 55, 168, 94, 199, 53, 225, 92, 136, 53, 233, 70, 205, 223, 148, 187, 171, 217, 134, 242, 174, 216, 128, 217, 46, 61, 206, 197, 62, 115, 216, 195, 46, 137, 201, 236, 174, 133, 223, 188, 91, 84, 168, 240, 75, 72, 186, 164, 237, 230, 57, 202, 212, 237, 120, 220, 215, 168, 45, 198, 212, 231, 59, 195, 152, 252, 42, 201, 214, 249, 45, 193, 212, 228, 118, 136, 232, 228, 61, 201, 203, 237, 120, 220, 202, 241, 120, 201, 223, 233, 49, 198, 150, 106, 123, 63, 86, 73, 114, 122, 82, 84, 99, 63, 69, 26, 110, 53, 66, 72, 55, 54, 94, 89, 114, 52, 68, 95, 55, 49, 82, 67, 57, 66, 241, 203, 68, 119, 244, 204, 76, 117, 233, 228, 5, 117, 236, 218, 64, 119, 246, 220, 5, 108, 235, 213, 74, 122, 238, 153, 67, 120, 236, 213, 64, 125, 17, 154, 133, 118, 40, 145, 196, 96, 43, 212, 145, 122, 40, 155, 135, 127, 100, 128, 150, 117, 42, 133, 145, 125, 40, 152, 202, 52, 20, 152, 129, 117, 55, 145, 196, 96, 54, 141, 196, 117, 35, 149, 141, 122, 106, 235, 248, 207, 7, 237, 234, 134, 2, 236, 236, 8, 111, 96, 28, 68, 127, 124, 14, 16, 233, 212, 136, 227, 229, 220, 35, 247, 205, 221, 40, 243, 68, 52, 224, 240, 119, 152, 196, 188, 103, 132, 214, 232, 247, 171, 24, 199, 245, 177, 30, 143, 242, 172, 11, 215, 239, 239, 28, 208, 244, 183, 11, 143, 182, 167, 9, 208, 244, 176, 210, 127, 125, 211, 208, 101, 123, 155, 219, 100, 108, 217, 204, 59, 51, 222, 215, 114, 122, 211, 208, 132, 56, 107, 148, 134, 34, 109, 220, 141, 35, 122, 158, 154, 124, 37, 135, 129, 34, 97, 147, 132, 52, 142, 210, 225, 190, 140, 200, 231, 246, 139, 213, 242, 174, 150, 150, 229, 169, 141, 206, 242, 246, 207, 222, 240, 169, 141, 201, 148, 200, 187, 100, 150, 210, 189, 44, 157, 211, 170, 110, 138, 140, 245, 119, 145, 210, 177, 99, 148, 196, 71, 122, 104, 86, 69, 96, 110, 30, 78, 97, 121, 92, 89, 62, 38, 91, 66, 119, 111, 86, 69, 37, 237, 13, 91, 55, 241, 12, 86, 71, 58, 142, 79, 114, 63, 137, 71, 112, 34, 161, 14, 84, 25, 181, 106, 60, 62, 147, 66, 112, 39, 146, 73, 60, 38, 153, 66, 108, 43, 142, 14, 105, 32, 157, 88, 125, 39, 144, 79, 126, 34, 153, 54, 63, 191, 10, 3, 58, 184, 2, 1, 39, 144, 75, 37, 28, 132, 47, 77, 59, 162, 7, 1, 34, 163, 12, 77, 45, 172, 2, 1, 46, 169, 247, 172, 194, 16, 242, 171, 202, 18, 239, 155, 205, 13, 246, 172, 198, 50, 234, 189, 198, 16, 240, 187, 229, 77, 87, 226, 243, 181, 215, 84, 233, 250, 158, 30, 234, 180, 137, 20, 233, 238, 137, 85, 241, 239, 148, 23, 177, 106, 4, 214, 182, 113, 17, 209, 170, 118, 203, 243, 249, 220, 221, 193, 163, 224, 222, 220, 176, 157, 79, 252, 177, 210, 6, 182, 178, 156, 17, 188, 177, 198, 17, 253, 169, 199, 12, 191, 180, 131, 16, 163, 168, 147, 94, 181, 174, 131, 183, 246, 159, 133, 251, 236, 159, 128, 178, 225, 152, 155, 228, 241, 150, 152, 110, 37, 10, 147, 127, 63, 83, 159, 105, 49, 104, 191, 140, 128, 110, 173, 197, 133, 111, 171, 152, 46, 45, 146, 159, 53, 56, 149, 131, 50, 41, 146, 136, 95, 137, 106, 117, 88, 146, 127, 114, 68, 149, 110, 117, 79]);
  const tranquill_2 = self["tranquill_PACK"] = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  tranquill_2.data["push"](tranquill_1);
  const tranquill_3 = tranquill_2.data.length - 1;
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 0,
    len: 24,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 24,
    len: 31,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 55,
    len: 36,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 91,
    len: 55,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 146,
    len: 63,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 209,
    len: 39,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 248,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 264,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 280,
    len: 14,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 294,
    len: 13,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 307,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 319,
    len: 14,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 333,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 353,
    len: 15,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 368,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 372,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 388,
    len: 49,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 437,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 443,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 448,
    len: 60,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 508,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 518,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 528,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 537,
    len: 9,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 546,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 550,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 561,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 571,
    len: 44,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 615,
    len: 43,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 658,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 668,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 678,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 684,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 684,
    len: 9,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 693,
    len: 45,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 738,
    len: 30,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 768,
    len: 33,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 801,
    len: 45,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 846,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 856,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 865,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 869,
    len: 11,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 880,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 889,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 915,
    len: 21,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 936,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 958,
    len: 26,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 984,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1006,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1027,
    len: 0,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1027,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1035,
    len: 43,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1078,
    len: 31,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1109,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1131,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1136,
    len: 19,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1155,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1165,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1170,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1176,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1195,
    len: 10,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1205,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1216,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1221,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1231,
    len: 10,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1241,
    len: 13,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1254,
    len: 13,
    kind: 1
  });
})();
(function () {
  "use strict";

  const tranquill_4 = tranquill_S("0x6c62272e07bb0142");
  const tranquill_5 = 900;
  const tranquill_6 = 600;
  const tranquill_7 = 900;
  const tranquill_8 = 320;
  const tranquill_9 = 460;
  const tranquill_a = 320;
  const tranquill_b = tranquill_S("0x6c62272e07bb0142");
  const tranquill_c = tranquill_S("0x6c62272e07bb0142");
  const tranquill_d = tranquill_S("0x6c62272e07bb0142");
  const tranquill_e = tranquill_S("0x6c62272e07bb0142");
  const tranquill_f = 250;
  const tranquill_g = 20;
  const tranquill_h = self?.log ?? console;
  const tranquill_i = self?.tranquillLicenseManager;
  const tranquill_j = tranquill_i ? new tranquill_i({
    storageKey: tranquill_4,
    logger: tranquill_h,
    chrome: self?.chrome ?? null,
    hwidResolver: tranquill_1n,
    defaultErrorMessage: tranquill_c,
    networkErrorMessage: tranquill_d,
    hwidErrorMessage: tranquill_e
  }) : null;
  if (!tranquill_j) {
    tranquill_h?.error?.(tranquill_S("0x6c62272e07bb0142"));
    return;
  }
  const tranquill_l = {
    isLoading: false,
    isUnlocked: false,
    originalButtonLabel: null
  };
  document.addEventListener(tranquill_S("0x6c62272e07bb0142"), () => {
    const tranquill_m = document.querySelector(tranquill_S("0x6c62272e07bb0142"));
    const tranquill_n = document.querySelector(tranquill_S("0x6c62272e07bb0142"));
    const tranquill_o = document["querySelector"](tranquill_S("0x6c62272e07bb0142"));
    const tranquill_p = document.querySelector(tranquill_S("0x6c62272e07bb0142"));
    const tranquill_q = document["querySelector"](tranquill_S("0x6c62272e07bb0142"));
    const tranquill_r = document.querySelector(tranquill_S("0x6c62272e07bb0142"));
    const tranquill_s = tranquill_o?.querySelector(tranquill_S("0x6c62272e07bb0142"));
    const tranquill_t = tranquill_s?.querySelector(tranquill_S("0x6c62272e07bb0142"));
    const tranquill_u = document.querySelector(tranquill_S("0x6c62272e07bb0142"));
    if (!tranquill_m || !tranquill_n || !tranquill_o || !tranquill_p || !tranquill_s || !tranquill_t) {
      tranquill_h?.warn?.(tranquill_S("0x6c62272e07bb0142"));
      return;
    }
    tranquill_l.originalButtonLabel = tranquill_t.textContent;
    tranquill_o.addEventListener(tranquill_S("0x6c62272e07bb0142"), tranquill_B => {
      tranquill_B.preventDefault();
      void tranquill_S({
        root: tranquill_m,
        container: tranquill_n,
        input: tranquill_p,
        inputGroup: tranquill_r,
        errorEl: tranquill_q,
        button: tranquill_s,
        buttonLabel: tranquill_t,
        successEl: tranquill_u
      });
    });
    tranquill_p.addEventListener(tranquill_S("0x6c62272e07bb0142"), () => {
      tranquill_1e({
        inputGroup: tranquill_r,
        errorEl: tranquill_q
      });
    });
    if (!tranquill_u) {
      tranquill_h?.warn?.(tranquill_S("0x6c62272e07bb0142"));
    }
    void tranquill_D({
      root: tranquill_m,
      container: tranquill_n,
      input: tranquill_p,
      inputGroup: tranquill_r,
      errorEl: tranquill_q,
      button: tranquill_s,
      buttonLabel: tranquill_t,
      successEl: tranquill_u
    });
  });
  async function tranquill_D({
    root: tranquill_E,
    container: tranquill_F,
    input: tranquill_G,
    inputGroup: tranquill_H,
    errorEl: tranquill_I,
    button: tranquill_J,
    buttonLabel: tranquill_K,
    successEl: tranquill_L
  }) {
    let storedLicense = null;
    try {
      storedLicense = await tranquill_j.getStoredLicenseKey();
      tranquill_F.classList.remove(tranquill_S("0x6c62272e07bb0142"));
      if (!storedLicense) {
        tranquill_F.classList.remove(tranquill_S("0x6c62272e07bb0142"));
        tranquill_l["isLoading"] = false;
        tranquill_l.isUnlocked = false;
        if (tranquill_G) {
          tranquill_G.disabled = false;
          requestAnimationFrame(() => {
            try {
              tranquill_G.focus();
            } catch (tranquill_M) {}
          });
        }
        if (tranquill_J) {
          tranquill_J.disabled = false;
          tranquill_J.removeAttribute(tranquill_S("0x6c62272e07bb0142"));
        }
        if (tranquill_K) {
          tranquill_K["textContent"] = tranquill_l.originalButtonLabel;
        }
        return;
      }
      tranquill_l.isUnlocked = false;
      tranquill_l["isLoading"] = true;
      if (tranquill_G) {
        tranquill_G["value"] = storedLicense;
        tranquill_G.disabled = true;
      }
      if (tranquill_J) {
        tranquill_J.disabled = true;
        tranquill_J.setAttribute(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      }
      if (tranquill_K) {
        tranquill_K.textContent = tranquill_S("0x6c62272e07bb0142");
      }
      tranquill_F.classList.add(tranquill_S("0x6c62272e07bb0142"));
      try {
        await tranquill_1h(storedLicense);
        tranquill_l["isUnlocked"] = true;
        await tranquill_1W();
        await tranquill_1S({
          root: tranquill_E,
          container: tranquill_F,
          successEl: tranquill_L
        });
        return;
      } catch (tranquill_N) {
        tranquill_h?.warn?.(tranquill_S("0x6c62272e07bb0142"), tranquill_N);
        throw tranquill_N;
      }
    } catch (tranquill_O) {
      tranquill_h?.warn?.(tranquill_S("0x6c62272e07bb0142"), tranquill_O);
      tranquill_F.classList.remove(tranquill_S("0x6c62272e07bb0142"));
      tranquill_F.classList.remove(tranquill_S("0x6c62272e07bb0142"));
      const tranquill_P = Boolean(tranquill_O && typeof tranquill_O === tranquill_S("0x6c62272e07bb0142") && tranquill_O.shouldClearLicense);
      if (tranquill_P) {
        await tranquill_j.clearStoredLicenseKey();
      }
      if (tranquill_G) {
        tranquill_G.disabled = false;
        if (tranquill_P) {
          tranquill_G["value"] = tranquill_S("0x6c62272e07bb0142");
        } else if (storedLicense) {
          tranquill_G.value = storedLicense;
        }
        requestAnimationFrame(() => {
          try {
            tranquill_G.focus();
          } catch (tranquill_R) {}
        });
      }
      if (tranquill_J) {
        tranquill_J.disabled = false;
        tranquill_J.removeAttribute(tranquill_S("0x6c62272e07bb0142"));
      }
      if (tranquill_K) {
        tranquill_K["textContent"] = tranquill_l.originalButtonLabel;
      }
      tranquill_l.isLoading = false;
      tranquill_l["isUnlocked"] = false;
      tranquill_1a({
        message: tranquill_O?.message || tranquill_S("0x6c62272e07bb0142"),
        inputGroup: tranquill_H,
        errorEl: tranquill_I
      });
    }
  }
  async function tranquill_S({
    root: tranquill_T,
    container: tranquill_U,
    input: tranquill_V,
    inputGroup: tranquill_W,
    errorEl: tranquill_X,
    button: tranquill_Y,
    buttonLabel: tranquill_Z,
    successEl: tranquill_10
  }) {
    if (tranquill_l.isLoading) {
      return;
    }
    const tranquill_11 = tranquill_V.value.trim();
    if (!tranquill_11) {
      tranquill_1a({
        message: tranquill_S("0x6c62272e07bb0142"),
        inputGroup: tranquill_W,
        errorEl: tranquill_X
      });
      return;
    }
    tranquill_1e({
      inputGroup: tranquill_W,
      errorEl: tranquill_X
    });
    tranquill_14({
      container: tranquill_U,
      button: tranquill_Y,
      buttonLabel: tranquill_Z,
      input: tranquill_V,
      isLoading: true
    });
    try {
      await tranquill_1h(tranquill_11);
      await tranquill_j.persistLicenseKey(tranquill_11);
      await tranquill_1r();
      tranquill_l.isUnlocked = true;
      await tranquill_1W();
      await tranquill_1S({
        root: tranquill_T,
        container: tranquill_U,
        successEl: tranquill_10
      });
    } catch (tranquill_13) {
      tranquill_h?.warn?.(tranquill_S("0x6c62272e07bb0142"), tranquill_13?.message || tranquill_13);
      tranquill_l["isUnlocked"] = false;
      tranquill_1a({
        message: tranquill_13?.message || tranquill_S("0x6c62272e07bb0142"),
        inputGroup: tranquill_W,
        errorEl: tranquill_X
      });
    } finally {
      if (!tranquill_l.isUnlocked) {
        tranquill_14({
          container: tranquill_U,
          button: tranquill_Y,
          buttonLabel: tranquill_Z,
          input: tranquill_V,
          isLoading: false
        });
      }
    }
  }
  function tranquill_14({
    container: tranquill_15,
    button: tranquill_16,
    buttonLabel: tranquill_17,
    input: tranquill_18,
    isLoading: tranquill_19
  }) {
    tranquill_l.isLoading = tranquill_19;
    tranquill_15.classList.toggle(tranquill_S("0x6c62272e07bb0142"), tranquill_19);
    tranquill_16.disabled = Boolean(tranquill_19);
    tranquill_18.disabled = Boolean(tranquill_19);
    if (tranquill_19) {
      tranquill_16.setAttribute(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      tranquill_17.textContent = tranquill_S("0x6c62272e07bb0142");
    } else {
      tranquill_16.removeAttribute(tranquill_S("0x6c62272e07bb0142"));
      tranquill_17.textContent = tranquill_l.originalButtonLabel;
    }
  }
  function tranquill_1a({
    message: tranquill_1b,
    inputGroup: tranquill_1c,
    errorEl: tranquill_1d
  }) {
    if (tranquill_1c) {
      tranquill_1c["classList"].add(tranquill_S("0x6c62272e07bb0142"));
    }
    if (tranquill_1d) {
      tranquill_1d.classList.replace(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      tranquill_1d.textContent = tranquill_1b;
    }
  }
  function tranquill_1e({
    inputGroup: tranquill_1f,
    errorEl: tranquill_1g
  }) {
    if (tranquill_1f) {
      tranquill_1f.classList["remove"](tranquill_S("0x6c62272e07bb0142"));
    }
    if (tranquill_1g) {
      tranquill_1g.classList.replace(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      tranquill_1g.textContent = tranquill_S("0x6c62272e07bb0142");
    }
  }
  async function tranquill_1h(tranquill_1i) {
    const tranquill_1j = tranquill_1i.trim();
    const tranquill_1k = tranquill_5 + Math["floor"](Math.random() * tranquill_6);
    const tranquill_1l = tranquill_1I(tranquill_1k);
    try {
      await tranquill_j["validateLicenseKey"](tranquill_1j);
      return true;
    } catch (tranquill_1m) {
      if (tranquill_1m instanceof Error) {
        throw tranquill_1m;
      }
      throw new Error(tranquill_c);
    } finally {
      await tranquill_1l;
    }
  }
  function tranquill_1n() {
    const tranquill_1o = window?.tranquillPollHWID;
    if (typeof tranquill_1o !== tranquill_S("0x6c62272e07bb0142")) {
      tranquill_h?.warn?.(tranquill_S("0x6c62272e07bb0142"));
      return Promise.resolve(null);
    }
    return tranquill_1o({
      interval: tranquill_f,
      attempts: tranquill_g
    }).catch(tranquill_1q => {
      tranquill_h?.warn?.(tranquill_S("0x6c62272e07bb0142"), tranquill_1q);
      return null;
    });
  }
  function tranquill_1r() {
    return new Promise(tranquill_1s => {
      if (!chrome?.runtime?.sendMessage) {
        tranquill_1s();
        return;
      }
      try {
        chrome.runtime.sendMessage({
          action: tranquill_S("0x6c62272e07bb0142")
        }, () => tranquill_1s());
      } catch (tranquill_1t) {
        tranquill_1s();
      }
    });
  }
  async function tranquill_1u() {
    tranquill_1y(tranquill_S("0x6c62272e07bb0142"));
    try {
      await tranquill_1F();
    } catch (tranquill_1v) {}
    await tranquill_1I(250);
    const tranquill_1w = new URL(tranquill_S("0x6c62272e07bb0142"), window.location.href);
    tranquill_1w.searchParams.set(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
    try {
      window.location.replace(tranquill_1w["toString"]());
    } catch (tranquill_1x) {
      window.location.href = tranquill_1w.toString();
    }
  }
  function tranquill_1y(tranquill_1z) {
    if (typeof tranquill_1z !== tranquill_S("0x6c62272e07bb0142")) {
      return;
    }
    const tranquill_1B = tranquill_1z.trim();
    if (!tranquill_1B) {
      return;
    }
    try {
      const tranquill_1D = window?.sessionStorage;
      tranquill_1D?.setItem?.(tranquill_b, tranquill_1B);
    } catch (tranquill_1E) {}
  }
  function tranquill_1F() {
    if (!chrome?.action?.setPopup) {
      return Promise.resolve();
    }
    return new Promise(tranquill_1G => {
      try {
        chrome.action["setPopup"]({
          popup: tranquill_S("0x6c62272e07bb0142")
        }, () => tranquill_1G());
      } catch (tranquill_1H) {
        tranquill_1G();
      }
    });
  }
  function tranquill_1I(tranquill_1J) {
    return new Promise(tranquill_1K => {
      setTimeout(tranquill_1K, tranquill_1J);
    });
  }
  function tranquill_1L({
    container: tranquill_1M,
    successEl: tranquill_1N
  }) {
    if (!tranquill_1M) {
      return Promise.resolve();
    }
    tranquill_1M.classList["add"](tranquill_S("0x6c62272e07bb0142"));
    if (tranquill_1N) {
      tranquill_1N.setAttribute(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
    }
    return tranquill_1X(tranquill_1M, tranquill_8);
  }
  function tranquill_1P(tranquill_1Q) {
    if (!tranquill_1Q) {
      return Promise.resolve();
    }
    tranquill_1Q.classList.add(tranquill_S("0x6c62272e07bb0142"));
    return tranquill_1X(tranquill_1Q, tranquill_9);
  }
  async function tranquill_1S({
    root: tranquill_1T,
    container: tranquill_1U,
    successEl: tranquill_1V
  }) {
    if (tranquill_1U) {
      tranquill_1U["classList"].remove(tranquill_S("0x6c62272e07bb0142"));
    }
    await tranquill_1L({
      container: tranquill_1U,
      successEl: tranquill_1V
    });
    await tranquill_1I(tranquill_7);
    await tranquill_1P(tranquill_1T);
    await tranquill_1u();
  }
  function tranquill_1W() {
    return tranquill_1I(tranquill_a);
  }
  function tranquill_1X(tranquill_1Y, tranquill_1Z) {
    return new Promise(tranquill_20 => {
      if (!tranquill_1Y) {
        tranquill_20();
        return;
      }
      let resolved = false;
      const tranquill_22 = () => {
        if (resolved) {
          return;
        }
        resolved = true;
        tranquill_1Y["removeEventListener"](tranquill_S("0x6c62272e07bb0142"), tranquill_22);
        tranquill_20();
      };
      tranquill_1Y.addEventListener(tranquill_S("0x6c62272e07bb0142"), tranquill_22);
      const tranquill_23 = Number.isFinite(tranquill_1Z) ? tranquill_1Z : 400;
      setTimeout(tranquill_22, tranquill_23);
    });
  }
})();
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}