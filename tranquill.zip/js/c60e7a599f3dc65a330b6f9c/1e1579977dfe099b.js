const tranquill_global = typeof self !== "undefined" ? self : globalThis;
if (!tranquill_global.tranquill_runtime_ready) {
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::cd312c1cae0d84219e6e1a7a094b17ad"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = "tranquill_tranquill_tranquill";
        tranquill_global.tranquill_runtime_ready = true;
}

(function tranquill_0() {
  const tranquill_1 = new Uint8Array([87, 212, 255, 171, 19, 19, 179, 165, 84, 223, 236, 172, 23, 8, 254, 228, 75, 206, 251, 164, 3, 5, 254, 236, 73, 213, 234, 172, 6, 16, 183, 255, 66, 216, 190, 172, 9, 92, 184, 247, 70, 209, 251, 148, 191, 76, 240, 80, 120, 128, 29, 139, 185, 89, 251, 74, 99, 191, 59, 133, 179, 84, 145, 42, 137, 165, 85, 109, 69, 171, 130, 45, 134, 191, 68, 108, 92, 171, 146, 33, 154, 162, 81, 118, 8, 226, 143, 43, 156, 162, 64, 110, 65, 241, 136, 44, 143, 159, 132, 93, 102, 82, 1, 135, 184, 177, 205, 93, 107, 75, 6, 142, 172, 86, 254, 239, 39, 163, 40, 72, 96, 101, 45, 189, 182, 104, 235, 250, 55, 164, 61, 242, 11, 8, 81, 175, 216, 8, 129, 118, 87, 213, 82, 6, 15, 12, 45, 219, 220, 229, 111, 210, 38, 176, 109, 22, 113, 253, 45, 223, 61, 170, 41, 20, 122, 227, 45, 200, 36, 160, 44, 9, 113, 224, 37, 232, 239, 74, 248, 59, 35, 102, 117, 96, 254, 181, 57, 252, 227, 102, 228, 47, 183, 138, 137, 156, 234, 89, 165, 30, 148, 113, 240, 247, 94, 58, 216, 224, 175, 137, 13, 150, 249, 75, 208, 236, 167, 163, 56, 167, 126, 224, 125, 174, 38, 170, 121, 189, 119, 235, 125, 174, 51, 167, 54, 188, 102, 165, 116, 235, 33, 182, 56, 169, 119, 253, 79, 58, 150, 40, 205, 254, 65, 229, 13, 37, 150, 57, 158, 230, 65, 248, 158, 32, 25, 201, 75, 103, 149, 160, 204, 50, 26, 228, 27, 127, 218, 191, 204, 35, 68, 252, 27, 98, 143, 212, 90, 223, 90, 61, 144, 20, 144, 198, 135, 239, 69, 68, 67, 56, 136, 132, 132, 242, 80, 0, 8, 59, 144, 205, 132, 248, 85, 188, 11, 137, 192, 105, 137, 77, 23, 164, 73, 138, 221, 124, 205, 6, 6, 181, 27, 131, 197, 84, 210, 98, 229, 148, 93, 146, 131, 2, 145, 68, 43, 8, 126, 3, 126, 138, 58, 212, 51, 74, 114, 25, 107, 196, 54, 212, 106, 2, 112, 31, 110, 198, 56, 223, 45, 74, 119, 16, 99, 198, 52, 213, 114, 55, 117, 33, 189, 253, 172, 244, 117, 229, 99, 210, 74, 176, 244, 213, 167, 34, 190, 21, 243, 106, 252, 219, 233, 51, 186, 29, 231, 119, 253, 209, 233, 49, 183, 13, 252, 102, 225, 200, 31, 116, 135, 123, 219, 179, 75, 245, 28, 104, 135, 97, 202, 252, 84, 176, 28, 121, 146, 21, 26, 111, 70, 212, 202, 172, 133, 15, 0, 113, 22, 210, 198, 178, 147, 20, 79, 122, 78, 214, 198, 173, 147, 2, 195, 145, 83, 100, 24, 77, 138, 207, 186, 5, 118, 14, 234, 198, 53, 213, 160, 27, 43, 25, 247, 197, 47, 206, 170, 17, 206, 214, 26, 120, 27, 151, 198, 10, 203, 193, 0, 126, 94, 151, 222, 50, 206, 212, 16, 127, 69, 196, 197, 51, 223, 202, 1, 116, 19, 196, 220, 53, 223, 199, 1, 114, 8, 129, 103, 202, 241, 162, 50, 11, 173, 208, 98, 221, 235, 164, 119, 15, 191, 232, 99, 209, 240, 166, 119, 30, 177, 243, 55, 217, 253, 181, 62, 14, 187, 161, 101, 221, 239, 180, 50, 11, 170, 174, 157, 248, 197, 123, 92, 36, 55, 171, 138, 226, 195, 62, 70, 51, 10, 187, 55, 17, 185, 241, 114, 204, 233, 169, 58, 22, 173, 161, 99, 208, 235, 175, 39, 23, 167, 161, 103, 202, 227, 166, 52, 29, 184, 51, 75, 173, 2, 119, 140, 225, 140, 55, 81, 165, 11, 100, 134, 254, 140, 37, 66, 160, 0, 97, 130, 239, 199, 99, 87, 165, 1, 102, 140, 249, 216, 112, 98, 160, 55, 171, 190, 121, 248, 206, 42, 84, 171, 25, 113, 222, 234, 221, 42, 95, 191, 29, 101, 150, 6, 220, 204, 85, 194, 27, 0, 175, 4, 221, 202, 92, 211, 6, 30, 67, 70, 69, 221, 134, 207, 157, 23, 2, 92, 76, 214, 134, 207, 153, 16, 67, 65, 93, 215, 143, 207, 157, 10, 75, 72, 78, 221, 144, 166, 12, 72, 152, 241, 180, 166, 46, 104, 170, 238, 101, 63, 180, 162, 39, 105, 244, 206, 140, 157, 5, 31, 78, 85, 211, 236, 130, 196, 144, 27, 194, 104, 73, 163, 22, 185, 204, 102, 219, 124, 66, 162, 28, 176, 204, 98, 193, 116, 75, 177, 22, 175, 208, 234, 168, 185, 33, 59, 106, 113, 247, 127, 174, 57, 166, 41, 235, 123, 238, 62, 177, 44, 167, 42, 234, 112, 253, 119, 161, 117, 171, 63, 225, 126, 250, 110, 163, 54, 172, 155, 222, 221, 216, 70, 13, 151, 76, 65, 200, 65, 137, 131, 0, 214, 83, 84, 201, 66, 136, 136, 19, 159, 67, 13, 204, 83, 153, 137, 8, 129, 78, 143, 245, 183, 230, 126, 36, 117, 46, 168, 44, 164, 250, 23, 104, 228, 179, 152, 47, 180, 242, 13, 123, 229, 247, 204, 44, 168, 240, 31, 123, 243, 247, 220, 43, 164, 183, 12, 113, 161, 181, 217, 61, 170, 228, 8, 127, 226, 178, 94, 1, 90, 57, 132, 202, 147, 189, 93, 12, 85, 51, 153, 203, 153, 189, 79, 5, 87, 54, 158, 212, 149, 254, 72, 253, 149, 231, 88, 185, 82, 171, 180, 236, 158, 237, 69, 189, 92, 165, 147, 237, 106, 211, 59, 182, 40, 25, 52, 246, 104, 205, 49, 165, 57, 20, 122, 227, 45, 214, 49, 189, 41, 18, 99, 234, 37, 232, 239, 74, 248, 59, 52, 119, 107, 108, 228, 183, 57, 252, 227, 102, 228, 47, 203, 163, 83, 112, 97, 248, 137, 19, 37, 184, 92, 100, 118, 235, 141, 43, 210, 130, 65, 144, 9, 88, 190, 92, 213, 137, 112, 135, 30, 77, 153, 214, 167, 44, 123, 0, 226, 110, 51, 151, 169, 37, 114, 24, 249, 101, 61, 217, 187, 53, 96, 229, 246, 161, 162, 62, 42, 123, 127, 245, 230, 145, 236, 157, 39, 65, 47, 94, 252, 139, 242, 192, 48, 73, 44, 89, 236, 107, 17, 125, 165, 34, 212, 60, 225, 41, 31, 119, 160, 38, 207, 55, 239, 103, 13, 103, 178, 140, 63, 54, 243, 64, 233, 144, 179, 120, 204, 84, 116, 180, 50, 137, 181, 126, 145, 75, 57, 194, 74, 152, 255, 3, 195, 94, 50, 198, 77, 154, 245, 10, 195, 94, 51, 201, 68, 59, 83, 165, 26, 127, 148, 233, 231, 46, 79, 133, 23, 127, 146, 242, 209, 59, 67, 165, 10, 127, 132, 233, 132, 42, 72, 176, 13, 125, 138, 240, 205, 36, 69, 228, 23, 127, 138, 240, 193, 107, 72, 172, 5, 101, 140, 225, 192, 110, 91, 54, 4, 170, 156, 250, 249, 103, 93, 35, 2, 187, 135, 254, 201, 77, 71, 54, 24, 170, 225, 92, 62, 65, 164, 151, 120, 141, 241, 86, 123, 73, 188, 147, 117, 141, 251, 95, 123, 74, 173, 156, 111, 145, 241, 70, 50, 90, 244, 129, 111, 152, 230, 70, 37, 232, 239, 74, 248, 59, 35, 102, 117, 96, 254, 181, 19, 222, 139, 65, 215, 25, 71, 207, 16, 207, 132, 91, 203, 19, 94, 134, 0, 150, 143, 65, 199, 86, 94, 134, 14, 211, 133, 90, 215, 216, 218, 8, 143, 3, 6, 209, 196, 243, 80, 103, 31, 175, 138, 58, 212, 167, 91, 125, 19, 231, 147, 58, 196, 249, 87, 125, 16, 206, 172, 75, 109, 31, 251, 141, 44, 143, 191, 64, 105, 1, 251, 135, 37, 143, 188, 81, 102, 27, 231, 141, 60, 198, 172, 8, 123, 27, 238, 154, 60, 140, 103, 84, 168, 72, 32, 152, 213, 133, 97, 65, 174, 89, 59, 156, 229, 185, 97, 81, 137, 50, 214, 171, 76, 121, 16, 231, 153, 56, 147, 163, 84, 125, 29, 231, 147, 49, 147, 160, 69, 114, 7, 251, 153, 40, 218, 176, 28, 121, 29, 247, 32, 149, 215, 243, 111, 95, 14, 166, 39, 77, 50, 233, 246, 150, 110, 179, 171, 93, 102, 226, 236, 154, 77, 252, 37, 227, 137, 187, 105, 158, 68, 250, 48, 229, 152, 160, 109, 174, 127, 245, 39, 230, 142, 164, 101, 174, 88, 76, 191, 75, 227, 137, 173, 149, 191, 67, 185, 78, 227, 153, 228, 133, 230, 79, 172, 69, 237, 158, 253, 135, 165, 72, 237, 81, 239, 131, 233, 137, 177, 240, 125, 216, 34, 180, 58, 20, 95, 249, 123, 205, 36, 165, 33, 16, 111, 193, 119, 214, 62, 180, 3, 182, 216, 39, 198, 253, 30, 107, 19, 188, 157, 47, 222, 249, 19, 107, 25, 181, 157, 44, 207, 246, 9, 119, 19, 172, 212, 60, 150, 249, 31, 112, 4, 172, 189, 108, 181, 147, 249, 43, 249, 29, 190, 125, 186, 137, 229, 33, 224, 84, 174, 36, 181, 159, 226, 54, 224, 88, 169, 193, 71, 54, 174, 20, 210, 31, 198, 171, 9, 195, 28, 118, 194, 75, 201, 189, 14, 212, 28, 225, 96, 170, 168, 37, 178, 125, 101, 217, 24, 170, 53, 25, 215, 235, 119, 201, 10, 99, 111, 253, 174, 39, 40, 177, 160, 112, 104, 242, 180, 54, 41, 168, 160, 96, 100, 238, 169, 35, 51, 252, 242, 118, 102, 248, 185, 152, 179, 64, 252, 92, 116, 140, 17, 135, 181, 85, 247, 70, 111, 179, 55, 137, 191, 88]);
  const tranquill_2 = self.tranquill_PACK = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  tranquill_2["data"].push(tranquill_1);
  const tranquill_3 = tranquill_2.data["length"] - 1;
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 0,
    len: 43,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 43,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 62,
    len: 35,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 97,
    len: 2,
    kind: 2
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 99,
    len: 14,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 113,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 119,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 125,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 131,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 137,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 143,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 149,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 174,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 180,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 180,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 186,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 186,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 192,
    len: 0,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 192,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 198,
    len: 0,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 198,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 206,
    len: 11,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 217,
    len: 28,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 245,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 262,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 267,
    len: 17,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 284,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 292,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 313,
    len: 20,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 333,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 338,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 344,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 376,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 385,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 390,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 416,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 435,
    len: 25,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 460,
    len: 7,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 467,
    len: 19,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 486,
    len: 38,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 524,
    len: 39,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 563,
    len: 17,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 580,
    len: 27,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 607,
    len: 32,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 639,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 646,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 662,
    len: 14,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 676,
    len: 30,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 706,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 711,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 723,
    len: 9,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 732,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 737,
    len: 22,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 759,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 768,
    len: 28,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 796,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 802,
    len: 26,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 828,
    len: 9,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 837,
    len: 39,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 876,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 901,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 917,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 942,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 948,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 954,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 960,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 961,
    len: 15,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 976,
    len: 15,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 991,
    len: 20,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1011,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1020,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1037,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1057,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1063,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1074,
    len: 21,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1095,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1111,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1143,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1164,
    len: 34,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1198,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1204,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1210,
    len: 29,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1239,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1246,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1267,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1299,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1318,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1350,
    len: 9,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1359,
    len: 13,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1372,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1397,
    len: 32,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1429,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1450,
    len: 34,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1484,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1509,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1514,
    len: 15,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1529,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1536,
    len: 11,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1547,
    len: 28,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1575,
    len: 19,
    kind: 1
  });
})();
(() => {
  if (window.__tranquillPhantomInitialized) {
    log.debug(tranquill_S("0x6c62272e07bb0142"));
    chrome.runtime?.sendMessage?.({
      action: tranquill_S("0x6c62272e07bb0142")
    });
    return;
  }
  window.__tranquillPhantomInitialized = true;
  log["info"](tranquill_S("0x6c62272e07bb0142"));
  const tranquill_4 = 320;
  const tranquill_5 = 200;
  const tranquill_6 = tranquill_RN("0x6c62272e07bb0142");
  const tranquill_7 = 480;
  const tranquill_8 = 600;
  const tranquill_9 = tranquill_S("0x6c62272e07bb0142");
  const tranquill_a = Object.freeze({
    key: tranquill_S("0x6c62272e07bb0142"),
    code: tranquill_S("0x6c62272e07bb0142"),
    altKey: false,
    ctrlKey: false,
    metaKey: false,
    shiftKey: false
  });
  let abortBinding = {
    ...tranquill_a
  };
  let isActive = false;
  let suppressionTimer = null;
  let suppressionActive = false;
  let currentSyntheticCharacter = null;
  let activeRequest = null;
  let tranquill_b = 0;
  const tranquill_c = [];
  let allowSyntheticBackspace = false;
  let syntheticBackspaceTimer = null;
  const tranquill_d = {
    enqueued: 0,
    completed: 0,
    backspaces: 0,
    aborted: 0
  };
  const tranquill_e = tranquill_f => {
    if (tranquill_f && typeof tranquill_f === tranquill_S("0x6c62272e07bb0142")) {
      const tranquill_h = typeof tranquill_f["key"] === tranquill_S("0x6c62272e07bb0142") && tranquill_f["key"].length > 0 ? tranquill_f.key : tranquill_a.key;
      const tranquill_i = typeof tranquill_f.code === tranquill_S("0x6c62272e07bb0142") && tranquill_f["code"].length > 0 ? tranquill_f.code : tranquill_h;
      return {
        key: tranquill_h,
        code: tranquill_i,
        altKey: tranquill_f["altKey"] === true,
        ctrlKey: tranquill_f.ctrlKey === true,
        metaKey: tranquill_f.metaKey === true,
        shiftKey: tranquill_f.shiftKey === true
      };
    }
    if (typeof tranquill_f === tranquill_S("0x6c62272e07bb0142") && tranquill_f.trim().length > 0) {
      const tranquill_k = tranquill_f.trim();
      return {
        key: tranquill_k,
        code: tranquill_k,
        altKey: false,
        ctrlKey: false,
        metaKey: false,
        shiftKey: false
      };
    }
    return {
      ...tranquill_a
    };
  };
  const tranquill_l = tranquill_m => {
    abortBinding = tranquill_e(tranquill_m);
    log.debug(tranquill_S("0x6c62272e07bb0142"), abortBinding);
  };
  const tranquill_n = tranquill_o => {
    if (!tranquill_o || !abortBinding) return false;
    const tranquill_q = typeof tranquill_o.code === tranquill_S("0x6c62272e07bb0142") ? tranquill_o.code : tranquill_S("0x6c62272e07bb0142");
    const tranquill_r = typeof tranquill_o.key === tranquill_S("0x6c62272e07bb0142") ? tranquill_o.key : tranquill_S("0x6c62272e07bb0142");
    const tranquill_s = typeof abortBinding.code === tranquill_S("0x6c62272e07bb0142") && abortBinding.code["length"] > 0 ? abortBinding.code : tranquill_S("0x6c62272e07bb0142");
    const tranquill_t = typeof abortBinding.key === tranquill_S("0x6c62272e07bb0142") && abortBinding["key"].length > 0 ? abortBinding["key"] : tranquill_S("0x6c62272e07bb0142");
    const tranquill_u = tranquill_s ? tranquill_s === tranquill_q : tranquill_t === tranquill_r;
    if (!tranquill_u) return false;
    return tranquill_o.altKey === Boolean(abortBinding.altKey) && tranquill_o.ctrlKey === Boolean(abortBinding.ctrlKey) && tranquill_o.metaKey === Boolean(abortBinding.metaKey) && tranquill_o.shiftKey === Boolean(abortBinding["shiftKey"]);
  };
  const tranquill_w = (tranquill_x = tranquill_S("0x6c62272e07bb0142")) => {
    try {
      chrome.runtime?.sendMessage?.({
        action: tranquill_S("0x6c62272e07bb0142"),
        reason: tranquill_x
      });
    } catch (tranquill_y) {
      log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_y);
    }
  };
  const tranquill_z = tranquill_A => {
    if (!tranquill_n(tranquill_A)) return false;
    if (tranquill_A.repeat) return true;
    log.info(tranquill_S("0x6c62272e07bb0142"), {
      key: tranquill_A.key ?? null,
      code: tranquill_A["code"] ?? null,
      isActive
    });
    tranquill_c["length"] = 0;
    if (isActive) {
      tranquill_P(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      tranquill_T();
    }
    tranquill_w(tranquill_S("0x6c62272e07bb0142"));
    return true;
  };
  const tranquill_B = () => {
    try {
      chrome.storage?.local?.get?.(tranquill_9, tranquill_C => {
        const tranquill_D = chrome.runtime?.lastError ?? null;
        if (tranquill_D) {
          log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_D);
          tranquill_l(tranquill_a);
          return;
        }
        const tranquill_E = tranquill_C?.[tranquill_9] ?? null;
        tranquill_l(tranquill_E?.abortKey);
      });
    } catch (tranquill_F) {
      log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_F);
      tranquill_l(tranquill_a);
    }
  };
  tranquill_B();
  chrome["storage"]?.onChanged?.addListener?.((tranquill_G, tranquill_H) => {
    if (tranquill_H !== tranquill_S("0x6c62272e07bb0142")) return;
    if (!tranquill_G || typeof tranquill_G !== tranquill_S("0x6c62272e07bb0142")) return;
    const tranquill_K = tranquill_G[tranquill_9];
    if (!tranquill_K) return;
    try {
      tranquill_l(tranquill_K["newValue"]?.abortKey);
    } catch (tranquill_M) {
      log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_M);
    }
  });
  const tranquill_N = () => {
    if (suppressionTimer !== null) {
      clearTimeout(suppressionTimer);
      suppressionTimer = null;
    }
  };
  const tranquill_O = () => {
    if (syntheticBackspaceTimer !== null) {
      clearTimeout(syntheticBackspaceTimer);
      syntheticBackspaceTimer = null;
    }
    allowSyntheticBackspace = false;
  };
  const tranquill_P = (tranquill_Q, tranquill_R) => {
    if (activeRequest?.fallbackTimer) {
      clearTimeout(activeRequest.fallbackTimer);
      activeRequest["fallbackTimer"] = null;
    }
    const tranquill_S = activeRequest ? activeRequest.id : null;
    tranquill_N();
    suppressionActive = false;
    currentSyntheticCharacter = null;
    tranquill_O();
    if (activeRequest && tranquill_Q === tranquill_S("0x6c62272e07bb0142")) tranquill_d.completed += 1;
    if (tranquill_Q === tranquill_S("0x6c62272e07bb0142")) tranquill_d.aborted += 1;
    log["debug"](tranquill_S("0x6c62272e07bb0142"), {
      requestId: tranquill_S,
      status: tranquill_Q,
      reason: tranquill_R,
      queueLength: tranquill_c.length
    });
    activeRequest = null;
    tranquill_Y();
  };
  const tranquill_T = () => {
    tranquill_c["length"] = 0;
    activeRequest = null;
    tranquill_N();
    suppressionActive = false;
    currentSyntheticCharacter = null;
    tranquill_O();
    log["debug"](tranquill_S("0x6c62272e07bb0142"));
  };
  const tranquill_U = (tranquill_V, tranquill_W) => {
    const tranquill_X = Number.isFinite(tranquill_V) && tranquill_V > 0 ? tranquill_V : tranquill_4;
    tranquill_N();
    suppressionActive = true;
    suppressionTimer = window["setTimeout"](() => {
      suppressionTimer = null;
      suppressionActive = false;
      log.warn(tranquill_S("0x6c62272e07bb0142"), {
        requestId: tranquill_W ?? null,
        queueLength: tranquill_c["length"]
      });
      tranquill_P(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
    }, tranquill_X + tranquill_5);
  };
  const tranquill_Y = () => {
    if (!isActive) {
      log.debug(tranquill_S("0x6c62272e07bb0142"));
      return;
    }
    if (activeRequest) {
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        requestId: activeRequest["id"],
        queueLength: tranquill_c["length"]
      });
      return;
    }
    if (tranquill_c["length"] === 0) {
      log["debug"](tranquill_S("0x6c62272e07bb0142"));
      return;
    }
    const tranquill_Z = tranquill_c.shift();
    activeRequest = tranquill_Z;
    tranquill_U(tranquill_4, tranquill_Z.id);
    tranquill_d.enqueued += 1;
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      requestId: tranquill_Z["id"],
      queueLength: tranquill_c["length"]
    });
    tranquill_Z.fallbackTimer = window.setTimeout(() => {
      log.warn(tranquill_S("0x6c62272e07bb0142"), {
        requestId: tranquill_Z.id
      });
      tranquill_P(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
    }, tranquill_6);
    try {
      chrome.runtime?.sendMessage?.({
        action: tranquill_S("0x6c62272e07bb0142"),
        requestId: tranquill_Z["id"],
        key: tranquill_Z.key,
        timeStamp: tranquill_Z.timeStamp
      });
    } catch (tranquill_10) {
      log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_10);
      tranquill_P(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
    }
  };
  const tranquill_11 = tranquill_12 => {
    if (!isActive) return false;
    if (tranquill_12.isComposing) return false;
    if (tranquill_12["ctrlKey"] || tranquill_12.metaKey || tranquill_12.altKey) return false;
    if (tranquill_12["key"] === tranquill_S("0x6c62272e07bb0142")) return true;
    if (tranquill_12.key["length"] === 1) return true;
    if (tranquill_12["key"] === tranquill_S("0x6c62272e07bb0142")) return true;
    return false;
  };
  const tranquill_13 = tranquill_14 => {
    const tranquill_15 = {
      id: ++tranquill_b,
      key: tranquill_14.key,
      timeStamp: tranquill_14.timeStamp ?? null,
      createdAt: Date.now(),
      expectedKeys: [],
      fallbackTimer: null
    };
    tranquill_c.push(tranquill_15);
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      requestId: tranquill_15.id,
      queueLength: tranquill_c["length"],
      suppressionActive,
      activeRequest: activeRequest ? activeRequest.id : null
    });
    tranquill_Y();
  };
  const tranquill_17 = tranquill_18 => {
    if (tranquill_z(tranquill_18)) return;
    if (!tranquill_11(tranquill_18)) return;
    if (allowSyntheticBackspace && tranquill_18["key"] === tranquill_S("0x6c62272e07bb0142")) {
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        queueLength: tranquill_c["length"]
      });
      tranquill_O();
      return;
    }
    if (activeRequest?.expectedKeys?.length) {
      const tranquill_19 = activeRequest["expectedKeys"][0];
      if (typeof tranquill_19 === tranquill_S("0x6c62272e07bb0142") && tranquill_18.key === tranquill_19) {
        activeRequest.expectedKeys.shift();
        log["debug"](tranquill_S("0x6c62272e07bb0142"), {
          requestId: activeRequest.id,
          key: tranquill_18.key,
          remaining: activeRequest["expectedKeys"].length
        });
        return;
      }
    }
    if (tranquill_18.key === tranquill_S("0x6c62272e07bb0142")) {
      tranquill_18.preventDefault();
      tranquill_18.stopImmediatePropagation?.();
      tranquill_18.stopPropagation();
      if (tranquill_c.length > 0) {
        const tranquill_1b = tranquill_c.pop();
        log.debug(tranquill_S("0x6c62272e07bb0142"), {
          removedRequest: tranquill_1b?.id ?? null,
          queueLength: tranquill_c.length
        });
        return;
      }
      tranquill_d.backspaces += 1;
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        activeRequest: activeRequest ? activeRequest["id"] : null
      });
      chrome.runtime?.sendMessage?.({
        action: tranquill_S("0x6c62272e07bb0142")
      });
      return;
    }
    if (tranquill_18["repeat"]) {
      tranquill_18["preventDefault"]();
      tranquill_18.stopImmediatePropagation?.();
      tranquill_18.stopPropagation();
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        key: tranquill_18["key"]
      });
      return;
    }
    tranquill_18.preventDefault();
    tranquill_18.stopImmediatePropagation?.();
    tranquill_18.stopPropagation();
    tranquill_13(tranquill_18);
  };
  const tranquill_1c = tranquill_1d => {
    if (!isActive || tranquill_1d["isComposing"]) return;
    if (typeof tranquill_1d.inputType === tranquill_S("0x6c62272e07bb0142") && tranquill_1d["inputType"].startsWith(tranquill_S("0x6c62272e07bb0142"))) return;
    const tranquill_1e = (() => {
      if (typeof tranquill_1d["data"] === tranquill_S("0x6c62272e07bb0142") && tranquill_1d.data.length > 0) {
        return tranquill_1d.data === currentSyntheticCharacter;
      }
      if (currentSyntheticCharacter === tranquill_S("0x6c62272e07bb0142")) {
        return tranquill_1d.inputType === tranquill_S("0x6c62272e07bb0142") || tranquill_1d["inputType"] === tranquill_S("0x6c62272e07bb0142");
      }
      return false;
    })();
    const tranquill_1f = suppressionActive && !activeRequest && tranquill_c.length === 0 && currentSyntheticCharacter === null;
    if (tranquill_1e || tranquill_1f) {
      let _tranquill_cond = activeRequest;
      if (_tranquill_cond) {
        activeRequest["id"];
      } else {
        null;
      }
      log["debug"](tranquill_S("0x6c62272e07bb0142"), {
        reason: tranquill_1e ? tranquill_S("0x6c62272e07bb0142") : tranquill_S("0x6c62272e07bb0142"),
        inputType: tranquill_1d["inputType"],
        requestId: _tranquill_cond
      });
      currentSyntheticCharacter = null;
      return;
    }
    let _tranquill_cond2 = activeRequest;
    if (_tranquill_cond2) {
      activeRequest.id;
    } else {
      null;
    }
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      inputType: tranquill_1d.inputType,
      data: tranquill_1d.data,
      suppressionActive,
      activeRequest: _tranquill_cond2
    });
    tranquill_1d.preventDefault();
    tranquill_1d["stopImmediatePropagation"]?.();
    tranquill_1d.stopPropagation();
  };
  chrome.runtime.onMessage["addListener"]((tranquill_1g, tranquill_1h, tranquill_1i) => {
    if (!tranquill_1g || typeof tranquill_1g !== tranquill_S("0x6c62272e07bb0142")) {
      tranquill_1i?.({
        success: false
      });
      return false;
    }
    if (tranquill_1g.action === tranquill_S("0x6c62272e07bb0142")) {
      log.debug(tranquill_S("0x6c62272e07bb0142"));
      tranquill_1i?.({
        success: true,
        pong: true
      });
      return false;
    }
    if (tranquill_1g.action === tranquill_S("0x6c62272e07bb0142")) {
      isActive = !!tranquill_1g.active;
      log["info"](tranquill_S("0x6c62272e07bb0142"), {
        isActive
      });
      if (!isActive) {
        tranquill_T();
      } else {
        tranquill_Y();
      }
      tranquill_1i?.({
        success: true
      });
      return false;
    }
    if (tranquill_1g.action === tranquill_S("0x6c62272e07bb0142")) {
      if (!activeRequest || tranquill_1g.requestId !== activeRequest.id) {
        log.warn(tranquill_S("0x6c62272e07bb0142"), {
          requestId: tranquill_1g["requestId"] ?? null,
          activeRequest: activeRequest ? activeRequest.id : null
        });
        tranquill_1i?.({
          success: false,
          accepted: false
        });
        return false;
      }
      activeRequest.expectedKeys = Array.isArray(tranquill_1g.keys) ? tranquill_1g.keys["filter"](tranquill_1l => typeof tranquill_1l === tranquill_S("0x6c62272e07bb0142") && tranquill_1l.length > 0) : [];
      currentSyntheticCharacter = typeof tranquill_1g.character === tranquill_S("0x6c62272e07bb0142") ? tranquill_1g.character : null;
      tranquill_U(Number(tranquill_1g.duration), activeRequest["id"]);
      if (activeRequest.fallbackTimer) {
        clearTimeout(activeRequest.fallbackTimer);
      }
      const tranquill_1n = Math.max(tranquill_4, Number(tranquill_1g.duration) || tranquill_4);
      activeRequest["fallbackTimer"] = window.setTimeout(() => {
        log["warn"](tranquill_S("0x6c62272e07bb0142"), {
          requestId: activeRequest?.id ?? null
        });
        tranquill_P(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      }, tranquill_1n + tranquill_7);
      log["debug"](tranquill_S("0x6c62272e07bb0142"), {
        requestId: activeRequest.id,
        expectedKeys: activeRequest.expectedKeys,
        character: currentSyntheticCharacter
      });
      tranquill_1i?.({
        success: true,
        accepted: true
      });
      return false;
    }
    if (tranquill_1g["action"] === tranquill_S("0x6c62272e07bb0142")) {
      if (!activeRequest || tranquill_1g.requestId !== activeRequest.id) {
        log.warn(tranquill_S("0x6c62272e07bb0142"), {
          requestId: tranquill_1g.requestId ?? null,
          activeRequest: activeRequest ? activeRequest["id"] : null
        });
        tranquill_1i?.({
          success: false
        });
        return false;
      }
      tranquill_P(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      tranquill_1i?.({
        success: true
      });
      return false;
    }
    if (tranquill_1g.action === tranquill_S("0x6c62272e07bb0142")) {
      tranquill_O();
      allowSyntheticBackspace = true;
      const tranquill_1o = Math["max"](tranquill_8, Number(tranquill_1g.duration) || 0);
      syntheticBackspaceTimer = window.setTimeout(tranquill_O, tranquill_1o + tranquill_7);
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        windowMs: tranquill_1o
      });
      tranquill_1i?.({
        success: true
      });
      return false;
    }
    if (tranquill_1g.action === tranquill_S("0x6c62272e07bb0142")) {
      if (!activeRequest || tranquill_1g.requestId !== activeRequest["id"]) {
        log.warn(tranquill_S("0x6c62272e07bb0142"), {
          requestId: tranquill_1g.requestId ?? null,
          activeRequest: activeRequest ? activeRequest.id : null
        });
        tranquill_1i?.({
          success: false
        });
        return false;
      }
      log.warn(tranquill_S("0x6c62272e07bb0142"), {
        requestId: activeRequest.id,
        character: tranquill_1g.character ?? null
      });
      tranquill_P(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      tranquill_1i?.({
        success: true
      });
      return false;
    }
    tranquill_1i?.({
      success: false
    });
    return false;
  });
  window.addEventListener(tranquill_S("0x6c62272e07bb0142"), tranquill_17, true);
  window.addEventListener(tranquill_S("0x6c62272e07bb0142"), tranquill_1c, true);
  log.info(tranquill_S("0x6c62272e07bb0142"), tranquill_d);
  chrome.runtime?.sendMessage?.({
    action: tranquill_S("0x6c62272e07bb0142")
  });
})();
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}