var tranquill_runtime_exports = (() => {
        const tranquill_global = typeof self !== "undefined" ? self : globalThis;
        if (tranquill_global.tranquill_runtime_ready) {
                return {
                        tranquill_S: tranquill_global.tranquill_S,
                        tranquill_RN: tranquill_global.tranquill_RN,
                        tranquill_next: tranquill_global.tranquill_next,
                        tranquill_signature: tranquill_global.tranquill_signature,
                        tranquill_seed: tranquill_global.tranquill_seed,
                };
        }
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::457f0536cb00f0db9dec4c0cbf422f54"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        const exports = {
                tranquill_S,
                tranquill_RN,
                tranquill_next,
                tranquill_signature: "tranquill_tranquill_tranquill",
                tranquill_seed: tranquill_global.tranquill_seed,
        };
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = exports.tranquill_signature;
        tranquill_global.tranquill_seed = exports.tranquill_seed;
        tranquill_global.tranquill_runtime_ready = true;
        if (typeof tranquill_global === "object" && tranquill_global) {
                try {
                        tranquill_global.tranquill_runtime = exports;
                } catch (error) {
                        // ignore assignment issues in restricted environments
                }
        }
        if (typeof window !== "undefined") {
                window.tranquill_S = tranquill_S;
                window.tranquill_RN = tranquill_RN;
                window.tranquill_next = tranquill_next;
        }
        if (typeof global !== "undefined") {
                global.tranquill_S = tranquill_S;
                global.tranquill_RN = tranquill_RN;
                global.tranquill_next = tranquill_next;
        }
        return exports;
})();

(function tranquill_0() {
  const tranquill_1 = new Uint8Array([186, 143, 213, 179, 167, 146, 181, 16, 114, 189, 162, 177, 78, 132, 177, 163, 69, 156, 180, 185, 82, 207, 178, 186, 162, 138, 211, 167, 191, 153, 182, 237, 13, 133, 231, 58, 150, 155, 247, 126, 150, 138, 128, 43, 182, 139, 131, 135, 105, 50, 158, 139, 127, 154, 231, 125, 138, 141, 177, 44, 182, 129, 134, 151, 121, 34, 142, 155, 111, 235, 143, 226, 192, 242, 137, 226, 219, 254, 244, 88, 5, 245, 233, 75, 238, 198, 159, 235, 243, 213, 209, 50, 148, 222, 212, 53, 156, 220, 201, 109, 153, 223, 194, 109, 134, 196, 215, 37, 148, 221, 198, 125, 125, 204, 187, 162, 203, 214, 162, 167, 128, 133, 68, 197, 161, 137, 76, 215, 242, 148, 77, 144, 161, 133, 86, 144, 167, 142, 81, 197, 162, 144, 77, 194, 166, 133, 70, 144, 190, 143, 69, 144, 190, 133, 84, 213, 190, 18, 36, 69, 29, 14, 38, 125, 52, 23, 36, 93, 54, 13, 9, 16, 21, 8, 64, 8, 31, 76, 19, 25, 4, 76, 12, 19, 23, 76, 12, 25, 6, 9, 12, 29, 254, 107, 30, 30, 126, 75, 17, 119, 99, 86, 89, 223, 233, 21, 89, 144, 245, 15, 78, 215, 240, 14, 78, 144, 251, 18, 64, 212, 254, 5, 9, 213, 234, 20, 72, 210, 245, 9, 90, 216, 252, 4, 0, 175, 223, 82, 35, 170, 150, 74, 41, 238, 223, 80, 47, 186, 223, 95, 42, 167, 204, 91, 102, 162, 217, 89, 33, 167, 216, 89, 102, 172, 196, 87, 34, 169, 211, 187, 218, 43, 80, 155, 230, 47, 74, 153, 212, 60, 64, 197, 210, 62, 81, 184, 212, 45, 64, 143, 225, 62, 93, 159, 149, 50, 75, 157, 218, 48, 64, 143, 135, 51, 146, 103, 144, 6, 129, 122, 128, 118, 52, 134, 158, 86, 8, 130, 132, 84, 58, 145, 142, 8, 60, 147, 159, 117, 58, 128, 142, 66, 15, 147, 147, 82, 123, 144, 138, 79, 55, 147, 143, 148, 20, 36, 190, 180, 40, 32, 164, 182, 26, 51, 174, 234, 28, 49, 191, 151, 26, 34, 174, 160, 47, 49, 179, 176, 91, 38, 174, 183, 20, 56, 189, 161, 31, 159, 142, 47, 164, 191, 178, 43, 190, 189, 128, 56, 180, 225, 146, 58, 165, 156, 128, 41, 180, 171, 181, 58, 169, 187, 209, 151, 33, 253, 241, 171, 37, 231, 243, 153, 54, 237, 175, 139, 52, 252, 210, 153, 39, 237, 229, 172, 52, 240, 245, 216, 55, 233, 232, 148, 52, 236, 240, 121, 0, 19, 208, 69, 4, 9, 210, 119, 23, 3, 142, 101, 21, 18, 243, 119, 6, 3, 196, 66, 21, 30, 212, 54, 3, 19, 195, 117, 21, 21, 211, 103, 104, 119, 66, 71, 84, 115, 88, 69, 102, 96, 82, 25, 100, 107, 82, 86, 117, 84, 86, 65, 98, 99, 99, 82, 127, 115, 71, 243, 82, 39, 80, 198, 65, 58, 64, 60, 154, 232, 90, 38, 132, 200, 65, 39, 132, 234, 86, 59, 144, 162, 198, 82, 108, 130, 250, 86, 118, 128, 200, 69, 124, 220, 202, 78, 124, 147, 219, 113, 120, 132, 204, 70, 77, 151, 209, 86, 57, 148, 200, 75, 117, 151, 205, 67, 36, 51, 142, 99, 24, 55, 148, 97, 42, 36, 158, 61, 40, 47, 158, 114, 57, 16, 154, 101, 46, 39, 175, 118, 51, 55, 219, 96, 62, 32, 152, 118, 56, 48, 249, 95, 105, 149, 217, 99, 109, 143, 219, 81, 126, 133, 135, 66, 124, 147, 204, 68, 77, 153, 217, 89, 119, 135, 249, 66, 118, 135, 219, 85, 106, 147, 146, 33, 66, 203, 178, 29, 70, 209, 176, 47, 85, 219, 236, 60, 87, 205, 167, 58, 102, 199, 178, 39, 92, 217, 146, 60, 93, 217, 176, 43, 65, 205, 226, 40, 83, 215, 174, 43, 86, 216, 38, 104, 236, 248, 26, 108, 246, 250, 40, 127, 252, 166, 59, 125, 234, 237, 61, 76, 224, 248, 32, 118, 254, 216, 59, 119, 254, 250, 44, 107, 234, 168, 58, 109, 250, 235, 44, 107, 234, 219, 78, 235, 228, 251, 116, 210, 210, 228, 79, 239, 227, 228, 77, 247, 244, 249, 1, 248, 254, 229, 82, 239, 227, 254, 66, 239, 244, 239, 105, 171, 249, 65, 73, 145, 192, 119, 86, 170, 253, 70, 86, 168, 229, 81, 75, 234, 224, 90, 80, 176, 169, 71, 77, 165, 251, 64, 4, 201, 84, 35, 36, 243, 109, 21, 59, 200, 80, 36, 59, 202, 72, 51, 38, 134, 77, 56, 61, 210, 77, 55, 56, 207, 94, 51, 48, 160, 86, 252, 151, 249, 90, 234, 147, 161, 71, 242, 178, 13, 167, 185, 236, 14, 164, 168, 181, 3, 191, 217, 231, 66, 118, 146, 225, 10, 103, 130, 225, 83, 106, 153, 42, 21, 160, 151, 118, 18, 249, 148, 113, 18, 160, 153, 106, 32, 80, 187, 103, 122, 74, 176, 116, 125, 14, 188, 102, 122, 87, 177, 125, 189, 20, 246, 202, 247, 22, 174, 207, 250, 29, 232, 250, 81, 74, 219, 218, 107, 115, 237, 197, 80, 78, 220, 197, 82, 86, 203, 216, 30, 89, 207, 201, 86, 95, 235, 198, 91, 87, 203, 196, 74, 73, 208, 141, 42, 210, 216, 140, 22, 192, 194, 151, 88, 155, 157, 131, 11, 192, 218, 145, 0, 154, 209, 139, 15, 155, 221, 147, 7, 218, 213, 150, 7, 211, 193, 139, 12, 155, 198, 150, 3, 218, 195, 145, 11, 216, 222, 203, 195, 222, 157, 31, 225, 139, 152, 18, 234, 192, 212, 24, 232, 194, 151, 16, 225, 207, 16, 77, 234, 18, 24, 219, 187, 46, 239, 236, 250, 44, 239, 240, 174, 120, 236, 250, 181, 53, 170, 248, 181, 40, 255, 248, 105, 150, 150, 75, 74, 147, 223, 83, 64, 215, 140, 70, 89, 146, 223, 83, 74, 143, 139, 83, 238, 73, 81, 91, 106, 138, 86, 75, 30, 134, 64, 79, 75, 155, 14, 92, 82, 138, 79, 77, 91, 139, 14, 73, 87, 142, 14, 77, 91, 156, 75, 75, 173, 55, 123, 138, 156, 62, 122, 203, 157, 58, 104, 142, 138, 123, 106, 142, 150, 47, 62, 152, 154, 58, 106, 142, 178, 34, 237, 159, 145, 39, 164, 135, 155, 99, 231, 159, 145, 34, 246, 211, 135, 34, 242, 150, 144, 99, 240, 150, 140, 55, 144, 205, 106, 146, 152, 145, 52, 184, 159, 140, 254, 25, 247, 210, 227, 90, 226, 213, 229, 24, 245, 207, 49, 243, 208, 187, 61, 229, 212, 238, 32, 171, 209, 235, 48, 234, 208, 254, 48, 200, 221, 220, 221, 210, 195, 255, 192, 221, 208, 217, 199, 255, 204, 205, 218, 219, 193, 200, 129, 30, 149, 190, 187, 0, 197, 164, 161, 6, 145, 162, 166, 71, 144, 167, 177, 6, 145, 178, 245, 21, 128, 180, 176, 14, 147, 178, 177, 57, 20, 131, 43, 49, 1, 88, 38, 12, 2, 22, 50, 12, 5, 77, 40, 7, 22, 74, 111, 1, 5, 84, 45, 25, 60, 124, 16, 30, 39, 105, 23, 2, 32, 27, 185, 105, 13, 212, 139, 156, 243, 253, 139, 158, 243, 244, 141, 202, 238, 245, 202, 153, 255, 238, 158, 131, 244, 253, 153, 202, 234, 251, 141, 143, 122, 24, 200, 108, 99, 28, 242, 93, 94, 11, 228, 77, 17, 10, 224, 95, 84, 29, 161, 93, 84, 1, 245, 125, 83, 130, 46, 94, 86, 203, 54, 84, 18, 153, 39, 72, 70, 132, 48, 94, 18, 152, 35, 77, 87, 143, 98, 79, 87, 147, 54, 174, 147, 205, 75, 150, 153, 138, 88, 131, 140, 195, 66, 157, 220, 195, 75, 148, 147, 216, 73, 158, 199, 138, 77, 150, 142, 207, 77, 158, 133, 138, 92, 136, 147, 201, 73, 137, 143, 195, 66, 157, 71, 189, 130, 156, 107, 185, 130, 156, 98, 233, 130, 150, 38, 186, 130, 152, 116, 189, 214, 141, 127, 185, 159, 151, 97, 233, 129, 144, 114, 161, 153, 140, 114, 233, 130, 156, 126, 189, 248, 3, 26, 213, 223, 30, 21, 192, 139, 3, 2, 215, 194, 25, 28, 135, 217, 18, 10, 210, 206, 4, 15, 156, 55, 200, 215, 166, 41, 152, 205, 173, 61, 203, 215, 167, 32, 152, 205, 188, 47, 202, 202, 173, 42, 152, 216, 186, 33, 213, 158, 184, 33, 200, 203, 184, 18, 174, 109, 51, 49, 171, 36, 43, 59, 239, 119, 43, 53, 189, 112, 127, 32, 182, 116, 54, 58, 168, 42, 68, 31, 6, 31, 5, 30, 12, 10, 76, 4, 18, 90, 87, 15, 4, 15, 64, 25, 1, 31, 65, 221, 218, 105, 26, 231, 196, 57, 3, 232, 214, 106, 22, 237, 91, 35, 228, 126, 120, 38, 173, 102, 114, 98, 253, 115, 104, 49, 232, 50, 105, 59, 253, 123, 115, 37, 119, 208, 222, 123, 106, 147, 203, 124, 108, 209, 220, 80, 55, 25, 60, 77, 116, 12, 59, 75, 54, 27, 34, 81, 100, 64, 47, 74, 61, 25, 44, 75, 113, 80, 41, 74, 119, 48, 151, 178, 65, 55, 183, 170, 67, 42, 141, 180, 137, 224, 103, 176, 179, 249, 98, 254, 185, 252, 126, 177, 174, 174, 127, 170, 189, 252, 120, 183, 178, 233, 44, 170, 165, 254, 101, 176, 187, 139, 122, 94, 120, 158, 79, 82, 123, 146, 117, 76, 64, 6, 206, 118, 122, 31, 203, 56, 112, 26, 215, 119, 103, 72, 213, 121, 96, 27, 204, 118, 114, 72, 209, 97, 101, 1, 203, 127, 202, 53, 103, 255, 252, 40, 41, 232, 224, 60, 96, 242, 254, 108, 122, 232, 248, 56, 124, 239, 131, 89, 156, 164, 160, 92, 213, 188, 170, 24, 134, 177, 171, 91, 213, 188, 188, 72, 156, 166, 162, 24, 134, 188, 164, 76, 128, 187, 217, 127, 122, 254, 199, 106, 103, 196, 217, 73, 122, 203, 202, 111, 125, 2, 48, 96, 6, 12, 1, 109, 21, 13, 59, 115, 54, 16, 52, 96, 16, 23, 117, 114, 4, 13, 57, 113, 1, 198, 35, 162, 31, 255, 40, 227, 9, 252, 109, 167, 24, 231, 40, 177, 16, 250, 35, 166, 93, 231, 52, 179, 20, 253, 42, 227, 14, 231, 44, 183, 8, 224, 85, 201, 87, 63, 91, 248, 90, 44, 90, 194, 68, 15, 71, 205, 87, 41, 64, 140, 81, 57, 64, 220, 76, 50, 64, 201, 3, 53, 93, 218, 66, 48, 90, 200, 82, 113, 231, 51, 71, 88, 33, 249, 68, 53, 233, 212, 72, 20, 240, 222, 78, 64, 234, 196, 72, 18, 237, 144, 75, 21, 237, 196, 70, 14, 185, 209, 89, 16, 252, 209, 91, 1, 247, 211, 76, 151, 189, 21, 171, 144, 228, 22, 172, 144, 189, 27, 183, 144, 220, 5, 190, 133, 144, 18, 184, 148, 201, 31, 163, 141, 227, 53, 96, 193, 225, 46, 100, 159, 226, 57, 101, 116, 231, 37, 128, 149, 192, 111, 130, 150, 98, 22, 122, 149, 46, 8, 114, 150, 102, 8, 219, 211, 14, 209, 238, 146, 15, 219, 251, 219, 21, 197, 244, 178, 22, 228, 211, 230, 3, 239, 215, 175, 25, 241, 222, 225, 110, 212, 207, 232, 180, 93, 182, 221, 245, 92, 188, 200, 188, 70, 162, 151, 157, 117, 203, 176, 201, 96, 192, 180, 128, 122, 222, 148, 128, 203, 189, 183, 133, 130, 165, 189, 193, 203, 191, 187, 149, 203, 176, 190, 136, 216, 180, 242, 145, 205, 161, 167, 145, 50, 244, 203, 40, 25, 213, 242, 14, 24, 207, 202, 4, 23, 223, 227, 15]);
  const tranquill_2 = self.tranquill_PACK = self["tranquill_PACK"] || {
    idx: new Map(),
    data: []
  };
  tranquill_2["data"].push(tranquill_1);
  const tranquill_3 = tranquill_2.data.length - 1;
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 0,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 6,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 11,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 15,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 19,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 24,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 30,
    len: 3,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 33,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 37,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 42,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 47,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 53,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 58,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 63,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 69,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 78,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 84,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 90,
    len: 20,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 110,
    len: 3,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 113,
    len: 7,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 120,
    len: 37,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 157,
    len: 11,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 168,
    len: 23,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 191,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 196,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 202,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 234,
    len: 35,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 269,
    len: 33,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 302,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 311,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 343,
    len: 34,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 377,
    len: 25,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 402,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 434,
    len: 33,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 467,
    len: 27,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 494,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 503,
    len: 14,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 517,
    len: 34,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 551,
    len: 35,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 586,
    len: 32,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 618,
    len: 39,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 657,
    len: 40,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 697,
    len: 29,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 726,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 754,
    len: 29,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 783,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 793,
    len: 12,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 805,
    len: 13,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 818,
    len: 13,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 831,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 847,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 858,
    len: 31,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 889,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 894,
    len: 41,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 935,
    len: 18,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 953,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 958,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 979,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 998,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1003,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1031,
    len: 24,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1055,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1081,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1086,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1091,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1102,
    len: 18,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1120,
    len: 19,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1139,
    len: 29,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1168,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1173,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1192,
    len: 10,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1202,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1206,
    len: 27,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1233,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1237,
    len: 19,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1256,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1284,
    len: 41,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1325,
    len: 38,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1363,
    len: 23,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1386,
    len: 33,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1419,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1441,
    len: 22,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1463,
    len: 13,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1476,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1498,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1509,
    len: 11,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1520,
    len: 15,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1535,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1546,
    len: 29,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1575,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1586,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1614,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1634,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1662,
    len: 15,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1677,
    len: 24,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1701,
    len: 33,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1734,
    len: 34,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1768,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1773,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1777,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1809,
    len: 12,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1821,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1833,
    len: 12,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1845,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1849,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1854,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1864,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1876,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1888,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1893,
    len: 12,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1905,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1917,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1943,
    len: 16,
    kind: 1
  });
})();
let loggingPort = null;
const tranquill_4 = new Set([tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")]);
const tranquill_5 = tranquill_6 => {
  if (typeof tranquill_6 !== tranquill_S("0x6c62272e07bb0142")) return null;
  const tranquill_8 = tranquill_6["toLowerCase"]();
  if (tranquill_8 === tranquill_S("0x6c62272e07bb0142")) return tranquill_S("0x6c62272e07bb0142");
  if (tranquill_8 === tranquill_S("0x6c62272e07bb0142")) return tranquill_S("0x6c62272e07bb0142");
  return tranquill_4.has(tranquill_8) ? tranquill_8 : null;
};
const tranquill_9 = tranquill_a => {
  if (!tranquill_a || typeof tranquill_a !== tranquill_S("0x6c62272e07bb0142")) return tranquill_a;
  switch (tranquill_a.kind) {
    case tranquill_S("0x6c62272e07bb0142"):
      {
        const tranquill_d = new Error(tranquill_a.message);
        tranquill_d.name = tranquill_a.name || tranquill_S("0x6c62272e07bb0142");
        if (tranquill_a["stack"]) tranquill_d.stack = tranquill_a.stack;
        return tranquill_d;
      }
    case tranquill_S("0x6c62272e07bb0142"):
    case tranquill_S("0x6c62272e07bb0142"):
      return tranquill_a.value;
    case tranquill_S("0x6c62272e07bb0142"):
      return tranquill_a.value;
    default:
      return tranquill_a.value;
  }
};
const tranquill_e = tranquill_f => {
  if (typeof tranquill_f !== tranquill_S("0x6c62272e07bb0142")) return null;
  let hash = 0;
  for (let tranquill_h = 0; tranquill_h < tranquill_f["length"]; tranquill_h++) {
    hash = Math["imul"](31, hash) + tranquill_f.charCodeAt(tranquill_h);
    hash |= 0;
  }
  return `${tranquill_f.length}:${(hash >>> 0).toString(16)}`;
};
function tranquill_j() {
  if (loggingPort) return;
  try {
    const tranquill_k = chrome["runtime"].connect({
      name: tranquill_S("0x6c62272e07bb0142")
    });
    tranquill_k.onMessage.addListener(tranquill_l => {
      const tranquill_m = tranquill_l?.level || tranquill_S("0x6c62272e07bb0142");
      const tranquill_n = Array["isArray"](tranquill_l?.args) ? tranquill_l["args"].map(tranquill_9) : [];
      const tranquill_o = tranquill_l?.meta?.source ? tranquill_l.meta.source : tranquill_S("0x6c62272e07bb0142");
      const tranquill_p = tranquill_l?.meta?.timestamp ? new Date(tranquill_l.meta["timestamp"]).toISOString() : "";
      const tranquill_q = `[${tranquill_o}]${tranquill_p ? ` ${tranquill_p}` : ""}`;
      const tranquill_r = console[tranquill_m] || console["log"];
      tranquill_r.call(console, tranquill_q, ...tranquill_n);
    });
    tranquill_k.onDisconnect.addListener(() => {
      loggingPort = null;
    });
    loggingPort = tranquill_k;
    window.tranquillSetLogLevel = tranquill_s => {
      if (!loggingPort) return;
      const tranquill_t = tranquill_5(tranquill_s);
      if (!tranquill_t) {
        log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_s);
        return;
      }
      try {
        loggingPort.postMessage({
          type: tranquill_S("0x6c62272e07bb0142"),
          level: tranquill_t
        });
      } catch (tranquill_v) {
        log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_v);
      }
    };
    window.tranquillSetDebugLogging = tranquill_w => {
      const tranquill_x = tranquill_w ? tranquill_S("0x6c62272e07bb0142") : tranquill_S("0x6c62272e07bb0142");
      window.tranquillSetLogLevel(tranquill_x);
    };
    log["info"](tranquill_S("0x6c62272e07bb0142"));
  } catch (tranquill_y) {
    log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_y);
  }
}
tranquill_j();
class tranquill_z {
  static getSavedText() {
    log.debug(tranquill_S("0x6c62272e07bb0142"));
    return new Promise((tranquill_A, tranquill_B) => {
      chrome.storage.local.get(tranquill_S("0x6c62272e07bb0142"), tranquill_C => {
        if (chrome.runtime["lastError"]) {
          const tranquill_D = new Error(chrome["runtime"].lastError.message);
          log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_D);
          tranquill_B(tranquill_D);
          return;
        }
        log.debug(tranquill_S("0x6c62272e07bb0142"), {
          length: tranquill_C.savedText?.length ?? 0
        });
        tranquill_A(tranquill_C["savedText"] || "");
      });
    });
  }
  static setSavedText(tranquill_E) {
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      length: tranquill_E?.length ?? 0
    });
    return new Promise((tranquill_F, tranquill_G) => {
      chrome.storage["local"]["set"]({
        savedText: tranquill_E
      }, () => {
        if (chrome.runtime.lastError) {
          const tranquill_H = new Error(chrome.runtime.lastError.message);
          log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_H);
          tranquill_G(tranquill_H);
          return;
        }
        log["debug"](tranquill_S("0x6c62272e07bb0142"));
        tranquill_F();
      });
    });
  }
  static clearSavedText() {
    log.debug(tranquill_S("0x6c62272e07bb0142"));
    return new Promise((tranquill_I, tranquill_J) => {
      chrome.storage.local.remove([tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")], () => {
        if (chrome["runtime"].lastError) {
          const tranquill_K = new Error(chrome["runtime"].lastError.message);
          log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_K);
          tranquill_J(tranquill_K);
          return;
        }
        log.debug(tranquill_S("0x6c62272e07bb0142"));
        tranquill_I();
      });
    });
  }
  static resetTypingProgress(tranquill_L) {
    const tranquill_M = tranquill_e(String(tranquill_L || ""));
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      signature: tranquill_M
    });
    return new Promise((tranquill_N, tranquill_O) => {
      chrome["storage"].local.set({
        typingProgress: 0,
        typingProgressSignature: tranquill_M
      }, () => {
        if (chrome["runtime"].lastError) {
          const tranquill_P = new Error(chrome.runtime.lastError["message"]);
          log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_P);
          tranquill_O(tranquill_P);
          return;
        }
        log.debug(tranquill_S("0x6c62272e07bb0142"), {
          signature: tranquill_M
        });
        tranquill_N();
      });
    });
  }
}
class tranquill_Q {
  constructor(tranquill_R) {
    this.documentRef = tranquill_R;
    this.textInput = null;
    this.saveButton = null;
    this.resetButton = null;
    this.startButton = null;
    this.settingsButton = null;
    this.guideButton = null;
    this.isProcessing = false;
    this.isTyping = false;
    log["debug"](tranquill_S("0x6c62272e07bb0142"));
  }
  async init() {
    log["debug"](tranquill_S("0x6c62272e07bb0142"));
    this["cacheElements"]();
    this["registerListeners"]();
    await this.restoreSavedText();
    await this.syncTypingStatus();
    this["updateStartButtonAppearance"]();
    log["info"](tranquill_S("0x6c62272e07bb0142"));
  }
  cacheElements() {
    this["textInput"] = this.documentRef["getElementById"](tranquill_S("0x6c62272e07bb0142"));
    this.saveButton = this.documentRef.querySelector(tranquill_S("0x6c62272e07bb0142"));
    this.resetButton = this["documentRef"].querySelector(tranquill_S("0x6c62272e07bb0142"));
    this.startButton = this["documentRef"].querySelector(tranquill_S("0x6c62272e07bb0142"));
    this.settingsButton = this["documentRef"].querySelector(tranquill_S("0x6c62272e07bb0142"));
    this.guideButton = this.documentRef["querySelector"](tranquill_S("0x6c62272e07bb0142"));
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      hasTextInput: Boolean(this["textInput"]),
      hasStartButton: Boolean(this.startButton)
    });
  }
  registerListeners() {
    if (this.guideButton) {
      this.guideButton.addEventListener(tranquill_S("0x6c62272e07bb0142"), tranquill_T => {
        tranquill_T.preventDefault();
        chrome["tabs"].create({
          url: tranquill_S("0x6c62272e07bb0142")
        });
        log.info(tranquill_S("0x6c62272e07bb0142"));
      });
    }
    if (this["saveButton"]) {
      this.saveButton["addEventListener"](tranquill_S("0x6c62272e07bb0142"), async () => {
        try {
          const tranquill_U = this.textInput?.value || "";
          await tranquill_z.setSavedText(tranquill_U);
          await tranquill_z.resetTypingProgress(tranquill_U);
          log.info(tranquill_S("0x6c62272e07bb0142"), {
            length: this["textInput"]?.value?.length ?? 0,
            progressReset: true
          });
        } catch (tranquill_V) {
          log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_V);
        }
      });
    }
    if (this["resetButton"]) {
      this.resetButton.addEventListener(tranquill_S("0x6c62272e07bb0142"), async () => {
        if (this.textInput) {
          this.textInput.value = "";
          log.info(tranquill_S("0x6c62272e07bb0142"));
          await this["handlePause"]();
        }
        try {
          await tranquill_z.clearSavedText();
          log.info(tranquill_S("0x6c62272e07bb0142"));
        } catch (tranquill_W) {
          log["error"](tranquill_S("0x6c62272e07bb0142"), tranquill_W);
        }
      });
    }
    if (this["startButton"]) {
      this.startButton.addEventListener(tranquill_S("0x6c62272e07bb0142"), () => this.handleToggleTyping());
    }
    if (this.textInput) {
      this.textInput["addEventListener"](tranquill_S("0x6c62272e07bb0142"), () => {
        this["textInput"].classList["remove"](tranquill_S("0x6c62272e07bb0142"));
        log.debug(tranquill_S("0x6c62272e07bb0142"), {
          length: this.textInput["value"].length
        });
      });
    }
    chrome["runtime"].onMessage.addListener(tranquill_X => {
      if (tranquill_X && tranquill_X["action"] === tranquill_S("0x6c62272e07bb0142")) {
        this.isTyping = Boolean(tranquill_X["isTyping"]);
        this.isProcessing = false;
        this.setStartButtonLoading(false);
        this.updateStartButtonAppearance();
        log.info(tranquill_S("0x6c62272e07bb0142"), {
          isTyping: this.isTyping
        });
      }
    });
    if (this.settingsButton) {
      this.settingsButton.addEventListener(tranquill_S("0x6c62272e07bb0142"), () => {
        const tranquill_Y = new URL(chrome["runtime"].getURL(tranquill_S("0x6c62272e07bb0142")));
        tranquill_Y.searchParams.set(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
        window.location.href = tranquill_Y["toString"]();
        log["info"](tranquill_S("0x6c62272e07bb0142"), {
          transition: tranquill_S("0x6c62272e07bb0142")
        });
      });
    }
  }
  async restoreSavedText() {
    try {
      const tranquill_Z = await tranquill_z.getSavedText();
      if (this.textInput) {
        this.textInput.value = tranquill_Z;
        log.debug(tranquill_S("0x6c62272e07bb0142"), {
          length: tranquill_Z["length"]
        });
      }
    } catch (tranquill_10) {
      log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_10);
    }
  }
  async handleToggleTyping() {
    if (this.isProcessing) {
      log.debug(tranquill_S("0x6c62272e07bb0142"));
      return;
    }
    if (this.isTyping) {
      await this.handlePause();
      return;
    }
    await this.handleStart();
  }
  async handleStart() {
    const tranquill_11 = this.textInput ? this.textInput.value : "";
    if (!tranquill_11 || tranquill_11.trim().length === 0) {
      this.indicateValidationError();
      log.warn(tranquill_S("0x6c62272e07bb0142"));
      return;
    }
    this.isProcessing = true;
    this["setStartButtonLoading"](true);
    log["info"](tranquill_S("0x6c62272e07bb0142"), {
      length: tranquill_11.length
    });
    try {
      const tranquill_13 = await tranquill_z.getSavedText();
      await tranquill_z["setSavedText"](tranquill_11);
      const tranquill_14 = tranquill_13 !== tranquill_11;
      await this.sendStartTypingRequest(tranquill_11, tranquill_14, tranquill_13);
      this.isTyping = true;
      this.updateStartButtonAppearance();
      log["info"](tranquill_S("0x6c62272e07bb0142"));
    } catch (tranquill_15) {
      log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_15);
      this.isTyping = false;
      this.updateStartButtonAppearance();
    } finally {
      this["isProcessing"] = false;
      this.setStartButtonLoading(false);
    }
  }
  async handlePause() {
    this.isProcessing = true;
    this["setStartButtonLoading"](true);
    log.info(tranquill_S("0x6c62272e07bb0142"));
    try {
      await this["sendPauseTypingRequest"]();
      this.isTyping = false;
      this.updateStartButtonAppearance();
      log["info"](tranquill_S("0x6c62272e07bb0142"));
    } catch (tranquill_16) {
      log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_16);
    } finally {
      this.isProcessing = false;
      this.setStartButtonLoading(false);
    }
  }
  indicateValidationError() {
    if (!this.textInput) {
      return;
    }
    this.textInput.classList.add(tranquill_S("0x6c62272e07bb0142"));
    setTimeout(() => this.textInput.classList.remove(tranquill_S("0x6c62272e07bb0142")), 600);
    this.textInput.focus();
  }
  setStartButtonLoading(tranquill_17) {
    if (!this.startButton) {
      return;
    }
    this.startButton["disabled"] = tranquill_17;
    this["startButton"].classList.toggle(tranquill_S("0x6c62272e07bb0142"), tranquill_17);
  }
  async sendStartTypingRequest(tranquill_18, tranquill_19 = false, tranquill_1a = null) {
    return new Promise((tranquill_1b, tranquill_1c) => {
      chrome.runtime["sendMessage"]({
        action: tranquill_S("0x6c62272e07bb0142"),
        text: tranquill_18,
        resetProgress: tranquill_19,
        previousText: tranquill_1a
      }, tranquill_1d => {
        if (chrome["runtime"].lastError) {
          tranquill_1c(new Error(chrome.runtime.lastError.message));
          return;
        }
        if (!tranquill_1d || tranquill_1d["success"] !== true) {
          const tranquill_1f = tranquill_1d && tranquill_1d.error ? tranquill_1d["error"] : tranquill_S("0x6c62272e07bb0142");
          tranquill_1c(new Error(tranquill_1f));
          return;
        }
        tranquill_1b();
      });
    });
  }
  async sendPauseTypingRequest() {
    return new Promise((tranquill_1g, tranquill_1h) => {
      chrome.runtime["sendMessage"]({
        action: tranquill_S("0x6c62272e07bb0142")
      }, tranquill_1i => {
        if (chrome["runtime"].lastError) {
          tranquill_1h(new Error(chrome.runtime.lastError.message));
          return;
        }
        if (!tranquill_1i || tranquill_1i.success !== true) {
          const tranquill_1k = tranquill_1i && tranquill_1i["error"] ? tranquill_1i["error"] : tranquill_S("0x6c62272e07bb0142");
          tranquill_1h(new Error(tranquill_1k));
          return;
        }
        tranquill_1g();
      });
    });
  }
  async syncTypingStatus() {
    try {
      const tranquill_1l = await this.fetchTypingStatus();
      this["isTyping"] = Boolean(tranquill_1l);
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        isTyping: this.isTyping
      });
    } catch (tranquill_1m) {
      log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_1m);
      this["isTyping"] = false;
    }
  }
  async fetchTypingStatus() {
    return new Promise((tranquill_1n, tranquill_1o) => {
      chrome.runtime["sendMessage"]({
        action: tranquill_S("0x6c62272e07bb0142")
      }, tranquill_1p => {
        if (chrome.runtime["lastError"]) {
          const tranquill_1q = new Error(chrome.runtime["lastError"].message);
          log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_1q);
          tranquill_1o(tranquill_1q);
          return;
        }
        if (!tranquill_1p || tranquill_1p.success !== true) {
          const tranquill_1s = tranquill_1p && tranquill_1p["error"] ? tranquill_1p.error : tranquill_S("0x6c62272e07bb0142");
          const tranquill_1t = new Error(tranquill_1s);
          log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_1t);
          tranquill_1o(tranquill_1t);
          return;
        }
        tranquill_1n(Boolean(tranquill_1p.isTyping));
      });
    });
  }
  updateStartButtonAppearance() {
    if (!this.startButton) {
      return;
    }
    const tranquill_1u = Boolean(this.isTyping);
    const tranquill_1v = tranquill_1u ? tranquill_S("0x6c62272e07bb0142") : tranquill_S("0x6c62272e07bb0142");
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      isTyping: tranquill_1u
    });
    this.startButton["classList"].toggle(tranquill_S("0x6c62272e07bb0142"), !tranquill_1u);
    this.startButton["classList"].toggle(tranquill_S("0x6c62272e07bb0142"), tranquill_1u);
    this["startButton"].innerHTML = `<i class="fa fa-${tranquill_1v}"></i>`;
    this.startButton.setAttribute(tranquill_S("0x6c62272e07bb0142"), tranquill_1u ? tranquill_S("0x6c62272e07bb0142") : tranquill_S("0x6c62272e07bb0142"));
    this["startButton"]["setAttribute"](tranquill_S("0x6c62272e07bb0142"), tranquill_1u ? tranquill_S("0x6c62272e07bb0142") : tranquill_S("0x6c62272e07bb0142"));
    this.startButton["setAttribute"](tranquill_S("0x6c62272e07bb0142"), tranquill_1u ? tranquill_S("0x6c62272e07bb0142") : tranquill_S("0x6c62272e07bb0142"));
  }
}
function tranquill_1x() {
  const tranquill_1y = new tranquill_Q(document);
  tranquill_1y.init()["catch"](tranquill_1z => {
    log["error"](tranquill_S("0x6c62272e07bb0142"), tranquill_1z);
  });
}
document.addEventListener(tranquill_S("0x6c62272e07bb0142"), tranquill_1x);
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}