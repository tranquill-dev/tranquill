var tranquill_runtime_exports = (() => {
        const tranquill_global = typeof self !== "undefined" ? self : globalThis;
        if (tranquill_global.tranquill_runtime_ready) {
                return {
                        tranquill_S: tranquill_global.tranquill_S,
                        tranquill_RN: tranquill_global.tranquill_RN,
                        tranquill_next: tranquill_global.tranquill_next,
                        tranquill_signature: tranquill_global.tranquill_signature,
                        tranquill_seed: tranquill_global.tranquill_seed,
                };
        }
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::457f0536cb00f0db9dec4c0cbf422f54"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        const exports = {
                tranquill_S,
                tranquill_RN,
                tranquill_next,
                tranquill_signature: "tranquill_tranquill_tranquill",
                tranquill_seed: tranquill_global.tranquill_seed,
        };
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = exports.tranquill_signature;
        tranquill_global.tranquill_seed = exports.tranquill_seed;
        tranquill_global.tranquill_runtime_ready = true;
        if (typeof tranquill_global === "object" && tranquill_global) {
                try {
                        tranquill_global.tranquill_runtime = exports;
                } catch (error) {
                        // ignore assignment issues in restricted environments
                }
        }
        if (typeof window !== "undefined") {
                window.tranquill_S = tranquill_S;
                window.tranquill_RN = tranquill_RN;
                window.tranquill_next = tranquill_next;
        }
        if (typeof global !== "undefined") {
                global.tranquill_S = tranquill_S;
                global.tranquill_RN = tranquill_RN;
                global.tranquill_next = tranquill_next;
        }
        return exports;
})();

(function tranquill_0() {
  const tranquill_1 = new Uint8Array([184, 69, 35, 152, 134, 116, 38, 159, 142, 118, 59, 208, 221, 118, 62, 137, 130, 116, 36, 143, 202, 113, 50, 147, 183, 163, 140, 158, 137, 146, 137, 153, 129, 144, 148, 214, 210, 140, 157, 130, 140, 149, 150, 139, 197, 136, 138, 141, 134, 143, 145, 152, 129, 147, 150, 117, 54, 210, 128, 77, 38, 158, 135, 76, 116, 134, 195, 84, 54, 128, 138, 68, 42, 210, 151, 74, 50, 134, 195, 78, 58, 145, 134, 76, 32, 151, 195, 73, 54, 139, 205, 148, 26, 179, 140, 172, 10, 255, 139, 173, 88, 231, 207, 177, 26, 242, 140, 171, 95, 231, 135, 166, 95, 255, 134, 160, 26, 253, 156, 166, 95, 224, 138, 177, 9, 246, 157, 237, 95, 195, 131, 166, 30, 224, 138, 227, 11, 225, 150, 227, 30, 244, 142, 170, 17, 189, 197, 99, 2, 213, 253, 115, 78, 210, 252, 33, 86, 150, 246, 99, 86, 211, 224, 107, 75, 216, 247, 38, 91, 217, 231, 116, 2, 210, 247, 112, 75, 213, 247, 38, 75, 210, 247, 104, 86, 223, 244, 111, 71, 196, 188, 38, 114, 218, 247, 103, 81, 211, 178, 114, 80, 207, 178, 103, 69, 215, 251, 104, 12, 98, 1, 251, 36, 87, 4, 252, 44, 85, 25, 212, 101, 85, 28, 234, 32, 87, 6, 236, 101, 84, 20, 231, 36, 94, 16, 251, 101, 76, 27, 232, 51, 88, 28, 229, 36, 91, 25, 236, 3, 109, 154, 17, 40, 76, 163, 55, 41, 86, 155, 61, 38, 70, 178, 54, 249, 113, 40, 140, 163, 115, 46, 140, 178, 96, 105, 142, 184, 117, 46, 140, 247, 146, 198, 169, 176, 144, 132, 173, 182, 144, 221, 171, 183, 138, 214, 62, 129, 97, 157, 60, 155, 103, 213, 52, 135, 112, 149, 37, 75, 191, 148, 99, 73, 165, 146, 43, 76, 179, 142, 46, 119, 57, 136, 101, 117, 35, 142, 45, 126, 34, 153, 111, 105, 182, 97, 33, 254, 253, 99, 59, 248, 181, 100, 38, 237, 237, 121, 101, 250, 234, 98, 61, 237, 159, 185, 136, 166, 212, 187, 146, 160, 156, 183, 148, 177, 197, 186, 143, 200, 234, 42, 196, 253, 242, 10, 173, 182, 240, 16, 171, 254, 237, 22, 173, 176, 251, 16, 189, 217, 248, 64, 253, 236, 253, 71, 245, 238, 224, 111, 188, 238, 227, 85, 245, 236, 172, 103, 213, 162, 229, 65, 188, 239, 229, 65, 239, 235, 226, 85, 188, 240, 233, 67, 233, 235, 254, 87, 248, 162, 233, 94, 249, 239, 233, 92, 232, 241, 13, 100, 44, 12, 23, 101, 28, 241, 117, 26, 1, 24, 46, 65, 11, 45, 43, 70, 3, 47, 54, 110, 74, 47, 53, 84, 3, 45, 122, 102, 35, 99, 51, 64, 74, 46, 51, 64, 25, 42, 52, 84, 74, 55, 50, 86, 74, 48, 47, 80, 9, 38, 41, 64, 74, 37, 63, 86, 14, 33, 59, 80, 1, 99, 63, 95, 15, 46, 63, 93, 30, 40, 81, 124, 65, 52, 65, 50, 87, 50, 81, 178, 15, 102, 128, 180, 29, 47, 133, 181, 27, 135, 122, 31, 185, 203, 106, 3, 171, 159, 190, 179, 70, 176, 242, 163, 90, 162, 166, 153, 58, 232, 157, 185, 50, 15, 105, 145, 51, 4, 109, 24, 218, 204, 111, 214, 251, 153, 105, 196, 178, 156, 104, 194, 69, 43, 156, 142, 112, 46, 155, 134, 114, 51, 179, 207, 109, 43, 129, 157, 123, 59, 206, 131, 119, 60, 139, 129, 109, 58, 206, 153, 127, 51, 135, 139, 127, 43, 135, 128, 112, 127, 136, 142, 119, 51, 139, 139, 128, 239, 249, 170, 181, 234, 254, 162, 183, 247, 214, 235, 189, 250, 226, 167, 190, 255, 171, 191, 180, 187, 226, 165, 178, 239, 226, 170, 183, 242, 241, 174, 251, 247, 228, 172, 178, 245, 171, 172, 186, 239, 238, 14, 123, 154, 52, 8, 105, 211, 49, 9, 111, 8, 241, 28, 33, 20, 225, 82, 55, 18, 241, 0, 166, 245, 17, 12, 176, 19, 38, 139, 229, 95, 54, 151, 247, 11, 242, 11, 214, 23, 203, 0, 151, 1, 200, 69, 194, 27, 203, 10, 212, 30, 135, 17, 197, 20, 201, 20, 194, 28, 203, 9, 153, 85, 247, 9, 210, 20, 212, 0, 151, 1, 213, 28, 151, 20, 192, 4, 222, 27, 137, 19, 212, 150, 41, 48, 221, 211, 45, 45, 204, 150, 58, 99, 193, 156, 61, 49, 152, 159, 33, 32, 221, 157, 59, 38, 152, 152, 45, 58, 150, 181, 156, 236, 121, 128, 153, 235, 113, 130, 132, 195, 56, 130, 129, 253, 125, 128, 155, 251, 56, 155, 134, 242, 119, 141, 131, 190, 126, 143, 129, 242, 125, 138, 70, 183, 34, 107, 127, 188, 99, 125, 124, 249, 54, 103, 127, 182, 32, 98, 51, 173, 49, 104, 125, 168, 54, 96, 127, 181, 109, 41, 67, 181, 38, 104, 96, 188, 99, 125, 97, 160, 99, 104, 116, 184, 42, 103, 61, 250, 71, 174, 200, 252, 85, 231, 205, 253, 83, 255, 178, 71, 241, 179, 162, 91, 227, 231, 216, 187, 105, 220, 250, 177, 140, 170, 210, 176, 135, 174, 91, 89, 79, 167, 218, 127, 217, 235, 202, 99, 203, 191, 162, 180, 253, 168, 160, 174, 251, 224, 167, 179, 238, 184, 186, 240, 249, 191, 161, 168, 238, 224, 227, 184, 236, 191, 161, 175, 1, 222, 94, 2, 3, 196, 88, 74, 8, 197, 79, 8, 31, 154, 16, 15, 4, 211, 89, 2, 3, 29, 7, 66, 27, 31, 29, 68, 83, 20, 28, 83, 17, 3, 67, 12, 8, 24, 29, 72, 28, 29, 11, 255, 141, 192, 241, 253, 151, 198, 185, 250, 138, 211, 225, 231, 201, 196, 230, 252, 145, 211, 185, 190, 129, 209, 230, 252, 150, 77, 87, 18, 75, 79, 77, 20, 3, 68, 76, 3, 65, 83, 19, 92, 88, 72, 77, 24, 76, 77, 91, 84, 195, 75, 95, 86, 217, 77, 23, 93, 216, 90, 85, 74, 135, 5, 82, 81, 206, 76, 95, 86, 188, 66, 100, 132, 174, 94, 101, 137, 180, 91, 45, 126, 129, 94, 42, 118, 131, 67, 2, 63, 167, 120, 22, 91, 207, 95, 48, 115, 131, 70, 49, 120, 207, 71, 58, 115, 159, 74, 45, 63, 154, 65, 62, 105, 142, 70, 51, 126, 141, 67, 58, 77, 22, 20, 115, 120, 19, 19, 123, 122, 14, 59, 50, 94, 53, 47, 86, 54, 18, 9, 126, 122, 11, 8, 117, 54, 4, 7, 123, 122, 7, 2, 218, 131, 223, 207, 223, 132, 215, 205, 194, 180, 208, 210, 219, 131, 219, 237, 199, 146, 219, 207, 221, 148, 214, 44, 180, 211, 192, 226, 186, 179, 180, 173, 243, 249, 183, 227, 228, 243, 180, 185, 228, 178, 172, 184, 249, 240, 44, 197, 105, 9, 43, 222, 124, 14, 55, 217, 52, 78, 214, 49, 34, 40, 140, 217, 33, 53, 159, 74, 82, 91, 28, 5, 27, 17, 31, 75, 12, 27, 28, 17, 12, 90, 4, 16, 17, 24, 25, 252, 205, 12, 5, 236, 131, 26, 3, 252, 232, 91, 112, 24, 164, 65, 112, 29, 237, 76, 119, 108, 73, 214, 107, 111, 115, 10, 103, 76, 98, 16, 62, 64, 116, 30, 125, 128, 233, 79, 123, 146, 160, 74, 122, 148, 111, 243, 138, 127, 104, 232, 159, 120, 116, 239, 142, 127, 127, 76, 224, 73, 44, 75, 251, 92, 43, 87, 252, 77, 44, 92]);
  const tranquill_2 = self.tranquill_PACK = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  tranquill_2["data"].push(tranquill_1);
  const tranquill_3 = tranquill_2.data.length - 1;
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 0,
    len: 24,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 24,
    len: 31,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 55,
    len: 36,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 91,
    len: 55,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 146,
    len: 63,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 209,
    len: 39,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 248,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 264,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 280,
    len: 14,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 294,
    len: 13,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 307,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 319,
    len: 14,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 333,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 353,
    len: 15,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 368,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 372,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 388,
    len: 49,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 437,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 443,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 448,
    len: 60,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 508,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 518,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 528,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 537,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 546,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 550,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 561,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 571,
    len: 44,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 615,
    len: 43,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 658,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 668,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 678,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 684,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 693,
    len: 45,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 738,
    len: 30,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 768,
    len: 33,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 801,
    len: 45,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 846,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 856,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 865,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 869,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 880,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 889,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 915,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 936,
    len: 22,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 958,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 984,
    len: 22,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1006,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1027,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1035,
    len: 43,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1078,
    len: 31,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1109,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1131,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1136,
    len: 19,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1155,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1165,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1170,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1176,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1195,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1205,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1216,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1221,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1231,
    len: 10,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1241,
    len: 13,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1254,
    len: 13,
    kind: 1
  });
})();
let _tranquill_cond = tranquill_i;
if (_tranquill_cond) {
  new tranquill_i({
    storageKey: tranquill_4,
    logger: tranquill_h,
    chrome: self?.chrome ?? null,
    hwidResolver: tranquill_1o,
    defaultErrorMessage: tranquill_c,
    networkErrorMessage: tranquill_d,
    hwidErrorMessage: tranquill_e
  });
} else {
  null;
}
(function () {
  "use strict";

  const tranquill_4 = tranquill_S("0x6c62272e07bb0142");
  const tranquill_5 = 900;
  const tranquill_6 = 600;
  const tranquill_7 = 900;
  const tranquill_8 = 320;
  const tranquill_9 = 460;
  const tranquill_a = 320;
  const tranquill_b = tranquill_S("0x6c62272e07bb0142");
  const tranquill_c = tranquill_S("0x6c62272e07bb0142");
  const tranquill_d = tranquill_S("0x6c62272e07bb0142");
  const tranquill_e = tranquill_S("0x6c62272e07bb0142");
  const tranquill_f = 250;
  const tranquill_g = 20;
  const tranquill_h = self?.log ?? console;
  const tranquill_i = self?.tranquillLicenseManager;
  const tranquill_j = _tranquill_cond;
  if (!tranquill_j) {
    tranquill_h?.error?.(tranquill_S("0x6c62272e07bb0142"));
    return;
  }
  const tranquill_l = {
    isLoading: false,
    isUnlocked: false,
    originalButtonLabel: null
  };
  document.addEventListener(tranquill_S("0x6c62272e07bb0142"), () => {
    const tranquill_m = document.querySelector(tranquill_S("0x6c62272e07bb0142"));
    const tranquill_n = document["querySelector"](tranquill_S("0x6c62272e07bb0142"));
    const tranquill_o = document["querySelector"](tranquill_S("0x6c62272e07bb0142"));
    const tranquill_p = document.querySelector(tranquill_S("0x6c62272e07bb0142"));
    const tranquill_q = document.querySelector(tranquill_S("0x6c62272e07bb0142"));
    const tranquill_r = document.querySelector(tranquill_S("0x6c62272e07bb0142"));
    const tranquill_s = tranquill_o?.querySelector(tranquill_S("0x6c62272e07bb0142"));
    const tranquill_t = tranquill_s?.querySelector(tranquill_S("0x6c62272e07bb0142"));
    const tranquill_u = document.querySelector(tranquill_S("0x6c62272e07bb0142"));
    if (!tranquill_m || !tranquill_n || !tranquill_o || !tranquill_p || !tranquill_s || !tranquill_t) {
      tranquill_h?.warn?.(tranquill_S("0x6c62272e07bb0142"));
      return;
    }
    tranquill_l.originalButtonLabel = tranquill_t.textContent;
    tranquill_o.addEventListener(tranquill_S("0x6c62272e07bb0142"), tranquill_B => {
      tranquill_B["preventDefault"]();
      void tranquill_T({
        root: tranquill_m,
        container: tranquill_n,
        input: tranquill_p,
        inputGroup: tranquill_r,
        errorEl: tranquill_q,
        button: tranquill_s,
        buttonLabel: tranquill_t,
        successEl: tranquill_u
      });
    });
    tranquill_p.addEventListener(tranquill_S("0x6c62272e07bb0142"), () => {
      tranquill_1f({
        inputGroup: tranquill_r,
        errorEl: tranquill_q
      });
    });
    if (!tranquill_u) {
      tranquill_h?.warn?.(tranquill_S("0x6c62272e07bb0142"));
    }
    void tranquill_D({
      root: tranquill_m,
      container: tranquill_n,
      input: tranquill_p,
      inputGroup: tranquill_r,
      errorEl: tranquill_q,
      button: tranquill_s,
      buttonLabel: tranquill_t,
      successEl: tranquill_u
    });
  });
  async function tranquill_D({
    root: tranquill_E,
    container: tranquill_F,
    input: tranquill_G,
    inputGroup: tranquill_H,
    errorEl: tranquill_I,
    button: tranquill_J,
    buttonLabel: tranquill_K,
    successEl: tranquill_L
  }) {
    let storedLicense = null;
    try {
      storedLicense = await tranquill_j["getStoredLicenseKey"]();
      tranquill_F.classList.remove(tranquill_S("0x6c62272e07bb0142"));
      if (!storedLicense) {
        tranquill_F.classList["remove"](tranquill_S("0x6c62272e07bb0142"));
        tranquill_l.isLoading = false;
        tranquill_l.isUnlocked = false;
        if (tranquill_G) {
          tranquill_G["disabled"] = false;
          requestAnimationFrame(() => {
            try {
              tranquill_G["focus"]();
            } catch (tranquill_M) {}
          });
        }
        if (tranquill_J) {
          tranquill_J.disabled = false;
          tranquill_J.removeAttribute(tranquill_S("0x6c62272e07bb0142"));
        }
        if (tranquill_K) {
          tranquill_K.textContent = tranquill_l.originalButtonLabel;
        }
        return;
      }
      tranquill_l["isUnlocked"] = false;
      tranquill_l.isLoading = true;
      if (tranquill_G) {
        tranquill_G.value = storedLicense;
        tranquill_G.disabled = true;
      }
      if (tranquill_J) {
        tranquill_J.disabled = true;
        tranquill_J.setAttribute(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      }
      if (tranquill_K) {
        tranquill_K.textContent = tranquill_S("0x6c62272e07bb0142");
      }
      tranquill_F.classList.add(tranquill_S("0x6c62272e07bb0142"));
      try {
        await tranquill_1i(storedLicense);
        tranquill_l.isUnlocked = true;
        await tranquill_1X();
        await tranquill_1T({
          root: tranquill_E,
          container: tranquill_F,
          successEl: tranquill_L
        });
        return;
      } catch (tranquill_N) {
        tranquill_h?.warn?.(tranquill_S("0x6c62272e07bb0142"), tranquill_N);
        throw tranquill_N;
      }
    } catch (tranquill_O) {
      tranquill_h?.warn?.(tranquill_S("0x6c62272e07bb0142"), tranquill_O);
      tranquill_F["classList"].remove(tranquill_S("0x6c62272e07bb0142"));
      tranquill_F.classList.remove(tranquill_S("0x6c62272e07bb0142"));
      const tranquill_P = Boolean(tranquill_O && typeof tranquill_O === tranquill_S("0x6c62272e07bb0142") && tranquill_O.shouldClearLicense);
      if (tranquill_P) {
        await tranquill_j["clearStoredLicenseKey"]();
      }
      if (tranquill_G) {
        tranquill_G.disabled = false;
        if (tranquill_P) {
          tranquill_G.value = "";
        } else if (storedLicense) {
          tranquill_G.value = storedLicense;
        }
        requestAnimationFrame(() => {
          try {
            tranquill_G.focus();
          } catch (tranquill_R) {}
        });
      }
      if (tranquill_J) {
        tranquill_J["disabled"] = false;
        tranquill_J.removeAttribute(tranquill_S("0x6c62272e07bb0142"));
      }
      if (tranquill_K) {
        tranquill_K.textContent = tranquill_l.originalButtonLabel;
      }
      tranquill_l.isLoading = false;
      tranquill_l.isUnlocked = false;
      tranquill_1b({
        message: tranquill_O?.message || tranquill_S("0x6c62272e07bb0142"),
        inputGroup: tranquill_H,
        errorEl: tranquill_I
      });
    }
  }
  async function tranquill_T({
    root: tranquill_U,
    container: tranquill_V,
    input: tranquill_W,
    inputGroup: tranquill_X,
    errorEl: tranquill_Y,
    button: tranquill_Z,
    buttonLabel: tranquill_10,
    successEl: tranquill_11
  }) {
    if (tranquill_l.isLoading) {
      return;
    }
    const tranquill_12 = tranquill_W.value.trim();
    if (!tranquill_12) {
      tranquill_1b({
        message: tranquill_S("0x6c62272e07bb0142"),
        inputGroup: tranquill_X,
        errorEl: tranquill_Y
      });
      return;
    }
    tranquill_1f({
      inputGroup: tranquill_X,
      errorEl: tranquill_Y
    });
    tranquill_15({
      container: tranquill_V,
      button: tranquill_Z,
      buttonLabel: tranquill_10,
      input: tranquill_W,
      isLoading: true
    });
    try {
      await tranquill_1i(tranquill_12);
      await tranquill_j["persistLicenseKey"](tranquill_12);
      await tranquill_1s();
      tranquill_l.isUnlocked = true;
      await tranquill_1X();
      await tranquill_1T({
        root: tranquill_U,
        container: tranquill_V,
        successEl: tranquill_11
      });
    } catch (tranquill_14) {
      tranquill_h?.warn?.(tranquill_S("0x6c62272e07bb0142"), tranquill_14?.message || tranquill_14);
      tranquill_l.isUnlocked = false;
      tranquill_1b({
        message: tranquill_14?.message || tranquill_S("0x6c62272e07bb0142"),
        inputGroup: tranquill_X,
        errorEl: tranquill_Y
      });
    } finally {
      if (!tranquill_l.isUnlocked) {
        tranquill_15({
          container: tranquill_V,
          button: tranquill_Z,
          buttonLabel: tranquill_10,
          input: tranquill_W,
          isLoading: false
        });
      }
    }
  }
  function tranquill_15({
    container: tranquill_16,
    button: tranquill_17,
    buttonLabel: tranquill_18,
    input: tranquill_19,
    isLoading: tranquill_1a
  }) {
    tranquill_l.isLoading = tranquill_1a;
    tranquill_16.classList["toggle"](tranquill_S("0x6c62272e07bb0142"), tranquill_1a);
    tranquill_17.disabled = Boolean(tranquill_1a);
    tranquill_19.disabled = Boolean(tranquill_1a);
    if (tranquill_1a) {
      tranquill_17["setAttribute"](tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      tranquill_18.textContent = tranquill_S("0x6c62272e07bb0142");
    } else {
      tranquill_17.removeAttribute(tranquill_S("0x6c62272e07bb0142"));
      tranquill_18.textContent = tranquill_l.originalButtonLabel;
    }
  }
  function tranquill_1b({
    message: tranquill_1c,
    inputGroup: tranquill_1d,
    errorEl: tranquill_1e
  }) {
    if (tranquill_1d) {
      tranquill_1d.classList.add(tranquill_S("0x6c62272e07bb0142"));
    }
    if (tranquill_1e) {
      tranquill_1e.classList["replace"](tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      tranquill_1e.textContent = tranquill_1c;
    }
  }
  function tranquill_1f({
    inputGroup: tranquill_1g,
    errorEl: tranquill_1h
  }) {
    if (tranquill_1g) {
      tranquill_1g.classList.remove(tranquill_S("0x6c62272e07bb0142"));
    }
    if (tranquill_1h) {
      tranquill_1h["classList"].replace(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      tranquill_1h["textContent"] = "";
    }
  }
  async function tranquill_1i(tranquill_1j) {
    const tranquill_1k = tranquill_1j.trim();
    const tranquill_1l = tranquill_5 + Math.floor(Math.random() * tranquill_6);
    const tranquill_1m = tranquill_1J(tranquill_1l);
    try {
      await tranquill_j.validateLicenseKey(tranquill_1k);
      return true;
    } catch (tranquill_1n) {
      if (tranquill_1n instanceof Error) {
        throw tranquill_1n;
      }
      throw new Error(tranquill_c);
    } finally {
      await tranquill_1m;
    }
  }
  function tranquill_1o() {
    const tranquill_1p = window?.tranquillPollHWID;
    if (typeof tranquill_1p !== tranquill_S("0x6c62272e07bb0142")) {
      tranquill_h?.warn?.(tranquill_S("0x6c62272e07bb0142"));
      return Promise.resolve(null);
    }
    return tranquill_1p({
      interval: tranquill_f,
      attempts: tranquill_g
    }).catch(tranquill_1r => {
      tranquill_h?.warn?.(tranquill_S("0x6c62272e07bb0142"), tranquill_1r);
      return null;
    });
  }
  function tranquill_1s() {
    return new Promise(tranquill_1t => {
      if (!chrome?.runtime?.sendMessage) {
        tranquill_1t();
        return;
      }
      try {
        chrome.runtime.sendMessage({
          action: tranquill_S("0x6c62272e07bb0142")
        }, () => tranquill_1t());
      } catch (tranquill_1u) {
        tranquill_1t();
      }
    });
  }
  async function tranquill_1v() {
    tranquill_1z(tranquill_S("0x6c62272e07bb0142"));
    try {
      await tranquill_1G();
    } catch (tranquill_1w) {}
    await tranquill_1J(250);
    const tranquill_1x = new URL(tranquill_S("0x6c62272e07bb0142"), window["location"]["href"]);
    tranquill_1x.searchParams.set(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
    try {
      window.location.replace(tranquill_1x.toString());
    } catch (tranquill_1y) {
      window.location.href = tranquill_1x.toString();
    }
  }
  function tranquill_1z(tranquill_1A) {
    if (typeof tranquill_1A !== tranquill_S("0x6c62272e07bb0142")) {
      return;
    }
    const tranquill_1C = tranquill_1A["trim"]();
    if (!tranquill_1C) {
      return;
    }
    try {
      const tranquill_1E = window?.sessionStorage;
      tranquill_1E?.setItem?.(tranquill_b, tranquill_1C);
    } catch (tranquill_1F) {}
  }
  function tranquill_1G() {
    if (!chrome?.action?.setPopup) {
      return Promise.resolve();
    }
    return new Promise(tranquill_1H => {
      try {
        chrome.action.setPopup({
          popup: tranquill_S("0x6c62272e07bb0142")
        }, () => tranquill_1H());
      } catch (tranquill_1I) {
        tranquill_1H();
      }
    });
  }
  function tranquill_1J(tranquill_1K) {
    return new Promise(tranquill_1L => {
      setTimeout(tranquill_1L, tranquill_1K);
    });
  }
  function tranquill_1M({
    container: tranquill_1N,
    successEl: tranquill_1O
  }) {
    if (!tranquill_1N) {
      return Promise.resolve();
    }
    tranquill_1N.classList.add(tranquill_S("0x6c62272e07bb0142"));
    if (tranquill_1O) {
      tranquill_1O["setAttribute"](tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
    }
    return tranquill_1Y(tranquill_1N, tranquill_8);
  }
  function tranquill_1Q(tranquill_1R) {
    if (!tranquill_1R) {
      return Promise.resolve();
    }
    tranquill_1R.classList["add"](tranquill_S("0x6c62272e07bb0142"));
    return tranquill_1Y(tranquill_1R, tranquill_9);
  }
  async function tranquill_1T({
    root: tranquill_1U,
    container: tranquill_1V,
    successEl: tranquill_1W
  }) {
    if (tranquill_1V) {
      tranquill_1V["classList"].remove(tranquill_S("0x6c62272e07bb0142"));
    }
    await tranquill_1M({
      container: tranquill_1V,
      successEl: tranquill_1W
    });
    await tranquill_1J(tranquill_7);
    await tranquill_1Q(tranquill_1U);
    await tranquill_1v();
  }
  function tranquill_1X() {
    return tranquill_1J(tranquill_a);
  }
  function tranquill_1Y(tranquill_1Z, tranquill_20) {
    return new Promise(tranquill_21 => {
      if (!tranquill_1Z) {
        tranquill_21();
        return;
      }
      let resolved = false;
      const tranquill_23 = () => {
        if (resolved) {
          return;
        }
        resolved = true;
        tranquill_1Z.removeEventListener(tranquill_S("0x6c62272e07bb0142"), tranquill_23);
        tranquill_21();
      };
      tranquill_1Z.addEventListener(tranquill_S("0x6c62272e07bb0142"), tranquill_23);
      const tranquill_24 = Number.isFinite(tranquill_20) ? tranquill_20 : 400;
      setTimeout(tranquill_23, tranquill_24);
    });
  }
})();
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}