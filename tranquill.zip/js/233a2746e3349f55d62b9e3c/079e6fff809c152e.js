var tranquill_runtime_exports = (() => {
        const tranquill_global = typeof self !== "undefined" ? self : globalThis;
        if (tranquill_global.tranquill_runtime_ready) {
                return {
                        tranquill_S: tranquill_global.tranquill_S,
                        tranquill_RN: tranquill_global.tranquill_RN,
                        tranquill_next: tranquill_global.tranquill_next,
                        tranquill_signature: tranquill_global.tranquill_signature,
                        tranquill_seed: tranquill_global.tranquill_seed,
                };
        }
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::457f0536cb00f0db9dec4c0cbf422f54"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        const exports = {
                tranquill_S,
                tranquill_RN,
                tranquill_next,
                tranquill_signature: "tranquill_tranquill_tranquill",
                tranquill_seed: tranquill_global.tranquill_seed,
        };
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = exports.tranquill_signature;
        tranquill_global.tranquill_seed = exports.tranquill_seed;
        tranquill_global.tranquill_runtime_ready = true;
        if (typeof tranquill_global === "object" && tranquill_global) {
                try {
                        tranquill_global.tranquill_runtime = exports;
                } catch (error) {
                        // ignore assignment issues in restricted environments
                }
        }
        if (typeof window !== "undefined") {
                window.tranquill_S = tranquill_S;
                window.tranquill_RN = tranquill_RN;
                window.tranquill_next = tranquill_next;
        }
        if (typeof global !== "undefined") {
                global.tranquill_S = tranquill_S;
                global.tranquill_RN = tranquill_RN;
                global.tranquill_next = tranquill_next;
        }
        return exports;
})();

(function tranquill_0() {
  const tranquill_1 = new Uint8Array([191, 153, 236, 129, 180, 157, 241, 156, 252, 146, 241, 135, 188, 181, 172, 230, 180, 190, 168, 251, 169, 246, 172, 230, 190, 176, 162, 250, 243, 178, 190, 231, 179, 113, 145, 189, 133, 106, 223, 230, 218, 109, 151, 168, 155, 104, 144, 160, 153, 117, 200, 173, 144, 111, 203, 174, 156, 109, 141, 188, 151, 55, 140, 166, 218, 109, 151, 168, 155, 104, 144, 160, 153, 117, 202, 164, 148, 119, 140, 175, 144, 106, 145, 231, 159, 106, 138, 167, 243, 227, 200, 222, 205, 210, 205, 217, 197, 208, 208, 150, 150, 202, 217, 222, 223, 213, 211, 194, 129, 221, 210, 207, 196, 211, 206, 137, 56, 210, 165, 183, 9, 215, 162, 191, 11, 202, 237, 236, 10, 199, 185, 191, 1, 195, 164, 162, 74, 210, 182, 187, 23, 195, 165, 57, 140, 226, 17, 7, 189, 231, 22, 15, 191, 250, 89, 92, 191, 255, 0, 3, 189, 229, 6, 75, 184, 243, 26, 239, 199, 195, 243, 244, 137, 152, 172, 243, 193, 214, 237, 246, 198, 222, 239, 235, 157, 212, 224, 168, 210, 199, 234, 168, 223, 216, 228, 238, 221, 152, 123, 201, 227, 79, 105, 213, 226, 66, 115, 193, 235, 71, 97, 221, 234, 74, 76, 175, 9, 117, 91, 173, 9, 121, 102, 176, 255, 53, 83, 181, 248, 61, 81, 168, 208, 116, 75, 161, 255, 39, 84, 171, 227, 116, 94, 172, 232, 55, 86, 228, 235, 53, 84, 168, 232, 48, 53, 174, 204, 43, 0, 171, 203, 35, 2, 182, 227, 106, 2, 179, 221, 47, 0, 169, 219, 106, 9, 187, 202, 47, 78, 191, 200, 43, 2, 175, 223, 62, 7, 181, 208, 106, 8, 187, 215, 38, 11, 190, 158, 46, 27, 168, 215, 36, 9, 250, 200, 47, 28, 169, 215, 37, 0, 250, 221, 34, 11, 185, 213, 38, 179, 119, 125, 105, 250, 61, 126, 39, 232, 40, 105, 105, 233, 61, 35, 96, 233, 53, 97, 194, 148, 201, 205, 207, 145, 247, 196, 196, 156, 220, 192, 217, 129, 247, 204, 217, 152, 219, 209, 201, 157, 193, 58, 204, 208, 205, 33, 127, 215, 195, 61, 81, 214, 223, 34, 125, 203, 207, 39, 217, 164, 165, 223, 208, 169, 164, 59, 224, 226, 5, 14, 229, 229, 13, 12, 248, 205, 68, 22, 241, 226, 23, 9, 251, 254, 68, 3, 252, 245, 7, 11, 180, 245, 22, 18, 251, 226, 8, 172, 91, 32, 18, 172, 4, 54, 16, 244, 67, 248, 10, 244, 28, 238, 7, 233, 178, 30, 11, 255, 245, 68, 36, 7, 239, 66, 51, 46, 241, 78, 36, 26, 227, 83, 122, 148, 114, 26, 242, 83, 100, 113, 49, 50, 25, 6, 61, 118, 84, 3, 99, 122, 66, 8, 9, 120, 69, 68, 126, 113, 72, 69, 106, 158, 197, 100, 108, 158, 67, 42, 188, 84, 67, 86, 224, 183, 33, 87, 245, 36, 86, 37, 96, 32, 84, 38, 95, 42, 72, 104, 176, 185, 62, 39, 249, 243, 61, 105, 242, 249, 41, 47, 240, 184, 38, 50, 243, 250, 247, 255, 230, 145, 184, 182, 172, 146, 246, 189, 166, 134, 176, 191, 231, 137, 173, 188, 165, 210, 202, 195, 132, 157, 131, 137, 135, 211, 148, 131, 132, 137, 148, 194, 156, 136, 137, 128, 115, 19, 10, 150, 70, 22, 13, 158, 68, 11, 37, 215, 68, 14, 27, 146, 70, 20, 29, 215, 79, 6, 12, 146, 8, 2, 14, 150, 68, 18, 25, 131, 65, 8, 22, 215, 78, 6, 17, 155, 77, 3, 249, 155, 204, 236, 245, 141, 145, 73, 64, 199, 222, 0, 10, 196, 144, 11, 0, 208, 214, 9, 65, 223, 203, 10, 3]);
  const tranquill_2 = self.tranquill_PACK = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  tranquill_2.data.push(tranquill_1);
  const tranquill_3 = tranquill_2.data.length - 1;
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 0,
    len: 13,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 13,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 33,
    len: 55,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 88,
    len: 27,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 115,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 143,
    len: 24,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 167,
    len: 31,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 198,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 206,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 214,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 222,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 254,
    len: 63,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 317,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 337,
    len: 22,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 359,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 363,
    len: 14,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 377,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 384,
    len: 31,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 415,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 423,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 431,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 437,
    len: 14,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 451,
    len: 2,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 453,
    len: 3,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 456,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 463,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 464,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 470,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 471,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 472,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 479,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 485,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 490,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 496,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 506,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 525,
    len: 19,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 544,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 563,
    len: 42,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 605,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 611,
    len: 19,
    kind: 1
  });
})();
const tranquill_4 = chrome["runtime"].getURL(tranquill_S("0x6c62272e07bb0142"));
const tranquill_5 = chrome.runtime.getURL(tranquill_S("0x6c62272e07bb0142"));
const tranquill_6 = tranquill_S("0x6c62272e07bb0142");
const tranquill_7 = tranquill_S("0x6c62272e07bb0142");
const tranquill_8 = tranquill_S("0x6c62272e07bb0142");
const tranquill_9 = tranquill_S("0x6c62272e07bb0142");
const tranquill_a = tranquill_S("0x6c62272e07bb0142");
const tranquill_b = self?.tranquillLicenseManager;
const tranquill_c = tranquill_b ? new tranquill_b({
  storageKey: tranquill_9,
  validationEndpoint: tranquill_a,
  logger: console,
  chrome: self?.chrome ?? null,
  hwidResolver: () => {
    if (typeof ensureDeviceHWID === tranquill_S("0x6c62272e07bb0142")) {
      return ensureDeviceHWID();
    }
    const tranquill_d = self?.ensureDeviceHWID;
    if (typeof tranquill_d === tranquill_S("0x6c62272e07bb0142")) {
      return tranquill_d();
    }
    return null;
  }
}) : null;
self.addEventListener(tranquill_S("0x6c62272e07bb0142"), tranquill_f => {
  tranquill_f.waitUntil(tranquill_g());
});
if (chrome?.runtime?.onStartup) {
  chrome.runtime.onStartup["addListener"](() => {
    tranquill_g();
  });
}
void tranquill_g();
async function tranquill_g() {
  let isNewVersionAvailable = false;
  try {
    isNewVersionAvailable = Boolean(await tranquill_j());
  } catch (tranquill_h) {
    console?.warn?.(tranquill_S("0x6c62272e07bb0142"), tranquill_h);
  }
  try {
    await tranquill_1w();
  } catch (tranquill_i) {
    console?.warn?.(tranquill_S("0x6c62272e07bb0142"), tranquill_i);
  }
  if (isNewVersionAvailable) {
    await tranquill_1C(tranquill_S("0x6c62272e07bb0142"));
  }
}
async function tranquill_j() {
  try {
    const [tranquill_k, tranquill_l, tranquill_m] = await Promise.all([tranquill_v(), tranquill_z(), tranquill_x()]);
    const tranquill_n = tranquill_l?.canonicalManifest || tranquill_k || null;
    if (!tranquill_n && !tranquill_m) {
      return false;
    }
    const [tranquill_q, tranquill_r] = await Promise.all([tranquill_n ? tranquill_J(tranquill_n, {
      normalizePaths: true
    }) : null, tranquill_m ? tranquill_J(tranquill_m, {
      normalizePaths: true
    }) : null]);
    const tranquill_s = tranquill_l?.hashedManifestDigest || null;
    let actualHashedDigest = null;
    const tranquill_t = [];
    if (tranquill_s && tranquill_k) {
      actualHashedDigest = await tranquill_J(tranquill_k, {
        normalizePaths: false
      });
      if (actualHashedDigest && actualHashedDigest !== tranquill_s) {
        tranquill_t.push({
          type: tranquill_S("0x6c62272e07bb0142"),
          expected: tranquill_s,
          actual: actualHashedDigest
        });
      }
    }
    let anchor = await tranquill_Z({
      localManifest: tranquill_n,
      localDigest: tranquill_q,
      remoteManifest: tranquill_m,
      remoteDigest: tranquill_r
    });
    if (!anchor) {
      return false;
    }
    let manifestInSync = tranquill_t.length === 0;
    let tamperDetected = false;
    if (tranquill_q && anchor.manifestDigest && tranquill_q !== anchor.manifestDigest) {
      if (tranquill_r && tranquill_q === tranquill_r && tranquill_m) {
        anchor = await tranquill_1f({
          version: tranquill_m.version,
          manifestDigest: tranquill_q,
          reason: tranquill_S("0x6c62272e07bb0142")
        });
        manifestInSync = true;
      } else {
        manifestInSync = false;
        tranquill_t.push({
          type: tranquill_S("0x6c62272e07bb0142"),
          anchorDigest: anchor.manifestDigest || null,
          localDigest: tranquill_q,
          remoteDigest: tranquill_r || null
        });
      }
    } else if (!anchor.manifestDigest && tranquill_q) {
      anchor = await tranquill_1f({
        version: anchor.version,
        manifestDigest: tranquill_q,
        reason: tranquill_S("0x6c62272e07bb0142")
      });
      manifestInSync = manifestInSync && tranquill_t.length === 0;
    }
    if (tranquill_t.length) {
      manifestInSync = false;
      tamperDetected = true;
      await tranquill_1k({
        anchorDigest: anchor.manifestDigest || null,
        localDigest: tranquill_q,
        remoteDigest: tranquill_r,
        hashedDigestExpected: tranquill_s,
        hashedDigestActual: actualHashedDigest,
        reasons: tranquill_t
      });
    } else if (manifestInSync) {
      await tranquill_1p();
    }
    if (tamperDetected) {
      await tranquill_1r(tranquill_m?.version ?? anchor.version ?? null);
      return true;
    }
    if (tranquill_m && tranquill_m.version && tranquill_m.version !== anchor.version) {
      await tranquill_1r(tranquill_m.version);
      return true;
    }
    if (tranquill_r && anchor.manifestDigest && tranquill_r !== anchor.manifestDigest) {
      await tranquill_1r(tranquill_m?.version ?? null);
      return true;
    }
    await tranquill_1u();
    return false;
  } catch (tranquill_u) {
    console?.warn?.(tranquill_S("0x6c62272e07bb0142"), tranquill_u);
    return false;
  }
}
function tranquill_v() {
  return fetch(tranquill_4).then(tranquill_w => tranquill_w.json()).catch(() => null);
}
function tranquill_x() {
  return fetch(tranquill_6, {
    cache: tranquill_S("0x6c62272e07bb0142")
  })["then"](tranquill_y => tranquill_y.json())["catch"](() => null);
}
function tranquill_z() {
  return fetch(tranquill_5, {
    cache: tranquill_S("0x6c62272e07bb0142")
  }).then(tranquill_A => {
    if (!tranquill_A?.ok) {
      return null;
    }
    return tranquill_A.json();
  })["catch"](() => null);
}
const tranquill_B = tranquill_C => tranquill_C !== null && typeof tranquill_C === tranquill_S("0x6c62272e07bb0142") && !Array.isArray(tranquill_C);
function tranquill_E(tranquill_F) {
  if (!tranquill_B(tranquill_F)) {
    return tranquill_F;
  }
  const tranquill_G = JSON["parse"](JSON.stringify(tranquill_F));
  if (tranquill_B(tranquill_G.background)) {
    if (Object.prototype.hasOwnProperty["call"](tranquill_G.background, tranquill_S("0x6c62272e07bb0142"))) {
      delete tranquill_G["background"].service_worker;
    }
    if (!Object["keys"](tranquill_G["background"]).length) {
      delete tranquill_G.background;
    }
  }
  if (Array.isArray(tranquill_G.content_scripts)) {
    tranquill_G.content_scripts = tranquill_G.content_scripts.map(tranquill_H => {
      if (!tranquill_B(tranquill_H)) {
        return tranquill_H;
      }
      const tranquill_I = {
        ...tranquill_H
      };
      if (Object["prototype"]["hasOwnProperty"].call(tranquill_I, tranquill_S("0x6c62272e07bb0142"))) {
        delete tranquill_I.js;
      }
      if (Object.prototype["hasOwnProperty"].call(tranquill_I, tranquill_S("0x6c62272e07bb0142"))) {
        delete tranquill_I.css;
      }
      return tranquill_I;
    });
  }
  return tranquill_G;
}
async function tranquill_J(tranquill_K, {
  normalizePaths: tranquill_L = true
} = {}) {
  if (!crypto?.subtle?.digest || tranquill_K == null) {
    return null;
  }
  const tranquill_M = tranquill_L ? tranquill_E(tranquill_K) : tranquill_K;
  const tranquill_N = tranquill_R(tranquill_M);
  const tranquill_O = new TextEncoder().encode(tranquill_N);
  const tranquill_P = await crypto["subtle"].digest(tranquill_S("0x6c62272e07bb0142"), tranquill_O);
  return Array["from"](new Uint8Array(tranquill_P)).map(tranquill_Q => tranquill_Q.toString(16).padStart(2, tranquill_S("0x6c62272e07bb0142"))).join("");
}
function tranquill_R(tranquill_T) {
  if (tranquill_T === null || typeof tranquill_T !== tranquill_S("0x6c62272e07bb0142")) {
    return JSON.stringify(tranquill_T);
  }
  if (Array["isArray"](tranquill_T)) {
    const tranquill_V = tranquill_T.map(tranquill_W => tranquill_R(tranquill_W));
    return `[${tranquill_V["join"](tranquill_S("0x6c62272e07bb0142"))}]`;
  }
  const tranquill_X = Object["keys"](tranquill_T).sort()["map"](tranquill_Y => `${JSON.stringify(tranquill_Y)}:${tranquill_R(tranquill_T[tranquill_Y])}`);
  return `{${tranquill_X.join(tranquill_S("0x6c62272e07bb0142"))}}`;
}
async function tranquill_Z({
  localManifest: tranquill_10,
  localDigest: tranquill_11,
  remoteManifest: tranquill_12,
  remoteDigest: tranquill_13
}) {
  const tranquill_14 = await tranquill_19();
  if (tranquill_14?.version) {
    if (!tranquill_14.manifestDigest && tranquill_11) {
      return tranquill_1f({
        version: tranquill_14.version,
        manifestDigest: tranquill_11,
        reason: tranquill_S("0x6c62272e07bb0142")
      });
    }
    return tranquill_14;
  }
  const tranquill_15 = tranquill_12 || tranquill_10;
  if (!tranquill_15) {
    return null;
  }
  const tranquill_17 = tranquill_13 || tranquill_11;
  const tranquill_18 = {
    version: tranquill_15["version"],
    manifestDigest: tranquill_17 || null,
    timestamp: Date["now"](),
    source: tranquill_12 ? tranquill_S("0x6c62272e07bb0142") : tranquill_S("0x6c62272e07bb0142")
  };
  await tranquill_1c(tranquill_18);
  return tranquill_18;
}
async function tranquill_19() {
  return new Promise(tranquill_1a => {
    chrome.storage.local["get"](tranquill_7, tranquill_1b => {
      tranquill_1a(tranquill_1b?.[tranquill_7] || null);
    });
  });
}
async function tranquill_1c(tranquill_1d) {
  return new Promise(tranquill_1e => {
    chrome.storage.local.set({
      [tranquill_7]: tranquill_1d
    }, () => tranquill_1e());
  });
}
async function tranquill_1f({
  version: tranquill_1g,
  manifestDigest: tranquill_1h,
  reason: tranquill_1i
}) {
  const tranquill_1j = {
    version: tranquill_1g,
    manifestDigest: tranquill_1h || null,
    reason: tranquill_1i || tranquill_S("0x6c62272e07bb0142"),
    timestamp: Date.now()
  };
  await tranquill_1c(tranquill_1j);
  return tranquill_1j;
}
async function tranquill_1k(tranquill_1l) {
  return new Promise(tranquill_1m => {
    const tranquill_1n = Array.isArray(tranquill_1l?.reasons) ? tranquill_1l["reasons"].map(tranquill_1o => ({
      ...tranquill_1o
    })) : [];
    chrome.storage.local.set({
      [tranquill_8]: {
        detectedAt: Date.now(),
        details: {
          anchorDigest: tranquill_1l?.anchorDigest ?? null,
          localDigest: tranquill_1l?.localDigest ?? null,
          remoteDigest: tranquill_1l?.remoteDigest ?? null,
          hashedDigestExpected: tranquill_1l?.hashedDigestExpected ?? null,
          hashedDigestActual: tranquill_1l?.hashedDigestActual ?? null,
          reasons: tranquill_1n
        }
      }
    }, () => tranquill_1m());
  });
}
async function tranquill_1p() {
  return new Promise(tranquill_1q => {
    chrome.storage["local"].remove(tranquill_8, () => tranquill_1q());
  });
}
async function tranquill_1r(tranquill_1s) {
  return new Promise(tranquill_1t => {
    chrome.storage.local["set"]({
      appVersion: tranquill_1s
    }, () => {
      tranquill_1t();
    });
  });
}
async function tranquill_1u() {
  return new Promise(tranquill_1v => {
    chrome.storage.local["remove"](tranquill_S("0x6c62272e07bb0142"), () => tranquill_1v());
  });
}
async function tranquill_1w() {
  if (!tranquill_c) {
    await tranquill_1C(tranquill_S("0x6c62272e07bb0142"));
    return false;
  }
  try {
    const tranquill_1y = await tranquill_c.gateLicenseKey({
      requireValidation: true
    });
    if (!tranquill_1y?.unlocked) {
      await tranquill_1C(tranquill_S("0x6c62272e07bb0142"));
      return false;
    }
    await tranquill_1C(tranquill_S("0x6c62272e07bb0142"));
    return true;
  } catch (tranquill_1z) {
    console?.warn?.(tranquill_S("0x6c62272e07bb0142"), tranquill_1z);
    if (tranquill_1z && typeof tranquill_1z === tranquill_S("0x6c62272e07bb0142") && tranquill_1z["shouldClearLicense"]) {
      try {
        await tranquill_c.clearStoredLicenseKey();
      } catch (tranquill_1B) {}
    }
    await tranquill_1C(tranquill_S("0x6c62272e07bb0142"));
    return false;
  }
}
async function tranquill_1C(tranquill_1D) {
  if (!chrome?.action?.setPopup) {
    return false;
  }
  return new Promise(tranquill_1E => {
    try {
      chrome["action"].setPopup({
        popup: tranquill_1D
      }, () => {
        if (chrome.runtime?.lastError) {
          console?.warn?.(`[tranquill] failed to set popup to "${tranquill_1D}"`, chrome.runtime["lastError"]);
        }
        tranquill_1E(true);
      });
    } catch (tranquill_1F) {
      console?.warn?.(`[tranquill] exception while setting popup to "${tranquill_1D}"`, tranquill_1F);
      tranquill_1E(false);
    }
  });
}
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}