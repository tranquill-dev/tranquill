var tranquill_runtime_exports = (() => {
        const tranquill_global = typeof self !== "undefined" ? self : globalThis;
        if (tranquill_global.tranquill_runtime_ready) {
                return {
                        tranquill_S: tranquill_global.tranquill_S,
                        tranquill_RN: tranquill_global.tranquill_RN,
                        tranquill_next: tranquill_global.tranquill_next,
                        tranquill_signature: tranquill_global.tranquill_signature,
                        tranquill_seed: tranquill_global.tranquill_seed,
                };
        }
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::457f0536cb00f0db9dec4c0cbf422f54"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        const exports = {
                tranquill_S,
                tranquill_RN,
                tranquill_next,
                tranquill_signature: "tranquill_tranquill_tranquill",
                tranquill_seed: tranquill_global.tranquill_seed,
        };
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = exports.tranquill_signature;
        tranquill_global.tranquill_seed = exports.tranquill_seed;
        tranquill_global.tranquill_runtime_ready = true;
        if (typeof tranquill_global === "object" && tranquill_global) {
                try {
                        tranquill_global.tranquill_runtime = exports;
                } catch (error) {
                        // ignore assignment issues in restricted environments
                }
        }
        if (typeof window !== "undefined") {
                window.tranquill_S = tranquill_S;
                window.tranquill_RN = tranquill_RN;
                window.tranquill_next = tranquill_next;
        }
        if (typeof global !== "undefined") {
                global.tranquill_S = tranquill_S;
                global.tranquill_RN = tranquill_RN;
                global.tranquill_next = tranquill_next;
        }
        return exports;
})();

(function tranquill_0() {
  const tranquill_1 = new Uint8Array([165, 143, 177, 143, 191, 145, 146, 131, 165, 130, 168, 136, 182, 133, 130, 31, 84, 189, 183, 9, 152, 129, 206, 163, 173, 151, 188, 226, 73, 181, 176, 244, 154, 178, 235, 159, 135, 161, 156, 48, 109, 157, 129, 35, 150, 190, 231, 147, 139, 173, 190, 44, 255, 132, 76, 49, 229, 133, 183, 50, 50, 164, 245, 110, 139, 131, 248, 92, 9, 241, 229, 79, 166, 208, 129, 18, 194, 230, 244, 88, 5, 245, 233, 75, 238, 198, 159, 235, 243, 213, 182, 21, 6, 144, 96, 231, 161, 170, 107, 244, 166, 144, 113, 252, 167, 162, 98, 246, 251, 173, 106, 225, 184, 162, 105, 250, 175, 166, 37, 187, 166, 166, 113, 231, 188, 173, 98, 224, 245, 179, 100, 244, 176, 234, 32, 134, 213, 49, 44, 144, 38, 7, 27, 52, 33, 9, 26, 11, 165, 21, 37, 30, 140, 31, 46, 44, 218, 187, 251, 22, 209, 168, 252, 44, 203, 160, 253, 30, 216, 170, 161, 24, 218, 187, 220, 26, 203, 187, 230, 17, 216, 188, 175, 87, 204, 170, 251, 11, 214, 161, 232, 12, 159, 191, 238, 24, 218, 230, 96, 201, 87, 40, 90, 194, 68, 47, 96, 216, 76, 46, 82, 203, 70, 114, 84, 201, 87, 15, 86, 216, 87, 53, 93, 203, 80, 124, 85, 205, 74, 48, 86, 200, 16, 55, 135, 54, 42, 60, 148, 49, 16, 38, 156, 48, 34, 53, 150, 108, 36, 55, 135, 17, 38, 38, 135, 43, 45, 53, 128, 98, 49, 55, 128, 45, 47, 36, 150, 38, 140, 107, 59, 170, 182, 96, 40, 173, 140, 122, 32, 172, 190, 105, 42, 240, 172, 111, 57, 187, 140, 107, 59, 170, 182, 96, 40, 173, 87, 105, 128, 136, 109, 98, 147, 143, 87, 120, 155, 142, 101, 107, 145, 210, 119, 109, 130, 153, 87, 105, 128, 136, 109, 98, 147, 143, 36, 106, 149, 149, 104, 105, 144, 245, 10, 162, 171, 207, 1, 177, 172, 245, 27, 185, 173, 199, 8, 179, 241, 213, 14, 160, 186, 245, 10, 162, 171, 207, 1, 177, 172, 134, 28, 163, 188, 197, 10, 165, 172, 159, 246, 72, 183, 165, 253, 91, 176, 156, 242, 91, 166, 143, 252, 82, 183, 190, 252, 80, 175, 169, 225, 28, 160, 163, 253, 79, 183, 190, 230, 95, 183, 169, 247, 44, 92, 187, 253, 22, 87, 168, 250, 47, 88, 168, 236, 60, 86, 161, 253, 13, 86, 163, 229, 26, 75, 225, 224, 17, 80, 187, 169, 12, 77, 174, 251, 11, 204, 125, 219, 28, 246, 118, 200, 27, 207, 121, 200, 13, 220, 119, 193, 28, 237, 119, 195, 4, 250, 106, 143, 1, 241, 113, 219, 1, 254, 116, 198, 18, 250, 124, 29, 77, 102, 90, 71, 87, 109, 73, 64, 19, 112, 66, 90, 90, 102, 92, 18, 83, 73, 68, 72, 73, 66, 87, 79, 13, 95, 92, 85, 68, 73, 66, 99, 127, 90, 81, 80, 85, 73, 102, 181, 235, 98, 56, 183, 249, 33, 60, 176, 245, 98, 60, 176, 255, 40, 36, 186, 246, 167, 251, 240, 185, 175, 231, 175, 172, 224, 227, 184, 161, 224, 234, 168, 172, 185, 231, 179, 213, 195, 88, 212, 154, 203, 68, 139, 143, 132, 64, 156, 130, 132, 79, 144, 136, 217, 71, 152, 130, 61, 54, 80, 33, 114, 62, 76, 126, 103, 113, 72, 105, 106, 113, 75, 101, 125, 40, 188, 163, 39, 212, 230, 185, 44, 199, 225, 253, 32, 193, 241, 187, 111, 194, 231, 164, 54, 207, 252, 235, 152, 60, 185, 209, 147, 47, 190, 232, 156, 47, 168, 251, 146, 38, 185, 202, 146, 36, 161, 221, 143, 104, 174, 217, 158, 32, 168, 253, 145, 45, 160, 221, 147, 60, 190, 34, 71, 203, 44, 63, 51, 103, 228, 38, 9, 108, 247, 33, 64, 113, 252, 59, 4, 103, 226, 114, 9, 108, 224, 39, 20, 55, 215, 133, 33, 51, 218, 41, 64, 30, 1, 19, 75, 13, 6, 90, 86, 6, 28, 30, 64, 24, 85, 25, 77, 11, 27, 29, 64, 227, 251, 177, 13, 231, 246, 193, 73, 64, 255, 229, 78, 76, 177, 252, 78, 69, 244, 177, 85, 78, 246, 246, 77, 68, 177, 242, 73, 64, 255, 246, 68, 69, 113, 44, 203, 115, 121, 116, 17, 142, 110, 124, 49, 201, 22, 93, 50, 135, 1, 87, 49, 221, 1, 22, 41, 220, 28, 84, 51, 218, 182, 86, 52, 193, 163, 81, 40, 198, 81, 127, 163, 75, 176, 127, 39, 158, 138, 116, 52, 153, 195, 120, 50, 137, 136, 58, 49, 159, 151, 110, 60, 132, 195, 121, 63, 131, 128, 113, 54, 142, 177, 159, 67, 171, 112, 155, 93, 99, 119, 147, 73, 111, 87, 131, 67, 99, 109, 157, 96, 122, 102, 159, 87, 42, 101, 155, 95, 102, 97, 155, 80, 97, 123, 129, 182, 121, 124, 137, 162, 117, 92, 153, 168, 121, 102, 135, 139, 96, 109, 133, 188, 209, 234, 238, 247, 242, 239, 167, 239, 248, 171, 235, 244, 246, 239, 167, 232, 242, 255, 243, 242, 249, 236, 244, 151, 79, 192, 206, 173, 68, 211, 201, 228, 88, 209, 201, 176, 69, 198, 223, 160, 180, 43, 149, 167, 172, 8, 128, 191, 161, 50, 139, 172, 166, 15, 138, 158, 156, 4, 254, 37, 63, 37, 235, 37, 126, 34, 226, 40, 58, 52, 252, 97, 58, 56, 253, 49, 50, 48, 247, 48, 136, 21, 57, 19, 218, 17, 36, 25, 218, 27, 47, 25, 40, 227, 242, 28, 0, 175, 239, 16, 75, 236, 243, 30, 5, 232, 254, 228, 69, 211, 4, 254, 78, 192, 3, 186, 75, 194, 9, 245, 73, 201, 20, 186, 66, 210, 4, 227, 79, 201, 93, 186, 76, 206, 3, 227, 69, 201, 25, 249, 71, 127, 93, 93, 108, 123, 79, 74, 76, 171, 107, 69, 12, 153, 18, 57, 57, 219, 22, 46, 52, 219, 30, 42, 61, 143, 8, 57, 40, 219, 14, 63, 44, 137, 9, 46, 41, 156, 100, 162, 164, 169, 38, 166, 179, 164, 38, 174, 183, 173, 114, 184, 164, 184, 98, 177, 19, 19, 162, 181, 1, 4, 182, 173, 17, 163, 176, 163, 174, 131, 133, 225, 170, 148, 136, 225, 162, 144, 129, 181, 180, 131, 148, 225, 162, 144, 159, 162, 164, 157, 157, 164, 165, 98, 69, 16, 131, 123, 83, 22, 163, 119, 84, 22, 153, 124, 71, 17, 208, 97, 75, 11, 128, 98, 69, 6, 203, 50, 78, 13, 132, 50, 82, 7, 131, 102, 79, 16, 149, 118, 249, 100, 206, 197, 195, 111, 221, 194, 138, 113, 223, 195, 217, 104, 201, 197, 207, 101, 241, 10, 14, 215, 210, 15, 71, 207, 216, 75, 20, 218, 193, 14, 71, 200, 210, 31, 19, 210, 217, 12, 20, 53, 141, 138, 240, 22, 136, 195, 232, 28, 204, 138, 242, 26, 152, 138, 253, 31, 133, 153, 249, 83, 159, 134, 232, 7, 133, 141, 251, 0, 204, 147, 253, 20, 137, 68, 51, 168, 229, 14, 57, 174, 243, 71, 60, 179, 238, 1, 5, 104, 43, 0, 12, 108, 250, 233, 116, 29, 242, 246, 126, 1, 252, 13, 61, 118, 106, 87, 39, 125, 121, 80, 99, 124, 110, 87, 39, 124, 112, 85, 42, 20, 124, 81, 45, 24, 63, 81, 45, 18, 117, 73, 39, 32, 202, 30, 74, 53, 133, 26, 93, 56, 133, 30, 72, 53, 193, 30, 86, 42, 205, 29, 44, 48, 198, 14, 43, 116, 199, 25, 44, 48, 199, 7, 117, 61, 193, 26, 57, 59, 196, 12, 60, 173, 28, 149, 191, 225, 10, 149, 173, 173, 12, 144, 187, 168, 150, 65, 135, 166, 129, 90, 118, 155, 155, 81, 101, 156, 223, 80, 114, 155, 155, 80, 108, 194, 150, 86, 113, 142, 144, 83, 103, 139, 100, 85, 252, 150, 40, 67, 252, 132, 100, 69, 249, 146, 97, 228, 203, 217, 240, 225, 202, 223, 226, 196, 155, 216, 201, 229, 162, 254, 200, 255, 154, 244, 199, 239, 179, 255]);
  const tranquill_2 = self.tranquill_PACK = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  tranquill_2["data"].push(tranquill_1);
  const tranquill_3 = tranquill_2.data.length - 1;
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 0,
    len: 14,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 14,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 20,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 26,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 32,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 38,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 44,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 50,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 54,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 58,
    len: 3,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 61,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 66,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 72,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 73,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 78,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 84,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 90,
    len: 3,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 93,
    len: 41,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 134,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 140,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 147,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 155,
    len: 43,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 198,
    len: 34,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 232,
    len: 36,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 268,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 296,
    len: 35,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 331,
    len: 36,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 367,
    len: 34,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 401,
    len: 33,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 434,
    len: 34,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 468,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 484,
    len: 23,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 507,
    len: 18,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 525,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 545,
    len: 21,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 566,
    len: 18,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 584,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 605,
    len: 36,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 641,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 646,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 667,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 673,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 695,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 701,
    len: 27,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 728,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 733,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 738,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 754,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 764,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 768,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 796,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 800,
    len: 28,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 828,
    len: 19,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 847,
    len: 23,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 870,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 887,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 904,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 926,
    len: 13,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 939,
    len: 15,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 954,
    len: 34,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 988,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 995,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 999,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1024,
    len: 18,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1042,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1049,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1053,
    len: 27,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1080,
    len: 37,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1117,
    len: 18,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1135,
    len: 23,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1158,
    len: 34,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1192,
    len: 13,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1205,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1211,
    len: 9,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1220,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1236,
    len: 14,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1250,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1266,
    len: 24,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1290,
    len: 13,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1303,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1307,
    len: 24,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1331,
    len: 13,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1344,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1351,
    len: 16,
    kind: 1
  });
})();
(function () {
  const tranquill_4 = tranquill_S("0x6c62272e07bb0142");
  const tranquill_5 = 60;
  const tranquill_6 = 200;
  const tranquill_7 = Object.freeze({
    key: tranquill_S("0x6c62272e07bb0142"),
    code: tranquill_S("0x6c62272e07bb0142"),
    altKey: false,
    ctrlKey: false,
    metaKey: false,
    shiftKey: false
  });
  const tranquill_8 = tranquill_9 => {
    if (tranquill_9 && typeof tranquill_9 === tranquill_S("0x6c62272e07bb0142")) {
      const tranquill_b = typeof tranquill_9.key === tranquill_S("0x6c62272e07bb0142") && tranquill_9.key.length > 0 ? tranquill_9["key"] : tranquill_7.key;
      const tranquill_c = typeof tranquill_9["code"] === tranquill_S("0x6c62272e07bb0142") && tranquill_9.code["length"] > 0 ? tranquill_9.code : tranquill_b;
      return {
        key: tranquill_b,
        code: tranquill_c,
        altKey: tranquill_9.altKey === true,
        ctrlKey: tranquill_9["ctrlKey"] === true,
        metaKey: tranquill_9.metaKey === true,
        shiftKey: tranquill_9.shiftKey === true
      };
    }
    if (typeof tranquill_9 === tranquill_S("0x6c62272e07bb0142") && tranquill_9.trim().length > 0) {
      const tranquill_e = tranquill_9["trim"]();
      return {
        key: tranquill_e,
        code: tranquill_e,
        altKey: false,
        ctrlKey: false,
        metaKey: false,
        shiftKey: false
      };
    }
    return {
      ...tranquill_7
    };
  };
  const tranquill_f = tranquill_g => {
    const tranquill_h = tranquill_8(tranquill_g);
    const tranquill_i = [];
    if (tranquill_h.ctrlKey) tranquill_i.push(tranquill_S("0x6c62272e07bb0142"));
    if (tranquill_h.metaKey) tranquill_i["push"](tranquill_S("0x6c62272e07bb0142"));
    if (tranquill_h.altKey) tranquill_i.push(tranquill_S("0x6c62272e07bb0142"));
    if (tranquill_h.shiftKey) tranquill_i.push(tranquill_S("0x6c62272e07bb0142"));
    let base = tranquill_h["key"];
    if (typeof base !== tranquill_S("0x6c62272e07bb0142") || base.length === 0) {
      base = tranquill_h.code;
    }
    if (base === tranquill_S("0x6c62272e07bb0142")) base = tranquill_S("0x6c62272e07bb0142");
    if (typeof base === tranquill_S("0x6c62272e07bb0142") && base.length === 1) {
      base = base.toUpperCase();
    }
    if (typeof base === tranquill_S("0x6c62272e07bb0142") && base.length > 1) {
      base = `${base.charAt(0).toUpperCase()}${base.slice(1)}`;
    }
    tranquill_i["push"](base);
    return tranquill_i["join"](tranquill_S("0x6c62272e07bb0142"));
  };
  const tranquill_j = tranquill_k => tranquill_8({
    key: tranquill_k["key"],
    code: tranquill_k.code,
    altKey: tranquill_k.altKey,
    ctrlKey: tranquill_k["ctrlKey"],
    metaKey: tranquill_k["metaKey"],
    shiftKey: tranquill_k.shiftKey
  });
  class tranquill_l {
    static get defaults() {
      return {
        typingSpeed: 120,
        phantomMode: false,
        abortKey: tranquill_8(tranquill_7)
      };
    }
    static normalize(tranquill_m) {
      log["debug"](tranquill_S("0x6c62272e07bb0142"), {
        rawSettings: tranquill_m
      });
      const tranquill_n = tranquill_l["defaults"];
      const tranquill_o = {
        ...tranquill_n,
        abortKey: tranquill_8(tranquill_n["abortKey"])
      };
      if (tranquill_m && typeof tranquill_m === tranquill_S("0x6c62272e07bb0142")) {
        const tranquill_q = Number.parseInt(tranquill_m.typingSpeed, 10);
        if (Number["isFinite"](tranquill_q)) {
          tranquill_o.typingSpeed = Math.min(tranquill_6, Math.max(tranquill_5, tranquill_q));
        }
        if (typeof tranquill_m.phantomMode === tranquill_S("0x6c62272e07bb0142")) {
          tranquill_o["phantomMode"] = tranquill_m.phantomMode;
        }
        if (Object.prototype.hasOwnProperty["call"](tranquill_m, tranquill_S("0x6c62272e07bb0142"))) {
          tranquill_o.abortKey = tranquill_8(tranquill_m.abortKey);
        }
      }
      return tranquill_o;
    }
    static getSettings() {
      log.debug(tranquill_S("0x6c62272e07bb0142"));
      return new Promise((tranquill_r, tranquill_s) => {
        chrome.storage.local.get(tranquill_4, tranquill_t => {
          if (chrome.runtime["lastError"]) {
            const tranquill_u = new Error(chrome.runtime["lastError"].message);
            log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_u);
            tranquill_s(tranquill_u);
            return;
          }
          const tranquill_v = tranquill_t[tranquill_4];
          const tranquill_w = tranquill_l.normalize(tranquill_v);
          log["debug"](tranquill_S("0x6c62272e07bb0142"), tranquill_w);
          tranquill_r(tranquill_w);
        });
      });
    }
    static saveSettings(tranquill_x) {
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        settings: tranquill_x
      });
      const tranquill_y = tranquill_l["normalize"](tranquill_x);
      return new Promise((tranquill_z, tranquill_A) => {
        chrome.storage.local.set({
          [tranquill_4]: tranquill_y
        }, () => {
          if (chrome["runtime"].lastError) {
            const tranquill_B = new Error(chrome["runtime"].lastError.message);
            log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_B);
            tranquill_A(tranquill_B);
            return;
          }
          log.debug(tranquill_S("0x6c62272e07bb0142"), tranquill_y);
          tranquill_z(tranquill_y);
        });
      });
    }
  }
  class tranquill_C {
    constructor(tranquill_D) {
      this.documentRef = tranquill_D;
      this.slider = null;
      this["sliderValue"] = null;
      this["phantomToggle"] = null;
      this.abortKeyButton = null;
      this["abortKeyValue"] = null;
      this["abortKeyHint"] = null;
      this["backButton"] = null;
      this.currentSettings = tranquill_l["defaults"];
      this.isRestored = false;
      this.isCapturingAbortKey = false;
      this.abortKeyCaptureHandler = null;
      this.abortKeyBlurHandler = null;
      log.debug(tranquill_S("0x6c62272e07bb0142"));
    }
    async init() {
      log.debug(tranquill_S("0x6c62272e07bb0142"));
      this.cacheElements();
      this.registerEventListeners();
      await this.restoreSettings();
      log.info(tranquill_S("0x6c62272e07bb0142"));
    }
    cacheElements() {
      this.slider = this["documentRef"].querySelector(tranquill_S("0x6c62272e07bb0142"));
      this.sliderValue = this.documentRef["querySelector"](tranquill_S("0x6c62272e07bb0142"));
      this["phantomToggle"] = this.documentRef.querySelector(tranquill_S("0x6c62272e07bb0142"));
      this.abortKeyButton = this.documentRef["querySelector"](tranquill_S("0x6c62272e07bb0142"));
      if (this["abortKeyButton"]) {
        this.abortKeyValue = this.abortKeyButton.querySelector(tranquill_S("0x6c62272e07bb0142"));
        this.abortKeyHint = this.abortKeyButton.querySelector(tranquill_S("0x6c62272e07bb0142"));
      } else {
        this["abortKeyValue"] = null;
        this["abortKeyHint"] = null;
      }
      this.backButton = this.documentRef.querySelector(tranquill_S("0x6c62272e07bb0142"));
      log["debug"](tranquill_S("0x6c62272e07bb0142"), {
        hasSlider: Boolean(this["slider"]),
        hasPhantomToggle: Boolean(this["phantomToggle"]),
        hasAbortKeyButton: Boolean(this["abortKeyButton"])
      });
    }
    registerEventListeners() {
      if (this["slider"]) {
        this.slider.addEventListener(tranquill_S("0x6c62272e07bb0142"), () => {
          const tranquill_E = this.sanitizeTypingSpeed(this.slider.value);
          this.updateSliderDisplay(tranquill_E);
          log.debug(tranquill_S("0x6c62272e07bb0142"), {
            sanitized: tranquill_E
          });
        });
        this.slider["addEventListener"](tranquill_S("0x6c62272e07bb0142"), async () => {
          const tranquill_F = this.sanitizeTypingSpeed(this["slider"].value);
          this.slider["value"] = String(tranquill_F);
          log["debug"](tranquill_S("0x6c62272e07bb0142"), {
            sanitized: tranquill_F
          });
          await this.persistSettings({
            typingSpeed: tranquill_F
          });
        });
      }
      if (this.phantomToggle) {
        this["phantomToggle"].addEventListener(tranquill_S("0x6c62272e07bb0142"), async () => {
          const tranquill_G = this.phantomToggle.checked;
          log.debug(tranquill_S("0x6c62272e07bb0142"), {
            isEnabled: tranquill_G
          });
          tranquill_14(tranquill_G);
          await this.persistSettings({
            phantomMode: tranquill_G
          });
        });
      }
      if (this["abortKeyButton"]) {
        this.abortKeyButton.addEventListener(tranquill_S("0x6c62272e07bb0142"), () => {
          this.startAbortKeyCapture();
        });
      }
      if (this.backButton) {
        this.backButton["addEventListener"](tranquill_S("0x6c62272e07bb0142"), () => {
          const tranquill_H = new URL(chrome.runtime.getURL(tranquill_S("0x6c62272e07bb0142")));
          tranquill_H.searchParams.set(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
          window.location.href = tranquill_H.toString();
          log.info(tranquill_S("0x6c62272e07bb0142"), {
            transition: tranquill_S("0x6c62272e07bb0142")
          });
        });
      }
    }
    sanitizeTypingSpeed(tranquill_I) {
      const tranquill_J = Number.parseInt(tranquill_I, 10);
      if (!Number.isFinite(tranquill_J)) {
        log.debug(tranquill_S("0x6c62272e07bb0142"), {
          value: tranquill_I,
          fallback: this.currentSettings.typingSpeed
        });
        return this["currentSettings"].typingSpeed;
      }
      const tranquill_K = Math.min(tranquill_6, Math.max(tranquill_5, tranquill_J));
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        value: tranquill_I,
        sanitized: tranquill_K
      });
      return tranquill_K;
    }
    async restoreSettings() {
      try {
        this.currentSettings = await tranquill_l.getSettings();
      } catch (tranquill_L) {
        log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_L);
        this.currentSettings = tranquill_l.defaults;
      }
      this.isRestored = true;
      this["applySettingsToUI"]();
      log.debug(tranquill_S("0x6c62272e07bb0142"), this.currentSettings);
      tranquill_14(this.currentSettings.phantomMode);
    }
    applySettingsToUI() {
      const {
        typingSpeed: tranquill_M,
        phantomMode: tranquill_N,
        abortKey: tranquill_O
      } = this.currentSettings;
      log.debug(tranquill_S("0x6c62272e07bb0142"), this["currentSettings"]);
      if (this.slider) {
        this.slider.value = String(tranquill_M);
        this.updateSliderDisplay(tranquill_M);
      }
      if (this.phantomToggle) {
        this.phantomToggle.checked = Boolean(tranquill_N);
      }
      this.updateAbortKeyDisplay(tranquill_O);
    }
    updateSliderDisplay(tranquill_P) {
      if (this.sliderValue) {
        this.sliderValue.textContent = `${tranquill_P} WPM`;
        log.debug(tranquill_S("0x6c62272e07bb0142"), {
          value: tranquill_P
        });
      }
    }
    updateAbortKeyDisplay(tranquill_Q = this.currentSettings["abortKey"]) {
      if (!this["abortKeyButton"]) return;
      const tranquill_R = tranquill_f(tranquill_Q);
      if (this["abortKeyValue"]) {
        this["abortKeyValue"].textContent = tranquill_R;
      } else {
        this.abortKeyButton["textContent"] = tranquill_R;
      }
      if (this["abortKeyHint"]) {
        this["abortKeyHint"].textContent = this.isCapturingAbortKey ? tranquill_S("0x6c62272e07bb0142") : tranquill_S("0x6c62272e07bb0142");
      }
      this["abortKeyButton"].classList.toggle(tranquill_S("0x6c62272e07bb0142"), this.isCapturingAbortKey);
    }
    startAbortKeyCapture() {
      if (!this.abortKeyButton) return;
      if (this.isCapturingAbortKey) {
        this.stopAbortKeyCapture({
          cancelled: true
        });
        return;
      }
      this.isCapturingAbortKey = true;
      this["updateAbortKeyDisplay"]();
      this.abortKeyCaptureHandler = tranquill_T => {
        this["handleAbortKeyCapture"](tranquill_T);
      };
      window["addEventListener"](tranquill_S("0x6c62272e07bb0142"), this.abortKeyCaptureHandler, true);
      this.abortKeyBlurHandler = () => {
        this.stopAbortKeyCapture({
          cancelled: true
        });
      };
      window["addEventListener"](tranquill_S("0x6c62272e07bb0142"), this.abortKeyBlurHandler);
      log.info(tranquill_S("0x6c62272e07bb0142"));
    }
    handleAbortKeyCapture(tranquill_U) {
      if (!this["isCapturingAbortKey"]) return;
      tranquill_U.preventDefault();
      tranquill_U.stopPropagation();
      if (tranquill_U["repeat"]) return;
      const tranquill_V = tranquill_j(tranquill_U);
      log["info"](tranquill_S("0x6c62272e07bb0142"), {
        binding: tranquill_V
      });
      this.stopAbortKeyCapture();
      this["updateAbortKeyDisplay"](tranquill_V);
      this.persistSettings({
        abortKey: tranquill_V
      });
    }
    stopAbortKeyCapture({
      cancelled: tranquill_W = false
    } = {}) {
      if (!this.isCapturingAbortKey) return;
      this.isCapturingAbortKey = false;
      if (this["abortKeyCaptureHandler"]) {
        window.removeEventListener(tranquill_S("0x6c62272e07bb0142"), this["abortKeyCaptureHandler"], true);
        this.abortKeyCaptureHandler = null;
      }
      if (this.abortKeyBlurHandler) {
        window["removeEventListener"](tranquill_S("0x6c62272e07bb0142"), this["abortKeyBlurHandler"]);
        this.abortKeyBlurHandler = null;
      }
      this["updateAbortKeyDisplay"]();
      if (tranquill_W) {
        log["debug"](tranquill_S("0x6c62272e07bb0142"));
      }
    }
    async persistSettings(tranquill_X) {
      if (!this.isRestored) {
        log.debug(tranquill_S("0x6c62272e07bb0142"));
        return;
      }
      const tranquill_Y = {
        ...this["currentSettings"],
        ...tranquill_X
      };
      try {
        this.currentSettings = await tranquill_l.saveSettings(tranquill_Y);
        this.applySettingsToUI();
        log.info(tranquill_S("0x6c62272e07bb0142"), tranquill_X);
      } catch (tranquill_Z) {
        log["error"](tranquill_S("0x6c62272e07bb0142"), tranquill_Z);
      }
    }
  }
  function tranquill_10() {
    const tranquill_11 = new tranquill_C(document);
    tranquill_11.init().catch(tranquill_12 => {
      log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_12);
    });
    const tranquill_13 = document["querySelector"](tranquill_S("0x6c62272e07bb0142"));
    let cText = tranquill_13.innerText;
    cText = cText.replace(tranquill_S("0x6c62272e07bb0142"), new Date()["getFullYear"]()).replace(tranquill_S("0x6c62272e07bb0142"), chrome.runtime.getManifest()["version"]);
    tranquill_13.innerText = cText;
  }
  function tranquill_14(tranquill_15) {
    document.querySelectorAll(tranquill_S("0x6c62272e07bb0142")).forEach(tranquill_16 => {
      if (tranquill_15) {
        if (!tranquill_16.classList.contains(tranquill_S("0x6c62272e07bb0142")) && !tranquill_16.classList.contains(tranquill_S("0x6c62272e07bb0142"))) {
          tranquill_16.classList.add(tranquill_S("0x6c62272e07bb0142"));
          tranquill_16.setAttribute(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
        }
      } else {
        tranquill_16.classList.remove(tranquill_S("0x6c62272e07bb0142"));
        tranquill_16.removeAttribute(tranquill_S("0x6c62272e07bb0142"));
      }
    });
  }
  if (document.readyState === tranquill_S("0x6c62272e07bb0142")) {
    document["addEventListener"](tranquill_S("0x6c62272e07bb0142"), tranquill_10);
  } else {
    tranquill_10();
  }
})();
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}