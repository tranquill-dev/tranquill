var tranquill_runtime_exports = (() => {
        const tranquill_global = typeof self !== "undefined" ? self : globalThis;
        if (tranquill_global.tranquill_runtime_ready) {
                return {
                        tranquill_S: tranquill_global.tranquill_S,
                        tranquill_RN: tranquill_global.tranquill_RN,
                        tranquill_next: tranquill_global.tranquill_next,
                        tranquill_signature: tranquill_global.tranquill_signature,
                        tranquill_seed: tranquill_global.tranquill_seed,
                };
        }
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::457f0536cb00f0db9dec4c0cbf422f54"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        const exports = {
                tranquill_S,
                tranquill_RN,
                tranquill_next,
                tranquill_signature: "tranquill_tranquill_tranquill",
                tranquill_seed: tranquill_global.tranquill_seed,
        };
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = exports.tranquill_signature;
        tranquill_global.tranquill_seed = exports.tranquill_seed;
        tranquill_global.tranquill_runtime_ready = true;
        if (typeof tranquill_global === "object" && tranquill_global) {
                try {
                        tranquill_global.tranquill_runtime = exports;
                } catch (error) {
                        // ignore assignment issues in restricted environments
                }
        }
        if (typeof window !== "undefined") {
                window.tranquill_S = tranquill_S;
                window.tranquill_RN = tranquill_RN;
                window.tranquill_next = tranquill_next;
        }
        if (typeof global !== "undefined") {
                global.tranquill_S = tranquill_S;
                global.tranquill_RN = tranquill_RN;
                global.tranquill_next = tranquill_next;
        }
        return exports;
})();

(function tranquill_0() {
  const tranquill_1 = new Uint8Array([191, 107, 63, 187, 246, 107, 37, 179, 182, 107, 63, 191, 246, 101, 37, 247, 183, 101, 42, 190, 157, 120, 216, 180, 154, 99, 205, 179, 134, 100, 177, 37, 10, 152, 143, 20, 15, 159, 135, 22, 18, 208, 212, 10, 27, 132, 138, 19, 16, 141, 195, 14, 12, 139, 128, 9, 23, 158, 135, 21, 16, 132, 254, 102, 129, 146, 233, 33, 234, 239, 178, 41, 225, 241, 242, 41, 251, 253, 178, 101, 233, 249, 251, 45, 198, 209, 165, 223, 157, 217, 174, 193, 221, 217, 180, 205, 157, 149, 179, 203, 209, 212, 165, 216, 46, 192, 168, 202, 50, 193, 165, 219, 63, 106, 210, 198, 44, 205, 165, 252, 200, 208, 182, 164, 42, 252, 204, 182, 54, 253, 193, 49, 196, 37, 17, 49, 196, 97, 5, 52, 210, 41, 70, 84, 61, 44, 71, 82, 55, 49, 142, 45, 28, 16, 183, 11, 29, 10, 143, 1, 18, 26, 166, 10]);
  const tranquill_2 = self["tranquill_PACK"] = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  tranquill_2.data.push(tranquill_1);
  const tranquill_3 = tranquill_2.data.length - 1;
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 0,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 20,
    len: 10,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 30,
    len: 31,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 61,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 66,
    len: 18,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 84,
    len: 19,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 103,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 111,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 117,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 123,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 131,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 141,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 148,
    len: 16,
    kind: 1
  });
})();
(function () {
  const tranquill_4 = tranquill_S("0x6c62272e07bb0142");
  const tranquill_5 = tranquill_S("0x6c62272e07bb0142");
  const tranquill_6 = tranquill_S("0x6c62272e07bb0142");
  const tranquill_7 = tranquill_S("0x6c62272e07bb0142");
  const tranquill_8 = {
    fade: tranquill_S("0x6c62272e07bb0142"),
    scale: tranquill_S("0x6c62272e07bb0142")
  };
  const tranquill_9 = tranquill_a => {
    Object["values"](tranquill_8).forEach(tranquill_b => {
      tranquill_a["classList"].remove(tranquill_b);
    });
  };
  const tranquill_c = (tranquill_d, tranquill_e) => {
    tranquill_9(tranquill_d);
    const tranquill_f = tranquill_8[tranquill_e];
    if (tranquill_f) {
      tranquill_d.classList["add"](tranquill_f);
    }
  };
  const tranquill_g = () => {
    try {
      window?.sessionStorage?.removeItem?.(tranquill_6);
    } catch (tranquill_h) {}
  };
  const tranquill_i = () => {
    try {
      const tranquill_j = window?.sessionStorage;
      if (!tranquill_j || typeof tranquill_j.getItem !== tranquill_S("0x6c62272e07bb0142")) {
        return null;
      }
      const tranquill_l = tranquill_j["getItem"](tranquill_6);
      tranquill_g();
      if (typeof tranquill_l !== tranquill_S("0x6c62272e07bb0142")) {
        return null;
      }
      const tranquill_n = tranquill_l.trim()["toLowerCase"]();
      if (!Object.prototype["hasOwnProperty"].call(tranquill_8, tranquill_n)) {
        return null;
      }
      return tranquill_n;
    } catch (tranquill_o) {
      return null;
    }
  };
  const tranquill_p = () => {
    if (!window.location || !window.location.search) {
      return tranquill_i();
    }
    const tranquill_q = new URLSearchParams(window["location"].search);
    const tranquill_r = tranquill_q.get(tranquill_5);
    if (typeof tranquill_r !== tranquill_S("0x6c62272e07bb0142")) {
      return tranquill_i();
    }
    const tranquill_t = tranquill_r.trim().toLowerCase();
    if (!Object["prototype"].hasOwnProperty.call(tranquill_8, tranquill_t)) {
      return tranquill_i();
    }
    tranquill_q["delete"](tranquill_5);
    const tranquill_u = tranquill_q.toString();
    const tranquill_v = `${window.location.pathname}${tranquill_u ? `?${tranquill_u}` : ""}${window.location.hash}`;
    if (window.history && typeof window.history.replaceState === tranquill_S("0x6c62272e07bb0142")) {
      window.history["replaceState"](null, "", tranquill_v);
    }
    tranquill_g();
    return tranquill_t;
  };
  const tranquill_w = tranquill_p();
  const tranquill_x = tranquill_y => {
    if (tranquill_y && Object.prototype.hasOwnProperty["call"](tranquill_8, tranquill_y)) {
      return tranquill_y;
    }
    return tranquill_7;
  };
  const tranquill_z = () => {
    const tranquill_A = document.querySelectorAll(`[${tranquill_4}]`);
    if (!tranquill_A["length"]) {
      return;
    }
    tranquill_A.forEach(tranquill_B => {
      const tranquill_C = tranquill_B["getAttribute"](tranquill_4)?.trim().toLowerCase();
      const tranquill_D = tranquill_x(tranquill_w || tranquill_C);
      tranquill_c(tranquill_B, tranquill_D);
    });
    requestAnimationFrame(() => {
      tranquill_A.forEach(tranquill_E => {
        tranquill_E["classList"]["add"](tranquill_S("0x6c62272e07bb0142"));
      });
    });
  };
  if (document.readyState === tranquill_S("0x6c62272e07bb0142")) {
    document.addEventListener(tranquill_S("0x6c62272e07bb0142"), tranquill_z, {
      once: true
    });
  } else {
    tranquill_z();
  }
})();
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}