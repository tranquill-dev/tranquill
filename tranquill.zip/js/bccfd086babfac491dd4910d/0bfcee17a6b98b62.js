var tranquill_global = typeof self !== "undefined" ? self : globalThis;
if (!tranquill_global.tranquill_runtime_ready) {
	const tranquill_uint32 = (value) => value >>> 0;
	const tranquill_sha256 = (input) => {
		const K = new Uint32Array([
			0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
			0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
			0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
			0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
			0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
			0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
			0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
			0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
			0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
			0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
			0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
			0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
			0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
		]);
		const words = new Uint32Array(64);
		const view = new DataView(new ArrayBuffer(64));
		const processChunk = (chunk, H) => {
			for (let i = 0; i < 16; i++) {
				words[i] = chunk.getUint32(i * 4);
			}
			for (let i = 16; i < 64; i++) {
				const s0 =
					((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
					((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
					(words[i - 15] >>> 3);
				const s1 =
					((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
					((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
					(words[i - 2] >>> 10);
				words[i] = tranquill_uint32(
					words[i - 16] + s0 + words[i - 7] + s1
				);
			}
			let [a, b, c, d, e, f, g, h] = H;
			for (let i = 0; i < 64; i++) {
				const S1 =
					((e >>> 6) | (e << 26)) ^
					((e >>> 11) | (e << 21)) ^
					((e >>> 25) | (e << 7));
				const ch = (e & f) ^ (~e & g);
				const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
				const S0 =
					((a >>> 2) | (a << 30)) ^
					((a >>> 13) | (a << 19)) ^
					((a >>> 22) | (a << 10));
				const maj = (a & b) ^ (a & c) ^ (b & c);
				const temp2 = tranquill_uint32(S0 + maj);
				h = g;
				g = f;
				f = e;
				e = tranquill_uint32(d + temp1);
				d = c;
				c = b;
				b = a;
				a = tranquill_uint32(temp1 + temp2);
			}
			H[0] = tranquill_uint32(H[0] + a);
			H[1] = tranquill_uint32(H[1] + b);
			H[2] = tranquill_uint32(H[2] + c);
			H[3] = tranquill_uint32(H[3] + d);
			H[4] = tranquill_uint32(H[4] + e);
			H[5] = tranquill_uint32(H[5] + f);
			H[6] = tranquill_uint32(H[6] + g);
			H[7] = tranquill_uint32(H[7] + h);
		};
		const H = [
			0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f,
			0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
		];
		const totalLen = input.length;
		const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
		const padded = new Uint8Array(paddedLen);
		padded.set(input);
		padded[totalLen] = 0x80;
		const bitLen = totalLen * 8;
		const lenView = new DataView(padded.buffer);
		lenView.setUint32(paddedLen - 4, bitLen);
		lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
		for (let offset = 0; offset < paddedLen; offset += 64) {
			for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
			processChunk(view, H);
		}
		const out = new Uint8Array(32);
		const outView = new DataView(out.buffer);
		for (let i = 0; i < 8; i++) {
			outView.setUint32(i * 4, H[i]);
		}
		return out;
	};
	const tranquill_seed_source = (() => {
		try {
			const enc = new TextEncoder();
			const parts = [];
			if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
				parts.push(enc.encode(chrome.runtime.id));
			}
			if (typeof location !== "undefined" && location?.hostname) {
				parts.push(enc.encode(location.hostname));
			}
			if (typeof navigator !== "undefined") {
				const hw = navigator.hardwareConcurrency | 0;
				parts.push(Uint8Array.of(hw & 0xff));
			}
			parts.push(
				enc.encode("tranquill_salt::b1c8ccd20ba8ba7ae0a009308b5681f7")
			);
			let total = 0;
			for (const part of parts) total += part.length;
			const blob = new Uint8Array(total);
			let offset = 0;
			for (const part of parts) {
				blob.set(part, offset);
				offset += part.length;
			}
			return blob;
		} catch (error) {
			return new Uint8Array([]);
		}
	})();
	const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
	const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
	tranquill_global.tranquill_seed = [
		tranquill_seed_view.getUint32(0),
		tranquill_seed_view.getUint32(4),
		tranquill_seed_view.getUint32(8),
		tranquill_seed_view.getUint32(12),
	];
	const tranquill_xorshift128p = (state) => {
		let s1 = state[0] | 0;
		const s0 = state[1] | 0;
		const result = (s0 + s1) | 0;
		s1 ^= s1 << 23;
		state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
		state[1] = s0;
		return result >>> 0;
	};
	const tranquill_unmask = (view, off, len, seed) => {
		const localSeed = [seed[0] ^ off, seed[1] ^ len];
		for (let i = 0; i < len; i++) {
			const value = tranquill_xorshift128p(localSeed) & 0xff;
			view[i] ^= value;
		}
	};
	const tranquill_cache = new Map();
	const tranquill_pack = (tranquill_global.tranquill_PACK =
		tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
	const decoder = new TextDecoder();
	const ensureShard = (meta) => {
		const buf = tranquill_pack.data[meta.shard];
		if (!buf) {
			return null;
		}
		return buf;
	};
	const tranquill_S = (id) => {
		const key = String(id);
		if (tranquill_cache.has(key)) {
			return tranquill_cache.get(key);
		}
		const meta = tranquill_pack.idx.get(key);
		if (!meta) {
			return "";
		}
		const shard = ensureShard(meta);
		if (!shard) {
			return "";
		}
		tranquill_unmask(
			shard,
			meta.off,
			meta.len,
			tranquill_global.tranquill_seed
		);
		const view = shard.subarray(meta.off, meta.off + meta.len);
		const decoded = decoder.decode(view);
		tranquill_cache.set(key, decoded);
		return decoded;
	};
	const tranquill_RN = (id) => {
		const key = String(id);
		if (tranquill_cache.has(key)) {
			return tranquill_cache.get(key);
		}
		const meta = tranquill_pack.idx.get(key);
		if (!meta) {
			return 0;
		}
		const shard = ensureShard(meta);
		if (!shard) {
			return 0;
		}
		tranquill_unmask(
			shard,
			meta.off,
			meta.len,
			tranquill_global.tranquill_seed
		);
		const view = shard.subarray(meta.off, meta.off + meta.len);
		let result = 0n;
		let shift = 0n;
		for (let i = 0; i < view.length; i++) {
			const byte = BigInt(view[i]);
			result |= (byte & 0x7fn) << shift;
			if ((byte & 0x80n) === 0n) {
				break;
			}
			shift += 7n;
		}
		const zigzag = (result >> 1n) ^ -(result & 1n);
		let numeric;
		if (
			zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
			zigzag <= BigInt(Number.MAX_SAFE_INTEGER)
		) {
			numeric = Number(zigzag);
		} else {
			numeric = Number.parseFloat(decoder.decode(view));
		}
		tranquill_cache.set(key, numeric);
		return numeric;
	};
	const tranquill_next = (state) =>
		((state * 1103515245 + 12345) >>> 0) & 0xffff;
	tranquill_global.tranquill_S = tranquill_S;
	tranquill_global.tranquill_RN = tranquill_RN;
	tranquill_global.tranquill_next = tranquill_next;
	tranquill_global.tranquill_signature = "tranquill_tranquill_tranquill";
	tranquill_global.tranquill_runtime_ready = true;
}

function tr4nquil1_0x360501(_0x113c8b, _0x547978, _0x1cd99d, _0x217a25, _0x1d52dd) {
  const tr4nquil1_0x2e8347 = {
    _0x1caf08: 0xa1
  };
  return tr4nquil1_0x1700(_0x113c8b - tr4nquil1_0x2e8347._0x1caf08, _0x547978);
}
function tr4nquil1_0x1700(_0x5b387c, _0x181053) {
  const _0x1dd03d = tr4nquil1_0x363b();
  return tr4nquil1_0x1700 = function (_0xe6c41, _0x484cd8) {
    _0xe6c41 = _0xe6c41 - (-0x5e * -0x5e + -0x55f * 0x7 + 0x494);
    let _0x2f6dfe = _0x1dd03d[_0xe6c41];
    if (tr4nquil1_0x1700['OKbVXh'] === undefined) {
      var _0x335d42 = function (_0x1782aa) {
        const _0xaa545c = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';
        let _0x51dfe3 = '',
          _0x455108 = '';
        for (let _0x55bb9e = -0x5a5 + -0x3 * 0xae + 0x7af, _0x1aa1b3, _0x4b0104, _0x630c63 = 0x8b5 + -0xb3e + 0x3b * 0xb; _0x4b0104 = _0x1782aa['charAt'](_0x630c63++); ~_0x4b0104 && (_0x1aa1b3 = _0x55bb9e % (-0x5f * 0x3b + -0x3a * 0x5b + 0x2a87) ? _0x1aa1b3 * (0xd * 0x109 + 0x3 * 0x393 + -0x17ee) + _0x4b0104 : _0x4b0104, _0x55bb9e++ % (-0xa07 + 0x2177 * -0x1 + 0x2b82 * 0x1)) ? _0x51dfe3 += String['fromCharCode'](-0x1 * -0x224 + 0x1 * -0x86f + -0x1 * -0x74a & _0x1aa1b3 >> (-(-0x2e * -0x62 + 0xeae + -0x2048) * _0x55bb9e & 0x2109 + -0xbbb * 0x2 + -0x98d)) : -0x1adc + -0x2 * 0xc7f + 0x33da * 0x1) {
          _0x4b0104 = _0xaa545c['indexOf'](_0x4b0104);
        }
        for (let _0x3774d9 = -0x228b + -0x8fe * -0x1 + -0xd3 * -0x1f, _0x136137 = _0x51dfe3['length']; _0x3774d9 < _0x136137; _0x3774d9++) {
          _0x455108 += '%' + ('00' + _0x51dfe3['charCodeAt'](_0x3774d9)['toString'](-0x1feb * -0x1 + 0x90f * 0x1 + 0x2 * -0x1475))['slice'](-(0xf5b + 0x941 + -0x189a));
        }
        return decodeURIComponent(_0x455108);
      };
      const _0xda7922 = function (_0xa3a16d, _0xe4d4a6) {
        let _0x1412bc = [],
          _0x103c22 = -0x1984 + -0xd66 + 0x2 * 0x1375,
          _0x1b21b6,
          _0x461e32 = '';
        _0xa3a16d = _0x335d42(_0xa3a16d);
        let _0x373ecb;
        for (_0x373ecb = 0x8 * 0x44e + 0x2 * -0x10b5 + 0x2 * -0x83; _0x373ecb < -0x2 * -0x6de + -0x249 + -0x1 * 0xa73; _0x373ecb++) {
          _0x1412bc[_0x373ecb] = _0x373ecb;
        }
        for (_0x373ecb = -0x3 * -0xe3 + -0x2626 + 0x237d; _0x373ecb < 0xfda + -0x4c0 + -0xa1a; _0x373ecb++) {
          _0x103c22 = (_0x103c22 + _0x1412bc[_0x373ecb] + _0xe4d4a6['charCodeAt'](_0x373ecb % _0xe4d4a6['length'])) % (0x1ca8 + 0x57 + -0x3 * 0x955), _0x1b21b6 = _0x1412bc[_0x373ecb], _0x1412bc[_0x373ecb] = _0x1412bc[_0x103c22], _0x1412bc[_0x103c22] = _0x1b21b6;
        }
        _0x373ecb = 0xc13 * 0x1 + 0x22d1 + -0x2ee4, _0x103c22 = 0xfe9 + -0xe3 * -0xd + -0x2 * 0xdb8;
        for (let _0x5ee55a = 0x1b50 + 0x1 * -0x99b + -0x11b5; _0x5ee55a < _0xa3a16d['length']; _0x5ee55a++) {
          _0x373ecb = (_0x373ecb + (0x442 + 0x2138 + -0x2579)) % (-0x655 * -0x6 + -0x1d61 * -0x1 + -0x51b * 0xd), _0x103c22 = (_0x103c22 + _0x1412bc[_0x373ecb]) % (-0xe * 0x95 + 0x8 * 0x21 + 0x81e), _0x1b21b6 = _0x1412bc[_0x373ecb], _0x1412bc[_0x373ecb] = _0x1412bc[_0x103c22], _0x1412bc[_0x103c22] = _0x1b21b6, _0x461e32 += String['fromCharCode'](_0xa3a16d['charCodeAt'](_0x5ee55a) ^ _0x1412bc[(_0x1412bc[_0x373ecb] + _0x1412bc[_0x103c22]) % (0x2 * -0x859 + -0x16 * 0x26 + 0x14f6)]);
        }
        return _0x461e32;
      };
      tr4nquil1_0x1700['FwlVum'] = _0xda7922, _0x5b387c = arguments, tr4nquil1_0x1700['OKbVXh'] = !![];
    }
    const _0x95c2be = _0x1dd03d[0x6b9 + -0x574 + -0x41 * 0x5],
      _0x510c5b = _0xe6c41 + _0x95c2be,
      _0x591ed9 = _0x5b387c[_0x510c5b];
    return !_0x591ed9 ? (tr4nquil1_0x1700['avwgXA'] === undefined && (tr4nquil1_0x1700['avwgXA'] = !![]), _0x2f6dfe = tr4nquil1_0x1700['FwlVum'](_0x2f6dfe, _0x484cd8), _0x5b387c[_0x510c5b] = _0x2f6dfe) : _0x2f6dfe = _0x591ed9, _0x2f6dfe;
  }, tr4nquil1_0x1700(_0x5b387c, _0x181053);
}
(function (_0x335d42, _0x95c2be) {
  const tr4nquil1_0x35ed6e = {
      _0x1bfd3b: 0x2d4,
      _0x53e572: 0x2c9,
      _0x5d0e25: 'EU&N',
      _0x28107e: 0x2bf,
      _0x451665: 0x2c1,
      _0x174e4f: 0x2e0,
      _0x47219b: 0x2d9,
      _0x570c3d: '21fI',
      _0x59cdc9: 0x2ca,
      _0x3611bf: 0x2e6,
      _0x6eeade: 0x3a4,
      _0xc75b04: 0x3a3,
      _0x30e201: 0x3ae,
      _0x135762: ')huw',
      _0x5778ff: 0x3a0,
      _0x2d81b4: 0x2c1,
      _0x4e4461: '!BQk',
      _0x1a04cd: 0x2c6,
      _0x32b89e: 0x2c8,
      _0xc41dcf: 0x2dd,
      _0x4105c5: 0x2d1,
      _0xb7f110: '*r$E',
      _0x42dd3b: 0x2d1,
      _0x191658: 0x24a,
      _0x4dd844: '!q1@',
      _0x5bc435: 0x23d,
      _0x344ba9: 0x243,
      _0x3848d8: 0x24b,
      _0x2ac553: 0x156,
      _0x34b8ca: 0x149,
      _0x384eb2: '*r$E',
      _0x34e50f: 0x13c,
      _0x52b7d5: 0x195,
      _0x4bd80a: 'b]zw',
      _0x2f37b5: 0x19d,
      _0x4c9738: 0x19e,
      _0x30a873: 0x18c,
      _0x27795f: 'M$@f',
      _0x560217: 0x240,
      _0x5370a5: 0x23e,
      _0x2445a3: 0x24e,
      _0x430490: 0x245
    },
    tr4nquil1_0xfd4ad2 = {
      _0x14260d: 0x225
    },
    tr4nquil1_0x507849 = {
      _0x3d867b: 0x13e
    },
    tr4nquil1_0x3692d3 = {
      _0x4a4ef7: 0x2ce
    },
    tr4nquil1_0x5da29b = {
      _0xa5c7e7: 0x33f
    },
    tr4nquil1_0x1eaf13 = {
      _0x3a5251: 0x3d1
    },
    tr4nquil1_0x5bbebe = {
      _0x312dd3: 0x227
    },
    tr4nquil1_0x5d5afe = {
      _0x584e84: 0x3c1
    },
    tr4nquil1_0x27ad8b = {
      _0x387296: 0xa8
    },
    tr4nquil1_0x38fbf1 = {
      _0x1faa92: 0x331
    };
  function _0x4bd3b1(_0x1e3e92, _0xeb468d, _0x2e789e, _0x122b42, _0x2192bb) {
    return tr4nquil1_0x1700(_0x1e3e92 - -tr4nquil1_0x38fbf1._0x1faa92, _0xeb468d);
  }
  function _0x3cda64(_0x2c1033, _0x22d82e, _0x542663, _0x5e4628, _0x56d453) {
    return tr4nquil1_0x1700(_0x22d82e - tr4nquil1_0x27ad8b._0x387296, _0x2c1033);
  }
  function _0x37565f(_0x443191, _0x498f46, _0x4fafb6, _0x26bd9b, _0x4a2bcf) {
    return tr4nquil1_0x1700(_0x4fafb6 - tr4nquil1_0x5d5afe._0x584e84, _0x4a2bcf);
  }
  function _0x903f43(_0x409403, _0x2b79b5, _0x22e9dd, _0x418396, _0x435929) {
    return tr4nquil1_0x1700(_0x22e9dd - tr4nquil1_0x5bbebe._0x312dd3, _0x418396);
  }
  function _0x296cf1(_0x3ba0e3, _0x246eae, _0x2de401, _0x134f63, _0x4ecef7) {
    return tr4nquil1_0x1700(_0x134f63 - -tr4nquil1_0x1eaf13._0x3a5251, _0x246eae);
  }
  function _0x3b4d07(_0x3012ff, _0x2d4429, _0x3dc3a7, _0x9309d4, _0x5d07bf) {
    return tr4nquil1_0x1700(_0x5d07bf - tr4nquil1_0x5da29b._0xa5c7e7, _0x2d4429);
  }
  function _0x4546b0(_0x3099fd, _0x5e66fa, _0x399ebe, _0x1b2a08, _0x5bb3ab) {
    return tr4nquil1_0x1700(_0x399ebe - -tr4nquil1_0x3692d3._0x4a4ef7, _0x1b2a08);
  }
  function _0x384817(_0x762be4, _0x23eff1, _0x427b84, _0x50e9c8, _0xcfb761) {
    return tr4nquil1_0x1700(_0x23eff1 - tr4nquil1_0x507849._0x3d867b, _0x427b84);
  }
  function _0x1d7fdf(_0x2abb42, _0x56d90e, _0x577160, _0xb9776f, _0x51f017) {
    return tr4nquil1_0x1700(_0x51f017 - tr4nquil1_0xfd4ad2._0x14260d, _0xb9776f);
  }
  const _0x510c5b = _0x335d42();
  while (!![]) {
    try {
      const _0x591ed9 = -parseInt(_0x384817(tr4nquil1_0x35ed6e._0x1bfd3b, tr4nquil1_0x35ed6e._0x53e572, tr4nquil1_0x35ed6e._0x5d0e25, tr4nquil1_0x35ed6e._0x28107e, tr4nquil1_0x35ed6e._0x451665)) / (-0x1462 + 0x1 * -0x132f + 0x2792) + -parseInt(_0x384817(tr4nquil1_0x35ed6e._0x174e4f, tr4nquil1_0x35ed6e._0x47219b, tr4nquil1_0x35ed6e._0x570c3d, tr4nquil1_0x35ed6e._0x59cdc9, tr4nquil1_0x35ed6e._0x3611bf)) / (-0x15a1 + 0x1047 * 0x2 + 0xaeb * -0x1) * (-parseInt(_0x903f43(tr4nquil1_0x35ed6e._0x6eeade, tr4nquil1_0x35ed6e._0xc75b04, tr4nquil1_0x35ed6e._0x30e201, tr4nquil1_0x35ed6e._0x135762, tr4nquil1_0x35ed6e._0x5778ff)) / (0xb * -0x2fe + -0x363 + -0x245 * -0x10)) + parseInt(_0x384817(tr4nquil1_0x35ed6e._0x451665, tr4nquil1_0x35ed6e._0x2d81b4, tr4nquil1_0x35ed6e._0x4e4461, tr4nquil1_0x35ed6e._0x1a04cd, tr4nquil1_0x35ed6e._0x32b89e)) / (-0x7 * -0x205 + -0x4d2 + 0x1 * -0x94d) + -parseInt(_0x384817(tr4nquil1_0x35ed6e._0xc41dcf, tr4nquil1_0x35ed6e._0x4105c5, tr4nquil1_0x35ed6e._0xb7f110, tr4nquil1_0x35ed6e._0x42dd3b, tr4nquil1_0x35ed6e._0x1bfd3b)) / (-0x343 * 0x3 + 0x442 + 0x58c) * (-parseInt(_0x296cf1(-tr4nquil1_0x35ed6e._0x191658, tr4nquil1_0x35ed6e._0x4dd844, -tr4nquil1_0x35ed6e._0x5bc435, -tr4nquil1_0x35ed6e._0x344ba9, -tr4nquil1_0x35ed6e._0x3848d8)) / (-0x655 * -0x6 + -0x1d61 * -0x1 + -0x335 * 0x15)) + -parseInt(_0x4546b0(-tr4nquil1_0x35ed6e._0x2ac553, -tr4nquil1_0x35ed6e._0x34b8ca, -tr4nquil1_0x35ed6e._0x34b8ca, tr4nquil1_0x35ed6e._0x384eb2, -tr4nquil1_0x35ed6e._0x34e50f)) / (-0xe * 0x95 + 0x8 * 0x21 + 0x725) + -parseInt(_0x4bd3b1(-tr4nquil1_0x35ed6e._0x52b7d5, tr4nquil1_0x35ed6e._0x4bd80a, -tr4nquil1_0x35ed6e._0x2f37b5, -tr4nquil1_0x35ed6e._0x4c9738, -tr4nquil1_0x35ed6e._0x30a873)) / (0x2 * -0x859 + -0x16 * 0x26 + 0x13fe) + -parseInt(_0x3cda64(tr4nquil1_0x35ed6e._0x27795f, tr4nquil1_0x35ed6e._0x560217, tr4nquil1_0x35ed6e._0x5370a5, tr4nquil1_0x35ed6e._0x2445a3, tr4nquil1_0x35ed6e._0x430490)) / (0x6b9 + -0x574 + -0x9e * 0x2);
      if (_0x591ed9 === _0x95c2be) break;else _0x510c5b['push'](_0x510c5b['shift']());
    } catch (_0xda7922) {
      _0x510c5b['push'](_0x510c5b['shift']());
    }
  }
})(tr4nquil1_0x363b, 0x10bcff + -0x11c212 + -0x1 * -0xa2fa9);
function tr4nquil1_0x363b() {
  const _0x2961c7 = ['ahiDDg3dLHtdUbRdR8oZWR7cIG', 'W7z+wWa', 'vcroccpcHeRdPdZdTmo2WRdcOY4aW7i', 'dCklF0uNwCkDW5NdKg3dSsZcVG', 'q8oIW64Pex0mzComFmo2rK/dJG', 'D8kTWQ3dT8og', 'sZfou2m', 'hmo5st3dGXBcImoQBGqbtXznWRXEW4u/WOJdPZe', 'ahyEFwddLHtdMWldR8oZWO/cSq', 'qSoiAINdTgNdRW', 'WOlcP3/dHHFdL8oysmoPW7qjW5nG', 'tSoXF8k5dxdcQs3dKsC', 'rJtdLCkLWOpcQe3cGWODWPD1iG', 'W5FdUrCkW7BcOCkSBmktW7/dOSo9vG', 'WRddTrVdQSooW6ZdLWJdPmkPbq', 'W57dJSk/tLdcIaePB8oaWPpdMtK', 'tIaBCmo2wG', 'WQVdJa8snCkGlZ4OWPCPWO8H', 'DujgWRxdLmoFWPGijmkztc/cGmoUoLe', 'c8kmFu8NxmkEW7xdRvFdJs/cUG', 'CSkAWOu', 'jHCAW4hdTmo9WRiuiCkL', 'WRmRaepdIMnDW4VcKmoC', 'WRmOdudcTdyQW57cRSo4W7FdPSon', 'mmocCa7dN0ldK8kGDaiStGzCWRbw', 'W4qYcCkNrwNcTCo1WPWlhG', 'W6tdGxBcGsZdRsddHGDe', 'W5RdGmk7s1ZcHWKVvSo5WQldUYK', 'pXu/qIioW5q', 'WR3cKSoVgSk3'];
  tr4nquil1_0x363b = function () {
    return _0x2961c7;
  };
  return tr4nquil1_0x363b();
}
function tr4nquil1_0xa45d45(_0x4a7f38, _0x154425, _0x4cfc0e, _0x26dab7, _0x304323) {
  const tr4nquil1_0x4319ea = {
    _0x4a6031: 0x3ad
  };
  return tr4nquil1_0x1700(_0x26dab7 - tr4nquil1_0x4319ea._0x4a6031, _0x4cfc0e);
}
document[tr4nquil1_0xa45d45(0x537, 0x534, 'M$@f', 0x53f, 0x54a)](tr4nquil1_0x360501(0x22b, '[h4L', 0x22a, 0x225, 0x22d), () => {
  const tr4nquil1_0x35f626 = {
      _0x549974: 0x2c,
      _0x4befe8: 0x35,
      _0x552c8b: 'bX@5',
      _0x12472e: 0x20,
      _0x5e8815: 0x29,
      _0x120613: 0x35a,
      _0xa5fa63: 0x360,
      _0x3818fb: 0x356,
      _0x1c1f04: 0x357,
      _0x5d3590: '[h4L',
      _0x50135b: 0x531,
      _0x3d67e3: 'H39X',
      _0x25c43f: 0x528,
      _0x4c4840: 0x53f,
      _0x23df7b: 0x528,
      _0x30897a: 0x35c,
      _0x214e8d: 0x358,
      _0x239950: 0x35a,
      _0x4394b3: 0x354,
      _0x271df1: '6R[I',
      _0xd8ad1b: 0xa4,
      _0x23e793: 0x97,
      _0x5512e9: ')huw',
      _0x3de8e5: 0xa1,
      _0x3a173a: 0x99,
      _0x5b974b: 0x548,
      _0x2399e3: 'EkrY',
      _0x4df6a3: 0x54a,
      _0x2c9db6: 0x53b,
      _0x140d14: 0x552
    },
    tr4nquil1_0x162762 = {
      _0x32fc6f: 0x3e0,
      _0x1a6263: '!6fL',
      _0x21114c: 0x3d7,
      _0x458e0c: 0x3ee,
      _0x431025: 0x3ed,
      _0x1e560e: 0x4f4,
      _0x28d26f: 0x4f3,
      _0x22d2eb: 0x4f0,
      _0x5888f1: 0x4fd,
      _0x57a947: 'YsmB',
      _0x3ef5ae: 0x3eb,
      _0x4e8450: '6IoF',
      _0x500b9c: 0x3f7,
      _0x3c4ead: 0x3f2,
      _0x20a834: 0x3e7,
      _0x5c2c50: 'Knl(',
      _0x183421: 0x240,
      _0x3b1612: 0x235,
      _0x423f49: 0x23e,
      _0x363d71: 0x23a
    },
    tr4nquil1_0x10b6eb = {
      _0x175ee4: 0x173,
      _0x41db35: 0x18e,
      _0x4df715: 0x1ed,
      _0x35c13a: 0x1bf
    },
    tr4nquil1_0xceeacf = {
      _0x495d7e: 0x2bc,
      _0x621fa6: 0x35,
      _0x3b70ba: 0x9d,
      _0x448c11: 0x64
    },
    tr4nquil1_0x8a48ce = {
      _0x37f37e: 0x204,
      _0x3833ed: 0x16,
      _0x45a2c3: 0x72,
      _0x53202f: 0x4f
    },
    tr4nquil1_0x28c417 = {
      _0x232b26: 0x40a,
      _0x4af389: 0x1cd,
      _0x23460c: 0x13,
      _0x5b5673: 0x2d
    },
    tr4nquil1_0x2c1c34 = {
      _0x143618: 0xeb,
      _0x9d2d38: 0xc6,
      _0x4a2a17: 0x293,
      _0x1f7b7b: 0xf7
    },
    tr4nquil1_0x4c1e32 = {
      _0x37c157: 0x311,
      _0x23c29f: 0x6c,
      _0x1c6d9e: 0xf7,
      _0x40114f: 0xf4
    };
  function _0x38ef08(_0x43dde4, _0x46af51, _0x5f5242, _0x5e685e, _0x57d855) {
    return tr4nquil1_0x360501(_0x43dde4 - tr4nquil1_0x4c1e32._0x37c157, _0x46af51, _0x5f5242 - tr4nquil1_0x4c1e32._0x23c29f, _0x5e685e - tr4nquil1_0x4c1e32._0x1c6d9e, _0x57d855 - tr4nquil1_0x4c1e32._0x40114f);
  }
  const _0x35bf85 = {};
  function _0x2f2b32(_0x5134f5, _0x272a0f, _0x389b8a, _0x146678, _0x5f5872) {
    return tr4nquil1_0xa45d45(_0x5134f5 - tr4nquil1_0x2c1c34._0x143618, _0x272a0f - tr4nquil1_0x2c1c34._0x9d2d38, _0x389b8a, _0x5f5872 - -tr4nquil1_0x2c1c34._0x4a2a17, _0x5f5872 - tr4nquil1_0x2c1c34._0x1f7b7b);
  }
  function _0x5968b5(_0x39113f, _0x203214, _0x4786aa, _0x450a74, _0x4b77cd) {
    return tr4nquil1_0x360501(_0x4b77cd - -tr4nquil1_0x28c417._0x232b26, _0x4786aa, _0x4786aa - tr4nquil1_0x28c417._0x4af389, _0x450a74 - tr4nquil1_0x28c417._0x23460c, _0x4b77cd - tr4nquil1_0x28c417._0x5b5673);
  }
  function _0x5e1bd7(_0x3f02c4, _0x3951c8, _0x4cafd3, _0x49387d, _0x3707ba) {
    return tr4nquil1_0x360501(_0x3f02c4 - -tr4nquil1_0x8a48ce._0x37f37e, _0x4cafd3, _0x4cafd3 - tr4nquil1_0x8a48ce._0x3833ed, _0x49387d - tr4nquil1_0x8a48ce._0x45a2c3, _0x3707ba - tr4nquil1_0x8a48ce._0x53202f);
  }
  _0x35bf85[_0x5e1bd7(tr4nquil1_0x35f626._0x549974, tr4nquil1_0x35f626._0x4befe8, tr4nquil1_0x35f626._0x552c8b, tr4nquil1_0x35f626._0x12472e, tr4nquil1_0x35f626._0x5e8815)] = _0x3f2428(tr4nquil1_0x35f626._0x120613, tr4nquil1_0x35f626._0xa5fa63, tr4nquil1_0x35f626._0x3818fb, tr4nquil1_0x35f626._0x1c1f04, tr4nquil1_0x35f626._0x5d3590);
  function _0x5bc181(_0x147cfe, _0x158a47, _0x47cea2, _0x1ce7e4, _0x2e0d16) {
    return tr4nquil1_0x360501(_0x158a47 - -tr4nquil1_0xceeacf._0x495d7e, _0x47cea2, _0x47cea2 - tr4nquil1_0xceeacf._0x621fa6, _0x1ce7e4 - tr4nquil1_0xceeacf._0x3b70ba, _0x2e0d16 - tr4nquil1_0xceeacf._0x448c11);
  }
  function _0x3f2428(_0x2a4151, _0x11d916, _0x708167, _0x46caa3, _0x2141e4) {
    return tr4nquil1_0xa45d45(_0x2a4151 - tr4nquil1_0x10b6eb._0x175ee4, _0x11d916 - tr4nquil1_0x10b6eb._0x41db35, _0x2141e4, _0x46caa3 - -tr4nquil1_0x10b6eb._0x4df715, _0x2141e4 - tr4nquil1_0x10b6eb._0x35c13a);
  }
  const _0x2bebad = _0x35bf85,
    _0x4aba84 = document[_0x38ef08(tr4nquil1_0x35f626._0x50135b, tr4nquil1_0x35f626._0x3d67e3, tr4nquil1_0x35f626._0x25c43f, tr4nquil1_0x35f626._0x4c4840, tr4nquil1_0x35f626._0x23df7b)](_0x3f2428(tr4nquil1_0x35f626._0x30897a, tr4nquil1_0x35f626._0x214e8d, tr4nquil1_0x35f626._0x239950, tr4nquil1_0x35f626._0x4394b3, tr4nquil1_0x35f626._0x271df1));
  _0x4aba84 && _0x4aba84[_0x5bc181(-tr4nquil1_0x35f626._0xd8ad1b, -tr4nquil1_0x35f626._0x23e793, tr4nquil1_0x35f626._0x5512e9, -tr4nquil1_0x35f626._0x3de8e5, -tr4nquil1_0x35f626._0x3a173a)](_0x38ef08(tr4nquil1_0x35f626._0x5b974b, tr4nquil1_0x35f626._0x2399e3, tr4nquil1_0x35f626._0x4df6a3, tr4nquil1_0x35f626._0x2c9db6, tr4nquil1_0x35f626._0x140d14), () => {
    const tr4nquil1_0x4dd449 = {
        _0x4d4616: 0x1b5,
        _0x783736: 0xdc,
        _0xff1ef6: 0x5f,
        _0x5e25c5: 0x6c4
      },
      tr4nquil1_0x59da22 = {
        _0x5ac877: 0x186,
        _0x48f75a: 0x1cb,
        _0x4cea32: 0x1a3,
        _0x3024aa: 0x140
      },
      tr4nquil1_0x3a1d81 = {
        _0x5a0657: 0x8f,
        _0x3b39cb: 0x99,
        _0x3f25c0: 0xf8,
        _0x290c54: 0x104
      },
      tr4nquil1_0xb72853 = {
        _0x1a4548: 0xfb,
        _0x39327b: 0x109,
        _0x53fccd: 0x18b,
        _0x5864c0: 0x15e
      },
      _0x348d62 = {};
    function _0x549241(_0x268ffa, _0x4da300, _0x16e846, _0x497509, _0x34061e) {
      return _0x2f2b32(_0x268ffa - tr4nquil1_0xb72853._0x1a4548, _0x4da300 - tr4nquil1_0xb72853._0x39327b, _0x497509, _0x497509 - tr4nquil1_0xb72853._0x53fccd, _0x16e846 - -tr4nquil1_0xb72853._0x5864c0);
    }
    function _0x239ead(_0x77b5af, _0x306d04, _0x52de61, _0x5e50f6, _0x4bb910) {
      return _0x3f2428(_0x77b5af - tr4nquil1_0x3a1d81._0x5a0657, _0x306d04 - tr4nquil1_0x3a1d81._0x3b39cb, _0x52de61 - tr4nquil1_0x3a1d81._0x3f25c0, _0x5e50f6 - -tr4nquil1_0x3a1d81._0x290c54, _0x77b5af);
    }
    _0x348d62[_0x1e165e(tr4nquil1_0x162762._0x32fc6f, tr4nquil1_0x162762._0x1a6263, tr4nquil1_0x162762._0x21114c, tr4nquil1_0x162762._0x458e0c, tr4nquil1_0x162762._0x431025)] = _0x2bebad[_0x2abf09(tr4nquil1_0x162762._0x1e560e, tr4nquil1_0x162762._0x28d26f, tr4nquil1_0x162762._0x22d2eb, tr4nquil1_0x162762._0x5888f1, tr4nquil1_0x162762._0x57a947)];
    function _0x1e165e(_0x392308, _0x3f79dc, _0x2d11e8, _0x3edb7f, _0x4da2f9) {
      return _0x2f2b32(_0x392308 - tr4nquil1_0x59da22._0x5ac877, _0x3f79dc - tr4nquil1_0x59da22._0x48f75a, _0x3f79dc, _0x3edb7f - tr4nquil1_0x59da22._0x4cea32, _0x392308 - tr4nquil1_0x59da22._0x3024aa);
    }
    function _0x2abf09(_0x3fcd3f, _0x2e550f, _0x252ba9, _0x3058dd, _0x2f2e9c) {
      return _0x5968b5(_0x3fcd3f - tr4nquil1_0x4dd449._0x4d4616, _0x2e550f - tr4nquil1_0x4dd449._0x783736, _0x2f2e9c, _0x3058dd - tr4nquil1_0x4dd449._0xff1ef6, _0x252ba9 - tr4nquil1_0x4dd449._0x5e25c5);
    }
    chrome[_0x1e165e(tr4nquil1_0x162762._0x3ef5ae, tr4nquil1_0x162762._0x4e8450, tr4nquil1_0x162762._0x500b9c, tr4nquil1_0x162762._0x3c4ead, tr4nquil1_0x162762._0x20a834)][_0x239ead(tr4nquil1_0x162762._0x5c2c50, tr4nquil1_0x162762._0x183421, tr4nquil1_0x162762._0x3b1612, tr4nquil1_0x162762._0x423f49, tr4nquil1_0x162762._0x363d71)](_0x348d62);
  });
});