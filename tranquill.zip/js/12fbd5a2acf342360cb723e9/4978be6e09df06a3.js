var tranquill_runtime_exports = (() => {
        const tranquill_global = typeof self !== "undefined" ? self : globalThis;
        if (tranquill_global.tranquill_runtime_ready) {
                return {
                        tranquill_S: tranquill_global.tranquill_S,
                        tranquill_RN: tranquill_global.tranquill_RN,
                        tranquill_next: tranquill_global.tranquill_next,
                        tranquill_signature: tranquill_global.tranquill_signature,
                        tranquill_seed: tranquill_global.tranquill_seed,
                };
        }
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::457f0536cb00f0db9dec4c0cbf422f54"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        const exports = {
                tranquill_S,
                tranquill_RN,
                tranquill_next,
                tranquill_signature: "tranquill_tranquill_tranquill",
                tranquill_seed: tranquill_global.tranquill_seed,
        };
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = exports.tranquill_signature;
        tranquill_global.tranquill_seed = exports.tranquill_seed;
        tranquill_global.tranquill_runtime_ready = true;
        if (typeof tranquill_global === "object" && tranquill_global) {
                try {
                        tranquill_global.tranquill_runtime = exports;
                } catch (error) {
                        // ignore assignment issues in restricted environments
                }
        }
        if (typeof window !== "undefined") {
                window.tranquill_S = tranquill_S;
                window.tranquill_RN = tranquill_RN;
                window.tranquill_next = tranquill_next;
        }
        if (typeof global !== "undefined") {
                global.tranquill_S = tranquill_S;
                global.tranquill_RN = tranquill_RN;
                global.tranquill_next = tranquill_next;
        }
        return exports;
})();

(function tranquill_0() {
  const tranquill_1 = new Uint8Array([132, 156, 69, 74, 128, 155, 73, 4, 135, 151, 86, 77, 132, 128, 4, 69, 152, 134, 65, 69, 144, 141, 4, 77, 154, 157, 80, 77, 149, 152, 77, 94, 145, 144, 4, 77, 154, 212, 66, 86, 149, 153, 65, 135, 71, 70, 145, 131, 64, 74, 188, 152, 65, 83, 154, 153, 91, 117, 154, 150, 75, 94, 106, 202, 11, 156, 110, 205, 7, 210, 121, 205, 4, 134, 127, 204, 30, 210, 105, 193, 24, 155, 106, 214, 74, 155, 116, 203, 30, 155, 123, 206, 3, 136, 115, 204, 13, 46, 220, 192, 46, 84, 174, 218, 48, 119, 162, 192, 35, 77, 169, 211, 36, 255, 166, 233, 196, 202, 176, 133, 32, 115, 194, 176, 54, 217, 187, 236, 204, 213, 173, 63, 211, 142, 62, 34, 192, 49, 89, 0, 52, 44, 74, 59, 223, 138, 50, 38, 204, 26, 47, 164, 15, 15, 109, 160, 24, 2, 109, 169, 20, 21, 41, 162, 19, 28, 109, 190, 13, 31, 44, 191, 24, 31, 20, 184, 229, 21, 9, 171, 14, 38, 127, 11, 19, 53, 0, 148, 241, 25, 29, 135, 122, 82, 11, 127, 103, 65, 124, 222, 226, 94, 105, 247, 232, 85, 115, 208, 173, 80, 102, 230, 187, 82, 123, 220, 165, 74, 224, 213, 93, 73, 229, 156, 69, 67, 161, 207, 84, 66, 229, 156, 80, 78, 238, 206, 69, 12, 236, 217, 66, 95, 224, 219, 84, 50, 63, 140, 63, 39, 125, 136, 40, 42, 125, 147, 63, 54, 46, 144, 40, 55, 177, 0, 111, 160, 164, 184, 45, 166, 173, 173, 98, 162, 186, 160, 98, 185, 173, 188, 60, 186, 186, 189, 130, 100, 92, 164, 151, 77, 86, 175, 159, 134, 1, 134, 138, 196, 5, 145, 135, 196, 2, 155, 159, 128, 78, 146, 159, 141, 2, 145, 154, 101, 195, 59, 99, 112, 129, 63, 116, 125, 129, 56, 126, 101, 197, 116, 101, 108, 211, 49, 102, 235, 130, 20, 252, 235, 244, 90, 1, 237, 248, 76, 214, 160, 232, 160, 195, 226, 236, 183, 206, 226, 228, 186, 214, 172, 224, 183, 151, 170, 230, 188, 211, 174, 238, 188, 208, 226, 225, 179, 222, 174, 226, 182, 221, 207, 99, 192, 210, 197, 122, 213, 218, 42, 75, 212, 43, 63, 13, 117, 181, 13, 7, 117, 161, 5, 5, 123, 251, 28, 3, 125, 181, 24, 4, 113, 251, 30, 14, 109, 174, 9, 24, 104, 12, 12, 13, 26, 8, 11, 1, 84, 15, 16, 13, 0, 25, 68, 30, 17, 15, 1, 24, 234, 210, 89, 231, 235, 194, 90, 228, 240, 200, 71, 183, 237, 206, 68, 242, 235, 135, 76, 239, 233, 206, 91, 242, 253, 112, 65, 89, 125, 107, 93, 64, 92, 130, 143, 87, 93, 146, 140, 84, 70, 152, 145, 10, 74, 143, 143, 78, 93, 146, 155, 63, 182, 144, 87, 42, 183, 140, 101, 58, 161, 138, 81, 111, 183, 148, 93, 63, 180, 154, 80, 116, 228, 143, 92, 46, 170, 139, 91, 34, 228, 150, 90, 46, 167, 139, 93, 57, 161, 148, 154, 123, 123, 129, 155, 103, 73, 145, 141, 97, 125, 196, 159, 117, 113, 144, 129, 122, 127, 196, 142, 123, 106, 196, 137, 119, 108, 141, 158, 113, 56, 150, 141, 101, 109, 129, 155, 96, 97, 101, 206, 100, 116, 100, 210, 86, 100, 114, 212, 98, 49, 126, 197, 107, 116, 204, 177, 171, 216, 201, 172, 187, 192, 193, 182, 191, 136, 216, 176, 185, 198, 220, 183, 181, 136, 220, 170, 177, 207, 207, 189, 170, 206, 235, 175, 189, 202, 236, 163, 243, 202, 241, 167, 180, 217, 230, 188, 243, 216, 226, 162, 191, 220, 226, 173, 184, 158, 247, 167, 190, 219, 236, 187, 167, 195, 50, 42, 206, 216, 46, 51, 17, 126, 60, 59, 2, 105, 39, 113, 3, 109, 60, 48, 22, 109, 51, 57, 23, 108, 214, 58, 19, 107, 218, 0, 21, 109, 208, 51, 2, 118, 227, 19, 92, 238, 224, 22, 21, 246, 234, 82, 70, 231, 235, 22, 21, 242, 237, 19, 91, 246, 234, 31, 21, 246, 247, 27, 82, 229, 224, 0, 105, 212, 78, 121, 126, 105, 150, 36, 71, 55, 158, 47, 80, 105, 146, 45, 70, 107, 102, 26, 124, 90, 119, 24, 116, 76, 83, 82, 210, 105, 100, 75, 16, 79, 64, 95, 1, 10, 69, 82, 4, 68, 65, 85, 8, 10, 65, 72, 12, 77, 82, 95, 23, 15, 138, 62, 80, 62, 155, 60, 88, 40, 130, 118, 63, 133, 148, 115, 61, 141, 195, 105, 42, 132, 151, 114, 54, 158, 138, 121, 115, 136, 130, 121, 56, 153, 147, 123, 48, 143, 166, 142, 215, 163, 187, 157, 102, 20, 91, 103, 112, 17, 89, 111, 39, 11, 78, 102, 115, 16, 82, 124, 110, 27, 23, 99, 98, 1, 83, 103, 112, 22, 64, 133, 49, 159, 113, 148, 51, 151, 103, 223, 132, 112, 190, 219, 132, 121, 241, 220, 148, 120, 164, 200, 133, 61, 165, 223, 136, 122, 182, 200, 147, 61, 181, 216, 132, 61, 165, 194, 193, 127, 176, 206, 138, 110, 161, 204, 130, 120, 177, 209, 92, 160, 171, 218, 85, 228, 178, 220, 83, 170, 182, 219, 95, 228, 160, 213, 81, 175, 177, 196, 83, 167, 167, 20, 37, 117, 51, 16, 34, 121, 31, 5, 46, 127, 46, 20, 44, 119, 56, 18, 42, 165, 18, 9, 40, 175, 93, 9, 40, 187, 24, 26, 57, 162, 19, 28, 109, 160, 24, 2, 41, 164, 10, 21, 20, 184, 229, 21, 9, 171, 25, 55, 97, 7, 9, 55, 0, 148, 241, 25, 29, 135, 4, 120, 27, 242, 64, 99, 1, 209, 68, 99, 20, 230, 87, 112, 5, 233, 73, 42, 67, 113, 82, 48, 124, 125, 78, 33, 114, 102, 69, 37, 91, 75, 151, 86, 68, 93, 146, 84, 76, 10, 153, 95, 77, 69, 137, 95, 66, 68, 139, 79, 95, 58, 158, 55, 67, 33, 130, 45, 94, 42, 57, 81, 234, 36, 56, 65, 233, 39, 35, 75, 244, 121, 47, 73, 234, 32, 51, 186, 161, 231, 190, 179, 164, 230, 186, 248, 175, 237, 187, 183, 191, 237, 180, 182, 189, 253, 169, 133, 231, 176, 144, 137, 241, 139, 115, 74, 101, 143, 116, 70, 91, 146, 117, 76, 126, 51, 191, 99, 101, 32, 185, 98, 44, 38, 180, 103, 98, 34, 179, 107, 44, 38, 181, 104, 107, 214, 227, 183, 245, 210, 228, 187, 200, 195, 255, 151, 248, 210, 226, 160, 254, 182, 19, 183, 165, 178, 20, 187, 235, 167, 24, 162, 162, 176, 26, 162, 162, 169, 21, 246, 184, 178, 26, 162, 174, 230, 24, 190, 170, 168, 28, 179, 175, 161, 59, 128, 173, 165, 60, 140, 144, 168, 61, 149, 171, 180, 39, 136, 160, 130, 39, 128, 177, 165, 28, 28, 60, 218, 25, 23, 58, 214, 12, 22, 121, 210, 1, 19, 55, 214, 6, 31, 121, 209, 16, 28, 45, 202, 12, 6, 48, 193, 73, 1, 45, 195, 27, 6, 20, 184, 229, 21, 9, 171, 14, 38, 127, 11, 19, 53, 252, 182, 61, 224, 248, 177, 49, 174, 255, 167, 50, 250, 228, 187, 40, 231, 239, 254, 57, 224, 232, 254, 40, 231, 225, 187, 51, 251, 248, 107, 154, 130, 102, 112, 134, 155, 91, 195, 86, 94, 64, 223, 76, 67, 75, 151, 93, 68, 76, 151, 85, 67, 91, 201, 81, 68, 79, 3, 116, 81, 66, 18, 99, 87, 67, 66, 103, 90, 70, 12, 99, 93, 74, 66, 100, 75, 73, 22, 127, 87, 83, 11, 116, 18, 84, 22, 118, 64, 83, 159, 95, 94, 137, 155, 88, 82, 180, 150, 89, 75, 143, 138, 67, 86, 132, 170, 89, 91, 96, 226, 160, 132, 101, 233, 166, 136, 112, 232, 229, 140, 125, 237, 171, 136, 122, 225, 229, 143, 108, 226, 177, 148, 112, 248, 172, 159, 53, 233, 171, 152, 255, 85, 161, 218, 240, 95, 184, 207, 248, 226, 18, 111, 239, 249, 14, 117, 242, 242, 70, 100, 245, 245, 194, 172, 35, 218, 198, 171, 47, 231, 203, 170, 54, 220, 215, 176, 43, 215, 240, 165, 33, 223, 193, 180, 35, 215, 215, 133, 111, 89, 200, 128, 61, 71, 212, 138, 105, 92, 200, 144, 116, 87, 141, 134, 124, 87, 198, 151, 109, 85, 206, 129, 61, 67, 196, 138, 121, 91, 218, 31, 93, 222, 11, 27, 90, 210, 54, 22, 91, 203, 13, 10, 65, 214, 6, 46, 87, 208, 23, 27, 242, 126, 210, 248, 247, 117, 212, 244, 226, 116, 151, 240, 239, 113, 217, 244, 232, 125, 151, 243, 254, 126, 195, 232, 226, 100, 222, 227, 167, 113, 213, 239, 245, 100, 82, 60, 179, 74, 86, 59, 191, 4, 81, 45, 188, 80, 74, 49, 166, 77, 65, 116, 179, 70, 77, 38, 166, 65, 70, 78, 39, 176, 71, 91, 89, 247, 244, 74, 66, 235, 238, 87, 73, 163, 251, 92, 69, 252, 238, 90, 56, 56, 73, 94, 42, 47, 182, 145, 98, 139, 166, 145, 109, 138, 164, 129, 112, 174, 39, 111, 177, 170, 32, 99, 255, 189, 32, 96, 171, 187, 33, 122, 255, 173, 44, 124, 182, 174, 59, 46, 173, 187, 46, 106, 166, 115, 67, 82, 149, 119, 68, 94, 184, 108, 69, 71, 158, 109, 95, 97, 158, 98, 79, 74]);
  const tranquill_2 = self.tranquill_PACK = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  tranquill_2.data.push(tranquill_1);
  const tranquill_3 = tranquill_2.data.length - 1;
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 0,
    len: 43,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 43,
    len: 19,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 62,
    len: 35,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 97,
    len: 2,
    kind: 2
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 99,
    len: 14,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 113,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 119,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 125,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 131,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 137,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 143,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 149,
    len: 25,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 174,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 180,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 186,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 192,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 198,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 206,
    len: 11,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 217,
    len: 28,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 245,
    len: 17,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 262,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 267,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 284,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 292,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 313,
    len: 20,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 333,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 338,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 344,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 376,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 385,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 390,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 416,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 435,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 460,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 467,
    len: 19,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 486,
    len: 38,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 524,
    len: 39,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 563,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 580,
    len: 27,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 607,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 639,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 646,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 662,
    len: 14,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 676,
    len: 30,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 706,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 711,
    len: 12,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 723,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 732,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 737,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 759,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 768,
    len: 28,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 796,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 802,
    len: 26,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 828,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 837,
    len: 39,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 876,
    len: 25,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 901,
    len: 16,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 917,
    len: 25,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 942,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 948,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 954,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 960,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 961,
    len: 15,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 976,
    len: 15,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 991,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1011,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1020,
    len: 17,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1037,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1057,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1063,
    len: 11,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1074,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1095,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1111,
    len: 32,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1143,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1164,
    len: 34,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1198,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1204,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1210,
    len: 29,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1239,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1246,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1267,
    len: 32,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1299,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1318,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1350,
    len: 9,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1359,
    len: 13,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1372,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1397,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1429,
    len: 21,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1450,
    len: 34,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1484,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1509,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1514,
    len: 15,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1529,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1536,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1547,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1575,
    len: 19,
    kind: 1
  });
})();
let _tranquill_cond = typeof tranquill_f.code === tranquill_S("0x6c62272e07bb0142") && tranquill_f["code"].length > 0;
if (_tranquill_cond) {
  tranquill_f.code;
} else {
  tranquill_h;
}
let _tranquill_cond2 = typeof abortBinding.key === tranquill_S("0x6c62272e07bb0142") && abortBinding.key.length > 0;
if (_tranquill_cond2) {
  abortBinding.key;
} else {
  "";
}
let _tranquill_cond3 = Number.isFinite(tranquill_W) && tranquill_W > 0;
if (_tranquill_cond3) {
  tranquill_W;
} else {
  tranquill_4;
}
(() => {
  if (window.__tranquillPhantomInitialized) {
    log.debug(tranquill_S("0x6c62272e07bb0142"));
    chrome.runtime?.sendMessage?.({
      action: tranquill_S("0x6c62272e07bb0142")
    });
    return;
  }
  window.__tranquillPhantomInitialized = true;
  log.info(tranquill_S("0x6c62272e07bb0142"));
  const tranquill_4 = 320;
  const tranquill_5 = 200;
  const tranquill_6 = tranquill_RN("0x6c62272e07bb0142");
  const tranquill_7 = 480;
  const tranquill_8 = 600;
  const tranquill_9 = tranquill_S("0x6c62272e07bb0142");
  const tranquill_a = Object.freeze({
    key: tranquill_S("0x6c62272e07bb0142"),
    code: tranquill_S("0x6c62272e07bb0142"),
    altKey: false,
    ctrlKey: false,
    metaKey: false,
    shiftKey: false
  });
  let abortBinding = {
    ...tranquill_a
  };
  let isActive = false;
  let suppressionTimer = null;
  let suppressionActive = false;
  let currentSyntheticCharacter = null;
  let activeRequest = null;
  let tranquill_b = 0;
  const tranquill_c = [];
  let allowSyntheticBackspace = false;
  let syntheticBackspaceTimer = null;
  const tranquill_d = {
    enqueued: 0,
    completed: 0,
    backspaces: 0,
    aborted: 0
  };
  const tranquill_e = tranquill_f => {
    if (tranquill_f && typeof tranquill_f === tranquill_S("0x6c62272e07bb0142")) {
      const tranquill_h = typeof tranquill_f.key === tranquill_S("0x6c62272e07bb0142") && tranquill_f.key["length"] > 0 ? tranquill_f.key : tranquill_a.key;
      const tranquill_i = _tranquill_cond;
      return {
        key: tranquill_h,
        code: tranquill_i,
        altKey: tranquill_f.altKey === true,
        ctrlKey: tranquill_f.ctrlKey === true,
        metaKey: tranquill_f["metaKey"] === true,
        shiftKey: tranquill_f.shiftKey === true
      };
    }
    if (typeof tranquill_f === tranquill_S("0x6c62272e07bb0142") && tranquill_f.trim().length > 0) {
      const tranquill_k = tranquill_f["trim"]();
      return {
        key: tranquill_k,
        code: tranquill_k,
        altKey: false,
        ctrlKey: false,
        metaKey: false,
        shiftKey: false
      };
    }
    return {
      ...tranquill_a
    };
  };
  const tranquill_l = tranquill_m => {
    abortBinding = tranquill_e(tranquill_m);
    log.debug(tranquill_S("0x6c62272e07bb0142"), abortBinding);
  };
  const tranquill_n = tranquill_o => {
    if (!tranquill_o || !abortBinding) return false;
    const tranquill_q = typeof tranquill_o.code === tranquill_S("0x6c62272e07bb0142") ? tranquill_o.code : "";
    const tranquill_r = typeof tranquill_o.key === tranquill_S("0x6c62272e07bb0142") ? tranquill_o.key : "";
    const tranquill_s = typeof abortBinding.code === tranquill_S("0x6c62272e07bb0142") && abortBinding.code["length"] > 0 ? abortBinding.code : "";
    const tranquill_t = _tranquill_cond2;
    const tranquill_u = tranquill_s ? tranquill_s === tranquill_q : tranquill_t === tranquill_r;
    if (!tranquill_u) return false;
    return tranquill_o.altKey === Boolean(abortBinding.altKey) && tranquill_o.ctrlKey === Boolean(abortBinding.ctrlKey) && tranquill_o.metaKey === Boolean(abortBinding["metaKey"]) && tranquill_o["shiftKey"] === Boolean(abortBinding.shiftKey);
  };
  const tranquill_w = (tranquill_x = tranquill_S("0x6c62272e07bb0142")) => {
    try {
      chrome["runtime"]?.sendMessage?.({
        action: tranquill_S("0x6c62272e07bb0142"),
        reason: tranquill_x
      });
    } catch (tranquill_y) {
      log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_y);
    }
  };
  const tranquill_z = tranquill_A => {
    if (!tranquill_n(tranquill_A)) return false;
    if (tranquill_A.repeat) return true;
    log.info(tranquill_S("0x6c62272e07bb0142"), {
      key: tranquill_A["key"] ?? null,
      code: tranquill_A["code"] ?? null,
      isActive
    });
    tranquill_c.length = 0;
    if (isActive) {
      tranquill_P(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      tranquill_U();
    }
    tranquill_w(tranquill_S("0x6c62272e07bb0142"));
    return true;
  };
  const tranquill_B = () => {
    try {
      chrome.storage?.local?.get?.(tranquill_9, tranquill_C => {
        const tranquill_D = chrome.runtime?.lastError ?? null;
        if (tranquill_D) {
          log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_D);
          tranquill_l(tranquill_a);
          return;
        }
        const tranquill_E = tranquill_C?.[tranquill_9] ?? null;
        tranquill_l(tranquill_E?.abortKey);
      });
    } catch (tranquill_F) {
      log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_F);
      tranquill_l(tranquill_a);
    }
  };
  tranquill_B();
  chrome["storage"]?.onChanged?.addListener?.((tranquill_G, tranquill_H) => {
    if (tranquill_H !== tranquill_S("0x6c62272e07bb0142")) return;
    if (!tranquill_G || typeof tranquill_G !== tranquill_S("0x6c62272e07bb0142")) return;
    const tranquill_K = tranquill_G[tranquill_9];
    if (!tranquill_K) return;
    try {
      tranquill_l(tranquill_K["newValue"]?.abortKey);
    } catch (tranquill_M) {
      log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_M);
    }
  });
  const tranquill_N = () => {
    if (suppressionTimer !== null) {
      clearTimeout(suppressionTimer);
      suppressionTimer = null;
    }
  };
  const tranquill_O = () => {
    if (syntheticBackspaceTimer !== null) {
      clearTimeout(syntheticBackspaceTimer);
      syntheticBackspaceTimer = null;
    }
    allowSyntheticBackspace = false;
  };
  const tranquill_P = (tranquill_Q, tranquill_R) => {
    if (activeRequest?.fallbackTimer) {
      clearTimeout(activeRequest.fallbackTimer);
      activeRequest["fallbackTimer"] = null;
    }
    const tranquill_T = activeRequest ? activeRequest.id : null;
    tranquill_N();
    suppressionActive = false;
    currentSyntheticCharacter = null;
    tranquill_O();
    if (activeRequest && tranquill_Q === tranquill_S("0x6c62272e07bb0142")) tranquill_d.completed += 1;
    if (tranquill_Q === tranquill_S("0x6c62272e07bb0142")) tranquill_d["aborted"] += 1;
    log["debug"](tranquill_S("0x6c62272e07bb0142"), {
      requestId: tranquill_T,
      status: tranquill_Q,
      reason: tranquill_R,
      queueLength: tranquill_c.length
    });
    activeRequest = null;
    tranquill_Z();
  };
  const tranquill_U = () => {
    tranquill_c.length = 0;
    activeRequest = null;
    tranquill_N();
    suppressionActive = false;
    currentSyntheticCharacter = null;
    tranquill_O();
    log.debug(tranquill_S("0x6c62272e07bb0142"));
  };
  const tranquill_V = (tranquill_W, tranquill_X) => {
    const tranquill_Y = _tranquill_cond3;
    tranquill_N();
    suppressionActive = true;
    suppressionTimer = window.setTimeout(() => {
      suppressionTimer = null;
      suppressionActive = false;
      log.warn(tranquill_S("0x6c62272e07bb0142"), {
        requestId: tranquill_X ?? null,
        queueLength: tranquill_c.length
      });
      tranquill_P(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
    }, tranquill_Y + tranquill_5);
  };
  const tranquill_Z = () => {
    if (!isActive) {
      log.debug(tranquill_S("0x6c62272e07bb0142"));
      return;
    }
    if (activeRequest) {
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        requestId: activeRequest.id,
        queueLength: tranquill_c.length
      });
      return;
    }
    if (tranquill_c.length === 0) {
      log.debug(tranquill_S("0x6c62272e07bb0142"));
      return;
    }
    const tranquill_10 = tranquill_c.shift();
    activeRequest = tranquill_10;
    tranquill_V(tranquill_4, tranquill_10.id);
    tranquill_d.enqueued += 1;
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      requestId: tranquill_10.id,
      queueLength: tranquill_c["length"]
    });
    tranquill_10.fallbackTimer = window["setTimeout"](() => {
      log["warn"](tranquill_S("0x6c62272e07bb0142"), {
        requestId: tranquill_10.id
      });
      tranquill_P(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
    }, tranquill_6);
    try {
      chrome.runtime?.sendMessage?.({
        action: tranquill_S("0x6c62272e07bb0142"),
        requestId: tranquill_10["id"],
        key: tranquill_10.key,
        timeStamp: tranquill_10.timeStamp
      });
    } catch (tranquill_11) {
      log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_11);
      tranquill_P(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
    }
  };
  const tranquill_12 = tranquill_13 => {
    if (!isActive) return false;
    if (tranquill_13.isComposing) return false;
    if (tranquill_13["ctrlKey"] || tranquill_13["metaKey"] || tranquill_13.altKey) return false;
    if (tranquill_13.key === tranquill_S("0x6c62272e07bb0142")) return true;
    if (tranquill_13["key"]["length"] === 1) return true;
    if (tranquill_13["key"] === tranquill_S("0x6c62272e07bb0142")) return true;
    return false;
  };
  const tranquill_14 = tranquill_15 => {
    const tranquill_16 = {
      id: ++tranquill_b,
      key: tranquill_15.key,
      timeStamp: tranquill_15.timeStamp ?? null,
      createdAt: Date.now(),
      expectedKeys: [],
      fallbackTimer: null
    };
    tranquill_c["push"](tranquill_16);
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      requestId: tranquill_16.id,
      queueLength: tranquill_c.length,
      suppressionActive,
      activeRequest: activeRequest ? activeRequest["id"] : null
    });
    tranquill_Z();
  };
  const tranquill_18 = tranquill_19 => {
    if (tranquill_z(tranquill_19)) return;
    if (!tranquill_12(tranquill_19)) return;
    if (allowSyntheticBackspace && tranquill_19["key"] === tranquill_S("0x6c62272e07bb0142")) {
      log["debug"](tranquill_S("0x6c62272e07bb0142"), {
        queueLength: tranquill_c.length
      });
      tranquill_O();
      return;
    }
    if (activeRequest?.expectedKeys?.length) {
      const tranquill_1a = activeRequest.expectedKeys[0];
      if (typeof tranquill_1a === tranquill_S("0x6c62272e07bb0142") && tranquill_19.key === tranquill_1a) {
        activeRequest["expectedKeys"].shift();
        log.debug(tranquill_S("0x6c62272e07bb0142"), {
          requestId: activeRequest.id,
          key: tranquill_19.key,
          remaining: activeRequest.expectedKeys.length
        });
        return;
      }
    }
    if (tranquill_19.key === tranquill_S("0x6c62272e07bb0142")) {
      tranquill_19["preventDefault"]();
      tranquill_19.stopImmediatePropagation?.();
      tranquill_19.stopPropagation();
      if (tranquill_c.length > 0) {
        const tranquill_1c = tranquill_c.pop();
        log.debug(tranquill_S("0x6c62272e07bb0142"), {
          removedRequest: tranquill_1c?.id ?? null,
          queueLength: tranquill_c.length
        });
        return;
      }
      tranquill_d.backspaces += 1;
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        activeRequest: activeRequest ? activeRequest.id : null
      });
      chrome.runtime?.sendMessage?.({
        action: tranquill_S("0x6c62272e07bb0142")
      });
      return;
    }
    if (tranquill_19.repeat) {
      tranquill_19.preventDefault();
      tranquill_19["stopImmediatePropagation"]?.();
      tranquill_19.stopPropagation();
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        key: tranquill_19.key
      });
      return;
    }
    tranquill_19["preventDefault"]();
    tranquill_19.stopImmediatePropagation?.();
    tranquill_19.stopPropagation();
    tranquill_14(tranquill_19);
  };
  const tranquill_1d = tranquill_1e => {
    if (!isActive || tranquill_1e["isComposing"]) return;
    if (typeof tranquill_1e["inputType"] === tranquill_S("0x6c62272e07bb0142") && tranquill_1e.inputType.startsWith(tranquill_S("0x6c62272e07bb0142"))) return;
    const tranquill_1f = (() => {
      if (typeof tranquill_1e["data"] === tranquill_S("0x6c62272e07bb0142") && tranquill_1e.data.length > 0) {
        return tranquill_1e["data"] === currentSyntheticCharacter;
      }
      if (currentSyntheticCharacter === tranquill_S("0x6c62272e07bb0142")) {
        return tranquill_1e.inputType === tranquill_S("0x6c62272e07bb0142") || tranquill_1e.inputType === tranquill_S("0x6c62272e07bb0142");
      }
      return false;
    })();
    const tranquill_1g = suppressionActive && !activeRequest && tranquill_c.length === 0 && currentSyntheticCharacter === null;
    if (tranquill_1f || tranquill_1g) {
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        reason: tranquill_1f ? tranquill_S("0x6c62272e07bb0142") : tranquill_S("0x6c62272e07bb0142"),
        inputType: tranquill_1e.inputType,
        requestId: activeRequest ? activeRequest.id : null
      });
      currentSyntheticCharacter = null;
      return;
    }
    let _tranquill_cond4 = activeRequest;
    if (_tranquill_cond4) {
      activeRequest.id;
    } else {
      null;
    }
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      inputType: tranquill_1e.inputType,
      data: tranquill_1e["data"],
      suppressionActive,
      activeRequest: _tranquill_cond4
    });
    tranquill_1e["preventDefault"]();
    tranquill_1e["stopImmediatePropagation"]?.();
    tranquill_1e["stopPropagation"]();
  };
  chrome.runtime["onMessage"].addListener((tranquill_1h, tranquill_1i, tranquill_1j) => {
    if (!tranquill_1h || typeof tranquill_1h !== tranquill_S("0x6c62272e07bb0142")) {
      tranquill_1j?.({
        success: false
      });
      return false;
    }
    if (tranquill_1h["action"] === tranquill_S("0x6c62272e07bb0142")) {
      log.debug(tranquill_S("0x6c62272e07bb0142"));
      tranquill_1j?.({
        success: true,
        pong: true
      });
      return false;
    }
    if (tranquill_1h.action === tranquill_S("0x6c62272e07bb0142")) {
      isActive = !!tranquill_1h.active;
      log.info(tranquill_S("0x6c62272e07bb0142"), {
        isActive
      });
      if (!isActive) {
        tranquill_U();
      } else {
        tranquill_Z();
      }
      tranquill_1j?.({
        success: true
      });
      return false;
    }
    if (tranquill_1h.action === tranquill_S("0x6c62272e07bb0142")) {
      if (!activeRequest || tranquill_1h.requestId !== activeRequest["id"]) {
        log.warn(tranquill_S("0x6c62272e07bb0142"), {
          requestId: tranquill_1h.requestId ?? null,
          activeRequest: activeRequest ? activeRequest.id : null
        });
        tranquill_1j?.({
          success: false,
          accepted: false
        });
        return false;
      }
      activeRequest.expectedKeys = Array.isArray(tranquill_1h.keys) ? tranquill_1h.keys.filter(tranquill_1m => typeof tranquill_1m === tranquill_S("0x6c62272e07bb0142") && tranquill_1m["length"] > 0) : [];
      currentSyntheticCharacter = typeof tranquill_1h.character === tranquill_S("0x6c62272e07bb0142") ? tranquill_1h["character"] : null;
      tranquill_V(Number(tranquill_1h.duration), activeRequest["id"]);
      if (activeRequest["fallbackTimer"]) {
        clearTimeout(activeRequest.fallbackTimer);
      }
      const tranquill_1o = Math.max(tranquill_4, Number(tranquill_1h.duration) || tranquill_4);
      activeRequest["fallbackTimer"] = window["setTimeout"](() => {
        log.warn(tranquill_S("0x6c62272e07bb0142"), {
          requestId: activeRequest?.id ?? null
        });
        tranquill_P(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      }, tranquill_1o + tranquill_7);
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        requestId: activeRequest["id"],
        expectedKeys: activeRequest["expectedKeys"],
        character: currentSyntheticCharacter
      });
      tranquill_1j?.({
        success: true,
        accepted: true
      });
      return false;
    }
    if (tranquill_1h.action === tranquill_S("0x6c62272e07bb0142")) {
      if (!activeRequest || tranquill_1h.requestId !== activeRequest["id"]) {
        log.warn(tranquill_S("0x6c62272e07bb0142"), {
          requestId: tranquill_1h.requestId ?? null,
          activeRequest: activeRequest ? activeRequest.id : null
        });
        tranquill_1j?.({
          success: false
        });
        return false;
      }
      tranquill_P(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      tranquill_1j?.({
        success: true
      });
      return false;
    }
    if (tranquill_1h.action === tranquill_S("0x6c62272e07bb0142")) {
      tranquill_O();
      allowSyntheticBackspace = true;
      const tranquill_1p = Math.max(tranquill_8, Number(tranquill_1h.duration) || 0);
      syntheticBackspaceTimer = window["setTimeout"](tranquill_O, tranquill_1p + tranquill_7);
      log["debug"](tranquill_S("0x6c62272e07bb0142"), {
        windowMs: tranquill_1p
      });
      tranquill_1j?.({
        success: true
      });
      return false;
    }
    if (tranquill_1h.action === tranquill_S("0x6c62272e07bb0142")) {
      if (!activeRequest || tranquill_1h.requestId !== activeRequest.id) {
        log.warn(tranquill_S("0x6c62272e07bb0142"), {
          requestId: tranquill_1h.requestId ?? null,
          activeRequest: activeRequest ? activeRequest.id : null
        });
        tranquill_1j?.({
          success: false
        });
        return false;
      }
      log.warn(tranquill_S("0x6c62272e07bb0142"), {
        requestId: activeRequest.id,
        character: tranquill_1h.character ?? null
      });
      tranquill_P(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      tranquill_1j?.({
        success: true
      });
      return false;
    }
    tranquill_1j?.({
      success: false
    });
    return false;
  });
  window.addEventListener(tranquill_S("0x6c62272e07bb0142"), tranquill_18, true);
  window.addEventListener(tranquill_S("0x6c62272e07bb0142"), tranquill_1d, true);
  log["info"](tranquill_S("0x6c62272e07bb0142"), tranquill_d);
  chrome.runtime?.sendMessage?.({
    action: tranquill_S("0x6c62272e07bb0142")
  });
})();
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}