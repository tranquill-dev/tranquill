var tranquill_runtime_exports = (() => {
        const tranquill_global = typeof self !== "undefined" ? self : globalThis;
        if (tranquill_global.tranquill_runtime_ready) {
                return {
                        tranquill_S: tranquill_global.tranquill_S,
                        tranquill_RN: tranquill_global.tranquill_RN,
                        tranquill_next: tranquill_global.tranquill_next,
                        tranquill_signature: tranquill_global.tranquill_signature,
                        tranquill_seed: tranquill_global.tranquill_seed,
                };
        }
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::457f0536cb00f0db9dec4c0cbf422f54"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        const exports = {
                tranquill_S,
                tranquill_RN,
                tranquill_next,
                tranquill_signature: "tranquill_tranquill_tranquill",
                tranquill_seed: tranquill_global.tranquill_seed,
        };
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = exports.tranquill_signature;
        tranquill_global.tranquill_seed = exports.tranquill_seed;
        tranquill_global.tranquill_runtime_ready = true;
        if (typeof tranquill_global === "object" && tranquill_global) {
                try {
                        tranquill_global.tranquill_runtime = exports;
                } catch (error) {
                        // ignore assignment issues in restricted environments
                }
        }
        if (typeof window !== "undefined") {
                window.tranquill_S = tranquill_S;
                window.tranquill_RN = tranquill_RN;
                window.tranquill_next = tranquill_next;
        }
        if (typeof global !== "undefined") {
                global.tranquill_S = tranquill_S;
                global.tranquill_RN = tranquill_RN;
                global.tranquill_next = tranquill_next;
        }
        return exports;
})();

(function tranquill_0() {
  const tranquill_1 = new Uint8Array([189, 190, 167, 171, 170, 165, 179, 189, 168, 191, 172, 175, 188, 184, 169, 191, 184, 188, 152, 150, 145, 135, 150, 129, 164, 163, 191, 175, 185, 189, 168, 164, 134, 141, 134, 150, 139, 134, 158, 155, 132, 146, 130, 130, 133, 131, 153, 132, 149, 145, 109, 107, 107, 108, 104, 104, 157, 152, 136, 151, 144, 144, 158, 149, 228, 226, 249, 250, 254, 227, 251, 249, 241, 230, 237, 237, 236, 255, 237, 250, 251, 251, 216, 219, 208, 197, 195, 220, 239, 255, 242, 240, 249, 253, 251, 255, 223, 206, 195, 212, 200, 192, 208, 214, 210, 192, 192, 220, 203, 216, 212, 165, 17, 87, 167, 161, 21, 83, 171, 173, 25, 95, 175, 169, 29, 91, 179, 181, 1, 71, 183, 177, 5, 67, 187, 189, 9, 127, 106, 97, 76, 42, 108, 47, 8, 41, 65, 24, 44, 52, 82, 19, 199, 130, 42, 14, 212, 57, 72, 156, 34, 203, 90, 21, 241, 224, 77, 65, 165, 245, 71, 90, 243, 236, 81, 80, 225, 165, 83, 90, 247, 165, 65, 76, 245, 236, 91, 82, 217, 128, 28, 9, 232, 201, 6, 23, 184, 211, 13, 3, 235, 201, 7, 30, 184, 201, 27, 80, 249, 204, 26, 21, 249, 196, 17, 80, 234, 213, 6, 30, 241, 206, 15, 84, 143, 150, 89, 83, 146, 153, 76, 7, 143, 142, 91, 78, 149, 144, 11, 84, 158, 132, 88, 78, 148, 153, 49, 246, 199, 43, 32, 186, 210, 56, 61, 253, 208, 47, 33, 233, 130, 44, 51, 243, 206, 181, 190, 32, 148, 160, 180, 39, 193, 182, 181, 42, 149, 178, 179, 47, 132, 243, 176, 49, 132, 178, 149, 235, 32, 129, 128, 164, 38, 144, 154, 240, 34, 150, 159, 225, 99, 149, 129, 225, 34, 212, 149, 229, 42, 152, 150, 224, 128, 180, 161, 130, 132, 179, 173, 155, 110, 190, 132, 251, 15, 26, 249, 255, 8, 22, 228, 69, 129, 207, 208, 47, 162, 233, 201, 57, 164, 186, 208, 56, 191, 253, 210, 47, 163, 233, 128, 98, 163, 238, 193, 56, 164, 179, 128, 44, 177, 243, 204, 202, 22, 222, 214, 208, 8, 142, 204, 219, 28, 221, 214, 209, 1, 142, 210, 223, 29, 197, 218, 218, 79, 207, 220, 202, 6, 216, 218, 63, 203, 222, 61, 59, 204, 210, 20, 122, 245, 12, 16, 125, 249, 66, 5, 113, 224, 11, 18, 115, 224, 11, 11, 124, 180, 4, 5, 123, 248, 7, 0, 195, 163, 162, 21, 231, 164, 174, 91, 222, 164, 167, 30, 179, 168, 172, 14, 255, 175, 227, 21, 252, 191, 227, 25, 246, 235, 162, 24, 231, 162, 181, 26, 231, 174, 167, 103, 184, 102, 78, 99, 191, 106, 0, 122, 191, 99, 69, 55, 162, 98, 65, 115, 169, 94, 61, 202, 93, 68, 35, 154, 88, 69, 43, 202, 20, 79, 54, 200, 91, 88, 48, 1, 146, 55, 55, 28, 157, 34, 99, 20, 134, 49, 44, 85, 135, 60, 51, 28, 157, 34, 99, 25, 156, 42, 51, 146, 239, 224, 169, 139, 249, 230, 250, 202, 235, 231, 174, 141, 163, 178, 188, 131, 227, 254, 142, 180, 75, 158, 207, 181, 70, 129, 134, 175, 88, 209, 131, 174, 80, 129, 207, 162, 80, 156, 159, 173, 90, 133, 138, 156, 45, 249, 135, 107, 25, 243, 159, 121, 5, 242, 146, 244, 126, 98, 170, 98, 100, 124, 250, 127, 115, 107, 181, 43, 99, 117, 176, 110, 105, 111, 191, 111, 169, 220, 165, 36, 221, 214, 165, 48, 213, 212, 171, 106, 200, 195, 188, 35, 210, 221, 236, 57, 217, 201, 191, 35, 211, 212, 213, 161, 180, 215, 209, 166, 184, 188, 248, 253, 174, 184, 255, 241, 224, 168, 245, 253, 163, 184, 249, 234, 161, 184, 245, 188, 166, 173, 249, 240, 14, 202, 248, 234, 13, 200, 255, 237, 74, 203, 255, 235, 11, 204, 242, 191, 5, 193, 186, 249, 3, 193, 251, 243, 3, 213, 255, 191, 12, 206, 243, 243, 7, 250, 34, 16, 231, 223, 145, 226, 246, 147, 132, 241, 235, 212, 134, 230, 247, 192, 212, 171, 224, 220, 154, 230, 173, 147, 146, 226, 237, 223, 97, 232, 243, 110, 120, 254, 245, 61, 57, 235, 232, 115, 112, 225, 232, 103, 116, 164, 161, 123, 112, 228, 237, 88, 65, 192, 89, 82, 65, 212, 93, 30, 75, 193, 85, 78, 68, 203, 76, 91, 49, 17, 125, 69, 98, 23, 119, 68, 55, 0, 97, 65, 39, 1, 71, 179, 166, 69, 67, 180, 170, 153, 233, 53, 130, 130, 242, 60, 204, 155, 244, 58, 130, 159, 243, 54, 204, 154, 233, 62, 153, 142, 188, 47, 141, 152, 247, 142, 128, 15, 150, 138, 135, 3, 216, 138, 137, 29, 147, 222, 142, 15, 145, 146, 108, 251, 232, 112, 108, 224, 252, 37, 121, 253, 248, 107, 125, 250, 244, 37, 125, 231, 240, 98, 110, 240, 235, 251, 190, 63, 213, 251, 165, 43, 128, 238, 184, 47, 206, 234, 191, 35, 128, 252, 177, 45, 203, 237, 160, 47, 195, 251, 217, 173, 184, 219, 221, 170, 180, 205, 220, 130, 221, 216, 221, 158, 215, 211, 201, 205, 206, 213, 207, 131, 202, 210, 195, 205, 202, 207, 199, 138, 217, 216, 220, 37, 144, 36, 6, 33, 151, 40, 72, 38, 140, 32, 24, 33, 149, 180, 47, 54, 141, 135, 11, 36, 154, 34, 10, 83, 39, 63, 25, 29, 148, 28, 47, 42, 13, 207, 76, 25, 9, 200, 64, 36, 4, 201, 89, 31, 24, 211, 68, 20, 46, 211, 76, 5, 9, 239, 202, 206, 28, 235, 205, 194, 82, 236, 219, 193, 6, 247, 199, 219, 27, 252, 130, 220, 6, 254, 208, 219, 82, 241, 205, 219, 82, 254, 193, 196, 28, 240, 213, 195, 23, 251, 197, 202, 22, 51, 82, 146, 36, 55, 85, 158, 106, 55, 67, 131, 47, 0, 82, 146, 56, 34, 89, 135, 47, 49, 26, 149, 43, 42, 86, 150, 46, 56, 72, 121, 62, 60, 79, 117, 3, 49, 78, 108, 56, 45, 84, 113, 51, 13, 78, 124, 149, 59, 180, 141, 145, 60, 184, 195, 128, 61, 177, 195, 139, 60, 161, 138, 131, 42, 245, 133, 132, 58, 185, 134, 129, 130, 152, 3, 110, 134, 159, 15, 83, 139, 158, 22, 104, 151, 132, 11, 99, 179, 146, 13, 114, 134, 97, 201, 192, 127, 101, 206, 204, 49, 112, 195, 206, 99, 101, 129, 207, 126, 101, 200, 199, 104, 49, 199, 192, 120, 125, 196, 197, 213, 214, 148, 192, 209, 209, 152, 142, 209, 199, 133, 203, 133, 219, 135, 220, 202, 204, 195, 85, 17, 179, 218, 67, 23, 224, 155, 64, 11, 161, 221, 68, 12, 173, 154, 16, 5, 161, 218, 92, 42, 224, 107, 54, 46, 231, 103, 120, 41, 252, 111, 40, 122, 235, 101, 53, 42, 228, 111, 44, 63, 30, 89, 31, 15, 26, 94, 19, 65, 30, 93, 31, 15, 78, 84, 6, 9, 15, 68, 13, 21, 11, 85, 19, 231, 242, 17, 23, 224, 254, 229, 154, 74, 251, 240, 155, 86, 241, 251, 143, 5, 232, 253, 137, 75, 236, 250, 133, 5, 250, 244, 139, 78, 235, 229, 137, 70, 253, 84, 186, 53, 76, 80, 189, 57, 113, 93, 188, 32, 74, 65, 166, 61, 65, 102, 179, 55, 73, 87, 162, 53, 65, 65, 55, 155, 150, 45, 51, 156, 154, 99, 37, 146, 148, 40, 52, 131, 150, 32, 34, 211, 153, 44, 51, 154, 145, 58, 103, 149, 150, 42, 43, 150, 147, 220, 133, 67, 132, 117, 129, 68, 136, 59, 151, 74, 134, 112, 134, 91, 132, 120, 144, 11, 129, 114, 134, 91, 132, 111, 150, 67, 197, 125, 148, 66, 137, 126, 145, 119, 119, 69, 113, 110, 97, 67, 34, 47, 98, 95, 99, 105, 102, 88, 111, 39, 112, 86, 97, 108, 97, 71, 99, 100, 119, 30, 34, 97, 115, 94, 110, 236, 164, 173, 242, 232, 163, 161, 188, 254, 173, 175, 247, 239, 188, 173, 255, 249, 236, 188, 238, 243, 175, 169, 239, 239, 169, 168, 203, 30, 31, 222, 209, 0, 60, 195, 222, 19, 26, 196, 252, 15, 14, 217, 216, 2, 11, 154, 71, 251, 215, 161, 84, 241, 220, 175, 2, 253, 220, 172, 18, 174, 230, 14, 8, 176, 182, 20, 18, 182, 226, 18, 21, 247, 244, 21, 9, 182, 242, 4, 7, 164, 226, 71, 0, 182, 255, 11, 18, 170, 106, 18, 24, 170, 126, 22, 84, 162, 98, 7, 17, 177, 36, 23, 17, 183, 101, 16, 28, 227, 98, 18, 29, 175]);
  const tranquill_2 = self.tranquill_PACK = self["tranquill_PACK"] || {
    idx: new Map(),
    data: []
  };
  tranquill_2["data"].push(tranquill_1);
  const tranquill_3 = tranquill_2["data"]["length"] - 1;
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 0,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 2,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 3,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 4,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 5,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 6,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 7,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 8,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 9,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 10,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 11,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 12,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 13,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 14,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 15,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 16,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 17,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 18,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 19,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 20,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 21,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 22,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 23,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 24,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 25,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 26,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 27,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 28,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 29,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 30,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 31,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 32,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 33,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 34,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 35,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 36,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 37,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 38,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 39,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 40,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 41,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 42,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 43,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 44,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 45,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 46,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 47,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 48,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 49,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 50,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 51,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 52,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 53,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 54,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 55,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 56,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 57,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 58,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 59,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 60,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 61,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 62,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 63,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 64,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 65,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 66,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 67,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 68,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 69,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 70,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 71,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 72,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 73,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 74,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 75,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 76,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 77,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 78,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 79,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 80,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 81,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 82,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 83,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 84,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 85,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 86,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 87,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 88,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 89,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 90,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 91,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 92,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 93,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 94,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 95,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 96,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 97,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 98,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 99,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 100,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 101,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 102,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 103,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 104,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 105,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 106,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 107,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 108,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 109,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 110,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 111,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 137,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 145,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 151,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 157,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 161,
    len: 27,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 188,
    len: 35,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 223,
    len: 23,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 246,
    len: 19,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 265,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 286,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 312,
    len: 7,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 319,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 323,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 330,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 334,
    len: 29,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 363,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 391,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 398,
    len: 25,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 423,
    len: 35,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 458,
    len: 18,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 476,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 493,
    len: 25,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 518,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 537,
    len: 25,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 562,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 566,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 574,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 575,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 595,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 596,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 621,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 628,
    len: 23,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 651,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 683,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 687,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 713,
    len: 23,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 736,
    len: 17,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 753,
    len: 14,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 767,
    len: 7,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 774,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 800,
    len: 17,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 817,
    len: 23,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 840,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 865,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 872,
    len: 26,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 898,
    len: 12,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 910,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 920,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 926,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 931,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 952,
    len: 40,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 992,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1020,
    len: 19,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1039,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1064,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1085,
    len: 27,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1112,
    len: 18,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1130,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1152,
    len: 21,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1173,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1195,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1202,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1230,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1255,
    len: 31,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1286,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1287,
    len: 33,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1320,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1352,
    len: 27,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1379,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1398,
    len: 13,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1411,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1439,
    len: 26,
    kind: 1
  });
})();
const tranquill_4 = Object.freeze({
  a: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  b: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  c: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  d: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  e: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  f: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  g: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  h: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  i: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  j: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  k: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  l: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  m: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  n: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  o: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  p: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  q: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  r: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  s: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  t: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  u: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  v: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  w: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  x: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  y: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  z: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")]
});
const tranquill_5 = tranquill_S("0x6c62272e07bb0142");
const tranquill_6 = tranquill_S("0x6c62272e07bb0142");
const tranquill_7 = tranquill_8 => {
  if (!Array.isArray(tranquill_8) || tranquill_8.length === 0) return null;
  const tranquill_9 = Math.floor(Math.random() * tranquill_8.length);
  return tranquill_8[tranquill_9];
};
const tranquill_a = tranquill_b => {
  if (!tranquill_b || typeof tranquill_b !== tranquill_S("0x6c62272e07bb0142")) return null;
  const tranquill_e = tranquill_b.charAt(0);
  if (!tranquill_6.test(tranquill_e)) return null;
  const tranquill_f = tranquill_e.toLowerCase();
  const tranquill_g = (tranquill_4[tranquill_f] || []).filter(tranquill_h => typeof tranquill_h === tranquill_S("0x6c62272e07bb0142") && tranquill_h.toLowerCase() !== tranquill_f);
  let candidate = null;
  if (tranquill_g["length"] && Math["random"]() < 0.75) candidate = tranquill_7(tranquill_g);
  if (!candidate) {
    const tranquill_j = tranquill_5.replace(tranquill_f, "");
    if (!tranquill_j.length) return null;
    candidate = tranquill_j.charAt(Math.floor(Math.random() * tranquill_j.length));
  }
  if (!candidate) return null;
  if (tranquill_e === tranquill_e.toUpperCase()) candidate = candidate.toUpperCase();
  if (candidate.toLowerCase() === tranquill_f) return null;
  return candidate;
};
class tranquill_k {
  constructor({
    debuggerManager: tranquill_l,
    typingModel: tranquill_m,
    phantomController: tranquill_n
  }) {
    this["debuggerManager"] = tranquill_l;
    this.typingModel = tranquill_m;
    this["phantomController"] = tranquill_n;
    this.isRunning = false;
    this["activeTabId"] = null;
    this.plan = null;
    this.delayController = null;
    this.ghostModeEnabled = true;
    this.ghostRevisions = [];
    this.mode = tranquill_S("0x6c62272e07bb0142");
    this.sourceText = "";
    this.lastOutputCharacter = null;
    this.textSignature = null;
    this.currentIndex = 0;
    this.totalCharacters = 0;
    this._phantomQueue = Promise.resolve();
    this._finalized = false;
  }
  isActive() {
    return this.isRunning;
  }
  async start({
    text: tranquill_o,
    startIndex: tranquill_p = 0,
    settings: tranquill_q = {}
  }) {
    if (!tranquill_o || !String(tranquill_o).trim()) throw new Error(tranquill_S("0x6c62272e07bb0142"));
    if (this["isRunning"]) throw new Error(tranquill_S("0x6c62272e07bb0142"));
    log.info(tranquill_S("0x6c62272e07bb0142"), {
      requestedStartIndex: tranquill_p,
      textLength: tranquill_o?.length ?? 0,
      phantomMode: tranquill_q?.phantomMode === true
    });
    let idx = Math.min(Math.max(tranquill_p, 0), tranquill_o.length);
    if (idx >= tranquill_o.length) {
      idx = 0;
      await TextStorage.clearProgress().catch(tranquill_s => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_s));
    }
    const tranquill_t = await this.debuggerManager.ensureAttached();
    this.activeTabId = tranquill_t;
    try {
      await this.debuggerManager.focusEditableArea(tranquill_t);
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        tabId: tranquill_t
      });
    } catch (tranquill_u) {
      await this.debuggerManager.detach();
      this["activeTabId"] = null;
      log["error"](tranquill_S("0x6c62272e07bb0142"), tranquill_u);
      throw tranquill_u;
    }
    let _tranquill_cond = tranquill_q["phantomMode"] === true;
    if (_tranquill_cond) {
      tranquill_S("0x6c62272e07bb0142");
    } else {
      tranquill_S("0x6c62272e07bb0142");
    }
    this.mode = _tranquill_cond;
    this.ghostModeEnabled = tranquill_q.ghostMode !== false && this.mode !== tranquill_S("0x6c62272e07bb0142");
    this.sourceText = String(tranquill_o);
    this["textSignature"] = TextStorage.createTextSignature(this["sourceText"]);
    this["_finalized"] = false;
    this._phantomQueue = Promise["resolve"]();
    const tranquill_v = new TypingPlan(this.sourceText, this.typingModel, idx);
    this.plan = tranquill_v;
    this.totalCharacters = tranquill_v.length;
    this.currentIndex = tranquill_v.currentIndex;
    this["lastOutputCharacter"] = idx > 0 ? this.sourceText[idx - 1] : null;
    this.ghostRevisions = this["ghostModeEnabled"] ? new RevisionPlanner(this.sourceText, this.typingModel, idx).build() : [];
    this.delayController = this.mode === tranquill_S("0x6c62272e07bb0142") ? new DelayController() : null;
    await TextStorage["setProgress"](this["currentIndex"], this["textSignature"]).catch(tranquill_w => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_w));
    this.isRunning = true;
    this.#broadcastTyping(true);
    log.info(tranquill_S("0x6c62272e07bb0142"), {
      mode: this.mode,
      tabId: tranquill_t,
      startingIndex: this["currentIndex"],
      totalCharacters: this.totalCharacters
    });
    if (this.mode === tranquill_S("0x6c62272e07bb0142")) {
      await this["phantomController"]["waitUntilReady"](tranquill_t);
      const tranquill_x = await this.phantomController["setActive"](tranquill_t, true);
      if (!tranquill_x) {
        log.error(tranquill_S("0x6c62272e07bb0142"), {
          tabId: tranquill_t
        });
        await this.finalize({
          completed: false,
          detachDebugger: true
        });
        throw new Error(tranquill_S("0x6c62272e07bb0142"));
      }
      log.info(tranquill_S("0x6c62272e07bb0142"), {
        tabId: tranquill_t
      });
      return;
    }
    (async () => {
      let completed = false;
      try {
        completed = await this.#runAuto(tranquill_v);
      } catch (tranquill_z) {
        log["error"](tranquill_S("0x6c62272e07bb0142"), tranquill_z);
      } finally {
        await this.finalize({
          completed,
          detachDebugger: true
        });
      }
    })();
  }
  async #runAuto(tranquill_A) {
    const tranquill_B = this.delayController;
    if (!tranquill_A || !tranquill_B) return false;
    log["debug"](tranquill_S("0x6c62272e07bb0142"), {
      remaining: Math.max(0, tranquill_A["length"] - tranquill_A["currentIndex"])
    });
    while (this.isRunning && tranquill_A.hasNext()) {
      const tranquill_E = tranquill_A.peek();
      if (!tranquill_E) break;
      await this.#maybeInjectTypo(tranquill_E);
      if (!this.isRunning || this.activeTabId === null) return false;
      await tranquill_B.wait(tranquill_E["delay"]);
      if (!this["isRunning"] || this.activeTabId === null) return false;
      await this.debuggerManager["typeCharacter"](this.activeTabId, tranquill_E["character"]);
      this.lastOutputCharacter = tranquill_E.character;
      tranquill_A.advance();
      this.currentIndex = tranquill_A["currentIndex"];
      await TextStorage["setProgress"](this.currentIndex, this.textSignature)["catch"](tranquill_G => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_G));
      await this.#maybeGhost(tranquill_A.currentIndex);
    }
    log["info"](tranquill_S("0x6c62272e07bb0142"), {
      finished: tranquill_A.hasNext() === false,
      currentIndex: this["currentIndex"]
    });
    return tranquill_A.hasNext() === false;
  }
  async #maybeGhost(tranquill_H) {
    if (!this.ghostModeEnabled || !this.ghostRevisions?.length) return;
    while (this["ghostRevisions"]["length"] && this["ghostRevisions"][0].triggerIndex <= tranquill_H) {
      const tranquill_I = this.ghostRevisions.shift();
      await this.#performGhost(tranquill_I);
      if (!this["isRunning"]) return;
    }
  }
  async #maybeInjectTypo(tranquill_J) {
    if (!this.ghostModeEnabled || this.mode !== tranquill_S("0x6c62272e07bb0142") || !this.delayController || !tranquill_J || !tranquill_6.test(tranquill_J["character"] || "") || this["activeTabId"] === null) return false;
    const tranquill_L = 0.05;
    if (Math.random() >= tranquill_L) return false;
    const tranquill_M = tranquill_a(tranquill_J.character);
    if (!tranquill_M) return false;
    const tranquill_O = this.delayController;
    const tranquill_P = Number.isFinite(tranquill_J["delay"]) ? tranquill_J["delay"] : typeof this.typingModel?.baseDelay === tranquill_S("0x6c62272e07bb0142") ? this.typingModel.baseDelay() : 120;
    const tranquill_Q = Math.max(155, Math.round(tranquill_P * 0.35 + Math.random() * 130));
    if (tranquill_Q > 0) {
      await tranquill_O.wait(tranquill_Q);
      if (!this["isRunning"] || this.activeTabId === null) return true;
    }
    await this.debuggerManager.typeCharacter(this.activeTabId, tranquill_M);
    this.lastOutputCharacter = tranquill_M;
    const tranquill_R = Math.max(170, Math.round(tranquill_P * 0.25 + Math["random"]() * 95));
    await tranquill_O.wait(tranquill_R);
    if (!this.isRunning || this.activeTabId === null) return true;
    await this.debuggerManager.typeCharacter(this["activeTabId"], tranquill_S("0x6c62272e07bb0142"));
    const tranquill_T = tranquill_J.index > 0 ? tranquill_J.index - 1 : -1;
    const tranquill_U = tranquill_T >= 0 && tranquill_T < this.sourceText.length ? this.sourceText[tranquill_T] : null;
    this.lastOutputCharacter = tranquill_U || null;
    const tranquill_V = Math.max(30, Math["round"](tranquill_P * 0.3 + Math.random() * 45));
    await tranquill_O.wait(tranquill_V);
    if (!this.isRunning || this.activeTabId === null) return true;
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      index: tranquill_J.index,
      intended: tranquill_J.character,
      injected: tranquill_M
    });
    return true;
  }
  async #performGhost(tranquill_W) {
    if (!tranquill_W || !tranquill_W.segmentText || !this["delayController"] || this.activeTabId === null) return;
    if (tranquill_W.pauseBefore > 0) {
      await this.delayController["wait"](tranquill_W.pauseBefore);
      if (!this.isRunning) return;
    }
    const tranquill_Y = Array["from"](tranquill_W["segmentText"]);
    for (let tranquill_Z = 0; tranquill_Z < tranquill_Y.length; tranquill_Z++) {
      const tranquill_11 = Array["isArray"](tranquill_W.backspaceDelays) ? tranquill_W.backspaceDelays[tranquill_Z] || 0 : 0;
      if (tranquill_11 > 0) {
        await this.delayController.wait(tranquill_11);
        if (!this["isRunning"]) return;
      }
      await this.debuggerManager.typeCharacter(this.activeTabId, tranquill_S("0x6c62272e07bb0142"));
    }
    this.lastOutputCharacter = tranquill_W.previousCharacter || null;
    if (!this.isRunning) return;
    if (tranquill_W["pauseAfter"] > 0) {
      await this.delayController.wait(tranquill_W.pauseAfter);
      if (!this.isRunning) return;
    }
    for (let tranquill_12 = 0; tranquill_12 < tranquill_Y["length"]; tranquill_12++) {
      const tranquill_14 = Array.isArray(tranquill_W.retypeDelays) ? tranquill_W.retypeDelays[tranquill_12] || 0 : 0;
      if (tranquill_14 > 0) {
        await this.delayController.wait(tranquill_14);
        if (!this.isRunning) return;
      }
      const tranquill_15 = tranquill_Y[tranquill_12];
      await this.debuggerManager.typeCharacter(this.activeTabId, tranquill_15);
      this["lastOutputCharacter"] = tranquill_15;
    }
  }
  async finalize({
    completed: tranquill_16 = false,
    detachDebugger: tranquill_17 = true
  } = {}) {
    if (this["_finalized"]) return;
    this["_finalized"] = true;
    log["info"](tranquill_S("0x6c62272e07bb0142"), {
      completed: tranquill_16,
      detachDebugger: tranquill_17,
      tabId: this["activeTabId"],
      mode: this["mode"],
      currentIndex: this["currentIndex"]
    });
    const tranquill_18 = this.delayController;
    this["delayController"] = null;
    if (tranquill_18) tranquill_18.cancel();
    const tranquill_19 = this.mode === tranquill_S("0x6c62272e07bb0142");
    const tranquill_1a = this["activeTabId"];
    if (tranquill_19 && tranquill_1a !== null) {
      try {
        await this.phantomController.setActive(tranquill_1a, false);
      } catch (tranquill_1b) {
        log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_1b);
      }
    }
    this.activeTabId = null;
    if (tranquill_17 && tranquill_1a !== null) {
      try {
        await this["debuggerManager"]["detach"]();
      } catch (tranquill_1c) {
        log["warn"](tranquill_S("0x6c62272e07bb0142"), tranquill_1c);
      }
    }
    const tranquill_1d = this.isRunning;
    this.isRunning = false;
    this["plan"] = null;
    this["ghostRevisions"] = [];
    this["sourceText"] = "";
    this.lastOutputCharacter = null;
    this.mode = tranquill_S("0x6c62272e07bb0142");
    this._phantomQueue = Promise.resolve();
    if (tranquill_16) {
      await TextStorage.clearProgress().catch(tranquill_1e => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_1e));
      this.currentIndex = 0;
      this["totalCharacters"] = 0;
    } else if (this.totalCharacters > 0) {
      await TextStorage.setProgress(this.currentIndex, this.textSignature).catch(tranquill_1f => log["warn"](tranquill_S("0x6c62272e07bb0142"), tranquill_1f));
    }
    this.textSignature = null;
    if (tranquill_1d) this.#broadcastTyping(false);
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      clearedProgress: tranquill_16,
      textSignature: this.textSignature
    });
  }
  async stop() {
    if (this._finalized && !this.isRunning) return;
    this.isRunning = false;
    log.info(tranquill_S("0x6c62272e07bb0142"), {
      currentIndex: this.currentIndex,
      tabId: this.activeTabId
    });
    if (this.delayController) this.delayController["cancel"]();
    await this.finalize({
      completed: false,
      detachDebugger: true
    });
  }
  #enqueuePhantom(tranquill_1g) {
    this._phantomQueue = (this._phantomQueue || Promise.resolve()).then(async () => {
      if (!this["isRunning"] || this["mode"] !== tranquill_S("0x6c62272e07bb0142")) return;
      log.debug(tranquill_S("0x6c62272e07bb0142"));
      await tranquill_1g();
    }).catch(tranquill_1h => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_1h));
    return this["_phantomQueue"];
  }
  handlePhantomTrigger(tranquill_1i, tranquill_1j = null, tranquill_1k = null, tranquill_1l = null, tranquill_1m = null) {
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      tabId: tranquill_1i,
      requestId: tranquill_1j,
      key: tranquill_1k,
      timeStamp: tranquill_1l,
      frameId: tranquill_1m
    });
    return this.#enqueuePhantom(() => this.#onPhantomTrigger(tranquill_1i, {
      requestId: tranquill_1j,
      key: tranquill_1k,
      timeStamp: tranquill_1l,
      frameId: tranquill_1m
    }));
  }
  handlePhantomBackspace(tranquill_1n, tranquill_1o = null) {
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      tabId: tranquill_1n,
      frameId: tranquill_1o
    });
    return this.#enqueuePhantom(() => this.#onPhantomBackspace(tranquill_1n, tranquill_1o));
  }
  async #onPhantomTrigger(tranquill_1p, tranquill_1q = {}) {
    if (!this.isRunning || this.mode !== tranquill_S("0x6c62272e07bb0142") || this["activeTabId"] !== tranquill_1p) return;
    const tranquill_1r = tranquill_1q?.requestId ?? null;
    const tranquill_1s = tranquill_1q?.key ?? null;
    const tranquill_1t = tranquill_1q?.timeStamp ?? null;
    const tranquill_1u = Number.isInteger(tranquill_1q?.frameId) ? tranquill_1q["frameId"] : null;
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      tabId: tranquill_1p,
      requestId: tranquill_1r,
      hasPlan: Boolean(this["plan"]),
      triggerKey: tranquill_1s,
      triggerTime: tranquill_1t,
      frameId: tranquill_1u
    });
    if (!this.plan || !this["plan"].hasNext()) {
      if (this.plan && !this.plan.hasNext()) await this.finalize({
        completed: true,
        detachDebugger: true
      });
      return;
    }
    const tranquill_1v = this.plan.peek();
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      requestId: tranquill_1r,
      character: tranquill_1v?.character ?? null,
      currentIndex: this.plan.currentIndex
    });
    const tranquill_1w = tranquill_1v && Number["isFinite"](tranquill_1v.delay) ? Math.max(220, Math.min(900, tranquill_1v["delay"] + 160)) : 320;
    const tranquill_1x = KeyEventFactory["build"](tranquill_1v.character);
    const tranquill_1y = tranquill_1x.filter(tranquill_1z => tranquill_1z?.type === tranquill_S("0x6c62272e07bb0142") && typeof tranquill_1z["key"] === tranquill_S("0x6c62272e07bb0142") && (tranquill_1z["key"]["length"] === 1 || tranquill_1z.key === tranquill_S("0x6c62272e07bb0142"))).map(tranquill_1A => tranquill_1A.key);
    const tranquill_1B = tranquill_1u !== null ? {
      frameId: tranquill_1u
    } : undefined;
    const tranquill_1C = await ChromeAsync.tabsSendMessage(tranquill_1p, {
      action: tranquill_S("0x6c62272e07bb0142"),
      duration: tranquill_1w,
      character: tranquill_1v.character,
      keys: tranquill_1y,
      requestId: tranquill_1r
    }, tranquill_1B);
    let tranquill_1D = tranquill_1C.success && tranquill_1C.response?.accepted;
    let typingError = null;
    if (!tranquill_1D) {
      log.warn(tranquill_S("0x6c62272e07bb0142"), {
        requestId: tranquill_1r,
        error: tranquill_1C["error"] || null,
        frameId: tranquill_1u
      });
    }
    try {
      await this.debuggerManager["typeCharacter"](tranquill_1p, tranquill_1v.character);
    } catch (tranquill_1F) {
      typingError = tranquill_1F;
      log["error"](tranquill_S("0x6c62272e07bb0142"), tranquill_1F);
    }
    if (tranquill_1D) {
      const tranquill_1G = await ChromeAsync.tabsSendMessage(tranquill_1p, {
        action: tranquill_S("0x6c62272e07bb0142"),
        requestId: tranquill_1r
      }, tranquill_1B);
      if (!tranquill_1G["success"]) log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_1G["error"]);
    } else {
      await ChromeAsync["tabsSendMessage"](tranquill_1p, {
        action: tranquill_S("0x6c62272e07bb0142"),
        requestId: tranquill_1r,
        character: tranquill_1v["character"]
      }, tranquill_1B).catch(tranquill_1H => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_1H));
    }
    if (typingError) {
      log.error(tranquill_S("0x6c62272e07bb0142"), typingError);
      await this["finalize"]({
        completed: false,
        detachDebugger: true
      });
      return;
    }
    this.plan["advance"]();
    this.currentIndex = this.plan.currentIndex;
    this.lastOutputCharacter = tranquill_1v.character;
    await TextStorage["setProgress"](this.currentIndex, this.textSignature).catch(tranquill_1I => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_1I));
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      requestId: tranquill_1r,
      index: this.currentIndex,
      remaining: Math.max(0, this.plan.length - this.currentIndex)
    });
    if (!this.plan.hasNext()) {
      log.info(tranquill_S("0x6c62272e07bb0142"), {
        tabId: tranquill_1p
      });
      await this["finalize"]({
        completed: true,
        detachDebugger: true
      });
    }
  }
  async #onPhantomBackspace(tranquill_1J, tranquill_1K = null) {
    if (!this.isRunning || this.mode !== tranquill_S("0x6c62272e07bb0142") || this["activeTabId"] !== tranquill_1J) return;
    if (!this.plan) return;
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      tabId: tranquill_1J,
      frameId: tranquill_1K
    });
    const tranquill_1L = tranquill_1K !== null ? {
      frameId: tranquill_1K
    } : undefined;
    const tranquill_1M = await ChromeAsync.tabsSendMessage(tranquill_1J, {
      action: tranquill_S("0x6c62272e07bb0142")
    }, tranquill_1L);
    if (!tranquill_1M.success) {
      log["warn"](tranquill_S("0x6c62272e07bb0142"), tranquill_1M.error);
      return;
    }
    let dispatchError = null;
    try {
      await this.debuggerManager.typeCharacter(tranquill_1J, tranquill_S("0x6c62272e07bb0142"));
    } catch (tranquill_1N) {
      dispatchError = tranquill_1N;
      log.error(tranquill_S("0x6c62272e07bb0142"), tranquill_1N);
    }
    if (dispatchError) return;
    this["plan"]["retreat"]();
    this["currentIndex"] = this.plan.currentIndex;
    this.lastOutputCharacter = this.currentIndex > 0 ? this.plan.text[this.currentIndex - 1] : null;
    await TextStorage.setProgress(this.currentIndex, this["textSignature"]).catch(tranquill_1O => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_1O));
    log.info(tranquill_S("0x6c62272e07bb0142"), {
      tabId: tranquill_1J,
      currentIndex: this.currentIndex
    });
  }
  #broadcastTyping(tranquill_1P) {
    try {
      chrome["runtime"]["sendMessage"]({
        action: tranquill_S("0x6c62272e07bb0142"),
        isTyping: tranquill_1P
      }, () => {
        const tranquill_1Q = chrome["runtime"]["lastError"];
        if (tranquill_1Q?.message?.includes(tranquill_S("0x6c62272e07bb0142"))) return;
      });
    } catch (tranquill_1R) {
      log.debug(tranquill_S("0x6c62272e07bb0142"), tranquill_1R);
    }
  }
  handleDebuggerDetached() {
    if (this["_finalized"]) return;
    if (this.delayController) {
      this.delayController.cancel();
      this.delayController = null;
    }
    this["isRunning"] = false;
    this.finalize({
      completed: false,
      detachDebugger: false
    }).catch(tranquill_1S => log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_1S));
  }
}
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}