var tranquill_runtime_exports = (() => {
        const tranquill_global = typeof self !== "undefined" ? self : globalThis;
        if (tranquill_global.tranquill_runtime_ready) {
                return {
                        tranquill_S: tranquill_global.tranquill_S,
                        tranquill_RN: tranquill_global.tranquill_RN,
                        tranquill_next: tranquill_global.tranquill_next,
                        tranquill_signature: tranquill_global.tranquill_signature,
                        tranquill_seed: tranquill_global.tranquill_seed,
                };
        }
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::457f0536cb00f0db9dec4c0cbf422f54"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        const exports = {
                tranquill_S,
                tranquill_RN,
                tranquill_next,
                tranquill_signature: "tranquill_tranquill_tranquill",
                tranquill_seed: tranquill_global.tranquill_seed,
        };
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = exports.tranquill_signature;
        tranquill_global.tranquill_seed = exports.tranquill_seed;
        tranquill_global.tranquill_runtime_ready = true;
        if (typeof tranquill_global === "object" && tranquill_global) {
                try {
                        tranquill_global.tranquill_runtime = exports;
                } catch (error) {
                        // ignore assignment issues in restricted environments
                }
        }
        if (typeof window !== "undefined") {
                window.tranquill_S = tranquill_S;
                window.tranquill_RN = tranquill_RN;
                window.tranquill_next = tranquill_next;
        }
        if (typeof global !== "undefined") {
                global.tranquill_S = tranquill_S;
                global.tranquill_RN = tranquill_RN;
                global.tranquill_next = tranquill_next;
        }
        return exports;
})();

(function tranquill_0() {
  const tranquill_1 = new Uint8Array([253, 202, 207, 187, 34, 45, 162, 184, 32, 42, 165, 255, 46, 60, 150, 171, 51, 46, 180, 183, 34, 43, 148, 23, 98, 151, 151, 21, 101, 144, 208, 27, 115, 163, 132, 6, 97, 129, 152, 23, 100, 182, 159, 159, 74, 73, 138, 156, 72, 78, 141, 219, 72, 78, 139, 186, 76, 95, 150, 141, 74, 127, 158, 153, 102, 79, 223, 146, 65, 93, 144, 144, 74, 79, 221, 63, 163, 193, 240, 36, 234, 214, 246, 112, 247, 193, 241, 112, 231, 197, 231, 53, 224, 212, 246, 52, 220, 193, 202, 193, 223, 195, 205, 198, 152, 193, 198, 199, 205, 214, 205, 245, 204, 208, 201, 215, 208, 193, 204, 177, 62, 135, 190, 178, 60, 128, 185, 245, 58, 145, 191, 180, 56, 141, 174, 177, 50, 245, 100, 21, 49, 247, 99, 18, 118, 244, 99, 20, 55, 243, 110, 5, 50, 6, 88, 16, 24, 5, 90, 23, 31, 66, 89, 23, 25, 3, 94, 26, 77, 4, 92, 27, 1, 7, 89, 19, 206, 197, 14, 16, 204, 194, 9, 87, 195, 198, 21, 19, 199, 194, 63, 18, 223, 198, 24, 31, 206, 195, 79, 185, 121, 89, 76, 187, 126, 94, 11, 186, 116, 79, 94, 175, 94, 72, 66, 168, 122, 78, 71, 185, 90, 94, 78, 189, 188, 252, 173, 228, 169, 234, 164, 191, 158, 244, 164, 228, 180, 244, 164, 167, 251, 186, 247, 176, 180, 183, 232, 173, 247, 191, 194, 171, 247, 161, 247, 228, 169, 244, 172, 161, 248, 248, 164, 178, 253, 177, 243, 237, 180, 233, 186, 228, 239, 222, 164, 228, 180, 244, 164, 228, 180, 244, 237, 162, 180, 252, 165, 161, 248, 253, 164, 182, 241, 160, 241, 182, 250, 244, 226, 165, 248, 167, 225, 255, 158, 244, 164, 228, 180, 244, 164, 228, 180, 183, 235, 170, 231, 160, 164, 182, 180, 233, 164, 161, 248, 250, 227, 161, 224, 150, 235, 177, 250, 176, 237, 170, 243, 151, 232, 173, 241, 186, 240, 150, 241, 183, 240, 236, 189, 239, 142, 228, 180, 244, 164, 228, 180, 244, 164, 167, 251, 186, 247, 176, 180, 172, 164, 249, 180, 153, 229, 176, 252, 250, 246, 171, 225, 186, 224, 236, 230, 250, 232, 161, 242, 160, 164, 239, 180, 166, 170, 179, 253, 176, 240, 172, 187, 230, 173, 255, 158, 244, 164, 228, 180, 244, 164, 228, 180, 183, 235, 170, 231, 160, 164, 189, 180, 233, 164, 137, 245, 160, 236, 234, 230, 187, 241, 170, 240, 252, 246, 234, 224, 187, 244, 228, 191, 244, 201, 165, 224, 188, 170, 169, 253, 186, 172, 182, 186, 188, 225, 173, 243, 188, 240, 235, 166, 248, 164, 246, 164, 253, 173, 255, 158, 244, 164, 228, 180, 244, 164, 228, 180, 183, 235, 170, 231, 160, 164, 173, 250, 189, 240, 228, 169, 244, 255, 228, 246, 161, 230, 166, 248, 177, 247, 254, 224, 166, 241, 161, 184, 244, 231, 165, 250, 183, 225, 168, 245, 182, 232, 161, 174, 160, 246, 177, 241, 248, 164, 167, 248, 189, 225, 170, 224, 140, 190, 188, 184, 244, 231, 168, 253, 177, 234, 176, 205, 238, 253, 232, 180, 182, 241, 176, 224, 187, 234, 254, 164, 248, 164, 166, 225, 160, 240, 171, 250, 167, 190, 245, 180, 169, 191, 206, 180, 244, 164, 228, 180, 244, 164, 228, 242, 187, 246, 228, 188, 183, 235, 170, 231, 160, 164, 176, 180, 187, 226, 228, 207, 246, 233, 171, 225, 167, 225, 160, 251, 163, 234, 230, 184, 246, 233, 171, 225, 167, 225, 177, 228, 246, 168, 230, 247, 184, 237, 167, 255, 246, 217, 237, 180, 177, 232, 234, 240, 189, 247, 180, 245, 160, 231, 172, 209, 162, 225, 170, 224, 252, 234, 161, 227, 244, 201, 171, 225, 167, 225, 129, 226, 177, 234, 176, 188, 160, 168, 228, 253, 186, 237, 176, 189, 253, 191, 206, 180, 244, 164, 228, 180, 244, 164, 228, 224, 166, 253, 228, 239, 244, 225, 168, 186, 178, 235, 167, 225, 167, 172, 191, 180, 164, 246, 161, 226, 177, 234, 176, 199, 183, 246, 171, 248, 184, 190, 228, 224, 166, 241, 161, 180, 169, 173, 255, 180, 169, 164, 167, 245, 160, 231, 172, 180, 175, 164, 161, 248, 250, 226, 171, 247, 161, 247, 236, 189, 239, 164, 185, 158, 244, 164, 228, 180, 244, 164, 228, 180, 189, 226, 228, 188, 162, 237, 161, 227, 235, 170, 162, 251, 183, 241, 183, 189, 244, 242, 173, 241, 163, 170, 162, 251, 183, 241, 183, 188, 253, 191, 206, 180, 244, 164, 228, 180, 244, 164, 228, 230, 177, 240, 177, 230, 186, 164, 176, 230, 161, 225, 255, 158, 244, 164, 228, 180, 244, 164, 185, 175, 222, 142, 228, 180, 244, 164, 228, 180, 183, 235, 170, 231, 160, 164, 183, 241, 184, 208, 171, 209, 186, 224, 228, 169, 244, 172, 160, 251, 183, 168, 228, 241, 184, 173, 228, 169, 234, 164, 191, 158, 244, 164, 228, 180, 244, 164, 228, 180, 183, 235, 170, 231, 160, 164, 183, 180, 233, 164, 160, 251, 183, 170, 163, 241, 160, 215, 161, 248, 177, 231, 176, 253, 187, 234, 251, 186, 252, 173, 255, 180, 189, 226, 228, 188, 245, 247, 228, 232, 168, 164, 229, 241, 184, 173, 228, 230, 177, 240, 177, 230, 186, 191, 206, 180, 244, 164, 228, 180, 244, 164, 228, 247, 187, 234, 183, 224, 244, 246, 165, 250, 179, 225, 228, 169, 244, 224, 171, 247, 250, 231, 182, 241, 181, 240, 161, 198, 181, 234, 163, 241, 252, 173, 255, 158, 244, 164, 228, 180, 244, 164, 228, 180, 166, 229, 170, 243, 177, 170, 183, 241, 184, 225, 167, 224, 154, 235, 160, 241, 151, 235, 170, 224, 177, 234, 176, 231, 252, 225, 168, 189, 239, 164, 182, 245, 186, 227, 161, 186, 183, 235, 168, 248, 181, 244, 183, 241, 252, 226, 165, 248, 167, 225, 237, 175, 222, 164, 228, 180, 244, 164, 228, 180, 244, 247, 234, 230, 177, 233, 171, 226, 177, 197, 168, 248, 134, 229, 170, 243, 177, 247, 236, 189, 239, 164, 183, 186, 181, 224, 160, 198, 181, 234, 163, 241, 252, 246, 165, 250, 179, 225, 237, 175, 222, 164, 228, 180, 244, 164, 228, 233, 239, 142, 206, 180, 244, 164, 228, 180, 244, 240, 182, 237, 244, 255, 206, 180, 244, 164, 228, 180, 244, 164, 228, 187, 251, 164, 131, 251, 187, 227, 168, 241, 244, 192, 171, 247, 167, 164, 173, 242, 166, 229, 169, 241, 222, 164, 228, 180, 244, 164, 228, 180, 244, 231, 171, 250, 167, 240, 228, 253, 178, 246, 165, 249, 177, 164, 249, 180, 176, 235, 167, 225, 185, 225, 170, 224, 250, 245, 177, 241, 166, 253, 151, 241, 184, 225, 167, 224, 187, 246, 236, 179, 189, 226, 182, 245, 185, 225, 234, 240, 187, 231, 183, 185, 160, 225, 188, 224, 177, 242, 161, 250, 160, 240, 165, 230, 179, 225, 176, 185, 189, 226, 182, 245, 185, 225, 232, 180, 189, 226, 182, 245, 185, 225, 234, 240, 187, 231, 183, 185, 160, 225, 188, 224, 177, 242, 161, 250, 160, 240, 165, 230, 179, 225, 176, 179, 253, 191, 206, 180, 244, 164, 228, 180, 244, 164, 228, 253, 178, 164, 236, 253, 178, 246, 165, 249, 177, 187, 234, 247, 187, 234, 176, 241, 186, 240, 147, 253, 186, 224, 171, 227, 235, 170, 160, 251, 183, 241, 169, 241, 186, 240, 237, 180, 175, 142, 228, 180, 244, 164, 228, 180, 244, 164, 228, 180, 183, 235, 170, 231, 160, 164, 179, 253, 186, 164, 249, 180, 189, 226, 182, 245, 185, 225, 234, 247, 187, 234, 176, 241, 186, 240, 147, 253, 186, 224, 171, 227, 248, 164, 160, 251, 183, 164, 249, 180, 163, 237, 170, 186, 176, 235, 167, 225, 185, 225, 170, 224, 239, 142, 228, 180, 244, 164, 228, 180, 244, 164, 228, 180, 183, 235, 170, 231, 160, 164, 176, 245, 166, 227, 161, 224, 244, 185, 228, 240, 187, 231, 234, 229, 161, 225, 182, 237, 135, 225, 168, 241, 183, 240, 171, 230, 252, 163, 159, 247, 187, 234, 176, 241, 186, 240, 161, 240, 189, 240, 165, 246, 184, 225, 249, 182, 160, 246, 177, 241, 246, 217, 227, 189, 244, 248, 184, 180, 176, 235, 167, 186, 182, 235, 160, 237, 239, 142, 228, 180, 244, 164, 228, 180, 244, 164, 228, 180, 189, 226, 228, 188, 183, 232, 173, 247, 191, 194, 171, 247, 161, 247, 236, 224, 181, 246, 163, 241, 160, 168, 228, 227, 189, 234, 237, 189, 244, 255, 228, 231, 177, 232, 144, 251, 145, 234, 160, 188, 176, 235, 167, 184, 244, 240, 165, 230, 179, 225, 176, 189, 239, 164, 182, 241, 160, 241, 182, 250, 244, 255, 228, 231, 161, 231, 167, 241, 167, 247, 254, 224, 166, 241, 161, 184, 244, 231, 176, 236, 238, 166, 160, 251, 183, 247, 233, 253, 178, 246, 165, 249, 177, 166, 228, 233, 239, 164, 185, 158, 244, 164, 228, 180, 244, 164, 228, 180, 169, 142, 228, 180, 244, 164, 228, 180, 244, 164, 235, 187, 244, 195, 161, 250, 177, 246, 173, 247, 222, 164, 228, 180, 244, 164, 228, 180, 244, 231, 171, 250, 167, 240, 228, 241, 176, 164, 249, 180, 176, 235, 167, 225, 185, 225, 170, 224, 250, 245, 177, 241, 166, 253, 151, 241, 184, 225, 167, 224, 187, 246, 236, 179, 143, 231, 171, 250, 160, 225, 170, 224, 177, 224, 173, 224, 181, 230, 168, 241, 233, 166, 176, 230, 161, 225, 230, 201, 248, 164, 160, 253, 162, 223, 182, 251, 184, 225, 249, 182, 160, 225, 188, 224, 182, 235, 188, 182, 137, 168, 228, 224, 177, 252, 176, 245, 166, 225, 165, 184, 244, 237, 170, 228, 161, 240, 159, 224, 173, 244, 161, 169, 246, 240, 161, 236, 160, 166, 153, 179, 253, 191, 206, 180, 244, 164, 228, 180, 244, 164, 228, 253, 178, 164, 236, 247, 184, 237, 167, 255, 146, 235, 167, 225, 167, 172, 161, 240, 248, 164, 179, 253, 186, 224, 171, 227, 253, 173, 228, 230, 177, 240, 177, 230, 186, 164, 191, 180, 167, 241, 167, 247, 177, 247, 183, 174, 160, 246, 177, 241, 248, 164, 167, 224, 172, 190, 230, 241, 176, 237, 176, 245, 182, 232, 161, 182, 244, 249, 255, 158, 244, 164, 228, 180, 244, 164, 228, 180, 166, 225, 176, 225, 166, 234, 228, 239, 244, 247, 177, 247, 183, 225, 183, 231, 238, 226, 165, 248, 167, 225, 228, 233, 239, 142, 228, 180, 244, 164, 228, 180, 169, 164, 167, 245, 160, 231, 172, 180, 252, 225, 237, 180, 175, 164, 182, 241, 160, 241, 182, 250, 244, 255, 228, 231, 161, 231, 167, 241, 167, 247, 254, 242, 181, 232, 183, 241, 248, 164, 161, 230, 166, 235, 182, 174, 244, 225, 251, 186, 185, 225, 183, 231, 181, 227, 161, 180, 169, 191, 228, 233, 222, 164, 228, 180, 244, 249, 237, 188, 253, 191, 200, 250, 164, 235, 243, 226, 175, 177, 255, 249, 171, 243, 239, 238, 190, 250, 241, 17, 85, 205, 200, 26, 20, 219, 203, 95, 82, 192, 199, 10, 71, 143, 193, 27, 93, 219, 203, 13, 186, 112, 204, 208, 185, 114, 203, 215, 254, 115, 193, 198, 171, 102, 235, 193, 183, 97, 207, 199, 178, 112, 239, 215, 187, 116, 142, 214, 171, 118, 205, 192, 173, 102, 8, 210, 158, 18, 11, 208, 153, 21, 76, 195, 133, 23, 9, 244, 148, 6, 30, 214, 159, 19, 9, 197, 59, 67, 18, 8, 6, 3, 6, 20, 1, 93, 3, 9, 17, 69, 41, 24, 11, 104, 20, 24, 28, 89]);
  const tranquill_2 = self.tranquill_PACK = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  tranquill_2.data.push(tranquill_1);
  const tranquill_3 = tranquill_2.data["length"] - 1;
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 0,
    len: 3,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 3,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 22,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 43,
    len: 31,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 74,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 96,
    len: 23,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 119,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 136,
    len: 17,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 153,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 175,
    len: 23,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 198,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 224,
    len: 1643,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1867,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1883,
    len: 22,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1905,
    len: 34,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1939,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1961,
    len: 22,
    kind: 1
  });
})();
class tranquill_4 {
  constructor() {
    this["attachedTabId"] = null;
    this.protocolVersion = tranquill_S("0x6c62272e07bb0142");
  }
  isAttached() {
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      attachedTabId: this.attachedTabId
    });
    return this.attachedTabId !== null;
  }
  isAttachedTo(tranquill_5) {
    log["debug"](tranquill_S("0x6c62272e07bb0142"), {
      tabId: tranquill_5,
      attachedTabId: this.attachedTabId
    });
    return this["attachedTabId"] === tranquill_5;
  }
  async getActiveTabId() {
    log.debug(tranquill_S("0x6c62272e07bb0142"));
    const tranquill_6 = await ChromeAsync.tabsQuery({
      active: true,
      currentWindow: true
    });
    if (!tranquill_6?.length) throw new Error(tranquill_S("0x6c62272e07bb0142"));
    return tranquill_6[0].id;
  }
  async ensureAttached() {
    const tranquill_7 = await this.getActiveTabId();
    log["debug"](tranquill_S("0x6c62272e07bb0142"), {
      tabId: tranquill_7,
      currentlyAttached: this.attachedTabId
    });
    if (this.attachedTabId === tranquill_7) return tranquill_7;
    await ChromeAsync.debuggerAttach(tranquill_7, this["protocolVersion"]);
    this.attachedTabId = tranquill_7;
    log["info"](tranquill_S("0x6c62272e07bb0142"), {
      tabId: tranquill_7
    });
    return tranquill_7;
  }
  async detach() {
    if (this.attachedTabId === null) return;
    const tranquill_8 = this["attachedTabId"];
    this["attachedTabId"] = null;
    try {
      await ChromeAsync.debuggerDetach(tranquill_8);
      log.info(tranquill_S("0x6c62272e07bb0142"), {
        tabId: tranquill_8
      });
    } catch (tranquill_9) {
      log.warn(tranquill_S("0x6c62272e07bb0142"), tranquill_9);
    }
  }
  handleDetached(tranquill_a) {
    log["warn"](tranquill_S("0x6c62272e07bb0142"), {
      tabId: tranquill_a,
      attachedTabId: this.attachedTabId
    });
    if (this.attachedTabId === tranquill_a) this.attachedTabId = null;
  }
  async focusEditableArea(tranquill_b) {
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      tabId: tranquill_b
    });
    const tranquill_c = tranquill_S("0x6c62272e07bb0142");
    const tranquill_d = await ChromeAsync["debuggerSend"](tranquill_b, tranquill_S("0x6c62272e07bb0142"), {
      expression: tranquill_c,
      returnByValue: true,
      includeCommandLineAPI: false
    });
    const tranquill_e = tranquill_d?.result?.value;
    if (!tranquill_e || tranquill_e.success !== true) throw new Error(tranquill_S("0x6c62272e07bb0142"));
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      tabId: tranquill_b,
      context: tranquill_e?.ctx ?? null
    });
  }
  async typeCharacter(tranquill_g, tranquill_h) {
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      tabId: tranquill_g,
      character: tranquill_h
    });
    const tranquill_i = KeyEventFactory.build(tranquill_h);
    for (const tranquill_j of tranquill_i) {
      await ChromeAsync.debuggerSend(tranquill_g, tranquill_S("0x6c62272e07bb0142"), tranquill_j);
    }
  }
}
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}