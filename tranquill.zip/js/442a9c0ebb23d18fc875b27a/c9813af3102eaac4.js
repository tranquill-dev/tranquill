var tranquill_runtime_exports = (() => {
        const tranquill_global = typeof self !== "undefined" ? self : globalThis;
        if (tranquill_global.tranquill_runtime_ready) {
                return {
                        tranquill_S: tranquill_global.tranquill_S,
                        tranquill_RN: tranquill_global.tranquill_RN,
                        tranquill_next: tranquill_global.tranquill_next,
                        tranquill_signature: tranquill_global.tranquill_signature,
                        tranquill_seed: tranquill_global.tranquill_seed,
                };
        }
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::457f0536cb00f0db9dec4c0cbf422f54"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        const exports = {
                tranquill_S,
                tranquill_RN,
                tranquill_next,
                tranquill_signature: "tranquill_tranquill_tranquill",
                tranquill_seed: tranquill_global.tranquill_seed,
        };
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = exports.tranquill_signature;
        tranquill_global.tranquill_seed = exports.tranquill_seed;
        tranquill_global.tranquill_runtime_ready = true;
        if (typeof tranquill_global === "object" && tranquill_global) {
                try {
                        tranquill_global.tranquill_runtime = exports;
                } catch (error) {
                        // ignore assignment issues in restricted environments
                }
        }
        if (typeof window !== "undefined") {
                window.tranquill_S = tranquill_S;
                window.tranquill_RN = tranquill_RN;
                window.tranquill_next = tranquill_next;
        }
        if (typeof global !== "undefined") {
                global.tranquill_S = tranquill_S;
                global.tranquill_RN = tranquill_RN;
                global.tranquill_next = tranquill_next;
        }
        return exports;
})();

(function tranquill_0() {
  const tranquill_1 = new Uint8Array([184, 69, 35, 152, 134, 116, 38, 159, 142, 118, 59, 208, 221, 118, 62, 137, 130, 116, 36, 143, 202, 113, 50, 147, 128, 136, 140, 156, 155, 198, 215, 195, 156, 142, 153, 130, 153, 137, 145, 128, 132, 210, 155, 143, 199, 157, 136, 133, 199, 144, 151, 139, 129, 146, 215, 104, 94, 176, 152, 122, 66, 177, 149, 77, 62, 202, 136, 117, 46, 134, 143, 116, 124, 158, 203, 108, 62, 152, 130, 124, 34, 202, 159, 114, 58, 158, 203, 118, 50, 137, 142, 116, 40, 143, 203, 113, 62, 147, 197, 140, 194, 171, 212, 180, 210, 231, 211, 181, 128, 255, 151, 169, 194, 234, 212, 179, 135, 255, 223, 190, 135, 231, 222, 184, 194, 229, 196, 190, 135, 248, 210, 169, 209, 238, 197, 245, 135, 219, 219, 190, 198, 248, 210, 251, 211, 249, 206, 251, 198, 236, 214, 178, 201, 165, 221, 155, 58, 205, 229, 139, 118, 202, 228, 217, 110, 142, 238, 155, 110, 203, 248, 147, 115, 192, 239, 222, 99, 193, 255, 140, 58, 202, 239, 136, 115, 205, 239, 222, 115, 202, 239, 144, 110, 199, 236, 151, 127, 220, 164, 222, 74, 194, 239, 159, 105, 203, 170, 138, 104, 215, 170, 159, 125, 207, 227, 144, 52, 70, 244, 222, 114, 84, 232, 223, 127, 94, 44, 198, 42, 76, 48, 199, 39, 76, 36, 34, 78, 72, 35, 54, 90, 119, 42, 78, 92, 114, 58, 203, 112, 83, 40, 203, 104, 95, 40, 87, 185, 226, 78, 91, 175, 189, 213, 140, 184, 160, 198, 150, 96, 165, 139, 169, 68, 136, 168, 177, 90, 135, 179, 151, 75, 118, 135, 159, 88, 103, 159, 159, 84, 104, 196, 156, 72, 105, 133, 103, 91, 134, 151, 111, 72, 151, 143, 111, 68, 152, 212, 108, 88, 153, 149, 114, 23, 203, 146, 71, 18, 204, 154, 69, 15, 228, 211, 69, 10, 218, 150, 71, 16, 220, 211, 95, 2, 213, 154, 77, 2, 205, 154, 70, 13, 153, 129, 76, 18, 204, 150, 90, 23, 153, 149, 72, 10, 213, 150, 77, 195, 247, 176, 208, 200, 240, 208, 100, 33, 169, 205, 119, 161, 223, 57, 217, 179, 195, 56, 212, 151, 232, 251, 190, 165, 251, 241, 236, 177, 242, 245, 186, 165, 245, 248, 173, 166, 240, 241, 4, 187, 168, 45, 54, 168, 162, 127, 34, 161, 166, 41, 54, 166, 171, 62, 53, 163, 162, 3, 113, 91, 55, 17, 109, 90, 58, 204, 96, 181, 229, 249, 101, 178, 237, 251, 120, 154, 164, 241, 117, 174, 232, 242, 112, 231, 240, 248, 52, 164, 232, 242, 117, 181, 164, 228, 96, 168, 246, 242, 112, 231, 232, 254, 119, 162, 234, 228, 113, 231, 239, 242, 109, 23, 68, 46, 1, 34, 65, 41, 9, 32, 92, 1, 64, 41, 72, 63, 5, 60, 68, 53, 15, 34, 16, 43, 8, 37, 92, 57, 64, 47, 92, 57, 1, 62, 89, 50, 7, 108, 67, 40, 15, 62, 85, 56, 64, 32, 89, 63, 5, 34, 67, 57, 64, 39, 85, 37, 183, 91, 6, 182, 170, 72, 169, 193, 152, 172, 180, 210, 93, 79, 100, 106, 104, 74, 99, 98, 106, 87, 75, 43, 78, 108, 95, 79, 38, 73, 115, 120, 105, 87, 96, 110, 116, 27, 112, 106, 111, 87, 115, 111, 104, 94, 176, 152, 122, 66, 177, 149, 121, 47, 128, 138, 76, 42, 135, 130, 78, 55, 175, 203, 68, 58, 155, 135, 71, 63, 210, 159, 77, 123, 128, 142, 67, 63, 210, 152, 67, 45, 151, 143, 2, 55, 155, 136, 71, 53, 129, 142, 2, 48, 151, 146, 144, 251, 9, 222, 165, 254, 14, 214, 167, 227, 38, 159, 174, 247, 24, 218, 187, 251, 18, 208, 165, 175, 12, 215, 162, 227, 30, 159, 185, 234, 26, 219, 162, 225, 28, 159, 167, 230, 24, 218, 165, 252, 30, 159, 160, 234, 2, 32, 116, 209, 57, 61, 103, 252, 206, 165, 235, 201, 203, 162, 227, 203, 214, 138, 170, 193, 219, 190, 230, 194, 222, 247, 254, 200, 154, 165, 239, 198, 222, 247, 230, 206, 217, 178, 228, 212, 223, 247, 225, 194, 195, 247, 236, 213, 213, 186, 170, 203, 213, 180, 235, 203, 233, 163, 229, 213, 219, 176, 239, 20, 54, 109, 19, 33, 51, 106, 27, 35, 46, 66, 82, 41, 35, 118, 30, 42, 38, 63, 6, 32, 98, 114, 27, 61, 48, 112, 0, 111, 46, 118, 17, 42, 44, 108, 23, 111, 41, 122, 11, 111, 54, 112, 82, 35, 45, 124, 19, 35, 17, 107, 29, 61, 35, 120, 23, 77, 124, 212, 89, 120, 121, 211, 81, 122, 100, 251, 24, 112, 105, 207, 84, 115, 108, 134, 76, 121, 40, 197, 84, 115, 105, 212, 24, 122, 97, 197, 93, 120, 123, 195, 24, 125, 109, 223, 24, 112, 122, 201, 85, 54, 100, 201, 91, 119, 100, 245, 76, 121, 122, 199, 95, 115, 241, 153, 192, 244, 236, 138, 231, 9, 82, 254, 235, 31, 237, 133, 220, 232, 240, 150, 231, 11, 86, 230, 250, 24, 217, 177, 232, 220, 196, 162, 216, 46, 192, 168, 202, 50, 193, 165, 131, 223, 58, 218, 182, 218, 61, 210, 180, 199, 21, 155, 190, 202, 33, 215, 189, 207, 104, 207, 183, 139, 58, 222, 185, 207, 104, 215, 177, 200, 45, 213, 171, 206, 104, 205, 185, 199, 33, 223, 185, 223, 33, 212, 182, 139, 58, 222, 171, 219, 39, 213, 171, 206, 198, 21, 63, 16, 243, 16, 56, 24, 241, 13, 16, 81, 251, 0, 36, 29, 248, 5, 109, 5, 242, 65, 61, 16, 239, 18, 40, 81, 241, 8, 46, 20, 243, 18, 40, 81, 235, 0, 33, 24, 249, 0, 57, 24, 242, 15, 109, 3, 248, 18, 61, 30, 243, 18, 40, 122, 88, 15, 111, 118, 78, 88, 252, 169, 81, 69, 239, 82, 122, 35, 87, 79, 105, 84, 248, 165, 85, 73, 235, 63, 66, 254, 89, 44, 69, 244, 89, 46]);
  const tranquill_2 = self.tranquill_PACK = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  tranquill_2["data"].push(tranquill_1);
  const tranquill_3 = tranquill_2.data.length - 1;
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 0,
    len: 24,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 24,
    len: 31,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 55,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 63,
    len: 36,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 99,
    len: 55,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 154,
    len: 63,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 217,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 225,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 233,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 240,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 246,
    len: 9,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 255,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 261,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 267,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 271,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 275,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 279,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 295,
    len: 16,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 311,
    len: 45,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 356,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 362,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 368,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 376,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 395,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 414,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 422,
    len: 46,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 468,
    len: 55,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 523,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 529,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 535,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 567,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 575,
    len: 44,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 619,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 666,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 672,
    len: 56,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 728,
    len: 56,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 784,
    len: 57,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 841,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 847,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 853,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 859,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 865,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 871,
    len: 8,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 879,
    len: 54,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 933,
    len: 55,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 988,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 994,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1000,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1006,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard: tranquill_3,
    off: 1012,
    len: 9,
    kind: 1
  });
})();
let _tranquill_cond = typeof tranquill_4.fetch === tranquill_S("0x6c62272e07bb0142");
if (_tranquill_cond) {
  tranquill_4.fetch.bind(tranquill_4);
} else {
  null;
}
let _tranquill_cond3 = typeof tranquill_u === tranquill_S("0x6c62272e07bb0142");
if (_tranquill_cond3) {
  tranquill_u.trim();
} else {
  "";
}
let _tranquill_cond4 = tranquill_18.length > 0;
if (_tranquill_cond4) {
  tranquill_18;
} else {
  null;
}
let _tranquill_cond5 = tranquill_1r.length > 0;
if (_tranquill_cond5) {
  tranquill_1r;
} else {
  null;
}
let _tranquill_cond6 = typeof tranquill_1w["error"] === tranquill_S("0x6c62272e07bb0142");
if (_tranquill_cond6) {
  tranquill_1w.error;
} else {
  let _tranquill_cond8 = typeof tranquill_1w.message === tranquill_S("0x6c62272e07bb0142");
  if (_tranquill_cond8) {
    tranquill_1w.message;
  } else {
    null;
  }
  _tranquill_cond8;
}
let _tranquill_cond7 = tranquill_1B.length > 0;
if (_tranquill_cond7) {
  tranquill_1B;
} else {
  null;
}
(function (tranquill_4) {
  "use strict";

  const tranquill_5 = tranquill_S("0x6c62272e07bb0142");
  const tranquill_6 = tranquill_S("0x6c62272e07bb0142");
  const tranquill_7 = {
    debug() {},
    info() {},
    warn() {},
    error() {}
  };
  class tranquill_8 {
    constructor(tranquill_9 = {}) {
      const {
        storageKey: tranquill_a = tranquill_5,
        validationEndpoint: tranquill_b = tranquill_6,
        fetchFn: tranquill_c = _tranquill_cond,
        logger: tranquill_d = tranquill_4["log"] || tranquill_4.console || tranquill_7,
        chrome: tranquill_e = tranquill_4["chrome"] || null,
        chromeStorage: tranquill_f = tranquill_e?.storage?.local || null,
        localStorage: tranquill_g = tranquill_1I(tranquill_4) || null,
        hwidResolver: tranquill_h = null,
        defaultErrorMessage: tranquill_i = tranquill_S("0x6c62272e07bb0142"),
        networkErrorMessage: tranquill_j = tranquill_S("0x6c62272e07bb0142"),
        hwidErrorMessage: tranquill_k = tranquill_S("0x6c62272e07bb0142")
      } = tranquill_9;
      this.storageKey = tranquill_a;
      this.validationEndpoint = tranquill_b;
      this["fetchFn"] = typeof tranquill_c === tranquill_S("0x6c62272e07bb0142") ? tranquill_c : null;
      this.logger = tranquill_d || tranquill_7;
      this.chrome = tranquill_e || tranquill_4.chrome || null;
      this.chromeStorage = tranquill_f;
      this.localStorage = tranquill_g;
      let _tranquill_cond2 = typeof tranquill_h === tranquill_S("0x6c62272e07bb0142");
      if (_tranquill_cond2) {
        tranquill_h;
      } else {
        null;
      }
      this["hwidResolver"] = _tranquill_cond2;
      this.messages = {
        default: tranquill_i,
        network: tranquill_j,
        hwid: tranquill_k
      };
    }
    async gateLicenseKey({
      requireValidation: tranquill_n = true
    } = {}) {
      const tranquill_o = await this.getStoredLicenseKey();
      if (!tranquill_o) {
        return {
          unlocked: false,
          licenseKey: null,
          reason: tranquill_S("0x6c62272e07bb0142")
        };
      }
      if (!tranquill_n) {
        return {
          unlocked: true,
          licenseKey: tranquill_o,
          reason: tranquill_S("0x6c62272e07bb0142")
        };
      }
      try {
        const {
          hwid: tranquill_r
        } = await this.validateLicenseKey(tranquill_o);
        return {
          unlocked: true,
          licenseKey: tranquill_o,
          hwid: tranquill_r,
          reason: tranquill_S("0x6c62272e07bb0142")
        };
      } catch (tranquill_s) {
        if (tranquill_s && typeof tranquill_s === tranquill_S("0x6c62272e07bb0142") && !tranquill_s.licenseKey) {
          tranquill_s["licenseKey"] = tranquill_o;
        }
        throw tranquill_s;
      }
    }
    async validateLicenseKey(tranquill_u, {
      hwid: tranquill_v
    } = {}) {
      const tranquill_w = _tranquill_cond3;
      if (!tranquill_w) {
        const tranquill_z = new Error(this.messages["default"]);
        tranquill_z["shouldClearLicense"] = false;
        throw tranquill_z;
      }
      const tranquill_A = await this.resolveHWID(tranquill_v);
      if (!tranquill_A) {
        const tranquill_C = new Error(this.messages.hwid);
        tranquill_C.shouldClearLicense = false;
        throw tranquill_C;
      }
      await this.validateAgainstServer({
        licenseKey: tranquill_w,
        hwid: tranquill_A
      });
      return {
        licenseKey: tranquill_w,
        hwid: tranquill_A
      };
    }
    async validateAgainstServer({
      licenseKey: tranquill_D,
      hwid: tranquill_E
    }) {
      if (!this.fetchFn) {
        const tranquill_F = new Error(this["messages"].network);
        tranquill_F.shouldClearLicense = false;
        throw tranquill_F;
      }
      let response;
      try {
        const tranquill_G = {
          license_key: tranquill_D,
          hwid: tranquill_E
        };
        response = await this.fetchFn(this.validationEndpoint, {
          method: tranquill_S("0x6c62272e07bb0142"),
          mode: tranquill_S("0x6c62272e07bb0142"),
          credentials: tranquill_S("0x6c62272e07bb0142"),
          headers: {
            Accept: tranquill_S("0x6c62272e07bb0142"),
            "Content-Type": tranquill_S("0x6c62272e07bb0142")
          },
          body: JSON.stringify(tranquill_G)
        });
      } catch (tranquill_H) {
        this["logWarn"](tranquill_S("0x6c62272e07bb0142"), tranquill_H);
        const tranquill_I = new Error(this["messages"].network);
        tranquill_I["cause"] = tranquill_H instanceof Error ? tranquill_H : undefined;
        tranquill_I.shouldClearLicense = false;
        throw tranquill_I;
      }
      const tranquill_J = await this.readJsonPayload(response);
      if (!response?.ok) {
        const tranquill_K = this.extractLicenseError(tranquill_J) || this["messages"]["default"];
        const tranquill_L = new Error(tranquill_K);
        if (response && typeof response["status"] === tranquill_S("0x6c62272e07bb0142") && response.status >= 400 && response.status < 500) {
          tranquill_L.shouldClearLicense = true;
        }
        throw tranquill_L;
      }
      if (!tranquill_J || tranquill_J.success !== true) {
        const tranquill_N = this.extractLicenseError(tranquill_J) || this.messages.default;
        const tranquill_O = new Error(tranquill_N);
        tranquill_O["shouldClearLicense"] = true;
        throw tranquill_O;
      }
      return tranquill_J;
    }
    async getStoredLicenseKey() {
      const tranquill_P = await this.readChromeStorage();
      const tranquill_Q = this.extractLicenseValue(tranquill_P);
      if (tranquill_Q) {
        return tranquill_Q;
      }
      return this.getLocalStorageFallback();
    }
    async persistLicenseKey(tranquill_R) {
      const tranquill_T = typeof tranquill_R === tranquill_S("0x6c62272e07bb0142") ? tranquill_R.trim() : "";
      if (!tranquill_T) {
        return null;
      }
      const tranquill_W = {
        value: tranquill_T,
        savedAt: Date["now"]()
      };
      await new Promise((tranquill_X, tranquill_Y) => {
        if (!this.chromeStorage || typeof this.chromeStorage.set !== tranquill_S("0x6c62272e07bb0142")) {
          tranquill_Y(new Error(tranquill_S("0x6c62272e07bb0142")));
          return;
        }
        try {
          this["chromeStorage"]["set"]({
            [this.storageKey]: tranquill_W
          }, () => {
            const tranquill_Z = this.chrome?.runtime?.lastError ?? null;
            if (tranquill_Z) {
              tranquill_Y(new Error(tranquill_Z.message || tranquill_S("0x6c62272e07bb0142")));
              return;
            }
            tranquill_X();
          });
        } catch (tranquill_10) {
          tranquill_Y(tranquill_10);
        }
      });
      this["writeLocalStorage"](tranquill_T);
      return tranquill_W;
    }
    async clearStoredLicenseKey() {
      this.clearLocalStorage();
      return new Promise(tranquill_11 => {
        if (!this.chromeStorage || typeof this.chromeStorage.remove !== tranquill_S("0x6c62272e07bb0142")) {
          tranquill_11();
          return;
        }
        try {
          this.chromeStorage.remove(this.storageKey, () => {
            const tranquill_12 = this.chrome?.runtime?.lastError ?? null;
            if (tranquill_12) {
              this["logWarn"](tranquill_S("0x6c62272e07bb0142"), tranquill_12);
            }
            tranquill_11();
          });
        } catch (tranquill_13) {
          this["logWarn"](tranquill_S("0x6c62272e07bb0142"), tranquill_13);
          tranquill_11();
        }
      });
    }
    async resolveHWID(tranquill_14) {
      if (typeof tranquill_14 === tranquill_S("0x6c62272e07bb0142") && tranquill_14.trim()["length"] > 0) {
        return tranquill_14.trim();
      }
      if (!this.hwidResolver) {
        return null;
      }
      try {
        const tranquill_16 = await this.hwidResolver();
        if (typeof tranquill_16 !== tranquill_S("0x6c62272e07bb0142")) {
          return null;
        }
        const tranquill_18 = tranquill_16.trim();
        return _tranquill_cond4;
      } catch (tranquill_19) {
        this["logWarn"](tranquill_S("0x6c62272e07bb0142"), tranquill_19);
        return null;
      }
    }
    readChromeStorage() {
      return new Promise(tranquill_1a => {
        if (!this.chromeStorage || typeof this.chromeStorage.get !== tranquill_S("0x6c62272e07bb0142")) {
          tranquill_1a(null);
          return;
        }
        try {
          this.chromeStorage.get(this.storageKey, tranquill_1b => {
            const tranquill_1c = this.chrome?.runtime?.lastError ?? null;
            if (tranquill_1c) {
              this.logWarn(tranquill_S("0x6c62272e07bb0142"), tranquill_1c);
              tranquill_1a(null);
              return;
            }
            tranquill_1a(tranquill_1b?.[this["storageKey"]] ?? null);
          });
        } catch (tranquill_1d) {
          this.logWarn(tranquill_S("0x6c62272e07bb0142"), tranquill_1d);
          tranquill_1a(null);
        }
      });
    }
    getLocalStorageFallback() {
      if (!this["localStorage"]) {
        return null;
      }
      try {
        const tranquill_1e = this["localStorage"]["getItem"](this["storageKey"]);
        if (typeof tranquill_1e !== tranquill_S("0x6c62272e07bb0142")) {
          return null;
        }
        const tranquill_1g = tranquill_1e.trim();
        return tranquill_1g.length > 0 ? tranquill_1g : null;
      } catch (tranquill_1h) {
        this["logDebug"](tranquill_S("0x6c62272e07bb0142"), tranquill_1h);
        return null;
      }
    }
    writeLocalStorage(tranquill_1i) {
      if (!this["localStorage"]) {
        return;
      }
      try {
        this.localStorage.setItem(this.storageKey, tranquill_1i);
      } catch (tranquill_1j) {
        this["logDebug"](tranquill_S("0x6c62272e07bb0142"), tranquill_1j);
      }
    }
    clearLocalStorage() {
      if (!this.localStorage) {
        return;
      }
      try {
        this.localStorage["removeItem"](this.storageKey);
      } catch (tranquill_1k) {
        this.logDebug(tranquill_S("0x6c62272e07bb0142"), tranquill_1k);
      }
    }
    extractLicenseValue(tranquill_1l) {
      if (typeof tranquill_1l === tranquill_S("0x6c62272e07bb0142")) {
        const tranquill_1n = tranquill_1l.trim();
        return tranquill_1n.length > 0 ? tranquill_1n : null;
      }
      if (tranquill_1l && typeof tranquill_1l === tranquill_S("0x6c62272e07bb0142")) {
        const tranquill_1p = typeof tranquill_1l["value"] === tranquill_S("0x6c62272e07bb0142") ? tranquill_1l.value : typeof tranquill_1l["key"] === tranquill_S("0x6c62272e07bb0142") ? tranquill_1l.key : null;
        if (typeof tranquill_1p === tranquill_S("0x6c62272e07bb0142")) {
          const tranquill_1r = tranquill_1p.trim();
          return _tranquill_cond5;
        }
      }
      return null;
    }
    async readJsonPayload(tranquill_1s) {
      if (!tranquill_1s || typeof tranquill_1s.text !== tranquill_S("0x6c62272e07bb0142")) {
        return null;
      }
      let raw = "";
      try {
        raw = await tranquill_1s.text();
      } catch (tranquill_1u) {
        this["logWarn"](tranquill_S("0x6c62272e07bb0142"), tranquill_1u);
        return null;
      }
      if (!raw) {
        return null;
      }
      try {
        return JSON.parse(raw);
      } catch (tranquill_1v) {
        this.logWarn(tranquill_S("0x6c62272e07bb0142"), tranquill_1v);
        return null;
      }
    }
    extractLicenseError(tranquill_1w) {
      if (!tranquill_1w || typeof tranquill_1w !== tranquill_S("0x6c62272e07bb0142")) {
        return null;
      }
      const tranquill_1z = _tranquill_cond6;
      if (typeof tranquill_1z !== tranquill_S("0x6c62272e07bb0142")) {
        return null;
      }
      const tranquill_1B = tranquill_1z.trim();
      return _tranquill_cond7;
    }
    logWarn(tranquill_1C, tranquill_1D) {
      try {
        this["logger"]?.warn?.(tranquill_1C, tranquill_1D);
      } catch (tranquill_1E) {}
    }
    logDebug(tranquill_1F, tranquill_1G) {
      try {
        this.logger?.debug?.(tranquill_1F, tranquill_1G);
      } catch (tranquill_1H) {}
    }
  }
  function tranquill_1I(tranquill_1J) {
    try {
      return tranquill_1J?.localStorage ?? null;
    } catch (tranquill_1K) {
      return null;
    }
  }
  tranquill_4.tranquillLicenseManager = tranquill_8;
})(typeof self !== tranquill_S("0x6c62272e07bb0142") ? self : this);
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}