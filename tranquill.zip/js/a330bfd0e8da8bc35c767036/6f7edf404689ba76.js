var tranquill_global = typeof self !== "undefined" ? self : globalThis;
if (!tranquill_global.tranquill_runtime_ready) {
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::c882198ca34f17b696c9b80e0eca21ea"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = "tranquill_tranquill_tranquill";
        tranquill_global.tranquill_runtime_ready = true;
}

(function tranquill_init_shard() {
  const a = new Uint8Array([247, 25, 5, 61, 137, 104, 64, 122, 193, 42, 29, 117, 210, 106, 88, 108, 205, 40, 2, 42, 197, 109, 84, 118, 244, 15, 208, 53, 138, 126, 149, 114, 194, 60, 200, 125, 209, 96, 129, 105, 207, 57, 202, 32, 198, 100, 150, 102, 197, 35, 205, 51, 130, 127, 138, 8, 32, 102, 127, 240, 240, 234, 184, 49, 98, 50, 60, 233, 224, 244, 181, 57, 60, 102, 104, 247, 228, 242, 252, 51, 44, 37, 121, 241, 246, 227, 252, 52, 32, 63, 50, 149, 168, 217, 149, 237, 248, 85, 82, 172, 234, 141, 214, 240, 232, 88, 85, 170, 237, 141, 158, 231, 173, 85, 95, 161, 168, 151, 133, 231, 173, 74, 83, 176, 187, 156, 132, 172, 173, 105, 90, 167, 172, 138, 147, 162, 249, 75, 79, 226, 172, 158, 151, 235, 227, 23, 70, 51, 90, 222, 62, 99, 214, 25, 127, 113, 14, 157, 53, 115, 206, 24, 99, 59, 19, 211, 52, 54, 195, 18, 100, 36, 90, 217, 52, 96, 211, 30, 116, 118, 19, 217, 52, 120, 206, 20, 119, 63, 31, 207, 127, 54, 234, 17, 116, 55, 9, 216, 113, 98, 200, 4, 49, 55, 29, 220, 56, 120, 148, 103, 211, 145, 225, 146, 22, 86, 169, 80, 203, 190, 160, 144, 14, 64, 165, 82, 212, 134, 160, 145, 6, 77, 161, 91, 194, 145, 160, 137, 9, 66, 182, 93, 206, 143, 225, 158, 11, 70, 12, 225, 204, 212, 103, 128, 181, 178, 38, 218, 205, 248, 105, 138, 164, 179, 182, 93, 30, 41, 172, 159, 88, 105, 253, 76, 95, 43, 183, 153, 88, 105, 180, 66, 188, 32, 179, 128, 190, 100, 245, 64, 167, 34, 180, 154, 89, 138, 233, 46, 210, 200, 179, 104, 90, 128, 239, 63, 218, 160, 245, 3, 3, 166, 183, 217, 69, 174, 242, 15, 25, 83, 229, 157, 3, 216, 167, 71, 69, 80, 236, 134, 18, 210, 187, 247, 87, 25, 97, 252, 149, 67, 39, 244, 82, 30, 114, 236, 143, 29, 37, 171, 84, 5, 114, 154, 11, 18, 115, 17, 73, 200, 53, 153, 5, 14, 100, 0, 72, 213, 207, 118, 132, 113, 250, 70, 148, 64, 241, 4, 78, 6, 249, 89, 136, 64, 247, 15, 78, 16, 94, 200, 252, 178, 43, 13, 187, 250, 105, 208, 211, 243, 41, 19, 169, 250, 107, 156, 219, 154, 101, 21, 189, 179, 104, 213, 253, 160, 44, 18, 169, 179, 119, 217, 255, 166, 44, 14, 171, 247, 37, 217, 226, 182, 40, 25, 160, 231, 118, 140, 246, 132, 183, 86, 183, 157, 127, 91, 175, 64, 31, 242, 255, 238, 106, 183, 184, 166, 40, 234, 208, 175, 104, 169, 170, 166, 42, 166, 216, 198, 36, 175, 190, 239, 41, 239, 254, 252, 109, 168, 170, 239, 48, 238, 232, 175, 119, 179, 174, 172, 33, 245, 254, 175, 98, 163, 168, 171, 38, 231, 238, 228, 36, 163, 161, 170, 41, 227, 227, 251, 43, 225, 214, 216, 119, 177, 88, 142, 49, 225, 241, 187, 76, 93, 183, 233, 69, 152, 246, 175, 200, 74, 123, 94, 196, 154, 39, 140, 208, 195, 157, 48, 41, 207, 77, 108, 123, 219, 30, 170, 198, 52, 58, 130, 103, 50, 210, 195, 44, 118, 155, 106, 164, 238, 100, 67, 50, 168, 54, 202, 119, 233, 112, 0, 37, 32, 73, 245, 224, 231, 129, 55, 61, 15, 8, 232, 229, 253, 154, 62, 53, 114, 68, 242, 242, 247, 134, 40, 52, 114, 94, 250, 253, 251, 140, 58, 37, 59, 71, 245, 177, 244, 137, 50, 61, 55, 76, 193, 221, 147, 179, 52, 24, 84, 123, 246, 197, 188, 242, 60, 8, 72, 126, 255, 205, 193, 166, 53, 73, 72, 124, 243, 221, 136, 179, 54, 0, 91, 119, 186, 197, 142, 181, 51, 7, 1, 117, 251, 221, 132, 77, 71, 224, 209, 11, 149, 233, 20, 74, 83, 75, 193, 118, 184, 23, 17, 120, 238, 81, 193, 131, 50, 223, 172, 79, 100, 148, 150, 231, 186, 24, 198, 187, 232, 140, 191, 61, 240, 254, 70, 246, 113, 40, 133, 115, 228, 242, 70, 252, 50, 55, 202, 39, 227, 253, 68, 226, 36, 53, 134, 63, 191, 188, 122, 255, 52, 61, 153, 54, 177, 232, 88, 234, 113, 61, 141, 50, 248, 242, 4, 16, 72, 236, 204, 115, 1, 233, 136, 46, 80, 236, 223, 32, 29, 166, 152, 50, 4, 229, 196, 99, 1, 167, 158, 37, 4, 226, 200, 121, 74, 42, 76, 136, 78, 223, 137, 79, 134, 29, 84, 167, 15, 221, 145, 89, 138, 31, 75, 159, 15, 196, 150, 86, 128, 18, 83, 218, 73, 208, 145, 86, 138, 21, 3, 137, 124, 114, 250, 66, 253, 164, 57, 199, 104, 126, 250, 72, 190, 187, 118, 147, 111, 113, 248, 86, 168, 185, 58, 139, 51, 48, 198, 75, 184, 177, 37, 130, 61, 100, 228, 94, 253, 177, 49, 134, 116, 126, 184, 185, 243, 4, 149, 255, 161, 13, 80, 190, 231, 128, 130, 51, 102, 140, 82, 111, 52, 152, 217, 37, 65, 107, 255, 3, 230, 119, 23, 66, 173, 51, 94, 235, 37, 168, 106, 91, 126, 164, 58, 135, 44, 176, 163, 6, 165, 67, 225, 92, 227, 75, 166, 1, 182, 83, 251, 2, 225, 20, 160, 26, 182, 11, 162, 74, 244, 20, 160, 29, 64, 96, 48, 167, 2, 58, 118, 175, 73, 123, 33, 173, 30, 100, 62, 234, 69, 109, 55, 167, 2, 158, 183, 40, 130, 92, 237, 110, 138, 151, 172, 57, 136, 64, 179, 38, 209, 155, 173, 34, 133, 94, 251, 124, 25, 170, 140, 62, 67, 236, 132, 121, 30, 185, 156, 36, 29, 238, 219, 127, 5, 185, 196, 125, 85, 251, 219, 127, 2, 14, 231, 120, 18, 76, 189, 62, 154, 7, 252, 105, 24, 80, 227, 118, 193, 11, 253, 114, 21, 78, 171, 91, 119, 51, 192, 153, 45, 117, 200, 82, 108, 34, 202, 133, 115, 61, 141, 94, 122, 52, 192, 153, 241, 252, 240, 83, 163, 160, 177, 158, 53, 9, 55, 87, 192, 204, 112, 159, 2, 17, 24, 22, 230, 234, 76, 178, 78, 13, 42, 90, 194, 212, 107, 145, 78, 21, 32, 90, 222, 216, 119, 214, 27, 19, 36, 64, 207, 212, 105, 151, 12, 17, 32, 206, 134, 140, 56, 187, 195, 75, 112, 249, 158, 163, 121, 157, 229, 119, 93, 181, 130, 145, 53, 185, 219, 80, 126, 181, 148, 159, 48, 185, 215, 90, 155, 49, 183, 148, 222, 118, 255, 86, 131, 6, 184, 137, 218, 113, 243, 118, 134, 32, 179, 148, 220, 102, 215, 130, 26, 102, 1, 225, 6, 151, 111, 238, 15, 29, 44, 224, 88, 215, 111, 250, 24, 86, 55, 187, 69, 212, 97, 119, 253, 194, 38, 44, 168, 5, 122, 107, 121, 24, 128, 200, 47, 107, 80, 179, 212, 54, 131, 9, 254, 15, 199, 6, 247, 5, 4, 8, 160, 79, 199, 18, 224, 78, 31, 83, 189, 76, 132, 110, 169, 167, 88, 62, 167, 241, 158, 110, 109, 233, 90, 133, 97, 179, 154, 192, 104, 254, 93, 43, 25, 186, 28, 104, 50, 184, 79, 23, 99, 226, 86, 219, 53, 172, 56, 50, 197, 20, 126, 96, 204, 209, 63, 38, 42, 221, 244, 230, 109, 6, 161, 161, 49, 193, 240, 230, 122, 67, 84, 33, 227, 132, 15, 116, 164, 88, 72, 37, 227, 147]);
  const pack = self.tranquill_PACK = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  pack.data.push(a);
  const shard = pack.data["length"] - 1;
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 0,
    len: 24,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 24,
    len: 31,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 55,
    len: 36,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 91,
    len: 55,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 146,
    len: 63,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 209,
    len: 39,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 248,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 264,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 280,
    len: 14,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 294,
    len: 13,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 307,
    len: 12,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 319,
    len: 14,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 333,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 353,
    len: 15,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 368,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 372,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 388,
    len: 49,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 437,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 443,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 448,
    len: 60,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 508,
    len: 10,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 518,
    len: 10,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 528,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 537,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 546,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 550,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 561,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 571,
    len: 44,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 615,
    len: 43,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 658,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 668,
    len: 10,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 678,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 684,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 684,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 693,
    len: 45,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 738,
    len: 30,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 768,
    len: 33,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 801,
    len: 45,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 846,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 856,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 865,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 869,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 880,
    len: 9,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 889,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 915,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 936,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 958,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 984,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1006,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1027,
    len: 0,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 1027,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1035,
    len: 43,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1078,
    len: 31,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1109,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1131,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1136,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1155,
    len: 10,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 1165,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 1170,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 1176,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 1195,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1205,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1216,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1221,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1231,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1241,
    len: 13,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1254,
    len: 13,
    kind: 1
  });
})();
(function () {
  "use strict";

  const LICENSE_STORAGE_KEY = tranquill_S("0x6c62272e07bb0142");
  const MIN_LOADING_DELAY_MS = 900;
  const MAX_LOADING_VARIANCE_MS = 600;
  const SUCCESS_DISPLAY_DURATION_MS = 900;
  const SUCCESS_TRANSITION_FALLBACK_MS = 320;
  const EXIT_TRANSITION_FALLBACK_MS = 460;
  const POST_VALIDATION_HANDSHAKE_DELAY_MS = 320;
  const TRANSITION_SESSION_KEY = tranquill_S("0x6c62272e07bb0142");
  const DEFAULT_LICENSE_ERROR_MESSAGE = tranquill_S("0x6c62272e07bb0142");
  const NETWORK_ERROR_MESSAGE = tranquill_S("0x6c62272e07bb0142");
  const HWID_ERROR_MESSAGE = tranquill_S("0x6c62272e07bb0142");
  const HWID_POLL_INTERVAL_MS = 250;
  const HWID_POLL_ATTEMPTS = 20;
  const logger = self?.log ?? console;
  const LicenseManagerClass = self?.tranquillLicenseManager;
  const licenseManager = LicenseManagerClass ? new LicenseManagerClass({
    storageKey: LICENSE_STORAGE_KEY,
    logger,
    chrome: self?.chrome ?? null,
    hwidResolver: resolveHWID,
    defaultErrorMessage: DEFAULT_LICENSE_ERROR_MESSAGE,
    networkErrorMessage: NETWORK_ERROR_MESSAGE,
    hwidErrorMessage: HWID_ERROR_MESSAGE
  }) : null;
  if (!licenseManager) {
    logger?.error?.(tranquill_S("0x6c62272e07bb0142"));
    return;
  }
  const state = {
    isLoading: false,
    isUnlocked: false,
    originalButtonLabel: null
  };
  document.addEventListener(tranquill_S("0x6c62272e07bb0142"), () => {
    const root = document.querySelector(tranquill_S("0x6c62272e07bb0142"));
    const container = document.querySelector(tranquill_S("0x6c62272e07bb0142"));
    const form = document.querySelector(tranquill_S("0x6c62272e07bb0142"));
    const input = document.querySelector(tranquill_S("0x6c62272e07bb0142"));
    const errorEl = document.querySelector(tranquill_S("0x6c62272e07bb0142"));
    const inputGroup = document.querySelector(tranquill_S("0x6c62272e07bb0142"));
    const button = form?.querySelector(tranquill_S("0x6c62272e07bb0142"));
    const buttonLabel = button?.querySelector(tranquill_S("0x6c62272e07bb0142"));
    const successEl = document.querySelector(tranquill_S("0x6c62272e07bb0142"));
    if (!root || !container || !form || !input || !button || !buttonLabel) {
      logger?.warn?.(tranquill_S("0x6c62272e07bb0142"));
      return;
    }
    state.originalButtonLabel = buttonLabel.textContent;
    form["addEventListener"](tranquill_S("0x6c62272e07bb0142"), event => {
      event.preventDefault();
      void handleSubmit({
        root,
        container,
        input,
        inputGroup,
        errorEl,
        button,
        buttonLabel,
        successEl
      });
    });
    input["addEventListener"](tranquill_S("0x6c62272e07bb0142"), () => {
      clearError({
        inputGroup,
        errorEl
      });
    });
    if (!successEl) {
      logger?.warn?.(tranquill_S("0x6c62272e07bb0142"));
    }
    void initialize({
      root,
      container,
      input,
      inputGroup,
      errorEl,
      button,
      buttonLabel,
      successEl
    });
  });
  async function initialize({
    root,
    container,
    input,
    inputGroup,
    errorEl,
    button,
    buttonLabel,
    successEl
  }) {
    let storedLicense = null;
    try {
      storedLicense = await licenseManager.getStoredLicenseKey();
      container.classList.remove(tranquill_S("0x6c62272e07bb0142"));
      if (!storedLicense) {
        container.classList["remove"](tranquill_S("0x6c62272e07bb0142"));
        state.isLoading = false;
        state.isUnlocked = false;
        if (input) {
          input.disabled = false;
          requestAnimationFrame(() => {
            try {
              input.focus();
            } catch (_) {}
          });
        }
        if (button) {
          button.disabled = false;
          button["removeAttribute"](tranquill_S("0x6c62272e07bb0142"));
        }
        if (buttonLabel) {
          buttonLabel.textContent = state["originalButtonLabel"];
        }
        return;
      }
      state["isUnlocked"] = false;
      state.isLoading = true;
      if (input) {
        input.value = storedLicense;
        input.disabled = true;
      }
      if (button) {
        button.disabled = true;
        button["setAttribute"](tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      }
      if (buttonLabel) {
        buttonLabel.textContent = tranquill_S("0x6c62272e07bb0142");
      }
      container.classList["add"](tranquill_S("0x6c62272e07bb0142"));
      try {
        await simulateLicenseValidation(storedLicense);
        state["isUnlocked"] = true;
        await performPostValidationHandshake();
        await completeUnlockFlow({
          root,
          container,
          successEl
        });
        return;
      } catch (error) {
        logger?.warn?.(tranquill_S("0x6c62272e07bb0142"), error);
        throw error;
      }
    } catch (error) {
      logger?.warn?.(tranquill_S("0x6c62272e07bb0142"), error);
      container.classList["remove"](tranquill_S("0x6c62272e07bb0142"));
      container.classList.remove(tranquill_S("0x6c62272e07bb0142"));
      const shouldClearLicense = Boolean(error && typeof error === tranquill_S("0x6c62272e07bb0142") && error["shouldClearLicense"]);
      if (shouldClearLicense) {
        await licenseManager.clearStoredLicenseKey();
      }
      if (input) {
        input.disabled = false;
        if (shouldClearLicense) {
          input.value = tranquill_S("0x6c62272e07bb0142");
        } else if (storedLicense) {
          input.value = storedLicense;
        }
        requestAnimationFrame(() => {
          try {
            input.focus();
          } catch (_) {}
        });
      }
      if (button) {
        button.disabled = false;
        button.removeAttribute(tranquill_S("0x6c62272e07bb0142"));
      }
      if (buttonLabel) {
        buttonLabel["textContent"] = state.originalButtonLabel;
      }
      state.isLoading = false;
      state.isUnlocked = false;
      showError({
        message: error?.message || tranquill_S("0x6c62272e07bb0142"),
        inputGroup,
        errorEl
      });
    }
  }
  async function handleSubmit({
    root,
    container,
    input,
    inputGroup,
    errorEl,
    button,
    buttonLabel,
    successEl
  }) {
    if (state.isLoading) {
      return;
    }
    const rawKey = input.value.trim();
    if (!rawKey) {
      showError({
        message: tranquill_S("0x6c62272e07bb0142"),
        inputGroup,
        errorEl
      });
      return;
    }
    clearError({
      inputGroup,
      errorEl
    });
    setLoadingState({
      container,
      button,
      buttonLabel,
      input,
      isLoading: true
    });
    try {
      await simulateLicenseValidation(rawKey);
      await licenseManager.persistLicenseKey(rawKey);
      await notifyServiceWorker();
      state["isUnlocked"] = true;
      await performPostValidationHandshake();
      await completeUnlockFlow({
        root,
        container,
        successEl
      });
    } catch (error) {
      logger?.warn?.(tranquill_S("0x6c62272e07bb0142"), error?.message || error);
      state.isUnlocked = false;
      showError({
        message: error?.message || tranquill_S("0x6c62272e07bb0142"),
        inputGroup,
        errorEl
      });
    } finally {
      if (!state["isUnlocked"]) {
        setLoadingState({
          container,
          button,
          buttonLabel,
          input,
          isLoading: false
        });
      }
    }
  }
  function setLoadingState({
    container,
    button,
    buttonLabel,
    input,
    isLoading
  }) {
    state["isLoading"] = isLoading;
    container["classList"].toggle(tranquill_S("0x6c62272e07bb0142"), isLoading);
    button["disabled"] = Boolean(isLoading);
    input.disabled = Boolean(isLoading);
    if (isLoading) {
      button.setAttribute(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      buttonLabel.textContent = tranquill_S("0x6c62272e07bb0142");
    } else {
      button.removeAttribute(tranquill_S("0x6c62272e07bb0142"));
      buttonLabel.textContent = state.originalButtonLabel;
    }
  }
  function showError({
    message,
    inputGroup,
    errorEl
  }) {
    if (inputGroup) {
      inputGroup["classList"].add(tranquill_S("0x6c62272e07bb0142"));
    }
    if (errorEl) {
      errorEl.classList.replace(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      errorEl.textContent = message;
    }
  }
  function clearError({
    inputGroup,
    errorEl
  }) {
    if (inputGroup) {
      inputGroup.classList["remove"](tranquill_S("0x6c62272e07bb0142"));
    }
    if (errorEl) {
      errorEl.classList["replace"](tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
      errorEl.textContent = tranquill_S("0x6c62272e07bb0142");
    }
  }
  async function simulateLicenseValidation(rawKey) {
    const trimmed = rawKey.trim();
    const delayMs = MIN_LOADING_DELAY_MS + Math.floor(Math["random"]() * MAX_LOADING_VARIANCE_MS);
    const minimumDelayPromise = delay(delayMs);
    try {
      await licenseManager.validateLicenseKey(trimmed);
      return true;
    } catch (error) {
      if (error instanceof Error) {
        throw error;
      }
      throw new Error(DEFAULT_LICENSE_ERROR_MESSAGE);
    } finally {
      await minimumDelayPromise;
    }
  }
  function resolveHWID() {
    const poll = window?.tranquillPollHWID;
    if (typeof poll !== tranquill_S("0x6c62272e07bb0142")) {
      logger?.warn?.(tranquill_S("0x6c62272e07bb0142"));
      return Promise["resolve"](null);
    }
    return poll({
      interval: HWID_POLL_INTERVAL_MS,
      attempts: HWID_POLL_ATTEMPTS
    }).catch(error => {
      logger?.warn?.(tranquill_S("0x6c62272e07bb0142"), error);
      return null;
    });
  }
  function notifyServiceWorker() {
    return new Promise(resolve => {
      if (!chrome?.runtime?.sendMessage) {
        resolve();
        return;
      }
      try {
        chrome.runtime.sendMessage({
          action: tranquill_S("0x6c62272e07bb0142")
        }, () => resolve());
      } catch (_) {
        resolve();
      }
    });
  }
  async function transitionToMainPopup() {
    persistTransitionOverride(tranquill_S("0x6c62272e07bb0142"));
    try {
      await setPopupToMain();
    } catch (_) {}
    await delay(250);
    const targetUrl = new URL(tranquill_S("0x6c62272e07bb0142"), window.location["href"]);
    targetUrl.searchParams.set(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
    try {
      window["location"].replace(targetUrl["toString"]());
    } catch (_) {
      window.location.href = targetUrl.toString();
    }
  }
  function persistTransitionOverride(value) {
    if (typeof value !== tranquill_S("0x6c62272e07bb0142")) {
      return;
    }
    const normalized = value["trim"]();
    if (!normalized) {
      return;
    }
    try {
      const storage = window?.sessionStorage;
      storage?.setItem?.(TRANSITION_SESSION_KEY, normalized);
    } catch (_) {}
  }
  function setPopupToMain() {
    if (!chrome?.action?.setPopup) {
      return Promise.resolve();
    }
    return new Promise(resolve => {
      try {
        chrome.action["setPopup"]({
          popup: tranquill_S("0x6c62272e07bb0142")
        }, () => resolve());
      } catch (_) {
        resolve();
      }
    });
  }
  function delay(duration) {
    return new Promise(resolve => {
      setTimeout(resolve, duration);
    });
  }
  function transitionToSuccessState({
    container,
    successEl
  }) {
    if (!container) {
      return Promise.resolve();
    }
    container.classList.add(tranquill_S("0x6c62272e07bb0142"));
    if (successEl) {
      successEl.setAttribute(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
    }
    return waitForTransitionEnd(container, SUCCESS_TRANSITION_FALLBACK_MS);
  }
  function animatePopupExit(root) {
    if (!root) {
      return Promise.resolve();
    }
    root.classList.add(tranquill_S("0x6c62272e07bb0142"));
    return waitForTransitionEnd(root, EXIT_TRANSITION_FALLBACK_MS);
  }
  async function completeUnlockFlow({
    root,
    container,
    successEl
  }) {
    if (container) {
      container.classList.remove(tranquill_S("0x6c62272e07bb0142"));
    }
    await transitionToSuccessState({
      container,
      successEl
    });
    await delay(SUCCESS_DISPLAY_DURATION_MS);
    await animatePopupExit(root);
    await transitionToMainPopup();
  }
  function performPostValidationHandshake() {
    return delay(POST_VALIDATION_HANDSHAKE_DELAY_MS);
  }
  function waitForTransitionEnd(element, fallbackDuration) {
    return new Promise(resolve => {
      if (!element) {
        resolve();
        return;
      }
      let resolved = false;
      const finish = () => {
        if (resolved) {
          return;
        }
        resolved = true;
        element.removeEventListener(tranquill_S("0x6c62272e07bb0142"), finish);
        resolve();
      };
      element.addEventListener(tranquill_S("0x6c62272e07bb0142"), finish);
      const fallback = Number["isFinite"](fallbackDuration) ? fallbackDuration : 400;
      setTimeout(finish, fallback);
    });
  }
})();
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}