var tranquill_global = typeof self !== "undefined" ? self : globalThis;
if (!tranquill_global.tranquill_runtime_ready) {
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::c882198ca34f17b696c9b80e0eca21ea"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = "tranquill_tranquill_tranquill";
        tranquill_global.tranquill_runtime_ready = true;
}

(function tranquill_init_shard() {
  const a = new Uint8Array([230, 63, 171, 70, 188, 97, 200, 138, 230, 50, 178, 65, 181, 117, 193, 203, 62, 64, 180, 29, 219, 81, 164, 90, 174, 135, 255, 206, 35, 80, 179, 24, 25, 34, 193, 38, 196, 113, 31, 164, 71, 32, 194, 247, 21, 46, 205, 42, 200, 125, 57, 188, 209, 13, 51, 161, 211, 60, 52, 162, 154, 41, 99, 88, 50, 206, 187, 0, 99, 132, 230, 211, 233, 149, 79, 124, 139, 227, 183, 12, 111, 136, 234, 223, 173, 150, 245, 146, 240, 69, 245, 69, 110, 149, 86, 137, 120, 239, 157, 90, 63, 149, 71, 146, 126, 231, 148, 88, 98, 168, 92, 143, 97, 231, 159, 84, 54, 163, 19, 213, 127, 227, 135, 73, 37, 168, 84, 142, 44, 246, 146, 90, 41, 239, 99, 82, 191, 204, 47, 132, 101, 211, 79, 207, 34, 29, 14, 70, 155, 97, 178, 19, 114, 43, 249, 173, 136, 193, 178, 87, 67, 18, 245, 173, 153, 218, 180, 95, 74, 16, 168, 153, 136, 193, 149, 91, 89, 1, 239, 144, 138, 198, 230, 22, 94, 16, 242, 138, 132, 219, 161, 77, 13, 5, 231, 153, 136, 156, 99, 157, 13, 5, 153, 86, 222, 194, 99, 140, 22, 3, 145, 95, 220, 159, 87, 157, 13, 34, 149, 76, 205, 216, 94, 159, 10, 81, 150, 89, 208, 221, 85, 156, 87, 59, 41, 51, 173, 240, 250, 244, 87, 42, 50, 53, 165, 249, 248, 169, 99, 59, 41, 20, 161, 234, 233, 238, 106, 57, 46, 103, 182, 251, 238, 232, 104, 40, 56, 35, 243, 95, 13, 39, 137, 148, 94, 96, 243, 78, 22, 33, 129, 157, 92, 61, 211, 91, 15, 54, 179, 159, 77, 103, 201, 84, 30, 32, 20, 69, 20, 115, 238, 142, 199, 180, 20, 84, 15, 117, 230, 135, 197, 233, 52, 65, 22, 98, 212, 133, 212, 179, 46, 78, 7, 116, 167, 134, 193, 174, 43, 69, 4, 240, 164, 206, 156, 10, 239, 29, 91, 240, 181, 213, 154, 2, 230, 31, 6, 208, 160, 204, 141, 48, 228, 14, 92, 202, 175, 221, 155, 67, 242, 15, 75, 192, 164, 201, 155, 218, 196, 84, 188, 32, 15, 135, 123, 217, 192, 71, 173, 10, 14, 142, 124, 251, 206, 76, 164, 44, 19, 192, 107, 230, 207, 83, 188, 59, 20, 131, 124, 236, 197, 81, 2, 221, 180, 43, 201, 14, 243, 82, 6, 206, 165, 1, 200, 7, 244, 112, 8, 197, 172, 39, 213, 71, 233, 108, 14, 221, 224, 49, 211, 8, 242, 118, 143, 97, 241, 233, 117, 170, 34, 46, 140, 101, 226, 248, 95, 171, 43, 41, 174, 107, 233, 241, 121, 182, 101, 52, 178, 109, 241, 244, 125, 168, 44, 39, 185, 96, 90, 249, 248, 247, 64, 163, 179, 164, 7, 167, 238, 239, 93, 174, 184, 177, 17, 231, 45, 223, 139, 189, 102, 140, 76, 185, 59, 199, 150, 176, 109, 153, 96, 203, 62, 202, 147, 161, 109, 107, 7, 207, 185, 117, 69, 29, 186, 49, 2, 209, 185, 113, 66, 27, 179, 41, 8, 183, 145, 67, 111, 184, 89, 31, 112, 237, 214, 91, 39, 160, 22, 18, 119, 237, 143, 95, 44, 80, 125, 54, 93, 223, 53, 106, 66, 10, 58, 46, 21, 199, 122, 97, 89, 13, 103, 41, 17, 199, 190, 130, 74, 76, 177, 202, 150, 83, 228, 197, 82, 4, 169, 133, 145, 72, 254, 156, 251, 115, 11, 115, 225, 41, 64, 32, 166, 45, 12, 102, 246, 43, 3, 37, 160, 116, 26, 104, 251, 234, 78, 68, 134, 16, 133, 151, 65, 233, 74, 87, 151, 58, 132, 158, 70, 203, 68, 92, 158, 28, 153, 208, 81, 216, 72, 88, 151, 60, 135, 149, 95, 220, 69, 68, 129, 103, 25, 165, 197, 58, 76, 83, 92, 185, 54, 152, 15, 254, 63, 69, 68, 164, 59, 147, 26, 173, 118, 88, 88, 184, 43, 114, 133, 233, 218, 54, 72, 168, 242, 118, 154, 82, 185, 37, 221, 219, 228, 110, 135, 95, 178, 48, 142, 152, 255, 99, 128, 92, 178, 158, 105, 5, 182, 90, 36, 68, 219, 42, 130, 32, 156, 102, 140, 121, 220, 47, 137, 116, 135, 100, 203, 115, 223, 46, 204, 55, 155, 106, 194, 115, 214, 47, 54, 28, 167, 20, 126, 57, 199, 248, 23, 113, 78, 121, 96, 212, 141, 119, 55, 158, 78, 109, 119, 159, 150, 44, 42, 157, 48, 102, 12, 243, 119, 61, 217, 180, 43, 122, 94, 235, 21, 246, 247, 35, 25, 59, 141, 104, 74, 124, 132, 36, 12, 44, 143, 38, 79, 122, 208, 50, 2, 33, 196, 101, 65, 102, 199, 45, 8, 43, 254, 75, 53, 86, 247, 7, 35, 6, 176, 79, 119, 74, 208, 31, 61, 6, 170, 65, 94, 95, 225, 3, 41, 79, 162, 71, 97, 67, 230, 7, 46, 4, 248, 21, 234, 50, 191, 93, 190, 126, 223, 13, 244, 50, 165, 83, 151, 107, 238, 17, 224, 144, 216, 68, 110, 243, 29, 77, 54, 185, 153, 65, 109, 247, 29, 77, 49, 179, 205, 89, 107, 248, 30, 30, 144, 251, 184, 65, 234, 176, 235, 6, 227, 236, 169, 70, 247, 177, 254, 16, 167, 181, 157, 11, 74, 237, 254, 222, 18, 160, 132, 21, 65, 231, 249, 212, 51, 157, 71, 206, 15, 166, 38, 27, 79, 167, 97, 210, 2, 163, 55, 12, 11, 227, 123, 205, 27, 171, 51, 7, 79, 92, 125, 182, 44, 206, 57, 235, 102, 14, 115, 160, 38, 169, 113, 168, 181, 65, 125, 245, 249, 202, 126, 169, 183, 68, 58, 228, 167, 105, 249, 225, 125, 162, 42, 38, 249, 103, 232, 236, 118, 165, 35, 49, 249, 110, 248, 225, 96, 163, 35, 120, 249, 96, 228, 230, 96, 169, 35, 60, 186, 107, 60, 9, 41, 23, 120, 219, 126, 73, 53, 71, 226, 13, 15, 124, 196, 120, 13, 56, 147, 53, 77, 112, 215, 124, 89, 38, 132, 41, 77, 96, 194, 109, 95, 39, 147, 40, 223, 84, 136, 61, 170, 214, 204, 106, 231, 22, 132, 46, 174, 130, 210, 125, 251, 82, 242, 195, 123, 89, 182, 17, 44, 247, 131, 121, 68, 245, 113, 132, 62, 128, 115, 192, 105, 205, 51, 136, 45, 132, 39, 222, 126, 209, 51, 136, 45, 154, 48, 206, 96, 216, 118, 143, 37, 117, 188, 100, 252, 163, 122, 132, 48, 100, 186, 126, 251, 183, 125, 247, 38, 123, 167, 103, 229, 181, 106, 236, 117, 126, 161, 99, 181, 162, 107, 164, 33, 127, 188, 114, 241, 184, 54, 150, 142, 194, 125, 197, 73, 203, 35, 135, 136, 216, 122, 209, 78, 142, 55, 240, 184, 100, 78, 19, 253, 109, 22, 217, 249, 126, 67, 0, 252, 109, 17, 211, 173, 121, 75, 24, 254, 62, 182, 89, 208, 221, 85, 156, 89, 5, 159, 24, 208, 223, 89, 140, 16, 16, 156, 81, 195, 212, 16, 139, 28, 5, 132, 81, 215, 214, 67, 216, 9, 16, 151, 93, 195, 131, 244, 178, 73, 201, 178, 228, 192, 140, 239, 185, 70, 132, 250, 131, 187, 77, 190, 123, 103, 82, 152, 51, 56, 152, 196, 125, 74, 9, 200, 231, 80, 211, 131, 180, 23, 87, 194, 227, 80, 211, 130, 189, 22, 26, 110, 21, 82, 221, 34, 150, 18, 29, 104, 28, 74, 215, 95, 122, 104, 195, 138, 117, 44, 148, 71, 53, 104, 193, 138, 49, 40, 159, 37, 93, 139, 213, 127, 22, 88, 146, 123, 87, 143, 213, 127, 23, 81, 204, 50, 81, 140, 192, 116, 20, 90, 133, 234, 176, 205, 88, 230, 230, 141, 138, 234, 160, 200, 92, 175, 235, 23, 243, 89, 220, 244, 210, 60, 134, 191, 129, 123, 130, 254, 214, 60, 134, 190, 136, 37, 203, 248, 213, 41, 141, 189, 131, 108, 229, 235, 194, 3, 233, 189, 2, 81, 229, 251, 199, 7, 160, 167, 151, 181, 139, 226, 86, 243, 167, 242, 167, 87, 204, 19, 222, 49, 141, 201, 166, 123, 194, 25, 207, 48]);
  const pack = self["tranquill_PACK"] = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  pack.data.push(a);
  const shard = pack.data.length - 1;
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 0,
    len: 14,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 14,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 20,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 26,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 32,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 38,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 44,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 50,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 54,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 58,
    len: 3,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 61,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 66,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 72,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 73,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 78,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 84,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 90,
    len: 3,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 93,
    len: 41,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 134,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 140,
    len: 7,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 147,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 155,
    len: 43,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 198,
    len: 34,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 232,
    len: 36,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 268,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 296,
    len: 35,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 331,
    len: 36,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 367,
    len: 34,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 401,
    len: 33,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 434,
    len: 34,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 468,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 484,
    len: 23,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 507,
    len: 18,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 525,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 545,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 566,
    len: 18,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 584,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 605,
    len: 36,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 641,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 646,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 667,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 673,
    len: 22,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 695,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 701,
    len: 27,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 728,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 733,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 738,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 754,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 764,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 768,
    len: 28,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 796,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 800,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 828,
    len: 19,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 847,
    len: 23,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 870,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 887,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 904,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 926,
    len: 13,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 939,
    len: 15,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 954,
    len: 34,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 988,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 995,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 999,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1024,
    len: 18,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1042,
    len: 7,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1049,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1053,
    len: 27,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1080,
    len: 37,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1117,
    len: 18,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1135,
    len: 23,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 1158,
    len: 34,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1192,
    len: 13,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1205,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 1211,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1220,
    len: 16,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1236,
    len: 14,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1250,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 1266,
    len: 24,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1290,
    len: 13,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 1303,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1307,
    len: 24,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1331,
    len: 13,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1344,
    len: 7,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 1351,
    len: 16,
    kind: 1
  });
})();
(function () {
  const SETTINGS_STORAGE_KEY = tranquill_S("0x6c62272e07bb0142");
  const MIN_WPM = 60;
  const MAX_WPM = 200;
  const DEFAULT_ABORT_KEY = Object["freeze"]({
    key: tranquill_S("0x6c62272e07bb0142"),
    code: tranquill_S("0x6c62272e07bb0142"),
    altKey: false,
    ctrlKey: false,
    metaKey: false,
    shiftKey: false
  });
  const normalizeAbortKey = rawBinding => {
    if (rawBinding && typeof rawBinding === tranquill_S("0x6c62272e07bb0142")) {
      const key = typeof rawBinding.key === tranquill_S("0x6c62272e07bb0142") && rawBinding["key"].length > 0 ? rawBinding.key : DEFAULT_ABORT_KEY.key;
      const code = typeof rawBinding.code === tranquill_S("0x6c62272e07bb0142") && rawBinding.code["length"] > 0 ? rawBinding["code"] : key;
      return {
        key,
        code,
        altKey: rawBinding.altKey === true,
        ctrlKey: rawBinding.ctrlKey === true,
        metaKey: rawBinding.metaKey === true,
        shiftKey: rawBinding.shiftKey === true
      };
    }
    if (typeof rawBinding === tranquill_S("0x6c62272e07bb0142") && rawBinding.trim().length > 0) {
      const value = rawBinding.trim();
      return {
        key: value,
        code: value,
        altKey: false,
        ctrlKey: false,
        metaKey: false,
        shiftKey: false
      };
    }
    return {
      ...DEFAULT_ABORT_KEY
    };
  };
  const formatAbortKey = binding => {
    const normalized = normalizeAbortKey(binding);
    const parts = [];
    if (normalized.ctrlKey) parts["push"](tranquill_S("0x6c62272e07bb0142"));
    if (normalized.metaKey) parts.push(tranquill_S("0x6c62272e07bb0142"));
    if (normalized["altKey"]) parts.push(tranquill_S("0x6c62272e07bb0142"));
    if (normalized.shiftKey) parts.push(tranquill_S("0x6c62272e07bb0142"));
    let base = normalized["key"];
    if (typeof base !== tranquill_S("0x6c62272e07bb0142") || base["length"] === 0) {
      base = normalized.code;
    }
    if (base === tranquill_S("0x6c62272e07bb0142")) base = tranquill_S("0x6c62272e07bb0142");
    if (typeof base === tranquill_S("0x6c62272e07bb0142") && base.length === 1) {
      base = base.toUpperCase();
    }
    if (typeof base === tranquill_S("0x6c62272e07bb0142") && base.length > 1) {
      base = `${base.charAt(0)["toUpperCase"]()}${base.slice(1)}`;
    }
    parts.push(base);
    return parts.join(tranquill_S("0x6c62272e07bb0142"));
  };
  const createAbortKeyFromEvent = event => normalizeAbortKey({
    key: event.key,
    code: event["code"],
    altKey: event.altKey,
    ctrlKey: event.ctrlKey,
    metaKey: event.metaKey,
    shiftKey: event.shiftKey
  });
  class SettingsStorage {
    static get defaults() {
      return {
        typingSpeed: 120,
        phantomMode: false,
        abortKey: normalizeAbortKey(DEFAULT_ABORT_KEY)
      };
    }
    static normalize(rawSettings) {
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        rawSettings
      });
      const defaults = SettingsStorage.defaults;
      const normalized = {
        ...defaults,
        abortKey: normalizeAbortKey(defaults.abortKey)
      };
      if (rawSettings && typeof rawSettings === tranquill_S("0x6c62272e07bb0142")) {
        const incomingSpeed = Number.parseInt(rawSettings.typingSpeed, 10);
        if (Number.isFinite(incomingSpeed)) {
          normalized.typingSpeed = Math.min(MAX_WPM, Math["max"](MIN_WPM, incomingSpeed));
        }
        if (typeof rawSettings.phantomMode === tranquill_S("0x6c62272e07bb0142")) {
          normalized.phantomMode = rawSettings.phantomMode;
        }
        if (Object.prototype.hasOwnProperty["call"](rawSettings, tranquill_S("0x6c62272e07bb0142"))) {
          normalized.abortKey = normalizeAbortKey(rawSettings.abortKey);
        }
      }
      return normalized;
    }
    static getSettings() {
      log.debug(tranquill_S("0x6c62272e07bb0142"));
      return new Promise((resolve, reject) => {
        chrome.storage.local.get(SETTINGS_STORAGE_KEY, result => {
          if (chrome.runtime["lastError"]) {
            const err = new Error(chrome.runtime.lastError.message);
            log.error(tranquill_S("0x6c62272e07bb0142"), err);
            reject(err);
            return;
          }
          const storedSettings = result[SETTINGS_STORAGE_KEY];
          const normalized = SettingsStorage.normalize(storedSettings);
          log["debug"](tranquill_S("0x6c62272e07bb0142"), normalized);
          resolve(normalized);
        });
      });
    }
    static saveSettings(settings) {
      log["debug"](tranquill_S("0x6c62272e07bb0142"), {
        settings
      });
      const sanitized = SettingsStorage.normalize(settings);
      return new Promise((resolve, reject) => {
        chrome.storage["local"].set({
          [SETTINGS_STORAGE_KEY]: sanitized
        }, () => {
          if (chrome.runtime["lastError"]) {
            const err = new Error(chrome.runtime.lastError.message);
            log.error(tranquill_S("0x6c62272e07bb0142"), err);
            reject(err);
            return;
          }
          log["debug"](tranquill_S("0x6c62272e07bb0142"), sanitized);
          resolve(sanitized);
        });
      });
    }
  }
  class SettingsPageController {
    constructor(documentRef) {
      this["documentRef"] = documentRef;
      this.slider = null;
      this["sliderValue"] = null;
      this.phantomToggle = null;
      this.abortKeyButton = null;
      this.abortKeyValue = null;
      this.abortKeyHint = null;
      this.backButton = null;
      this.currentSettings = SettingsStorage.defaults;
      this.isRestored = false;
      this.isCapturingAbortKey = false;
      this.abortKeyCaptureHandler = null;
      this["abortKeyBlurHandler"] = null;
      log.debug(tranquill_S("0x6c62272e07bb0142"));
    }
    async init() {
      log.debug(tranquill_S("0x6c62272e07bb0142"));
      this.cacheElements();
      this["registerEventListeners"]();
      await this.restoreSettings();
      log.info(tranquill_S("0x6c62272e07bb0142"));
    }
    cacheElements() {
      this.slider = this.documentRef.querySelector(tranquill_S("0x6c62272e07bb0142"));
      this.sliderValue = this.documentRef.querySelector(tranquill_S("0x6c62272e07bb0142"));
      this.phantomToggle = this.documentRef.querySelector(tranquill_S("0x6c62272e07bb0142"));
      this.abortKeyButton = this.documentRef.querySelector(tranquill_S("0x6c62272e07bb0142"));
      if (this["abortKeyButton"]) {
        this.abortKeyValue = this.abortKeyButton.querySelector(tranquill_S("0x6c62272e07bb0142"));
        this["abortKeyHint"] = this.abortKeyButton.querySelector(tranquill_S("0x6c62272e07bb0142"));
      } else {
        this.abortKeyValue = null;
        this["abortKeyHint"] = null;
      }
      this.backButton = this["documentRef"].querySelector(tranquill_S("0x6c62272e07bb0142"));
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        hasSlider: Boolean(this.slider),
        hasPhantomToggle: Boolean(this.phantomToggle),
        hasAbortKeyButton: Boolean(this.abortKeyButton)
      });
    }
    registerEventListeners() {
      if (this.slider) {
        this.slider.addEventListener(tranquill_S("0x6c62272e07bb0142"), () => {
          const sanitized = this.sanitizeTypingSpeed(this.slider.value);
          this.updateSliderDisplay(sanitized);
          log.debug(tranquill_S("0x6c62272e07bb0142"), {
            sanitized
          });
        });
        this.slider.addEventListener(tranquill_S("0x6c62272e07bb0142"), async () => {
          const sanitized = this.sanitizeTypingSpeed(this.slider.value);
          this.slider.value = String(sanitized);
          log.debug(tranquill_S("0x6c62272e07bb0142"), {
            sanitized
          });
          await this.persistSettings({
            typingSpeed: sanitized
          });
        });
      }
      if (this["phantomToggle"]) {
        this.phantomToggle.addEventListener(tranquill_S("0x6c62272e07bb0142"), async () => {
          const isEnabled = this.phantomToggle.checked;
          log.debug(tranquill_S("0x6c62272e07bb0142"), {
            isEnabled
          });
          toggleNonPhantomSettings(isEnabled);
          await this.persistSettings({
            phantomMode: isEnabled
          });
        });
      }
      if (this.abortKeyButton) {
        this.abortKeyButton.addEventListener(tranquill_S("0x6c62272e07bb0142"), () => {
          this.startAbortKeyCapture();
        });
      }
      if (this["backButton"]) {
        this.backButton.addEventListener(tranquill_S("0x6c62272e07bb0142"), () => {
          const popupUrl = new URL(chrome.runtime.getURL(tranquill_S("0x6c62272e07bb0142")));
          popupUrl.searchParams.set(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
          window.location.href = popupUrl["toString"]();
          log.info(tranquill_S("0x6c62272e07bb0142"), {
            transition: tranquill_S("0x6c62272e07bb0142")
          });
        });
      }
    }
    sanitizeTypingSpeed(value) {
      const parsed = Number["parseInt"](value, 10);
      if (!Number.isFinite(parsed)) {
        log["debug"](tranquill_S("0x6c62272e07bb0142"), {
          value,
          fallback: this.currentSettings.typingSpeed
        });
        return this.currentSettings.typingSpeed;
      }
      const sanitized = Math.min(MAX_WPM, Math.max(MIN_WPM, parsed));
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        value,
        sanitized
      });
      return sanitized;
    }
    async restoreSettings() {
      try {
        this.currentSettings = await SettingsStorage.getSettings();
      } catch (error) {
        log.warn(tranquill_S("0x6c62272e07bb0142"), error);
        this.currentSettings = SettingsStorage.defaults;
      }
      this.isRestored = true;
      this["applySettingsToUI"]();
      log.debug(tranquill_S("0x6c62272e07bb0142"), this.currentSettings);
      toggleNonPhantomSettings(this.currentSettings.phantomMode);
    }
    applySettingsToUI() {
      const {
        typingSpeed,
        phantomMode,
        abortKey
      } = this.currentSettings;
      log.debug(tranquill_S("0x6c62272e07bb0142"), this["currentSettings"]);
      if (this.slider) {
        this.slider.value = String(typingSpeed);
        this.updateSliderDisplay(typingSpeed);
      }
      if (this.phantomToggle) {
        this.phantomToggle.checked = Boolean(phantomMode);
      }
      this.updateAbortKeyDisplay(abortKey);
    }
    updateSliderDisplay(value) {
      if (this.sliderValue) {
        this.sliderValue["textContent"] = `${value} WPM`;
        log.debug(tranquill_S("0x6c62272e07bb0142"), {
          value
        });
      }
    }
    updateAbortKeyDisplay(binding = this["currentSettings"].abortKey) {
      if (!this.abortKeyButton) return;
      const formatted = formatAbortKey(binding);
      if (this.abortKeyValue) {
        this.abortKeyValue.textContent = formatted;
      } else {
        this.abortKeyButton["textContent"] = formatted;
      }
      if (this.abortKeyHint) {
        this.abortKeyHint.textContent = this["isCapturingAbortKey"] ? tranquill_S("0x6c62272e07bb0142") : tranquill_S("0x6c62272e07bb0142");
      }
      this["abortKeyButton"]["classList"].toggle(tranquill_S("0x6c62272e07bb0142"), this.isCapturingAbortKey);
    }
    startAbortKeyCapture() {
      if (!this.abortKeyButton) return;
      if (this.isCapturingAbortKey) {
        this.stopAbortKeyCapture({
          cancelled: true
        });
        return;
      }
      this.isCapturingAbortKey = true;
      this.updateAbortKeyDisplay();
      this.abortKeyCaptureHandler = event => {
        this["handleAbortKeyCapture"](event);
      };
      window.addEventListener(tranquill_S("0x6c62272e07bb0142"), this.abortKeyCaptureHandler, true);
      this.abortKeyBlurHandler = () => {
        this.stopAbortKeyCapture({
          cancelled: true
        });
      };
      window.addEventListener(tranquill_S("0x6c62272e07bb0142"), this.abortKeyBlurHandler);
      log.info(tranquill_S("0x6c62272e07bb0142"));
    }
    handleAbortKeyCapture(event) {
      if (!this.isCapturingAbortKey) return;
      event.preventDefault();
      event.stopPropagation();
      if (event["repeat"]) return;
      const binding = createAbortKeyFromEvent(event);
      log.info(tranquill_S("0x6c62272e07bb0142"), {
        binding
      });
      this.stopAbortKeyCapture();
      this["updateAbortKeyDisplay"](binding);
      this.persistSettings({
        abortKey: binding
      });
    }
    stopAbortKeyCapture({
      cancelled = false
    } = {}) {
      if (!this.isCapturingAbortKey) return;
      this.isCapturingAbortKey = false;
      if (this.abortKeyCaptureHandler) {
        window.removeEventListener(tranquill_S("0x6c62272e07bb0142"), this.abortKeyCaptureHandler, true);
        this.abortKeyCaptureHandler = null;
      }
      if (this.abortKeyBlurHandler) {
        window["removeEventListener"](tranquill_S("0x6c62272e07bb0142"), this["abortKeyBlurHandler"]);
        this.abortKeyBlurHandler = null;
      }
      this.updateAbortKeyDisplay();
      if (cancelled) {
        log["debug"](tranquill_S("0x6c62272e07bb0142"));
      }
    }
    async persistSettings(partialUpdate) {
      if (!this["isRestored"]) {
        log.debug(tranquill_S("0x6c62272e07bb0142"));
        return;
      }
      const nextSettings = {
        ...this.currentSettings,
        ...partialUpdate
      };
      try {
        this.currentSettings = await SettingsStorage.saveSettings(nextSettings);
        this.applySettingsToUI();
        log.info(tranquill_S("0x6c62272e07bb0142"), partialUpdate);
      } catch (error) {
        log.error(tranquill_S("0x6c62272e07bb0142"), error);
      }
    }
  }
  function initializeSettingsPage() {
    const controller = new SettingsPageController(document);
    controller.init().catch(error => {
      log.error(tranquill_S("0x6c62272e07bb0142"), error);
    });
    const creditsLink = document.querySelector(tranquill_S("0x6c62272e07bb0142"));
    let cText = creditsLink.innerText;
    cText = cText.replace(tranquill_S("0x6c62272e07bb0142"), new Date().getFullYear()).replace(tranquill_S("0x6c62272e07bb0142"), chrome.runtime.getManifest().version);
    creditsLink.innerText = cText;
  }
  function toggleNonPhantomSettings(isPhantom) {
    document.querySelectorAll(tranquill_S("0x6c62272e07bb0142")).forEach(el => {
      if (isPhantom) {
        if (!el.classList["contains"](tranquill_S("0x6c62272e07bb0142")) && !el.classList.contains(tranquill_S("0x6c62272e07bb0142"))) {
          el.classList.add(tranquill_S("0x6c62272e07bb0142"));
          el.setAttribute(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
        }
      } else {
        el.classList.remove(tranquill_S("0x6c62272e07bb0142"));
        el.removeAttribute(tranquill_S("0x6c62272e07bb0142"));
      }
    });
  }
  if (document.readyState === tranquill_S("0x6c62272e07bb0142")) {
    document.addEventListener(tranquill_S("0x6c62272e07bb0142"), initializeSettingsPage);
  } else {
    initializeSettingsPage();
  }
})();
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}