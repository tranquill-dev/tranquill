var tranquill_global = typeof self !== "undefined" ? self : globalThis;
if (!tranquill_global.tranquill_runtime_ready) {
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::c882198ca34f17b696c9b80e0eca21ea"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = "tranquill_tranquill_tranquill";
        tranquill_global.tranquill_runtime_ready = true;
}

(function tranquill_init_shard() {
  const a = new Uint8Array([249, 95, 191, 74, 164, 130, 234, 196, 234, 66, 189, 244, 224, 232, 70, 238, 19, 248, 75, 248, 12, 161, 55, 187, 225, 90, 185, 94, 188, 137, 245, 221, 117, 4, 121, 146, 33, 6, 97, 88, 47, 215, 7, 135, 30, 60, 196, 10, 251, 150, 37, 198, 173, 231, 113, 91, 51, 176, 54, 160, 30, 54, 193, 26, 235, 134, 53, 214, 189, 174, 57, 76, 153, 247, 127, 12, 66, 187, 183, 12, 111, 136, 234, 223, 173, 150, 245, 146, 240, 69, 150, 226, 250, 151, 211, 165, 178, 85, 142, 189, 247, 150, 197, 253, 168, 77, 144, 245, 250, 148, 197, 205, 37, 201, 41, 8, 78, 19, 112, 205, 199, 181, 104, 162, 38, 121, 160, 112, 181, 164, 97, 247, 38, 117, 186, 55, 224, 190, 125, 162, 37, 96, 161, 101, 225, 181, 106, 247, 57, 127, 169, 55, 249, 181, 120, 178, 57, 87, 22, 47, 128, 11, 212, 87, 233, 82, 22, 55, 181, 129, 101, 139, 86, 196, 108, 211, 156, 192, 127, 130, 71, 128, 32, 200, 148, 192, 96, 130, 69, 197, 32, 156, 104, 77, 163, 95, 61, 27, 123, 14, 96, 198, 86, 111, 143, 28, 150, 96, 83, 198, 65, 103, 150, 7, 129, 96, 93, 219, 79, 100, 152, 12, 198, 37, 76, 221, 71, 98, 147, 0, 149, 40, 90, 205, 67, 191, 247, 41, 160, 122, 126, 241, 106, 254, 247, 43, 172, 106, 55, 228, 105, 183, 228, 32, 229, 114, 49, 226, 98, 183, 240, 34, 229, 124, 44, 236, 97, 185, 251, 62, 108, 53, 89, 222, 16, 113, 131, 28, 98, 34, 73, 128, 36, 96, 152, 61, 98, 51, 73, 202, 23, 96, 148, 26, 35, 44, 66, 216, 44, 110, 137, 10, 0, 135, 250, 56, 215, 242, 169, 101, 7, 51, 34, 58, 81, 211, 222, 254, 139, 17, 44, 45, 65, 141, 234, 239, 144, 48, 44, 60, 65, 199, 217, 239, 156, 23, 109, 44, 69, 202, 225, 239, 128, 145, 198, 88, 117, 241, 58, 156, 47, 179, 200, 79, 101, 175, 14, 141, 52, 146, 200, 94, 101, 229, 61, 141, 56, 181, 137, 90, 101, 242, 6, 132, 54, 164, 205, 130, 0, 121, 93, 226, 124, 61, 7, 160, 14, 110, 77, 188, 92, 44, 28, 129, 14, 127, 77, 246, 123, 44, 16, 166, 174, 71, 87, 180, 78, 187, 147, 238, 140, 73, 64, 164, 16, 155, 130, 245, 173, 73, 81, 164, 90, 188, 130, 249, 138, 8, 65, 160, 87, 132, 130, 229, 143, 101, 184, 212, 111, 153, 124, 14, 173, 107, 175, 196, 49, 185, 109, 21, 140, 107, 190, 196, 123, 158, 109, 25, 171, 42, 187, 212, 124, 169, 109, 18, 172, 38, 58, 237, 11, 70, 70, 169, 209, 4, 52, 250, 27, 24, 118, 177, 219, 23, 39, 206, 31, 64, 112, 185, 234, 19, 45, 233, 64, 71, 58, 248, 151, 50, 105, 165, 71, 49, 40, 220, 241, 107, 118, 60, 170, 42, 54, 222, 253, 118, 98, 35, 148, 10, 71, 195, 104, 206, 157, 1, 154, 29, 87, 157, 88, 214, 151, 18, 137, 41, 83, 197, 94, 222, 166, 22, 131, 14, 18, 213, 90, 211, 158, 22, 159, 2, 54, 105, 103, 226, 202, 173, 189, 32, 56, 126, 119, 188, 250, 181, 183, 51, 43, 74, 115, 228, 252, 189, 134, 55, 33, 109, 50, 225, 236, 186, 177, 55, 42, 106, 246, 239, 15, 156, 22, 147, 203, 70, 212, 225, 24, 140, 72, 178, 218, 90, 195, 244, 43, 144, 22, 169, 209, 78, 246, 242, 16, 142, 20, 165, 204, 90, 209, 49, 106, 176, 49, 205, 174, 106, 243, 63, 125, 160, 111, 236, 191, 118, 228, 42, 78, 188, 49, 247, 180, 98, 209, 44, 117, 162, 51, 251, 169, 118, 161, 56, 123, 172, 45, 251, 190, 89, 24, 0, 203, 57, 228, 196, 17, 123, 22, 23, 219, 103, 197, 213, 13, 108, 3, 36, 199, 57, 222, 222, 25, 89, 5, 31, 217, 59, 210, 195, 13, 41, 4, 5, 221, 42, 210, 195, 13, 94, 192, 181, 157, 62, 186, 204, 235, 97, 193, 177, 154, 33, 131, 233, 205, 124, 143, 166, 135, 32, 156, 241, 218, 123, 204, 177, 141, 42, 38, 123, 111, 8, 70, 1, 22, 254, 25, 122, 107, 15, 89, 56, 51, 216, 4, 58, 118, 19, 95, 32, 127, 206, 2, 117, 109, 9, 3, 85, 76, 212, 99, 47, 181, 162, 60, 84, 72, 211, 124, 22, 144, 132, 33, 26, 85, 207, 122, 14, 149, 128, 63, 83, 70, 196, 119, 229, 228, 80, 76, 252, 168, 6, 136, 228, 245, 179, 156, 117, 48, 184, 2, 54, 115, 233, 155, 123, 40, 84, 81, 36, 63, 223, 23, 44, 110, 15, 87, 53, 35, 212, 173, 169, 24, 0, 177, 238, 129, 67, 246, 174, 24, 14, 173, 165, 198, 231, 40, 191, 156, 172, 123, 248, 152, 224, 41, 191, 129, 173, 114, 252, 166, 92, 147, 246, 228, 68, 86, 187, 175, 66, 185, 225, 18, 112, 217, 155, 107, 6, 134, 224, 22, 119, 198, 162, 78, 32, 155, 174, 1, 100, 202, 166, 71, 0, 133, 235, 15, 96, 199, 186, 81, 213, 35, 132, 123, 29, 203, 34, 232, 157, 16, 172, 115, 2, 196, 63, 232, 133, 22, 244, 114, 78, 204, 59, 179, 130, 20, 243, 50, 74, 209, 51, 251, 158, 12, 248, 115, 89, 209, 55, 242, 156, 22, 255, 48, 65, 140, 70, 108, 225, 148, 36, 121, 164, 217, 111, 114, 168, 147, 45, 48, 171, 219, 100, 125, 149, 227, 196, 187, 93, 84, 15, 118, 176, 35, 14, 52, 240, 127, 26, 32, 179, 53, 65, 45, 181, 119, 1, 112, 160, 55, 40, 36, 252, 18, 75, 97, 245, 202, 1, 101, 230, 31, 88, 96, 245, 202, 11, 61, 225, 76, 122, 81, 238, 132, 111, 4, 42, 204, 219, 72, 124, 136, 78, 21, 114, 219, 151, 68, 115, 138, 94, 5, 114, 206, 146, 64, 50, 138, 94, 18, 55, 204, 232, 225, 215, 53, 153, 168, 150, 52, 216, 236, 196, 49, 143, 237, 134, 113, 211, 249, 146, 39, 159, 172, 134, 113, 247, 240, 65, 36, 148, 181, 72, 124, 222, 177, 75, 36, 148, 176, 26, 40, 194, 240, 94, 45, 149, 241, 28, 109, 201, 229, 21, 99, 68, 59, 221, 30, 160, 0, 32, 195, 191, 171, 109, 155, 226, 168, 56, 92, 164, 170, 111, 140, 229, 73, 125, 184, 169, 31, 57, 173, 244, 17, 124, 232, 164, 16, 61, 189, 228, 203, 97, 184, 70, 17, 63, 219, 27, 222, 108, 189, 92, 60, 48, 233, 1, 216, 125, 172, 128, 128, 11, 75, 250, 222, 155, 17, 160, 152, 15, 87, 231, 153, 206, 18, 176, 152, 15, 71, 180, 203, 222, 1, 177, 144, 13, 71, 240, 126, 196, 239, 220, 54, 68, 234, 60, 161, 7, 228, 104, 225, 64, 255, 50, 170, 19, 184, 53, 236, 64, 230, 55, 154, 172, 38, 185, 93, 247, 115, 254, 129, 176, 156, 41, 71, 132, 87, 27, 244, 136, 62, 91, 182, 200, 119, 29, 162, 149, 54, 26, 177, 196, 109, 14, 235, 143, 62, 73, 226, 209, 120, 29, 231, 59, 198, 160, 27, 38, 174, 104, 240, 91, 249, 62, 160, 84, 184, 122, 242, 81, 239, 123, 176, 17, 179, 111, 122, 255, 252, 219, 153, 186, 245, 131, 83, 190, 231, 210, 143, 170, 186, 133, 89, 190, 230, 214, 138, 187, 177, 215, 72, 251, 237, 195, 41, 35, 97, 84, 209, 105, 102, 135, 4, 60, 111, 93, 218, 44, 47, 148, 19, 35, 116, 86, 217, 55, 102, 146, 17, 62, 99, 82, 217, 117, 102, 131, 15, 35, 101, 86, 206, 127, 47, 157, 26, 6, 175, 42, 103, 234, 107, 234, 167, 35, 251, 42, 109, 167, 104, 234, 163, 53, 175, 126, 118, 254, 107, 247, 172, 32, 251, 41, 107, 243, 115, 241, 183, 51, 251, 42, 103, 255, 111, 185, 177, 112, 140, 222, 236, 63, 89, 202, 177, 104, 142, 195, 235, 54, 30, 152, 160, 96, 139, 207, 246, 37, 211, 27, 208, 160, 41, 197, 64, 122, 226, 17, 211, 160, 40, 204, 64, 122, 243, 3, 210, 189, 34, 198, 64, 111, 245, 13, 205, 233, 55, 205, 16, 124, 247, 87, 156, 193, 168, 52, 89, 200, 240, 126, 221, 219, 176, 48, 79, 156, 164, 101, 132, 216, 173, 63, 90, 171, 246, 119, 157, 94, 247, 54, 215, 139, 254, 108, 137, 27, 165, 39, 223, 142, 242, 113, 154, 94, 179, 92, 108, 95, 183, 38, 50, 207, 238, 105, 96, 92, 187, 44, 24, 19, 78, 231, 123, 214, 71, 191, 49, 82, 87, 234, 107, 193, 2, 235, 42, 11, 87, 226, 112, 213, 52, 128, 166, 240, 105, 3, 243, 183, 47, 129, 164, 85, 133, 115, 225, 136, 134, 38, 166, 78, 132, 113, 33, 237, 88, 235, 108, 182, 193, 242, 47, 247, 77, 251, 106, 182, 139, 49, 37, 24, 216, 118, 69, 192, 154, 43, 63, 30, 206, 172, 223, 55, 180, 245, 154, 57, 254, 176, 198, 54, 169, 162, 135, 109, 250, 176, 192, 48, 181, 229, 212, 109, 226, 178, 221, 55, 188, 10, 200, 52, 33, 223, 189, 120, 98, 19, 199, 38, 199, 150, 208, 15, 189, 207, 21, 1, 247, 138, 201, 14, 160, 152, 11, 64, 231, 139, 210, 15, 181, 152, 15, 88, 226, 145, 213, 6, 133, 5, 193, 102, 243, 216, 207, 49, 175, 12, 198, 107, 241, 156, 156, 49, 183, 8, 218, 118, 132, 201, 226, 93, 231, 140, 235, 5, 173, 136, 248, 72, 236, 139, 235, 5, 187, 216, 226, 95, 229, 200, 184, 5, 163, 220, 254, 66, 218, 239, 66, 117, 4, 186, 159, 15, 218, 217, 66, 64, 9, 191, 133, 67, 230, 200, 185, 13, 151, 133, 234, 76, 237, 219, 137, 17, 162, 136, 239, 86, 163, 218, 187, 12, 175, 153, 254, 131, 53, 252, 246, 122, 254, 125, 32, 185, 123, 249, 241, 98, 254, 47, 57, 191, 53, 248, 180, 98, 226, 45, 61, 184, 60, 189, 231, 98, 250, 41, 33, 165, 86, 157, 13, 18, 152, 108, 192, 193, 89, 150, 30, 34, 132, 89, 205, 196, 67, 216, 11, 20, 131, 72, 214, 223, 67, 157, 89, 24, 158, 78, 216, 221, 89, 156, 85, 193, 203, 244, 128, 89, 183, 161, 251, 116, 247, 236, 63, 149, 46, 38, 249, 1, 244, 252, 63, 147, 51, 104, 252, 84, 243, 252, 49, 143, 103, 41, 238, 81, 226, 233, 44, 128, 41, 43, 251, 214, 131, 109, 76, 145, 26, 46, 139, 209, 131, 99, 80, 209, 138, 109, 49, 132, 6, 58, 119, 213, 159, 119, 44, 12, 109, 109, 55, 128, 47, 54, 115, 30, 108, 97, 50, 245, 113, 157, 63, 16, 110, 65, 43, 211, 225, 162, 80, 8, 237, 252, 152, 75, 229, 188, 156, 159, 80, 132, 233, 30, 17, 78, 188, 151, 75, 144, 187, 134, 112, 137, 220, 18, 37, 66, 152, 155, 127, 156, 217, 113, 66, 99, 8, 233, 2, 53, 121, 28, 3, 116, 51, 201, 10, 46, 109, 150, 35, 77, 108, 241, 55, 152, 39, 181, 62, 66, 121, 149, 18, 163, 70, 246, 87, 170, 30, 188, 83, 163, 68, 250, 71, 227, 11, 191, 26, 176, 79, 179, 67, 229, 26, 166, 3, 119, 66, 87, 135, 28, 35, 46, 225, 93, 121, 86, 171, 18, 41, 63, 224]);
  const pack = self.tranquill_PACK = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  pack.data.push(a);
  const shard = pack.data.length - 1;
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 0,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 6,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 11,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 15,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 19,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 24,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 30,
    len: 3,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 33,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 37,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 42,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 47,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 53,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 58,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 63,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 69,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 78,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 84,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 90,
    len: 20,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 110,
    len: 3,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 113,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 120,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 120,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 120,
    len: 37,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 157,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 168,
    len: 23,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 191,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 196,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 202,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 234,
    len: 35,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 269,
    len: 33,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 302,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 311,
    len: 32,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 343,
    len: 34,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 377,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 377,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 402,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 434,
    len: 33,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 467,
    len: 27,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 494,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 503,
    len: 14,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 517,
    len: 34,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 551,
    len: 35,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 586,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 586,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 618,
    len: 39,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 657,
    len: 40,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 697,
    len: 29,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 726,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 754,
    len: 29,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 783,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 793,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 805,
    len: 13,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 818,
    len: 13,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 831,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 847,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 858,
    len: 31,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 889,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 894,
    len: 41,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 935,
    len: 18,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 953,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 958,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 958,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 979,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 998,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1003,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1003,
    len: 28,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1031,
    len: 24,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 1055,
    len: 26,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1081,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1086,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 1091,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1102,
    len: 18,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 1120,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1139,
    len: 29,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1168,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1173,
    len: 19,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1192,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1202,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1206,
    len: 27,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 1233,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1237,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1256,
    len: 28,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1284,
    len: 41,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1325,
    len: 0,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1325,
    len: 38,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 1363,
    len: 23,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 1386,
    len: 33,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1419,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1441,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1463,
    len: 13,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1476,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1498,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1509,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1520,
    len: 15,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1535,
    len: 11,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1546,
    len: 29,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1575,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1586,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1614,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1634,
    len: 28,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1662,
    len: 15,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1677,
    len: 24,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1701,
    len: 33,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1734,
    len: 34,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 1768,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1773,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1777,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 1809,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1821,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1833,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1845,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1849,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1854,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1864,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1876,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1888,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1893,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1905,
    len: 12,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1917,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 1943,
    len: 16,
    kind: 1
  });
})();
let loggingPort = null;
const ALLOWED_LOG_LEVELS = new Set([tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")]);
const normalizePopupLogLevel = value => {
  if (typeof value !== tranquill_S("0x6c62272e07bb0142")) return null;
  const lowered = value.toLowerCase();
  if (lowered === tranquill_S("0x6c62272e07bb0142")) return tranquill_S("0x6c62272e07bb0142");
  if (lowered === tranquill_S("0x6c62272e07bb0142")) return tranquill_S("0x6c62272e07bb0142");
  return ALLOWED_LOG_LEVELS.has(lowered) ? lowered : null;
};
const materializeLogArg = payload => {
  if (!payload || typeof payload !== tranquill_S("0x6c62272e07bb0142")) return payload;
  switch (payload.kind) {
    case tranquill_S("0x6c62272e07bb0142"):
      {
        const err = new Error(payload["message"]);
        err.name = payload.name || tranquill_S("0x6c62272e07bb0142");
        if (payload.stack) err.stack = payload.stack;
        return err;
      }
    case tranquill_S("0x6c62272e07bb0142"):
    case tranquill_S("0x6c62272e07bb0142"):
      return payload["value"];
    case tranquill_S("0x6c62272e07bb0142"):
      return payload.value;
    default:
      return payload.value;
  }
};
const createTextSignature = text => {
  if (typeof text !== tranquill_S("0x6c62272e07bb0142")) return null;
  let hash = 0;
  for (let i = 0; i < text.length; i++) {
    hash = Math["imul"](31, hash) + text.charCodeAt(i);
    hash |= 0;
  }
  return `${text["length"]}:${(hash >>> 0)["toString"](16)}`;
};
function initializeLoggingBridge() {
  if (loggingPort) return;
  try {
    const port = chrome.runtime.connect({
      name: tranquill_S("0x6c62272e07bb0142")
    });
    let _tranquill_cond = Array.isArray(payload?.args);
    if (_tranquill_cond) {
      payload.args.map(materializeLogArg);
    } else {
      [];
    }
    let _tranquill_cond2 = payload?.meta?.timestamp;
    if (_tranquill_cond2) {
      new Date(payload.meta.timestamp).toISOString();
    } else {
      tranquill_S("0x6c62272e07bb0142");
    }
    let _tranquill_cond3 = stamp;
    if (_tranquill_cond3) {
      ` ${stamp}`;
    } else {
      tranquill_S("0x6c62272e07bb0142");
    }
    port.onMessage.addListener(payload => {
      const level = payload?.level || tranquill_S("0x6c62272e07bb0142");
      const args = _tranquill_cond;
      const source = payload?.meta?.source ? payload["meta"].source : tranquill_S("0x6c62272e07bb0142");
      const stamp = _tranquill_cond2;
      const prefix = `[${source}]${_tranquill_cond3}`;
      const method = console[level] || console.log;
      method.call(console, prefix, ...args);
    });
    port.onDisconnect.addListener(() => {
      loggingPort = null;
    });
    loggingPort = port;
    window.tranquillSetLogLevel = level => {
      if (!loggingPort) return;
      const normalized = normalizePopupLogLevel(level);
      if (!normalized) {
        log.warn(tranquill_S("0x6c62272e07bb0142"), level);
        return;
      }
      try {
        loggingPort.postMessage({
          type: tranquill_S("0x6c62272e07bb0142"),
          level: normalized
        });
      } catch (error) {
        log.warn(tranquill_S("0x6c62272e07bb0142"), error);
      }
    };
    window["tranquillSetDebugLogging"] = enabled => {
      const targetLevel = enabled ? tranquill_S("0x6c62272e07bb0142") : tranquill_S("0x6c62272e07bb0142");
      window.tranquillSetLogLevel(targetLevel);
    };
    log.info(tranquill_S("0x6c62272e07bb0142"));
  } catch (error) {
    log.error(tranquill_S("0x6c62272e07bb0142"), error);
  }
}
initializeLoggingBridge();
class PopupStorage {
  static getSavedText() {
    log["debug"](tranquill_S("0x6c62272e07bb0142"));
    return new Promise((resolve, reject) => {
      chrome.storage.local.get(tranquill_S("0x6c62272e07bb0142"), result => {
        if (chrome["runtime"].lastError) {
          const err = new Error(chrome.runtime.lastError.message);
          log.error(tranquill_S("0x6c62272e07bb0142"), err);
          reject(err);
          return;
        }
        log["debug"](tranquill_S("0x6c62272e07bb0142"), {
          length: result.savedText?.length ?? 0
        });
        resolve(result.savedText || tranquill_S("0x6c62272e07bb0142"));
      });
    });
  }
  static setSavedText(text) {
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      length: text?.length ?? 0
    });
    return new Promise((resolve, reject) => {
      chrome["storage"].local["set"]({
        savedText: text
      }, () => {
        if (chrome["runtime"].lastError) {
          const err = new Error(chrome.runtime.lastError["message"]);
          log.error(tranquill_S("0x6c62272e07bb0142"), err);
          reject(err);
          return;
        }
        log.debug(tranquill_S("0x6c62272e07bb0142"));
        resolve();
      });
    });
  }
  static clearSavedText() {
    log.debug(tranquill_S("0x6c62272e07bb0142"));
    return new Promise((resolve, reject) => {
      chrome["storage"].local.remove([tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")], () => {
        if (chrome.runtime.lastError) {
          const err = new Error(chrome.runtime["lastError"]["message"]);
          log["error"](tranquill_S("0x6c62272e07bb0142"), err);
          reject(err);
          return;
        }
        log.debug(tranquill_S("0x6c62272e07bb0142"));
        resolve();
      });
    });
  }
  static resetTypingProgress(text) {
    const signature = createTextSignature(String(text || tranquill_S("0x6c62272e07bb0142")));
    log["debug"](tranquill_S("0x6c62272e07bb0142"), {
      signature
    });
    return new Promise((resolve, reject) => {
      chrome.storage.local.set({
        typingProgress: 0,
        typingProgressSignature: signature
      }, () => {
        if (chrome.runtime.lastError) {
          const err = new Error(chrome.runtime.lastError.message);
          log.error(tranquill_S("0x6c62272e07bb0142"), err);
          reject(err);
          return;
        }
        log.debug(tranquill_S("0x6c62272e07bb0142"), {
          signature
        });
        resolve();
      });
    });
  }
}
class PopupUIController {
  constructor(documentRef) {
    this.documentRef = documentRef;
    this.textInput = null;
    this.saveButton = null;
    this["resetButton"] = null;
    this.startButton = null;
    this.settingsButton = null;
    this.guideButton = null;
    this.isProcessing = false;
    this.isTyping = false;
    log.debug(tranquill_S("0x6c62272e07bb0142"));
  }
  async init() {
    log.debug(tranquill_S("0x6c62272e07bb0142"));
    this.cacheElements();
    this.registerListeners();
    await this.restoreSavedText();
    await this.syncTypingStatus();
    this.updateStartButtonAppearance();
    log.info(tranquill_S("0x6c62272e07bb0142"));
  }
  cacheElements() {
    this.textInput = this.documentRef.getElementById(tranquill_S("0x6c62272e07bb0142"));
    this.saveButton = this["documentRef"].querySelector(tranquill_S("0x6c62272e07bb0142"));
    this.resetButton = this["documentRef"].querySelector(tranquill_S("0x6c62272e07bb0142"));
    this["startButton"] = this.documentRef.querySelector(tranquill_S("0x6c62272e07bb0142"));
    this.settingsButton = this.documentRef.querySelector(tranquill_S("0x6c62272e07bb0142"));
    this["guideButton"] = this.documentRef.querySelector(tranquill_S("0x6c62272e07bb0142"));
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      hasTextInput: Boolean(this.textInput),
      hasStartButton: Boolean(this.startButton)
    });
  }
  registerListeners() {
    if (this["guideButton"]) {
      this.guideButton.addEventListener(tranquill_S("0x6c62272e07bb0142"), event => {
        event.preventDefault();
        chrome.tabs.create({
          url: tranquill_S("0x6c62272e07bb0142")
        });
        log.info(tranquill_S("0x6c62272e07bb0142"));
      });
    }
    if (this["saveButton"]) {
      this.saveButton.addEventListener(tranquill_S("0x6c62272e07bb0142"), async () => {
        try {
          const textToSave = this.textInput?.value || tranquill_S("0x6c62272e07bb0142");
          await PopupStorage.setSavedText(textToSave);
          await PopupStorage["resetTypingProgress"](textToSave);
          log["info"](tranquill_S("0x6c62272e07bb0142"), {
            length: this.textInput?.value?.length ?? 0,
            progressReset: true
          });
        } catch (error) {
          log.error(tranquill_S("0x6c62272e07bb0142"), error);
        }
      });
    }
    if (this.resetButton) {
      this.resetButton.addEventListener(tranquill_S("0x6c62272e07bb0142"), async () => {
        if (this.textInput) {
          this.textInput.value = tranquill_S("0x6c62272e07bb0142");
          log.info(tranquill_S("0x6c62272e07bb0142"));
          await this.handlePause();
        }
        try {
          await PopupStorage["clearSavedText"]();
          log.info(tranquill_S("0x6c62272e07bb0142"));
        } catch (error) {
          log["error"](tranquill_S("0x6c62272e07bb0142"), error);
        }
      });
    }
    if (this.startButton) {
      this.startButton["addEventListener"](tranquill_S("0x6c62272e07bb0142"), () => this.handleToggleTyping());
    }
    if (this.textInput) {
      this["textInput"]["addEventListener"](tranquill_S("0x6c62272e07bb0142"), () => {
        this.textInput.classList.remove(tranquill_S("0x6c62272e07bb0142"));
        log.debug(tranquill_S("0x6c62272e07bb0142"), {
          length: this.textInput.value.length
        });
      });
    }
    chrome.runtime.onMessage["addListener"](message => {
      if (message && message.action === tranquill_S("0x6c62272e07bb0142")) {
        this.isTyping = Boolean(message.isTyping);
        this.isProcessing = false;
        this.setStartButtonLoading(false);
        this.updateStartButtonAppearance();
        log.info(tranquill_S("0x6c62272e07bb0142"), {
          isTyping: this.isTyping
        });
      }
    });
    if (this.settingsButton) {
      this.settingsButton.addEventListener(tranquill_S("0x6c62272e07bb0142"), () => {
        const settingsUrl = new URL(chrome.runtime.getURL(tranquill_S("0x6c62272e07bb0142")));
        settingsUrl.searchParams.set(tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"));
        window.location.href = settingsUrl.toString();
        log.info(tranquill_S("0x6c62272e07bb0142"), {
          transition: tranquill_S("0x6c62272e07bb0142")
        });
      });
    }
  }
  async restoreSavedText() {
    try {
      const savedText = await PopupStorage.getSavedText();
      if (this.textInput) {
        this.textInput.value = savedText;
        log.debug(tranquill_S("0x6c62272e07bb0142"), {
          length: savedText["length"]
        });
      }
    } catch (error) {
      log.error(tranquill_S("0x6c62272e07bb0142"), error);
    }
  }
  async handleToggleTyping() {
    if (this.isProcessing) {
      log.debug(tranquill_S("0x6c62272e07bb0142"));
      return;
    }
    if (this.isTyping) {
      await this["handlePause"]();
      return;
    }
    await this.handleStart();
  }
  async handleStart() {
    const textToType = this.textInput ? this.textInput.value : tranquill_S("0x6c62272e07bb0142");
    if (!textToType || textToType.trim()["length"] === 0) {
      this["indicateValidationError"]();
      log.warn(tranquill_S("0x6c62272e07bb0142"));
      return;
    }
    this["isProcessing"] = true;
    this.setStartButtonLoading(true);
    log.info(tranquill_S("0x6c62272e07bb0142"), {
      length: textToType.length
    });
    try {
      const previouslySavedText = await PopupStorage.getSavedText();
      await PopupStorage.setSavedText(textToType);
      const shouldResetProgress = previouslySavedText !== textToType;
      await this.sendStartTypingRequest(textToType, shouldResetProgress, previouslySavedText);
      this.isTyping = true;
      this["updateStartButtonAppearance"]();
      log["info"](tranquill_S("0x6c62272e07bb0142"));
    } catch (error) {
      log.error(tranquill_S("0x6c62272e07bb0142"), error);
      this.isTyping = false;
      this.updateStartButtonAppearance();
    } finally {
      this.isProcessing = false;
      this.setStartButtonLoading(false);
    }
  }
  async handlePause() {
    this.isProcessing = true;
    this.setStartButtonLoading(true);
    log.info(tranquill_S("0x6c62272e07bb0142"));
    try {
      await this.sendPauseTypingRequest();
      this.isTyping = false;
      this.updateStartButtonAppearance();
      log["info"](tranquill_S("0x6c62272e07bb0142"));
    } catch (error) {
      log["error"](tranquill_S("0x6c62272e07bb0142"), error);
    } finally {
      this.isProcessing = false;
      this.setStartButtonLoading(false);
    }
  }
  indicateValidationError() {
    if (!this.textInput) {
      return;
    }
    this.textInput.classList.add(tranquill_S("0x6c62272e07bb0142"));
    setTimeout(() => this.textInput.classList.remove(tranquill_S("0x6c62272e07bb0142")), 600);
    this.textInput.focus();
  }
  setStartButtonLoading(isLoading) {
    if (!this["startButton"]) {
      return;
    }
    this["startButton"].disabled = isLoading;
    this["startButton"].classList.toggle(tranquill_S("0x6c62272e07bb0142"), isLoading);
  }
  async sendStartTypingRequest(text, resetProgress = false, previousText = null) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({
        action: tranquill_S("0x6c62272e07bb0142"),
        text,
        resetProgress,
        previousText
      }, response => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome["runtime"].lastError.message));
          return;
        }
        if (!response || response["success"] !== true) {
          const errorMessage = response && response.error ? response.error : tranquill_S("0x6c62272e07bb0142");
          reject(new Error(errorMessage));
          return;
        }
        resolve();
      });
    });
  }
  async sendPauseTypingRequest() {
    return new Promise((resolve, reject) => {
      chrome["runtime"].sendMessage({
        action: tranquill_S("0x6c62272e07bb0142")
      }, response => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome["runtime"].lastError.message));
          return;
        }
        if (!response || response.success !== true) {
          const errorMessage = response && response.error ? response.error : tranquill_S("0x6c62272e07bb0142");
          reject(new Error(errorMessage));
          return;
        }
        resolve();
      });
    });
  }
  async syncTypingStatus() {
    try {
      const status = await this["fetchTypingStatus"]();
      this["isTyping"] = Boolean(status);
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        isTyping: this.isTyping
      });
    } catch (error) {
      log.warn(tranquill_S("0x6c62272e07bb0142"), error);
      this.isTyping = false;
    }
  }
  async fetchTypingStatus() {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({
        action: tranquill_S("0x6c62272e07bb0142")
      }, response => {
        if (chrome.runtime.lastError) {
          const err = new Error(chrome.runtime.lastError.message);
          log.error(tranquill_S("0x6c62272e07bb0142"), err);
          reject(err);
          return;
        }
        if (!response || response["success"] !== true) {
          const errorMessage = response && response.error ? response.error : tranquill_S("0x6c62272e07bb0142");
          const err = new Error(errorMessage);
          log.error(tranquill_S("0x6c62272e07bb0142"), err);
          reject(err);
          return;
        }
        resolve(Boolean(response.isTyping));
      });
    });
  }
  updateStartButtonAppearance() {
    if (!this.startButton) {
      return;
    }
    const isTyping = Boolean(this.isTyping);
    const icon = isTyping ? tranquill_S("0x6c62272e07bb0142") : tranquill_S("0x6c62272e07bb0142");
    log["debug"](tranquill_S("0x6c62272e07bb0142"), {
      isTyping
    });
    this.startButton["classList"]["toggle"](tranquill_S("0x6c62272e07bb0142"), !isTyping);
    this["startButton"].classList.toggle(tranquill_S("0x6c62272e07bb0142"), isTyping);
    this["startButton"].innerHTML = `<i class="fa fa-${icon}"></i>`;
    this["startButton"].setAttribute(tranquill_S("0x6c62272e07bb0142"), isTyping ? tranquill_S("0x6c62272e07bb0142") : tranquill_S("0x6c62272e07bb0142"));
    this.startButton.setAttribute(tranquill_S("0x6c62272e07bb0142"), isTyping ? tranquill_S("0x6c62272e07bb0142") : tranquill_S("0x6c62272e07bb0142"));
    this.startButton.setAttribute(tranquill_S("0x6c62272e07bb0142"), isTyping ? tranquill_S("0x6c62272e07bb0142") : tranquill_S("0x6c62272e07bb0142"));
  }
}
function initializePopup() {
  const controller = new PopupUIController(document);
  controller.init()["catch"](error => {
    log.error(tranquill_S("0x6c62272e07bb0142"), error);
  });
}
document["addEventListener"](tranquill_S("0x6c62272e07bb0142"), initializePopup);
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}