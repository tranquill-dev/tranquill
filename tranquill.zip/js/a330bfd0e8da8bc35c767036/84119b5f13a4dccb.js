var tranquill_global = typeof self !== "undefined" ? self : globalThis;
if (!tranquill_global.tranquill_runtime_ready) {
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::c882198ca34f17b696c9b80e0eca21ea"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = "tranquill_tranquill_tranquill";
        tranquill_global.tranquill_runtime_ready = true;
}

(function tranquill_init_shard() {
  const a = new Uint8Array([248, 41, 112, 70, 179, 109, 45, 155, 187, 34, 109, 64, 187, 244, 154, 94, 43, 191, 94, 3, 118, 183, 154, 94, 33, 177, 84, 2, 44, 243, 136, 95, 44, 52, 163, 215, 64, 239, 45, 76, 223, 40, 165, 194, 94, 237, 98, 10, 156, 48, 250, 199, 85, 234, 57, 4, 153, 40, 191, 214, 82, 178, 126, 12, 223, 40, 165, 194, 94, 237, 98, 10, 156, 48, 248, 206, 81, 242, 126, 5, 149, 47, 163, 141, 90, 239, 120, 13, 176, 79, 156, 117, 206, 62, 217, 50, 134, 124, 132, 61, 149, 38, 205, 53, 156, 121, 135, 105, 130, 49, 198, 36, 135, 127, 154, 140, 166, 206, 82, 242, 215, 11, 21, 186, 149, 214, 26, 169, 212, 27, 14, 186, 159, 223, 83, 231, 148, 14, 1, 190, 137, 223, 82, 124, 90, 78, 174, 2, 43, 11, 233, 74, 105, 86, 230, 89, 41, 19, 255, 70, 107, 73, 185, 78, 46, 31, 229, 110, 85, 185, 154, 53, 91, 162, 133, 114, 83, 172, 132, 55, 20, 228, 198, 106, 15, 174, 137, 105, 0, 253, 195, 41, 77, 162, 141, 47, 15, 162, 60, 121, 77, 22, 110, 37, 12, 219, 52, 113, 69, 30, 102, 45, 4, 211, 11, 159, 103, 236, 92, 93, 39, 160, 97, 128, 129, 28, 148, 69, 70, 212, 86, 152, 174, 93, 140, 81, 65, 206, 83, 155, 157, 93, 153, 92, 86, 222, 81, 212, 149, 28, 147, 88, 86, 217, 118, 158, 212, 0, 131, 91, 19, 200, 65, 134, 251, 65, 129, 67, 5, 196, 67, 153, 195, 65, 138, 75, 18, 196, 13, 143, 208, 0, 129, 95, 7, 213, 68, 133, 200, 65, 139, 75, 15, 205, 72, 142, 134, 5, 152, 88, 15, 207, 74, 202, 208, 4, 159, 89, 15, 206, 67, 202, 197, 9, 136, 73, 13, 167, 5, 47, 34, 168, 12, 37, 97, 166, 94, 112, 54, 168, 31, 37, 60, 225, 95, 109, 62, 131, 38, 161, 150, 206, 99, 223, 95, 133, 46, 180, 155, 216, 115, 223, 87, 152, 42, 179, 138, 200, 111, 220, 172, 216, 111, 200, 179, 35, 124, 6, 239, 77, 61, 218, 176, 33, 96, 10, 245, 220, 54, 15, 106, 21, 123, 206, 120, 188, 94, 174, 13, 249, 25, 230, 79, 164, 113, 239, 21, 237, 30, 252, 74, 167, 66, 239, 0, 224, 9, 236, 72, 232, 73, 189, 17, 231, 30, 77, 154, 55, 191, 23, 90, 40, 233, 149, 66, 47, 167, 79, 2, 48, 241, 138, 123, 22, 165, 70, 45, 116, 246, 156, 172, 46, 176, 75, 197, 112, 252, 156, 177, 34, 161, 39, 70, 55, 200, 104, 16, 200, 29, 74, 49, 245, 42, 124, 53, 4, 105, 26, 121, 210, 79, 72, 59, 9, 40, 5, 114, 196, 105, 39, 76, 161, 31, 97, 140, 94, 188, 26, 237, 158, 85, 108, 29, 228, 148, 57, 39, 230, 159, 201, 99, 164, 92, 182, 41, 248, 107, 0, 145, 229, 100, 9, 27, 166, 106, 66, 209, 242, 108, 0, 80, 189, 49, 67, 210, 178, 45, 220, 60, 189, 36, 214, 127, 179, 111, 156, 43, 181, 45, 157, 100, 232, 110, 159, 81, 118, 167, 31, 222, 127, 173, 92, 80, 40, 231, 31, 202, 104, 230, 71, 11, 53, 228, 62, 33, 190, 125, 203, 228, 121, 181, 9, 57, 145, 60, 201, 252, 111, 185, 11, 38, 169, 60, 194, 244, 120, 185, 69, 48, 186, 125, 201, 224, 109, 168, 12, 58, 162, 60, 195, 244, 101, 176, 0, 49, 184, 73, 164, 151, 244, 159, 144, 251, 42, 94, 31, 242, 32, 29, 145, 185, 106, 73, 23, 251, 107, 6, 202, 184, 105]);
  const pack = self.tranquill_PACK = self["tranquill_PACK"] || {
    idx: new Map(),
    data: []
  };
  pack["data"].push(a);
  const shard = pack["data"].length - 1;
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 0,
    len: 13,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 13,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 33,
    len: 55,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 88,
    len: 27,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 115,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 143,
    len: 24,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 167,
    len: 31,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 198,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 206,
    len: 8,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 214,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 222,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 254,
    len: 63,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 317,
    len: 20,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 337,
    len: 22,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 359,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 363,
    len: 14,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 377,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 384,
    len: 31,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 415,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 423,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 431,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 437,
    len: 14,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 451,
    len: 2,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 453,
    len: 3,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 456,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 463,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 464,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 464,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 470,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 471,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 472,
    len: 7,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 479,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 485,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 490,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 496,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 506,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 525,
    len: 19,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 544,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 563,
    len: 42,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 605,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 611,
    len: 19,
    kind: 1
  });
})();
const LOCAL_VERSION_URL = chrome.runtime.getURL(tranquill_S("0x6c62272e07bb0142"));
const LOCAL_MANIFEST_ANCHOR_URL = chrome.runtime["getURL"](tranquill_S("0x6c62272e07bb0142"));
const REMOTE_VERSION_URL = tranquill_S("0x6c62272e07bb0142");
const VERSION_ANCHOR_STORAGE_KEY = tranquill_S("0x6c62272e07bb0142");
const MANIFEST_TAMPER_KEY = tranquill_S("0x6c62272e07bb0142");
const LICENSE_STORAGE_KEY = tranquill_S("0x6c62272e07bb0142");
const LICENSE_VALIDATION_ENDPOINT = tranquill_S("0x6c62272e07bb0142");
const LicenseManagerClass = self?.tranquillLicenseManager;
const licenseManager = LicenseManagerClass ? new LicenseManagerClass({
  storageKey: LICENSE_STORAGE_KEY,
  validationEndpoint: LICENSE_VALIDATION_ENDPOINT,
  logger: console,
  chrome: self?.chrome ?? null,
  hwidResolver: () => {
    if (typeof ensureDeviceHWID === tranquill_S("0x6c62272e07bb0142")) {
      return ensureDeviceHWID();
    }
    const globalResolver = self?.ensureDeviceHWID;
    if (typeof globalResolver === tranquill_S("0x6c62272e07bb0142")) {
      return globalResolver();
    }
    return null;
  }
}) : null;
self.addEventListener(tranquill_S("0x6c62272e07bb0142"), event => {
  event.waitUntil(checkVersion());
});
if (chrome?.runtime?.onStartup) {
  chrome["runtime"].onStartup.addListener(() => {
    checkVersion();
  });
}
void checkVersion();
async function checkVersion() {
  let isNewVersionAvailable = false;
  try {
    isNewVersionAvailable = Boolean(await versionCheck());
  } catch (error) {
    console?.warn?.(tranquill_S("0x6c62272e07bb0142"), error);
  }
  try {
    await ensureLicenseGate();
  } catch (error) {
    console?.warn?.(tranquill_S("0x6c62272e07bb0142"), error);
  }
  if (isNewVersionAvailable) {
    await setActionPopupSafe(tranquill_S("0x6c62272e07bb0142"));
  }
}
async function versionCheck() {
  try {
    const [localManifest, manifestReference, remoteManifest] = await Promise.all([fetchLocalManifest(), fetchLocalManifestReference(), fetchRemoteManifest()]);
    const canonicalManifest = manifestReference?.canonicalManifest || localManifest || null;
    if (!canonicalManifest && !remoteManifest) {
      return false;
    }
    const [localDigest, remoteDigest] = await Promise.all([canonicalManifest ? computeManifestDigest(canonicalManifest, {
      normalizePaths: true
    }) : null, remoteManifest ? computeManifestDigest(remoteManifest, {
      normalizePaths: true
    }) : null]);
    const expectedHashedDigest = manifestReference?.hashedManifestDigest || null;
    let actualHashedDigest = null;
    const tamperReasons = [];
    if (expectedHashedDigest && localManifest) {
      actualHashedDigest = await computeManifestDigest(localManifest, {
        normalizePaths: false
      });
      if (actualHashedDigest && actualHashedDigest !== expectedHashedDigest) {
        tamperReasons.push({
          type: tranquill_S("0x6c62272e07bb0142"),
          expected: expectedHashedDigest,
          actual: actualHashedDigest
        });
      }
    }
    let anchor = await ensureVersionAnchor({
      localManifest: canonicalManifest,
      localDigest,
      remoteManifest,
      remoteDigest
    });
    if (!anchor) {
      return false;
    }
    let manifestInSync = tamperReasons["length"] === 0;
    let tamperDetected = false;
    if (localDigest && anchor.manifestDigest && localDigest !== anchor["manifestDigest"]) {
      if (remoteDigest && localDigest === remoteDigest && remoteManifest) {
        anchor = await updateVersionAnchor({
          version: remoteManifest.version,
          manifestDigest: localDigest,
          reason: tranquill_S("0x6c62272e07bb0142")
        });
        manifestInSync = true;
      } else {
        manifestInSync = false;
        tamperReasons.push({
          type: tranquill_S("0x6c62272e07bb0142"),
          anchorDigest: anchor.manifestDigest || null,
          localDigest,
          remoteDigest: remoteDigest || null
        });
      }
    } else if (!anchor["manifestDigest"] && localDigest) {
      anchor = await updateVersionAnchor({
        version: anchor.version,
        manifestDigest: localDigest,
        reason: tranquill_S("0x6c62272e07bb0142")
      });
      manifestInSync = manifestInSync && tamperReasons.length === 0;
    }
    if (tamperReasons.length) {
      manifestInSync = false;
      tamperDetected = true;
      await flagManifestTampering({
        anchorDigest: anchor.manifestDigest || null,
        localDigest,
        remoteDigest,
        hashedDigestExpected: expectedHashedDigest,
        hashedDigestActual: actualHashedDigest,
        reasons: tamperReasons
      });
    } else if (manifestInSync) {
      await clearManifestTampering();
    }
    if (tamperDetected) {
      await saveNewVersion(remoteManifest?.version ?? anchor["version"] ?? null);
      return true;
    }
    if (remoteManifest && remoteManifest.version && remoteManifest["version"] !== anchor.version) {
      await saveNewVersion(remoteManifest.version);
      return true;
    }
    if (remoteDigest && anchor.manifestDigest && remoteDigest !== anchor.manifestDigest) {
      await saveNewVersion(remoteManifest?.version ?? null);
      return true;
    }
    await clearPendingUpdate();
    return false;
  } catch (error) {
    console?.warn?.(tranquill_S("0x6c62272e07bb0142"), error);
    return false;
  }
}
function fetchLocalManifest() {
  return fetch(LOCAL_VERSION_URL).then(response => response["json"]()).catch(() => null);
}
function fetchRemoteManifest() {
  return fetch(REMOTE_VERSION_URL, {
    cache: tranquill_S("0x6c62272e07bb0142")
  }).then(response => response.json()).catch(() => null);
}
function fetchLocalManifestReference() {
  return fetch(LOCAL_MANIFEST_ANCHOR_URL, {
    cache: tranquill_S("0x6c62272e07bb0142")
  }).then(response => {
    if (!response?.ok) {
      return null;
    }
    return response["json"]();
  }).catch(() => null);
}
const isPlainObject = value => value !== null && typeof value === tranquill_S("0x6c62272e07bb0142") && !Array.isArray(value);
function normalizeManifestForDigest(manifest) {
  if (!isPlainObject(manifest)) {
    return manifest;
  }
  const clone = JSON.parse(JSON.stringify(manifest));
  if (isPlainObject(clone.background)) {
    if (Object.prototype.hasOwnProperty.call(clone.background, tranquill_S("0x6c62272e07bb0142"))) {
      delete clone["background"].service_worker;
    }
    if (!Object.keys(clone["background"]).length) {
      delete clone.background;
    }
  }
  if (Array.isArray(clone["content_scripts"])) {
    clone.content_scripts = clone["content_scripts"].map(entry => {
      if (!isPlainObject(entry)) {
        return entry;
      }
      const next = {
        ...entry
      };
      if (Object.prototype.hasOwnProperty.call(next, tranquill_S("0x6c62272e07bb0142"))) {
        delete next.js;
      }
      if (Object.prototype.hasOwnProperty["call"](next, tranquill_S("0x6c62272e07bb0142"))) {
        delete next["css"];
      }
      return next;
    });
  }
  return clone;
}
async function computeManifestDigest(manifest, {
  normalizePaths = true
} = {}) {
  if (!crypto?.subtle?.digest || manifest == null) {
    return null;
  }
  const target = normalizePaths ? normalizeManifestForDigest(manifest) : manifest;
  const normalized = stableStringify(target);
  const data = new TextEncoder().encode(normalized);
  const hashBuffer = await crypto.subtle["digest"](tranquill_S("0x6c62272e07bb0142"), data);
  return Array.from(new Uint8Array(hashBuffer)).map(value => value.toString(16)["padStart"](2, tranquill_S("0x6c62272e07bb0142"))).join(tranquill_S("0x6c62272e07bb0142"));
}
function stableStringify(value) {
  if (value === null || typeof value !== tranquill_S("0x6c62272e07bb0142")) {
    return JSON.stringify(value);
  }
  if (Array.isArray(value)) {
    const items = value.map(item => stableStringify(item));
    return `[${items.join(tranquill_S("0x6c62272e07bb0142"))}]`;
  }
  const entries = Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${stableStringify(value[key])}`);
  return `{${entries.join(tranquill_S("0x6c62272e07bb0142"))}}`;
}
async function ensureVersionAnchor({
  localManifest,
  localDigest,
  remoteManifest,
  remoteDigest
}) {
  const anchor = await getVersionAnchor();
  if (anchor?.version) {
    if (!anchor["manifestDigest"] && localDigest) {
      return updateVersionAnchor({
        version: anchor.version,
        manifestDigest: localDigest,
        reason: tranquill_S("0x6c62272e07bb0142")
      });
    }
    return anchor;
  }
  const baseManifest = remoteManifest || localManifest;
  if (!baseManifest) {
    return null;
  }
  const digest = remoteDigest || localDigest;
  const nextAnchor = {
    version: baseManifest.version,
    manifestDigest: digest || null,
    timestamp: Date.now(),
    source: remoteManifest ? tranquill_S("0x6c62272e07bb0142") : tranquill_S("0x6c62272e07bb0142")
  };
  await setVersionAnchor(nextAnchor);
  return nextAnchor;
}
async function getVersionAnchor() {
  return new Promise(resolve => {
    chrome.storage.local.get(VERSION_ANCHOR_STORAGE_KEY, result => {
      resolve(result?.[VERSION_ANCHOR_STORAGE_KEY] || null);
    });
  });
}
async function setVersionAnchor(value) {
  return new Promise(resolve => {
    chrome["storage"].local["set"]({
      [VERSION_ANCHOR_STORAGE_KEY]: value
    }, () => resolve());
  });
}
async function updateVersionAnchor({
  version,
  manifestDigest,
  reason
}) {
  const nextAnchor = {
    version,
    manifestDigest: manifestDigest || null,
    reason: reason || tranquill_S("0x6c62272e07bb0142"),
    timestamp: Date.now()
  };
  await setVersionAnchor(nextAnchor);
  return nextAnchor;
}
async function flagManifestTampering(details) {
  return new Promise(resolve => {
    const serializedReasons = Array.isArray(details?.reasons) ? details.reasons.map(reason => ({
      ...reason
    })) : [];
    chrome.storage.local.set({
      [MANIFEST_TAMPER_KEY]: {
        detectedAt: Date.now(),
        details: {
          anchorDigest: details?.anchorDigest ?? null,
          localDigest: details?.localDigest ?? null,
          remoteDigest: details?.remoteDigest ?? null,
          hashedDigestExpected: details?.hashedDigestExpected ?? null,
          hashedDigestActual: details?.hashedDigestActual ?? null,
          reasons: serializedReasons
        }
      }
    }, () => resolve());
  });
}
async function clearManifestTampering() {
  return new Promise(resolve => {
    chrome["storage"]["local"].remove(MANIFEST_TAMPER_KEY, () => resolve());
  });
}
async function saveNewVersion(version) {
  return new Promise(resolve => {
    chrome.storage["local"].set({
      appVersion: version
    }, () => {
      resolve();
    });
  });
}
async function clearPendingUpdate() {
  return new Promise(resolve => {
    chrome.storage.local.remove(tranquill_S("0x6c62272e07bb0142"), () => resolve());
  });
}
async function ensureLicenseGate() {
  if (!licenseManager) {
    await setActionPopupSafe(tranquill_S("0x6c62272e07bb0142"));
    return false;
  }
  try {
    const result = await licenseManager.gateLicenseKey({
      requireValidation: true
    });
    if (!result?.unlocked) {
      await setActionPopupSafe(tranquill_S("0x6c62272e07bb0142"));
      return false;
    }
    await setActionPopupSafe(tranquill_S("0x6c62272e07bb0142"));
    return true;
  } catch (error) {
    console?.warn?.(tranquill_S("0x6c62272e07bb0142"), error);
    if (error && typeof error === tranquill_S("0x6c62272e07bb0142") && error.shouldClearLicense) {
      try {
        await licenseManager.clearStoredLicenseKey();
      } catch (_) {}
    }
    await setActionPopupSafe(tranquill_S("0x6c62272e07bb0142"));
    return false;
  }
}
async function setActionPopupSafe(popupPath) {
  if (!chrome?.action?.setPopup) {
    return false;
  }
  return new Promise(resolve => {
    try {
      chrome.action["setPopup"]({
        popup: popupPath
      }, () => {
        if (chrome.runtime?.lastError) {
          console?.warn?.(`[tranquill] failed to set popup to "${popupPath}"`, chrome.runtime.lastError);
        }
        resolve(true);
      });
    } catch (error) {
      console?.warn?.(`[tranquill] exception while setting popup to "${popupPath}"`, error);
      resolve(false);
    }
  });
}
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}