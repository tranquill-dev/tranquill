var tranquill_global = typeof self !== "undefined" ? self : globalThis;
if (!tranquill_global.tranquill_runtime_ready) {
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::c882198ca34f17b696c9b80e0eca21ea"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = "tranquill_tranquill_tranquill";
        tranquill_global.tranquill_runtime_ready = true;
}

(function tranquill_init_shard() {
  const a = new Uint8Array([200, 86, 98, 74, 191, 215, 157, 45, 73, 160, 209, 223, 124, 216, 98, 129, 235, 89, 113, 84, 154, 136, 51, 156, 204, 224, 142, 58, 35, 145, 95, 120, 107, 199, 79, 63, 233, 210, 49, 201, 73, 74, 86, 90, 94, 90, 94, 90, 182, 186, 70, 176, 168, 187, 216, 217, 37, 65, 80, 84, 83, 81, 27, 49, 224, 139, 57, 193, 248, 139, 90, 177, 131, 251, 193, 133, 212, 63, 141, 245, 78, 159, 78, 165, 151, 239, 211, 153, 200, 35, 145, 233, 84, 147, 66, 169, 155, 227, 221, 237, 188, 87, 101, 29, 162, 231, 54, 221, 111, 23, 39, 225, 176, 91, 105, 17, 160, 251, 42, 193, 115, 11, 51, 249, 184, 5, 111, 7, 72, 201, 227, 206, 33, 94, 249, 2, 215, 55, 174, 87, 56, 121, 237, 23, 102, 196, 172, 220, 15, 19, 249, 45, 77, 209, 165, 203, 103, 213, 253, 160, 22, 24, 191, 248, 77, 173, 206, 168, 189, 93, 132, 233, 251, 144, 182, 43, 111, 177, 66, 191, 102, 78, 143, 93, 162, 171, 89, 190, 93, 234, 164, 34, 145, 166, 95, 26, 40, 124, 25, 105, 124, 48, 198, 61, 79, 33, 248, 190, 122, 155, 185, 240, 68, 95, 231, 181, 10, 146, 208, 140, 75, 1, 196, 169, 2, 134, 199, 236, 28, 4, 228, 188, 104, 112, 0, 124, 19, 169, 194, 91, 85, 253, 0, 103, 7, 180, 195, 37, 99, 114, 198, 103, 48, 243, 140, 224, 103, 171, 127, 132, 53, 252, 237, 220, 182, 95, 232, 167, 229, 124, 179, 227, 224, 95, 115, 180, 184, 44, 151, 230, 239, 197, 135, 36, 94, 162, 240, 222, 245, 43, 151, 58, 185, 107, 215, 11, 200, 119, 27, 220, 144, 4, 127, 14, 199, 30, 111, 133, 44, 233, 102, 80, 9, 178, 24, 183, 21, 12, 195, 43, 229, 198, 48, 204, 142, 100, 15, 149, 233, 0, 67, 85, 169]);
  const pack = self.tranquill_PACK = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  pack.data.push(a);
  const shard = pack.data.length - 1;
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 0,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 5,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 10,
    len: 3,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 13,
    len: 3,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 16,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 25,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 34,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 35,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 40,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 41,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 42,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 43,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 44,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 45,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 46,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 47,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 48,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 49,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 50,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 51,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 52,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 53,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 54,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 55,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 56,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 57,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 58,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 59,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 60,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 61,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 62,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 63,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 69,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 75,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 81,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 87,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 93,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 99,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 105,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 111,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 117,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 123,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 128,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 133,
    len: 11,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 144,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 156,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 165,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 174,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 179,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 184,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 190,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 195,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 204,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 232,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 233,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 234,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 243,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 252,
    len: 10,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 262,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 266,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 271,
    len: 10,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 281,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 286,
    len: 9,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 295,
    len: 10,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 305,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 309,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 314,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 319,
    len: 5,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 324,
    len: 9,
    kind: 1
  });
})();
const KeyEventFactory = (() => {
  const special = Object.freeze({
    "\n": {
      key: tranquill_S("0x6c62272e07bb0142"),
      code: tranquill_S("0x6c62272e07bb0142"),
      windowsVirtualKeyCode: 13,
      nativeVirtualKeyCode: 13
    },
    "\t": {
      key: tranquill_S("0x6c62272e07bb0142"),
      code: tranquill_S("0x6c62272e07bb0142"),
      windowsVirtualKeyCode: 9,
      nativeVirtualKeyCode: 9
    },
    "\b": {
      key: tranquill_S("0x6c62272e07bb0142"),
      code: tranquill_S("0x6c62272e07bb0142"),
      windowsVirtualKeyCode: 8,
      nativeVirtualKeyCode: 8
    },
    " ": {
      key: tranquill_S("0x6c62272e07bb0142"),
      code: tranquill_S("0x6c62272e07bb0142"),
      text: tranquill_S("0x6c62272e07bb0142"),
      unmodifiedText: tranquill_S("0x6c62272e07bb0142"),
      windowsVirtualKeyCode: 32,
      nativeVirtualKeyCode: 32,
      macCharCode: 32
    }
  });
  const shiftMap = Object.freeze({
    "!": tranquill_S("0x6c62272e07bb0142"),
    "@": tranquill_S("0x6c62272e07bb0142"),
    "#": tranquill_S("0x6c62272e07bb0142"),
    $: tranquill_S("0x6c62272e07bb0142"),
    "%": tranquill_S("0x6c62272e07bb0142"),
    "^": tranquill_S("0x6c62272e07bb0142"),
    "&": tranquill_S("0x6c62272e07bb0142"),
    "*": tranquill_S("0x6c62272e07bb0142"),
    "(": tranquill_S("0x6c62272e07bb0142"),
    ")": tranquill_S("0x6c62272e07bb0142"),
    _: tranquill_S("0x6c62272e07bb0142"),
    "+": tranquill_S("0x6c62272e07bb0142"),
    "{": tranquill_S("0x6c62272e07bb0142"),
    "}": tranquill_S("0x6c62272e07bb0142"),
    "|": tranquill_S("0x6c62272e07bb0142"),
    ":": tranquill_S("0x6c62272e07bb0142"),
    '"': tranquill_S("0x6c62272e07bb0142"),
    "<": tranquill_S("0x6c62272e07bb0142"),
    ">": tranquill_S("0x6c62272e07bb0142"),
    "?": tranquill_S("0x6c62272e07bb0142"),
    "~": tranquill_S("0x6c62272e07bb0142")
  });
  const codeMap = Object.freeze({
    1: tranquill_S("0x6c62272e07bb0142"),
    2: tranquill_S("0x6c62272e07bb0142"),
    3: tranquill_S("0x6c62272e07bb0142"),
    4: tranquill_S("0x6c62272e07bb0142"),
    5: tranquill_S("0x6c62272e07bb0142"),
    6: tranquill_S("0x6c62272e07bb0142"),
    7: tranquill_S("0x6c62272e07bb0142"),
    8: tranquill_S("0x6c62272e07bb0142"),
    9: tranquill_S("0x6c62272e07bb0142"),
    0: tranquill_S("0x6c62272e07bb0142"),
    "-": tranquill_S("0x6c62272e07bb0142"),
    "=": tranquill_S("0x6c62272e07bb0142"),
    "[": tranquill_S("0x6c62272e07bb0142"),
    "]": tranquill_S("0x6c62272e07bb0142"),
    "\\": tranquill_S("0x6c62272e07bb0142"),
    ";": tranquill_S("0x6c62272e07bb0142"),
    "'": tranquill_S("0x6c62272e07bb0142"),
    ",": tranquill_S("0x6c62272e07bb0142"),
    ".": tranquill_S("0x6c62272e07bb0142"),
    "/": tranquill_S("0x6c62272e07bb0142"),
    "`": tranquill_S("0x6c62272e07bb0142")
  });
  function requiresShift(ch) {
    return !!(ch && tranquill_S("0x6c62272e07bb0142").test(ch));
  }
  function unshifted(ch) {
    if (shiftMap[ch]) return shiftMap[ch];
    if (ch.length === 1 && ch >= tranquill_S("0x6c62272e07bb0142") && ch <= tranquill_S("0x6c62272e07bb0142")) return ch.toLowerCase();
    return ch;
  }
  function keyCode(base) {
    if (!base) return 0;
    const specials = {
      "-": 189,
      "=": 187,
      "[": 219,
      "]": 221,
      "\\": 220,
      ";": 186,
      "'": 222,
      ",": 188,
      ".": 190,
      "/": 191,
      "`": 192
    };
    if (specials[base]) return specials[base];
    if (tranquill_S("0x6c62272e07bb0142").test(base)) return base.charCodeAt(0);
    return base.toUpperCase().charCodeAt(0);
  }
  function code(base) {
    if (!base) return undefined;
    if (codeMap[base]) return codeMap[base];
    if (tranquill_S("0x6c62272e07bb0142").test(base)) return `Key${base.toUpperCase()}`;
    return undefined;
  }
  function create(type, props) {
    return {
      type,
      ...props
    };
  }
  function getSpecial(ch) {
    return special[ch] || null;
  }
  function build(ch) {
    const evts = [];
    const s = getSpecial(ch);
    if (s) {
      const base = {
        key: s.key,
        code: s.code,
        windowsVirtualKeyCode: s.windowsVirtualKeyCode,
        nativeVirtualKeyCode: s.nativeVirtualKeyCode
      };
      evts.push(create(tranquill_S("0x6c62272e07bb0142"), base));
      if (s.text) evts.push(create(tranquill_S("0x6c62272e07bb0142"), {
        ...base,
        key: s.key,
        text: s["text"],
        unmodifiedText: s.text
      }));
      evts.push(create(tranquill_S("0x6c62272e07bb0142"), base));
      return evts;
    }
    const needShift = requiresShift(ch);
    const baseCh = needShift ? unshifted(ch) : ch;
    const kCode = keyCode(baseCh);
    const kCodeStr = code(baseCh);
    if (needShift) evts.push(create(tranquill_S("0x6c62272e07bb0142"), {
      key: tranquill_S("0x6c62272e07bb0142"),
      code: tranquill_S("0x6c62272e07bb0142"),
      windowsVirtualKeyCode: 16,
      nativeVirtualKeyCode: 16
    }));
    const keyDesc = {
      key: ch,
      code: kCodeStr,
      windowsVirtualKeyCode: kCode,
      nativeVirtualKeyCode: kCode
    };
    evts.push(create(tranquill_S("0x6c62272e07bb0142"), keyDesc));
    evts.push(create(tranquill_S("0x6c62272e07bb0142"), {
      ...keyDesc,
      text: ch,
      unmodifiedText: baseCh
    }));
    evts.push(create(tranquill_S("0x6c62272e07bb0142"), keyDesc));
    if (needShift) evts.push(create(tranquill_S("0x6c62272e07bb0142"), {
      key: tranquill_S("0x6c62272e07bb0142"),
      code: tranquill_S("0x6c62272e07bb0142"),
      windowsVirtualKeyCode: 16,
      nativeVirtualKeyCode: 16
    }));
    return evts;
  }
  return {
    build
  };
})();
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}