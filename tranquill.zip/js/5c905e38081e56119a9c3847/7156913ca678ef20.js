var tranquill_global = typeof self !== "undefined" ? self : globalThis;
if (!tranquill_global.tranquill_runtime_ready) {
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::c882198ca34f17b696c9b80e0eca21ea"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = "tranquill_tranquill_tranquill";
        tranquill_global.tranquill_runtime_ready = true;
}

(function tranquill_init_shard() {
  const a = new Uint8Array([226, 227, 248, 234, 237, 224, 244, 252, 231, 242, 227, 238, 251, 253, 238, 254, 199, 193, 231, 215, 214, 194, 209, 192, 235, 238, 240, 238, 254, 248, 239, 229, 25, 16, 25, 23, 12, 3, 25, 26, 11, 31, 13, 3, 2, 6, 30, 5, 234, 236, 18, 234, 236, 233, 239, 233, 18, 21, 7, 22, 23, 21, 25, 20, 187, 191, 166, 187, 185, 166, 188, 184, 190, 171, 162, 172, 171, 186, 170, 187, 132, 134, 167, 154, 151, 128, 132, 157, 160, 178, 189, 177, 190, 184, 188, 190, 192, 211, 220, 213, 207, 197, 215, 215, 221, 205, 207, 221, 204, 221, 211, 160, 131, 59, 92, 228, 199, 127, 16, 168, 139, 51, 84, 236, 207, 119, 8, 176, 147, 43, 76, 244, 215, 111, 0, 184, 155, 62, 36, 201, 155, 43, 226, 199, 31, 104, 19, 112, 215, 53, 192, 110, 149, 246, 209, 51, 70, 120, 30, 228, 221, 70, 200, 111, 132, 45, 159, 123, 144, 120, 213, 32, 134, 33, 131, 106, 212, 40, 193, 32, 130, 104, 147, 118, 192, 97, 201, 40, 154, 180, 160, 226, 107, 61, 122, 60, 251, 231, 177, 232, 104, 61, 123, 53, 251, 253, 167, 187, 122, 56, 102, 62, 186, 240, 173, 187, 105, 33, 122, 53, 178, 250, 179, 21, 61, 252, 0, 82, 96, 179, 213, 70, 61, 228, 2, 79, 103, 186, 146, 21, 44, 238, 1, 79, 102, 179, 50, 70, 223, 192, 99, 74, 10, 147, 62, 77, 200, 196, 98, 25, 90, 135, 48, 67, 214, 240, 144, 14, 61, 165, 90, 73, 40, 243, 155, 4, 60, 183, 93, 65, 109, 182, 158, 31, 45, 183, 214, 191, 10, 60, 131, 176, 76, 109, 217, 164, 8, 43, 156, 245, 9, 104, 194, 181, 8, 105, 150, 241, 64, 101, 213, 180, 3, 56, 13, 57, 199, 127, 193, 22, 248, 26, 59, 186, 221, 112, 128, 254, 26, 60, 163, 245, 239, 134, 175, 27, 138, 102, 246, 205, 204, 117, 175, 12, 151, 114, 237, 219, 203, 38, 255, 86, 139, 97, 254, 204, 204, 124, 255, 24, 153, 124, 243, 207, 152, 162, 81, 21, 198, 178, 11, 222, 146, 161, 81, 20, 207, 178, 21, 218, 147, 185, 93, 31, 129, 243, 27, 207, 136, 164, 93, 126, 153, 180, 196, 58, 94, 248, 83, 46, 93, 179, 23, 105, 17, 189, 66, 37, 72, 180, 21, 103, 8, 244, 76, 40, 28, 187, 2, 111, 16, 248, 71, 130, 177, 248, 252, 102, 118, 52, 114, 159, 182, 253, 247, 50, 122, 54, 39, 190, 189, 185, 252, 125, 109, 121, 48, 183, 249, 248, 241, 102, 112, 47, 51, 166, 188, 253, 36, 148, 204, 235, 96, 83, 128, 229, 57, 147, 201, 224, 52, 78, 136, 164, 48, 133, 25, 237, 150, 18, 67, 179, 134, 215, 2, 251, 150, 91, 72, 166, 212, 212, 31, 53, 151, 252, 206, 114, 202, 179, 155, 102, 130, 232, 200, 105, 131, 169, 133, 54, 138, 243, 219, 38, 207, 178, 147, 54, 209, 223, 88, 34, 136, 9, 30, 49, 137, 219, 95, 37, 142, 83, 74, 119, 192, 211, 70, 211, 122, 29, 39, 210, 59, 80, 120, 219, 97, 14, 104, 158, 32, 70, 120, 146, 108, 6, 37, 130, 35, 76, 124, 215, 27, 189, 215, 14, 236, 169, 221, 6, 190, 245, 28, 75, 115, 243, 212, 14, 61, 169, 138, 158, 96, 254, 221, 17, 116, 174, 131, 212, 113, 228, 217, 27, 48, 232, 155, 117, 8, 98, 209, 53, 92, 42, 147, 123, 70, 119, 196, 44, 79, 45, 154, 60, 21, 102, 206, 47, 79, 44, 147, 216, 51, 30, 106, 28, 116, 210, 191, 76, 217, 117, 251, 11, 21, 123, 171, 65, 217, 120, 251, 13, 14, 58, 187, 65, 152, 125, 238, 13, 20, 131, 100, 156, 221, 64, 38, 91, 26, 199, 101, 155, 220, 70, 34, 86, 72, 136, 111, 222, 206, 78, 47, 95, 4, 142, 123, 155, 136, 65, 32, 87, 4, 130, 84, 142, 167, 98, 77, 253, 153, 51, 65, 168, 202, 110, 70, 234, 157, 50, 18, 248, 144, 101, 78, 246, 157, 104, 65, 190, 217, 104, 77, 36, 218, 89, 251, 125, 12, 31, 232, 124, 217, 66, 230, 117, 19, 2, 178, 49, 150, 11, 238, 117, 22, 7, 39, 241, 164, 206, 109, 177, 240, 138, 97, 251, 165, 194, 113, 180, 239, 155, 36, 48, 163, 69, 238, 35, 229, 143, 175, 54, 178, 89, 234, 102, 243, 70, 33, 12, 252, 130, 102, 192, 218, 189, 31, 63, 129, 230, 86, 49, 216, 160, 16, 63, 156, 231, 92, 49, 217, 189, 20, 36, 141, 168, 69, 112, 219, 163, 241, 48, 107, 1, 181, 119, 39, 15, 245, 57, 121, 4, 225, 126, 43, 70, 237, 233, 73, 194, 21, 169, 18, 22, 0, 252, 79, 210, 14, 184, 8, 30, 0, 248, 85, 218, 7, 171, 2, 1, 132, 110, 11, 98, 196, 53, 95, 119, 145, 104, 27, 121, 213, 47, 87, 119, 131, 97, 25, 124, 210, 48, 91, 52, 132, 220, 63, 18, 126, 24, 120, 222, 206, 108, 248, 84, 27, 45, 164, 30, 208, 121, 183, 71, 22, 63, 185, 3, 209, 115, 183, 67, 12, 55, 176, 16, 219, 108, 98, 32, 58, 223, 38, 103, 118, 81, 97, 60, 62, 193, 98, 33, 158, 242, 53, 121, 237, 22, 103, 46, 97, 218, 57, 222, 60, 9, 82, 64, 100, 208, 37, 140, 113, 34, 156, 72, 54, 110, 225, 133, 119, 55, 154, 89, 45, 106, 209, 175, 109, 34, 128, 72, 144, 230, 248, 201, 84, 33, 52, 71, 147, 247, 247, 211, 72, 43, 45, 14, 131, 174, 234, 211, 65, 60, 45, 71, 142, 225, 237, 135, 65, 45, 50, 9, 143, 249, 245, 194, 68, 41, 60, 3, 52, 206, 236, 193, 112, 137, 160, 207, 48, 223, 253, 202, 71, 142, 172, 157, 37, 197, 249, 202, 118, 198, 171, 142, 45, 202, 232, 203, 59, 220, 37, 245, 127, 155, 105, 136, 50, 218, 48, 243, 110, 128, 109, 184, 14, 218, 32, 212, 237, 154, 48, 144, 170, 214, 62, 193, 235, 159, 126, 138, 170, 207, 119, 194, 252, 219, 56, 133, 172, 215, 123, 192, 5, 8, 111, 9, 193, 79, 35, 116, 12, 14, 122, 15, 208, 84, 39, 68, 52, 2, 97, 21, 193, 228, 91, 170, 2, 160, 28, 230, 12, 245, 81, 164, 30, 160, 83, 229, 67, 224, 90, 173, 21, 244, 21, 234, 69, 248, 86, 175, 150, 102, 254, 153, 210, 33, 178, 23, 146, 119, 239, 146, 134, 43, 173, 69, 137, 124, 192, 249, 123, 86, 25, 175, 61, 69, 152, 236, 97, 68, 30, 168, 38, 8, 153, 188, 111, 68, 25, 176, 109, 208, 199, 161, 41, 23, 139, 175, 110, 204, 195, 191, 125, 27, 137, 226, 109, 212, 195, 187, 56, 95, 235, 119, 212, 27, 172, 59, 90, 95, 239, 119, 212, 79, 166, 46, 18, 78, 246, 101, 206, 10, 167, 146, 117, 216, 168, 86, 50, 20, 98, 10, 84, 130, 55, 75, 136, 200, 124, 31, 27, 145, 58, 89, 149, 213, 125, 21, 27, 131, 51, 91, 144, 210, 98, 25, 88, 132, 19, 110, 29, 243, 87, 41, 81, 142, 26, 104, 8, 245, 70, 50, 85, 190, 33, 103, 31, 246, 80, 54, 93, 190, 6, 54, 9, 236, 196, 114, 78, 160, 202, 36, 0, 238, 193, 117, 81, 172, 137, 35, 65, 227, 197, 114, 72, 171, 147, 102, 7, 236, 195, 106, 68, 169, 155, 4, 21, 218, 88, 192, 210, 22, 214, 22, 28, 216, 93, 199, 205, 26, 149, 17, 93, 223, 95, 199, 205, 26, 130, 23, 21, 155, 80, 213, 212, 23, 147, 16, 56, 123, 83, 116, 225, 173, 149, 231, 96, 110, 73, 102, 230, 170, 142, 170, 104, 124, 64, 100, 227, 173, 145, 166, 43, 123, 8, 39, 238, 191, 136, 171, 175, 104, 153, 121, 235, 47, 213, 119, 189, 97, 155, 124, 236, 48, 217, 52, 186, 32, 136, 101, 240, 35, 221, 36, 172, 101, 156, 202, 172, 117, 71, 16, 242, 22, 26, 223, 161, 112, 93, 61, 253, 36, 0, 217, 176, 97, 149, 243, 211, 120, 238, 160, 25, 51, 160, 182, 213, 115, 227, 87, 112, 90, 185, 13, 46, 74, 227, 87, 104, 94, 165, 16, 105, 8, 226, 76, 104, 78, 179, 2, 58, 30, 176, 69, 104, 67, 188, 87, 120, 198, 169, 29, 56, 146, 237, 17, 112, 206, 188, 20, 35, 200, 236, 84, 101, 201, 171, 25, 113, 142, 233, 88, 125]);
  const pack = self.tranquill_PACK = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  pack.data.push(a);
  const shard = pack.data.length - 1;
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 0,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 2,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 3,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 4,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 5,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 6,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 7,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 8,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 9,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 10,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 11,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 12,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 13,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 14,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 15,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 16,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 17,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 18,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 19,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 20,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 21,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 22,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 23,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 24,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 25,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 26,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 27,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 28,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 29,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 30,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 31,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 32,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 33,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 34,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 35,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 36,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 37,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 38,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 39,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 40,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 41,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 42,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 43,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 44,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 45,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 46,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 47,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 48,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 49,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 50,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 51,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 52,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 53,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 54,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 55,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 56,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 57,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 58,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 59,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 60,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 61,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 62,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 63,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 64,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 65,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 66,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 67,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 68,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 69,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 70,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 71,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 72,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 73,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 74,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 75,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 76,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 77,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 78,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 79,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 80,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 81,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 82,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 83,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 84,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 85,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 86,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 87,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 88,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 89,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 90,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 91,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 92,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 93,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 94,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 95,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 96,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 97,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 98,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 99,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 100,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 101,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 102,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 103,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 104,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 105,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 106,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 107,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 108,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 109,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 110,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"]["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 111,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 137,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 145,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 151,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 157,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 157,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 161,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 161,
    len: 27,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 188,
    len: 35,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 223,
    len: 23,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 246,
    len: 19,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 265,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 286,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 312,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 319,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 323,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 330,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 334,
    len: 29,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 363,
    len: 28,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 391,
    len: 7,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 398,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 423,
    len: 35,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 458,
    len: 18,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 476,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 493,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 518,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 537,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 562,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 566,
    len: 0,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 566,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 574,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 575,
    len: 20,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 595,
    len: 1,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 596,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 621,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 628,
    len: 23,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 651,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 683,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 683,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 687,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 713,
    len: 23,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 736,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 753,
    len: 14,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 767,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 774,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 800,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 817,
    len: 23,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 840,
    len: 25,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 865,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 872,
    len: 26,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 898,
    len: 12,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 910,
    len: 10,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 920,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 926,
    len: 5,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 931,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 952,
    len: 40,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 992,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 1020,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1039,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1064,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1085,
    len: 27,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1112,
    len: 18,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1130,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1152,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1173,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 1195,
    len: 7,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1202,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1230,
    len: 25,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1255,
    len: 31,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1286,
    len: 1,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1287,
    len: 33,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1320,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1352,
    len: 27,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1379,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1398,
    len: 13,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1411,
    len: 28,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1439,
    len: 26,
    kind: 1
  });
})();
const TYPO_NEIGHBORS = Object["freeze"]({
  a: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  b: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  c: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  d: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  e: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  f: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  g: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  h: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  i: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  j: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  k: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  l: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  m: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  n: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  o: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  p: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  q: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  r: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  s: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  t: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  u: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  v: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  w: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  x: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  y: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")],
  z: [tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142"), tranquill_S("0x6c62272e07bb0142")]
});
const TYPO_ALPHABET = tranquill_S("0x6c62272e07bb0142");
const TYPO_CHAR_PATTERN = tranquill_S("0x6c62272e07bb0142");
const pickRandom = items => {
  if (!Array.isArray(items) || items.length === 0) return null;
  const idx = Math.floor(Math.random() * items.length);
  return items[idx];
};
const generateTypoCharacter = character => {
  if (!character || typeof character !== tranquill_S("0x6c62272e07bb0142")) return null;
  const ref = character.charAt(0);
  if (!TYPO_CHAR_PATTERN["test"](ref)) return null;
  const lower = ref.toLowerCase();
  const neighbors = (TYPO_NEIGHBORS[lower] || []).filter(ch => typeof ch === tranquill_S("0x6c62272e07bb0142") && ch.toLowerCase() !== lower);
  let candidate = null;
  if (neighbors.length && Math.random() < 0.75) candidate = pickRandom(neighbors);
  if (!candidate) {
    const pool = TYPO_ALPHABET["replace"](lower, tranquill_S("0x6c62272e07bb0142"));
    if (!pool.length) return null;
    candidate = pool.charAt(Math["floor"](Math.random() * pool["length"]));
  }
  if (!candidate) return null;
  if (ref === ref.toUpperCase()) candidate = candidate.toUpperCase();
  if (candidate.toLowerCase() === lower) return null;
  return candidate;
};
class TypingSession {
  constructor({
    debuggerManager,
    typingModel,
    phantomController
  }) {
    this.debuggerManager = debuggerManager;
    this.typingModel = typingModel;
    this.phantomController = phantomController;
    this.isRunning = false;
    this["activeTabId"] = null;
    this.plan = null;
    this.delayController = null;
    this.ghostModeEnabled = true;
    this.ghostRevisions = [];
    this["mode"] = tranquill_S("0x6c62272e07bb0142");
    this.sourceText = tranquill_S("0x6c62272e07bb0142");
    this.lastOutputCharacter = null;
    this.textSignature = null;
    this.currentIndex = 0;
    this["totalCharacters"] = 0;
    this._phantomQueue = Promise.resolve();
    this._finalized = false;
  }
  isActive() {
    return this.isRunning;
  }
  async start({
    text,
    startIndex = 0,
    settings = {}
  }) {
    if (!text || !String(text)["trim"]()) throw new Error(tranquill_S("0x6c62272e07bb0142"));
    if (this["isRunning"]) throw new Error(tranquill_S("0x6c62272e07bb0142"));
    log.info(tranquill_S("0x6c62272e07bb0142"), {
      requestedStartIndex: startIndex,
      textLength: text?.length ?? 0,
      phantomMode: settings?.phantomMode === true
    });
    let idx = Math.min(Math.max(startIndex, 0), text.length);
    if (idx >= text.length) {
      idx = 0;
      await TextStorage.clearProgress().catch(e => log["warn"](tranquill_S("0x6c62272e07bb0142"), e));
    }
    const tabId = await this.debuggerManager.ensureAttached();
    this.activeTabId = tabId;
    try {
      await this.debuggerManager.focusEditableArea(tabId);
      log.debug(tranquill_S("0x6c62272e07bb0142"), {
        tabId
      });
    } catch (err) {
      await this.debuggerManager.detach();
      this.activeTabId = null;
      log["error"](tranquill_S("0x6c62272e07bb0142"), err);
      throw err;
    }
    this.mode = settings.phantomMode === true ? tranquill_S("0x6c62272e07bb0142") : tranquill_S("0x6c62272e07bb0142");
    this["ghostModeEnabled"] = settings.ghostMode !== false && this.mode !== tranquill_S("0x6c62272e07bb0142");
    this.sourceText = String(text);
    this.textSignature = TextStorage.createTextSignature(this.sourceText);
    this._finalized = false;
    this._phantomQueue = Promise.resolve();
    const plan = new TypingPlan(this.sourceText, this.typingModel, idx);
    this.plan = plan;
    this["totalCharacters"] = plan.length;
    this["currentIndex"] = plan.currentIndex;
    this.lastOutputCharacter = idx > 0 ? this.sourceText[idx - 1] : null;
    this["ghostRevisions"] = this.ghostModeEnabled ? new RevisionPlanner(this.sourceText, this.typingModel, idx).build() : [];
    this.delayController = this.mode === tranquill_S("0x6c62272e07bb0142") ? new DelayController() : null;
    await TextStorage["setProgress"](this.currentIndex, this["textSignature"]).catch(e => log.warn(tranquill_S("0x6c62272e07bb0142"), e));
    this.isRunning = true;
    this.#broadcastTyping(true);
    log.info(tranquill_S("0x6c62272e07bb0142"), {
      mode: this["mode"],
      tabId,
      startingIndex: this.currentIndex,
      totalCharacters: this.totalCharacters
    });
    if (this["mode"] === tranquill_S("0x6c62272e07bb0142")) {
      await this["phantomController"].waitUntilReady(tabId);
      const ok = await this.phantomController.setActive(tabId, true);
      if (!ok) {
        log.error(tranquill_S("0x6c62272e07bb0142"), {
          tabId
        });
        await this["finalize"]({
          completed: false,
          detachDebugger: true
        });
        throw new Error(tranquill_S("0x6c62272e07bb0142"));
      }
      log.info(tranquill_S("0x6c62272e07bb0142"), {
        tabId
      });
      return;
    }
    (async () => {
      let completed = false;
      try {
        completed = await this.#runAuto(plan);
      } catch (e) {
        log.error(tranquill_S("0x6c62272e07bb0142"), e);
      } finally {
        await this.finalize({
          completed,
          detachDebugger: true
        });
      }
    })();
  }
  async #runAuto(plan) {
    const ctrl = this["delayController"];
    if (!plan || !ctrl) return false;
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      remaining: Math.max(0, plan.length - plan.currentIndex)
    });
    while (this.isRunning && plan.hasNext()) {
      const step = plan.peek();
      if (!step) break;
      await this.#maybeInjectTypo(step);
      if (!this.isRunning || this.activeTabId === null) return false;
      await ctrl.wait(step["delay"]);
      if (!this.isRunning || this.activeTabId === null) return false;
      await this.debuggerManager.typeCharacter(this["activeTabId"], step.character);
      this.lastOutputCharacter = step.character;
      plan.advance();
      this.currentIndex = plan["currentIndex"];
      await TextStorage.setProgress(this.currentIndex, this.textSignature).catch(e => log.warn(tranquill_S("0x6c62272e07bb0142"), e));
      await this.#maybeGhost(plan.currentIndex);
    }
    log.info(tranquill_S("0x6c62272e07bb0142"), {
      finished: plan.hasNext() === false,
      currentIndex: this.currentIndex
    });
    return plan.hasNext() === false;
  }
  async #maybeGhost(i) {
    if (!this.ghostModeEnabled || !this["ghostRevisions"]?.length) return;
    while (this.ghostRevisions.length && this.ghostRevisions[0].triggerIndex <= i) {
      const rev = this.ghostRevisions.shift();
      await this.#performGhost(rev);
      if (!this.isRunning) return;
    }
  }
  async #maybeInjectTypo(step) {
    if (!this.ghostModeEnabled || this.mode !== tranquill_S("0x6c62272e07bb0142") || !this["delayController"] || !step || !TYPO_CHAR_PATTERN.test(step.character || tranquill_S("0x6c62272e07bb0142")) || this.activeTabId === null) return false;
    const probability = 0.05;
    if (Math.random() >= probability) return false;
    const typoChar = generateTypoCharacter(step.character);
    if (!typoChar) return false;
    const ctrl = this.delayController;
    const baseDelay = Number.isFinite(step.delay) ? step["delay"] : typeof this.typingModel?.baseDelay === tranquill_S("0x6c62272e07bb0142") ? this.typingModel.baseDelay() : 120;
    const preDelay = Math.max(155, Math.round(baseDelay * 0.35 + Math.random() * 130));
    if (preDelay > 0) {
      await ctrl["wait"](preDelay);
      if (!this.isRunning || this["activeTabId"] === null) return true;
    }
    await this.debuggerManager.typeCharacter(this.activeTabId, typoChar);
    this["lastOutputCharacter"] = typoChar;
    const correctionPause = Math["max"](170, Math.round(baseDelay * 0.25 + Math["random"]() * 95));
    await ctrl.wait(correctionPause);
    if (!this.isRunning || this.activeTabId === null) return true;
    await this.debuggerManager["typeCharacter"](this.activeTabId, tranquill_S("0x6c62272e07bb0142"));
    const priorIndex = step.index > 0 ? step.index - 1 : -1;
    const priorCharacter = priorIndex >= 0 && priorIndex < this.sourceText.length ? this.sourceText[priorIndex] : null;
    this.lastOutputCharacter = priorCharacter || null;
    const resumePause = Math.max(30, Math.round(baseDelay * 0.3 + Math["random"]() * 45));
    await ctrl.wait(resumePause);
    if (!this["isRunning"] || this.activeTabId === null) return true;
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      index: step.index,
      intended: step.character,
      injected: typoChar
    });
    return true;
  }
  async #performGhost(rev) {
    if (!rev || !rev.segmentText || !this["delayController"] || this.activeTabId === null) return;
    if (rev.pauseBefore > 0) {
      await this.delayController.wait(rev.pauseBefore);
      if (!this.isRunning) return;
    }
    const chars = Array.from(rev.segmentText);
    for (let i = 0; i < chars.length; i++) {
      const wait = Array["isArray"](rev["backspaceDelays"]) ? rev.backspaceDelays[i] || 0 : 0;
      if (wait > 0) {
        await this.delayController.wait(wait);
        if (!this.isRunning) return;
      }
      await this.debuggerManager.typeCharacter(this["activeTabId"], tranquill_S("0x6c62272e07bb0142"));
    }
    this.lastOutputCharacter = rev.previousCharacter || null;
    if (!this.isRunning) return;
    if (rev.pauseAfter > 0) {
      await this.delayController["wait"](rev.pauseAfter);
      if (!this["isRunning"]) return;
    }
    for (let i = 0; i < chars.length; i++) {
      const wait = Array.isArray(rev.retypeDelays) ? rev.retypeDelays[i] || 0 : 0;
      if (wait > 0) {
        await this.delayController.wait(wait);
        if (!this.isRunning) return;
      }
      const ch = chars[i];
      await this["debuggerManager"].typeCharacter(this.activeTabId, ch);
      this.lastOutputCharacter = ch;
    }
  }
  async finalize({
    completed = false,
    detachDebugger = true
  } = {}) {
    if (this._finalized) return;
    this["_finalized"] = true;
    log.info(tranquill_S("0x6c62272e07bb0142"), {
      completed,
      detachDebugger,
      tabId: this.activeTabId,
      mode: this.mode,
      currentIndex: this["currentIndex"]
    });
    const ctrl = this.delayController;
    this.delayController = null;
    if (ctrl) ctrl.cancel();
    const wasPhantom = this.mode === tranquill_S("0x6c62272e07bb0142");
    const tabId = this.activeTabId;
    if (wasPhantom && tabId !== null) {
      try {
        await this.phantomController.setActive(tabId, false);
      } catch (e) {
        log.warn(tranquill_S("0x6c62272e07bb0142"), e);
      }
    }
    this.activeTabId = null;
    if (detachDebugger && tabId !== null) {
      try {
        await this.debuggerManager.detach();
      } catch (e) {
        log.warn(tranquill_S("0x6c62272e07bb0142"), e);
      }
    }
    const wasRunning = this.isRunning;
    this.isRunning = false;
    this.plan = null;
    this.ghostRevisions = [];
    this.sourceText = tranquill_S("0x6c62272e07bb0142");
    this.lastOutputCharacter = null;
    this.mode = tranquill_S("0x6c62272e07bb0142");
    this._phantomQueue = Promise.resolve();
    if (completed) {
      await TextStorage.clearProgress()["catch"](e => log.warn(tranquill_S("0x6c62272e07bb0142"), e));
      this.currentIndex = 0;
      this.totalCharacters = 0;
    } else if (this.totalCharacters > 0) {
      await TextStorage.setProgress(this.currentIndex, this.textSignature)["catch"](e => log.warn(tranquill_S("0x6c62272e07bb0142"), e));
    }
    this.textSignature = null;
    if (wasRunning) this.#broadcastTyping(false);
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      clearedProgress: completed,
      textSignature: this.textSignature
    });
  }
  async stop() {
    if (this._finalized && !this.isRunning) return;
    this["isRunning"] = false;
    log.info(tranquill_S("0x6c62272e07bb0142"), {
      currentIndex: this.currentIndex,
      tabId: this.activeTabId
    });
    if (this["delayController"]) this["delayController"]["cancel"]();
    await this.finalize({
      completed: false,
      detachDebugger: true
    });
  }
  #enqueuePhantom(fn) {
    this["_phantomQueue"] = (this._phantomQueue || Promise["resolve"]()).then(async () => {
      if (!this.isRunning || this.mode !== tranquill_S("0x6c62272e07bb0142")) return;
      log.debug(tranquill_S("0x6c62272e07bb0142"));
      await fn();
    }).catch(e => log.warn(tranquill_S("0x6c62272e07bb0142"), e));
    return this._phantomQueue;
  }
  handlePhantomTrigger(tabId, requestId = null, key = null, timeStamp = null, frameId = null) {
    log["debug"](tranquill_S("0x6c62272e07bb0142"), {
      tabId,
      requestId,
      key,
      timeStamp,
      frameId
    });
    return this.#enqueuePhantom(() => this.#onPhantomTrigger(tabId, {
      requestId,
      key,
      timeStamp,
      frameId
    }));
  }
  handlePhantomBackspace(tabId, frameId = null) {
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      tabId,
      frameId
    });
    return this.#enqueuePhantom(() => this.#onPhantomBackspace(tabId, frameId));
  }
  async #onPhantomTrigger(tabId, context = {}) {
    if (!this.isRunning || this.mode !== tranquill_S("0x6c62272e07bb0142") || this.activeTabId !== tabId) return;
    const requestId = context?.requestId ?? null;
    const triggerKey = context?.key ?? null;
    const triggerTime = context?.timeStamp ?? null;
    const frameId = Number.isInteger(context?.frameId) ? context.frameId : null;
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      tabId,
      requestId,
      hasPlan: Boolean(this.plan),
      triggerKey,
      triggerTime,
      frameId
    });
    if (!this["plan"] || !this.plan.hasNext()) {
      if (this.plan && !this.plan.hasNext()) await this.finalize({
        completed: true,
        detachDebugger: true
      });
      return;
    }
    const step = this.plan.peek();
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      requestId,
      character: step?.character ?? null,
      currentIndex: this.plan.currentIndex
    });
    const suppression = step && Number.isFinite(step.delay) ? Math.max(220, Math.min(900, step["delay"] + 160)) : 320;
    const events = KeyEventFactory.build(step["character"]);
    const expectedKeys = events.filter(e => e?.type === tranquill_S("0x6c62272e07bb0142") && typeof e.key === tranquill_S("0x6c62272e07bb0142") && (e.key.length === 1 || e["key"] === tranquill_S("0x6c62272e07bb0142"))).map(e => e["key"]);
    const sendOptions = frameId !== null ? {
      frameId
    } : undefined;
    const start = await ChromeAsync.tabsSendMessage(tabId, {
      action: tranquill_S("0x6c62272e07bb0142"),
      duration: suppression,
      character: step.character,
      keys: expectedKeys,
      requestId
    }, sendOptions);
    let acked = start.success && start.response?.accepted;
    let typingError = null;
    if (!acked) {
      log.warn(tranquill_S("0x6c62272e07bb0142"), {
        requestId,
        error: start.error || null,
        frameId
      });
    }
    try {
      await this.debuggerManager.typeCharacter(tabId, step.character);
    } catch (e) {
      typingError = e;
      log["error"](tranquill_S("0x6c62272e07bb0142"), e);
    }
    if (acked) {
      const end = await ChromeAsync.tabsSendMessage(tabId, {
        action: tranquill_S("0x6c62272e07bb0142"),
        requestId
      }, sendOptions);
      if (!end.success) log["warn"](tranquill_S("0x6c62272e07bb0142"), end.error);
    } else {
      await ChromeAsync.tabsSendMessage(tabId, {
        action: tranquill_S("0x6c62272e07bb0142"),
        requestId,
        character: step.character
      }, sendOptions).catch(abortError => log.warn(tranquill_S("0x6c62272e07bb0142"), abortError));
    }
    if (typingError) {
      log.error(tranquill_S("0x6c62272e07bb0142"), typingError);
      await this.finalize({
        completed: false,
        detachDebugger: true
      });
      return;
    }
    this.plan.advance();
    this.currentIndex = this.plan.currentIndex;
    this.lastOutputCharacter = step.character;
    await TextStorage.setProgress(this.currentIndex, this.textSignature).catch(e => log["warn"](tranquill_S("0x6c62272e07bb0142"), e));
    log["debug"](tranquill_S("0x6c62272e07bb0142"), {
      requestId,
      index: this["currentIndex"],
      remaining: Math.max(0, this.plan.length - this.currentIndex)
    });
    if (!this.plan.hasNext()) {
      log.info(tranquill_S("0x6c62272e07bb0142"), {
        tabId
      });
      await this.finalize({
        completed: true,
        detachDebugger: true
      });
    }
  }
  async #onPhantomBackspace(tabId, frameId = null) {
    if (!this.isRunning || this.mode !== tranquill_S("0x6c62272e07bb0142") || this.activeTabId !== tabId) return;
    if (!this.plan) return;
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      tabId,
      frameId
    });
    const sendOptions = frameId !== null ? {
      frameId
    } : undefined;
    const prep = await ChromeAsync.tabsSendMessage(tabId, {
      action: tranquill_S("0x6c62272e07bb0142")
    }, sendOptions);
    if (!prep.success) {
      log.warn(tranquill_S("0x6c62272e07bb0142"), prep.error);
      return;
    }
    let dispatchError = null;
    try {
      await this.debuggerManager.typeCharacter(tabId, tranquill_S("0x6c62272e07bb0142"));
    } catch (err) {
      dispatchError = err;
      log["error"](tranquill_S("0x6c62272e07bb0142"), err);
    }
    if (dispatchError) return;
    this.plan.retreat();
    this["currentIndex"] = this.plan.currentIndex;
    this.lastOutputCharacter = this.currentIndex > 0 ? this.plan.text[this.currentIndex - 1] : null;
    await TextStorage.setProgress(this.currentIndex, this.textSignature)["catch"](e => log["warn"](tranquill_S("0x6c62272e07bb0142"), e));
    log.info(tranquill_S("0x6c62272e07bb0142"), {
      tabId,
      currentIndex: this["currentIndex"]
    });
  }
  #broadcastTyping(isTyping) {
    try {
      chrome.runtime.sendMessage({
        action: tranquill_S("0x6c62272e07bb0142"),
        isTyping
      }, () => {
        const err = chrome.runtime.lastError;
        if (err?.message?.includes(tranquill_S("0x6c62272e07bb0142"))) return;
      });
    } catch (e) {
      log.debug(tranquill_S("0x6c62272e07bb0142"), e);
    }
  }
  handleDebuggerDetached() {
    if (this._finalized) return;
    if (this.delayController) {
      this.delayController.cancel();
      this.delayController = null;
    }
    this.isRunning = false;
    this.finalize({
      completed: false,
      detachDebugger: false
    }).catch(e => log.warn(tranquill_S("0x6c62272e07bb0142"), e));
  }
}
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}