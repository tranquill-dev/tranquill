var tranquill_global = typeof self !== "undefined" ? self : globalThis;
if (!tranquill_global.tranquill_runtime_ready) {
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::c882198ca34f17b696c9b80e0eca21ea"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = "tranquill_tranquill_tranquill";
        tranquill_global.tranquill_runtime_ready = true;
}

(function tranquill_init_shard() {
  const a = new Uint8Array([190, 22, 171, 250, 16, 7, 59, 185, 210, 64, 124, 190, 28, 22, 15, 170, 193, 68, 109, 246, 16, 1, 203, 163, 250, 72, 136, 225, 189, 143, 143, 175, 235, 124, 155, 242, 185, 158, 199, 163, 252, 105, 128, 30, 248, 51, 3, 221, 186, 116, 68, 90, 250, 52, 2, 251, 190, 101, 95, 12, 248, 5, 23, 216, 148, 117, 22, 19, 243, 39, 25, 209, 184, 117, 158, 19, 9, 100, 243, 200, 0, 51, 181, 92, 93, 100, 242, 156, 13, 32, 164, 25, 74, 113, 245, 216, 223, 125, 166, 90, 28, 63, 225, 29, 155, 125, 170, 92, 14, 42, 225, 46, 207, 108, 165, 76, 19, 61, 224, 176, 136, 25, 83, 243, 202, 222, 20, 244, 140, 15, 82, 245, 206, 211, 3, 176, 125, 165, 208, 178, 62, 231, 151, 245, 57, 164, 215, 179, 56, 227, 154, 226, 125, 71, 234, 120, 195, 4, 168, 63, 4, 3, 235, 127, 194, 2, 172, 50, 86, 69, 238, 115, 218, 6, 171, 146, 124, 175, 151, 81, 62, 232, 208, 214, 113, 172, 140, 82, 53, 232, 230, 147, 109, 172, 129, 94, 60, 233, 12, 109, 211, 228, 79, 47, 148, 163, 72, 110, 222, 242, 93, 59, 180, 181, 1, 124, 208, 243, 68, 45, 176, 163, 13, 105, 255, 64, 201, 111, 170, 22, 128, 116, 221, 72, 192, 111, 183, 8, 128, 108, 184, 6, 147, 59, 183, 75, 204, 102, 180, 3, 166, 32, 244, 93, 211, 47, 234, 72, 200, 42, 251, 4, 128, 121, 190, 13, 151, 102, 183, 21, 158, 47, 172, 98, 192, 111, 183, 8, 128, 47, 247, 72, 137, 41, 183, 0, 129, 106, 187, 65, 192, 61, 242, 92, 213, 125, 185, 72, 134, 46, 251, 91, 197, 52, 221, 72, 192, 111, 183, 8, 128, 47, 247, 11, 143, 33, 228, 92, 128, 125, 247, 85, 192, 42, 251, 6, 199, 106, 163, 42, 143, 58, 249, 76, 201, 97, 176, 43, 140, 38, 242, 70, 212, 93, 178, 11, 148, 103, 190, 19, 170, 47, 247, 72, 192, 111, 183, 8, 128, 108, 184, 6, 147, 59, 183, 80, 128, 50, 247, 37, 129, 59, 255, 6, 210, 96, 162, 6, 132, 103, 229, 6, 204, 106, 177, 28, 192, 100, 183, 90, 142, 120, 190, 12, 148, 39, 184, 26, 137, 52, 221, 72, 192, 111, 183, 8, 128, 47, 247, 11, 143, 33, 228, 92, 128, 118, 247, 85, 192, 2, 246, 92, 200, 33, 165, 7, 149, 33, 243, 0, 210, 33, 163, 7, 144, 111, 188, 8, 237, 110, 163, 0, 206, 34, 254, 70, 136, 125, 249, 0, 133, 38, 240, 64, 212, 32, 229, 68, 192, 125, 167, 1, 137, 52, 221, 72, 192, 111, 183, 8, 128, 47, 247, 11, 143, 33, 228, 92, 128, 102, 185, 1, 148, 111, 170, 8, 219, 47, 181, 29, 130, 45, 251, 77, 211, 53, 163, 26, 149, 42, 187, 8, 195, 110, 185, 11, 133, 35, 246, 74, 204, 106, 237, 28, 146, 58, 242, 4, 128, 108, 187, 1, 133, 33, 227, 112, 154, 119, 251, 72, 131, 35, 254, 77, 206, 123, 142, 82, 153, 99, 183, 74, 213, 123, 163, 7, 142, 117, 167, 4, 128, 109, 162, 28, 148, 32, 249, 91, 154, 62, 247, 21, 219, 69, 183, 8, 128, 47, 247, 72, 192, 111, 241, 71, 210, 47, 255, 11, 143, 33, 228, 92, 128, 123, 247, 7, 134, 111, 204, 10, 205, 96, 162, 27, 133, 43, 248, 95, 206, 45, 251, 74, 141, 32, 226, 91, 197, 122, 167, 74, 204, 109, 244, 68, 201, 108, 188, 74, 189, 102, 183, 77, 204, 33, 179, 1, 147, 63, 246, 92, 195, 103, 146, 30, 133, 33, 227, 0, 206, 106, 160, 72, 173, 32, 226, 91, 197, 74, 161, 13, 142, 59, 191, 92, 140, 47, 190, 6, 137, 59, 190, 1, 155, 5, 247, 72, 192, 111, 183, 8, 128, 47, 163, 26, 153, 111, 236, 8, 197, 99, 249, 14, 143, 44, 226, 91, 136, 116, 247, 24, 146, 42, 225, 77, 206, 123, 132, 11, 146, 32, 251, 68, 154, 47, 163, 26, 149, 42, 183, 85, 137, 52, 247, 21, 192, 44, 246, 92, 195, 103, 247, 19, 192, 42, 251, 6, 198, 96, 180, 29, 147, 103, 190, 19, 128, 114, 221, 72, 192, 111, 183, 8, 128, 47, 247, 1, 134, 111, 191, 94, 201, 106, 160, 87, 206, 41, 248, 75, 213, 124, 254, 72, 150, 38, 242, 95, 142, 105, 184, 11, 149, 60, 191, 1, 155, 5, 247, 72, 192, 111, 183, 8, 128, 47, 165, 13, 148, 58, 229, 70, 128, 123, 165, 29, 133, 116, 157, 8, 128, 47, 247, 72, 192, 50, 172, 34, 170, 47, 247, 72, 192, 111, 183, 75, 207, 97, 164, 28, 192, 60, 242, 68, 244, 96, 146, 6, 132, 111, 170, 8, 136, 107, 184, 11, 204, 111, 242, 68, 137, 47, 234, 86, 192, 52, 157, 8, 128, 47, 247, 72, 192, 111, 183, 75, 207, 97, 164, 28, 192, 60, 183, 21, 128, 107, 184, 11, 206, 40, 242, 92, 243, 106, 187, 13, 131, 59, 254, 71, 206, 48, 249, 64, 201, 116, 183, 65, 198, 47, 255, 73, 147, 111, 235, 84, 128, 46, 178, 4, 201, 111, 229, 77, 212, 122, 165, 6, 219, 69, 183, 8, 128, 47, 247, 72, 192, 111, 244, 71, 206, 124, 163, 72, 146, 46, 249, 79, 197, 47, 234, 72, 132, 32, 244, 6, 195, 125, 178, 9, 148, 42, 197, 73, 206, 104, 178, 64, 201, 116, 157, 8, 128, 47, 247, 72, 192, 111, 183, 90, 193, 97, 176, 13, 206, 60, 242, 68, 197, 108, 163, 38, 143, 43, 242, 107, 207, 97, 163, 13, 142, 59, 228, 0, 197, 99, 254, 83, 192, 61, 246, 70, 199, 106, 249, 11, 143, 35, 251, 73, 208, 124, 178, 64, 134, 46, 251, 91, 197, 38, 236, 98, 192, 111, 183, 8, 128, 47, 247, 72, 147, 97, 229, 77, 205, 96, 161, 13, 161, 35, 251, 122, 193, 97, 176, 13, 147, 103, 190, 19, 128, 124, 249, 9, 132, 43, 197, 73, 206, 104, 178, 64, 146, 46, 249, 79, 197, 38, 236, 98, 192, 111, 183, 8, 128, 47, 170, 83, 234, 69, 183, 8, 128, 47, 247, 72, 148, 61, 238, 8, 219, 5, 247, 72, 192, 111, 183, 8, 128, 47, 248, 71, 192, 8, 248, 71, 199, 99, 178, 72, 164, 32, 244, 91, 128, 102, 177, 26, 129, 34, 242, 34, 128, 47, 247, 72, 192, 111, 183, 8, 195, 96, 185, 27, 148, 111, 254, 78, 210, 110, 186, 13, 192, 114, 183, 76, 207, 108, 162, 5, 133, 33, 227, 6, 209, 122, 178, 26, 153, 28, 242, 68, 197, 108, 163, 7, 146, 103, 176, 65, 198, 125, 182, 5, 133, 97, 243, 71, 195, 124, 250, 28, 133, 55, 227, 77, 214, 106, 185, 28, 148, 46, 229, 79, 197, 123, 250, 1, 134, 61, 246, 69, 197, 35, 247, 1, 134, 61, 246, 69, 197, 33, 179, 7, 131, 60, 186, 92, 197, 119, 163, 13, 150, 42, 249, 92, 212, 110, 165, 15, 133, 59, 176, 1, 155, 5, 247, 72, 192, 111, 183, 8, 128, 47, 190, 14, 192, 103, 254, 78, 210, 110, 186, 13, 223, 97, 244, 71, 206, 123, 178, 6, 148, 24, 254, 70, 196, 96, 160, 87, 206, 43, 248, 75, 213, 98, 178, 6, 148, 102, 183, 83, 170, 47, 247, 72, 192, 111, 183, 8, 128, 47, 247, 11, 143, 33, 228, 92, 128, 120, 190, 6, 192, 114, 183, 65, 198, 125, 182, 5, 133, 97, 244, 71, 206, 123, 178, 6, 148, 24, 254, 70, 196, 96, 160, 68, 192, 43, 248, 75, 128, 50, 247, 31, 137, 33, 185, 76, 207, 108, 162, 5, 133, 33, 227, 19, 170, 47, 247, 72, 192, 111, 183, 8, 128, 47, 247, 11, 143, 33, 228, 92, 128, 123, 182, 26, 135, 42, 227, 8, 157, 47, 179, 7, 131, 97, 230, 93, 197, 125, 174, 59, 133, 35, 242, 75, 212, 96, 165, 64, 199, 20, 244, 71, 206, 123, 178, 6, 148, 42, 243, 65, 212, 110, 181, 4, 133, 114, 181, 92, 210, 122, 178, 74, 189, 104, 190, 8, 220, 115, 247, 12, 143, 44, 185, 74, 207, 107, 174, 83, 234, 111, 183, 8, 128, 47, 247, 72, 192, 111, 183, 65, 198, 47, 255, 11, 140, 38, 244, 67, 230, 96, 180, 29, 147, 103, 227, 73, 210, 104, 178, 28, 204, 111, 224, 65, 206, 38, 254, 72, 155, 111, 228, 77, 204, 91, 184, 45, 142, 43, 191, 76, 207, 108, 251, 72, 148, 46, 229, 79, 197, 123, 254, 83, 192, 61, 242, 92, 213, 125, 185, 72, 155, 111, 228, 93, 195, 108, 178, 27, 147, 117, 227, 90, 213, 106, 251, 72, 131, 59, 239, 18, 130, 107, 184, 11, 147, 98, 254, 78, 210, 110, 186, 13, 194, 111, 234, 19, 128, 114, 221, 72, 192, 111, 183, 8, 128, 47, 247, 21, 234, 111, 183, 8, 128, 47, 247, 72, 192, 96, 184, 8, 231, 106, 185, 13, 146, 38, 244, 34, 128, 47, 247, 72, 192, 111, 183, 8, 195, 96, 185, 27, 148, 111, 242, 76, 128, 50, 247, 12, 143, 44, 226, 69, 197, 97, 163, 70, 145, 58, 242, 90, 217, 92, 178, 4, 133, 44, 227, 71, 210, 39, 240, 51, 131, 32, 249, 92, 197, 97, 163, 13, 132, 38, 227, 73, 194, 99, 178, 85, 194, 59, 229, 93, 197, 45, 138, 68, 192, 43, 254, 94, 251, 125, 184, 4, 133, 114, 181, 92, 197, 119, 163, 10, 143, 55, 181, 117, 140, 47, 163, 13, 152, 59, 246, 90, 197, 110, 251, 72, 137, 33, 231, 93, 212, 84, 163, 17, 144, 42, 170, 10, 212, 106, 175, 28, 194, 18, 176, 1, 155, 5, 247, 72, 192, 111, 183, 8, 128, 47, 190, 14, 192, 103, 244, 68, 201, 108, 188, 46, 143, 44, 226, 91, 136, 106, 179, 68, 192, 56, 254, 70, 196, 96, 160, 65, 201, 111, 229, 77, 212, 122, 165, 6, 192, 52, 183, 91, 213, 108, 180, 13, 147, 60, 173, 92, 210, 122, 178, 68, 192, 44, 227, 80, 154, 45, 178, 12, 137, 59, 246, 74, 204, 106, 245, 72, 157, 116, 157, 8, 128, 47, 247, 72, 192, 111, 183, 90, 197, 123, 162, 26, 142, 111, 236, 8, 211, 122, 180, 11, 133, 60, 228, 18, 198, 110, 187, 27, 133, 111, 234, 19, 170, 47, 247, 72, 192, 111, 183, 85, 128, 108, 182, 28, 131, 39, 183, 0, 197, 38, 247, 19, 192, 61, 242, 92, 213, 125, 185, 72, 155, 111, 228, 93, 195, 108, 178, 27, 147, 117, 241, 73, 204, 124, 178, 68, 192, 42, 229, 90, 207, 125, 237, 72, 133, 112, 185, 69, 197, 124, 164, 9, 135, 42, 183, 85, 155, 47, 170, 98, 192, 111, 183, 8, 221, 38, 255, 65, 219, 133, 180, 128, 124, 254, 236, 203, 102, 178, 183, 143, 100, 226, 224, 218, 45, 180, 163, 57, 150, 205, 232, 56, 64, 142, 237, 62, 155, 194, 248, 107, 20, 132, 169, 49, 128, 206, 255, 251, 98, 228, 171, 56, 160, 35, 108, 191, 97, 233, 189, 42, 180, 3, 122, 246, 115, 231, 188, 51, 162, 7, 108, 250, 102, 166, 173, 42, 164, 37, 123, 236, 116, 77, 96, 242, 201, 14, 34, 181, 14, 9, 113, 233, 204, 12, 6, 184, 29, 91, 100, 243, 200, 12, 55, 186, 241, 122, 147, 71, 241, 46, 207, 128, 239, 107, 146, 80, 183, 1, 195, 138, 218, 124, 131, 93, 171]);
  const pack = self.tranquill_PACK = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  pack.data.push(a);
  const shard = pack["data"].length - 1;
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 0,
    len: 3,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 3,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 22,
    len: 21,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 43,
    len: 31,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 74,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 96,
    len: 23,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 119,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 136,
    len: 17,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 153,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 175,
    len: 23,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 198,
    len: 26,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 224,
    len: 1643,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 1867,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1883,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1905,
    len: 34,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1939,
    len: 22,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1961,
    len: 22,
    kind: 1
  });
})();
class DebuggerManager {
  constructor() {
    this.attachedTabId = null;
    this.protocolVersion = tranquill_S("0x6c62272e07bb0142");
  }
  isAttached() {
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      attachedTabId: this.attachedTabId
    });
    return this.attachedTabId !== null;
  }
  isAttachedTo(tabId) {
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      tabId,
      attachedTabId: this.attachedTabId
    });
    return this.attachedTabId === tabId;
  }
  async getActiveTabId() {
    log.debug(tranquill_S("0x6c62272e07bb0142"));
    const tabs = await ChromeAsync.tabsQuery({
      active: true,
      currentWindow: true
    });
    if (!tabs?.length) throw new Error(tranquill_S("0x6c62272e07bb0142"));
    return tabs[0].id;
  }
  async ensureAttached() {
    const tabId = await this.getActiveTabId();
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      tabId,
      currentlyAttached: this["attachedTabId"]
    });
    if (this.attachedTabId === tabId) return tabId;
    await ChromeAsync.debuggerAttach(tabId, this.protocolVersion);
    this.attachedTabId = tabId;
    log.info(tranquill_S("0x6c62272e07bb0142"), {
      tabId
    });
    return tabId;
  }
  async detach() {
    if (this.attachedTabId === null) return;
    const t = this.attachedTabId;
    this.attachedTabId = null;
    try {
      await ChromeAsync.debuggerDetach(t);
      log.info(tranquill_S("0x6c62272e07bb0142"), {
        tabId: t
      });
    } catch (e) {
      log.warn(tranquill_S("0x6c62272e07bb0142"), e);
    }
  }
  handleDetached(tabId) {
    log.warn(tranquill_S("0x6c62272e07bb0142"), {
      tabId,
      attachedTabId: this["attachedTabId"]
    });
    if (this.attachedTabId === tabId) this["attachedTabId"] = null;
  }
  async focusEditableArea(tabId) {
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      tabId
    });
    const expr = tranquill_S("0x6c62272e07bb0142");
    const res = await ChromeAsync.debuggerSend(tabId, tranquill_S("0x6c62272e07bb0142"), {
      expression: expr,
      returnByValue: true,
      includeCommandLineAPI: false
    });
    const v = res?.result?.value;
    if (!v || v.success !== true) throw new Error(tranquill_S("0x6c62272e07bb0142"));
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      tabId,
      context: v?.ctx ?? null
    });
  }
  async typeCharacter(tabId, character) {
    log.debug(tranquill_S("0x6c62272e07bb0142"), {
      tabId,
      character
    });
    const events = KeyEventFactory["build"](character);
    for (const ev of events) {
      await ChromeAsync.debuggerSend(tabId, tranquill_S("0x6c62272e07bb0142"), ev);
    }
  }
}
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}