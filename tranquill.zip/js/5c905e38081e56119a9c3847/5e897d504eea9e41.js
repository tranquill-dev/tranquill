var tranquill_global = typeof self !== "undefined" ? self : globalThis;
if (!tranquill_global.tranquill_runtime_ready) {
        const tranquill_uint32 = (value) => value >>> 0;
        const tranquill_sha256 = (input) => {
                const K = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
                        0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
                        0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
                        0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
                        0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
                        0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
                        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
                        0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
                        0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
                        0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const words = new Uint32Array(64);
                const view = new DataView(new ArrayBuffer(64));
                const processChunk = (chunk, H) => {
                        for (let i = 0; i < 16; i++) {
                                words[i] = chunk.getUint32(i * 4);
                        }
                        for (let i = 16; i < 64; i++) {
                                const s0 = ((words[i - 15] >>> 7) | (words[i - 15] << 25)) ^
                                        ((words[i - 15] >>> 18) | (words[i - 15] << 14)) ^
                                        (words[i - 15] >>> 3);
                                const s1 = ((words[i - 2] >>> 17) | (words[i - 2] << 15)) ^
                                        ((words[i - 2] >>> 19) | (words[i - 2] << 13)) ^
                                        (words[i - 2] >>> 10);
                                words[i] = tranquill_uint32(words[i - 16] + s0 + words[i - 7] + s1);
                        }
                        let [a, b, c, d, e, f, g, h] = H;
                        for (let i = 0; i < 64; i++) {
                                const S1 = ((e >>> 6) | (e << 26)) ^
                                        ((e >>> 11) | (e << 21)) ^
                                        ((e >>> 25) | (e << 7));
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = tranquill_uint32(h + S1 + ch + K[i] + words[i]);
                                const S0 = ((a >>> 2) | (a << 30)) ^
                                        ((a >>> 13) | (a << 19)) ^
                                        ((a >>> 22) | (a << 10));
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = tranquill_uint32(S0 + maj);
                                h = g;
                                g = f;
                                f = e;
                                e = tranquill_uint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = tranquill_uint32(temp1 + temp2);
                        }
                        H[0] = tranquill_uint32(H[0] + a);
                        H[1] = tranquill_uint32(H[1] + b);
                        H[2] = tranquill_uint32(H[2] + c);
                        H[3] = tranquill_uint32(H[3] + d);
                        H[4] = tranquill_uint32(H[4] + e);
                        H[5] = tranquill_uint32(H[5] + f);
                        H[6] = tranquill_uint32(H[6] + g);
                        H[7] = tranquill_uint32(H[7] + h);
                };
                const H = [
                        0x6a09e667,
                        0xbb67ae85,
                        0x3c6ef372,
                        0xa54ff53a,
                        0x510e527f,
                        0x9b05688c,
                        0x1f83d9ab,
                        0x5be0cd19,
                ];
                const totalLen = input.length;
                const paddedLen = ((totalLen + 9 + 63) >> 6) << 6;
                const padded = new Uint8Array(paddedLen);
                padded.set(input);
                padded[totalLen] = 0x80;
                const bitLen = totalLen * 8;
                const lenView = new DataView(padded.buffer);
                lenView.setUint32(paddedLen - 4, bitLen);
                lenView.setUint32(paddedLen - 8, Math.floor(bitLen / 0x100000000));
                for (let offset = 0; offset < paddedLen; offset += 64) {
                        for (let i = 0; i < 64; i++) view.setUint8(i, padded[offset + i]);
                        processChunk(view, H);
                }
                const out = new Uint8Array(32);
                const outView = new DataView(out.buffer);
                for (let i = 0; i < 8; i++) {
                        outView.setUint32(i * 4, H[i]);
                }
                return out;
        };
        const tranquill_seed_source = (() => {
                try {
                        const enc = new TextEncoder();
                        const parts = [];
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(enc.encode(chrome.runtime.id));
                        }
                        if (typeof location !== "undefined" && location?.hostname) {
                                parts.push(enc.encode(location.hostname));
                        }
                        if (typeof navigator !== "undefined") {
                                const hw = navigator.hardwareConcurrency | 0;
                                parts.push(Uint8Array.of(hw & 0xff));
                        }
                        parts.push(enc.encode("tranquill_salt::c882198ca34f17b696c9b80e0eca21ea"));
                        let total = 0;
                        for (const part of parts) total += part.length;
                        const blob = new Uint8Array(total);
                        let offset = 0;
                        for (const part of parts) {
                                blob.set(part, offset);
                                offset += part.length;
                        }
                        return blob;
                } catch (error) {
                        return new Uint8Array([]);
                }
        })();
        const tranquill_seed_digest = tranquill_sha256(tranquill_seed_source);
        const tranquill_seed_view = new DataView(tranquill_seed_digest.buffer);
        tranquill_global.tranquill_seed = [
                tranquill_seed_view.getUint32(0),
                tranquill_seed_view.getUint32(4),
                tranquill_seed_view.getUint32(8),
                tranquill_seed_view.getUint32(12),
        ];
        const tranquill_xorshift128p = (state) => {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                const result = (s0 + s1) | 0;
                s1 ^= s1 << 23;
                state[0] = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26)) | 0;
                state[1] = s0;
                return result >>> 0;
        };
        const tranquill_unmask = (view, off, len, seed) => {
                const localSeed = [seed[0] ^ off, seed[1] ^ len];
                for (let i = 0; i < len; i++) {
                        const value = tranquill_xorshift128p(localSeed) & 0xff;
                        view[i] ^= value;
                }
        };
        const tranquill_cache = new Map();
        const tranquill_pack = (tranquill_global.tranquill_PACK =
                tranquill_global.tranquill_PACK || { idx: new Map(), data: [] });
        const decoder = new TextDecoder();
        const ensureShard = (meta) => {
                const buf = tranquill_pack.data[meta.shard];
                if (!buf) {
                        return null;
                }
                return buf;
        };
        const tranquill_S = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                        return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                                return "";
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return "";
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                const decoded = decoder.decode(view);
                tranquill_cache.set(key, decoded);
                return decoded;
        };
        const tranquill_RN = (id) => {
                const key = String(id);
                if (tranquill_cache.has(key)) {
                                return tranquill_cache.get(key);
                }
                const meta = tranquill_pack.idx.get(key);
                if (!meta) {
                        return 0;
                }
                const shard = ensureShard(meta);
                if (!shard) {
                        return 0;
                }
                tranquill_unmask(shard, meta.off, meta.len, tranquill_global.tranquill_seed);
                const view = shard.subarray(meta.off, meta.off + meta.len);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < view.length; i++) {
                        const byte = BigInt(view[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                let numeric;
                if (zigzag >= BigInt(Number.MIN_SAFE_INTEGER) &&
                        zigzag <= BigInt(Number.MAX_SAFE_INTEGER)) {
                        numeric = Number(zigzag);
                } else {
                        numeric = Number.parseFloat(decoder.decode(view));
                }
                tranquill_cache.set(key, numeric);
                return numeric;
        };
        const tranquill_next = (state) => ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        tranquill_global.tranquill_S = tranquill_S;
        tranquill_global.tranquill_RN = tranquill_RN;
        tranquill_global.tranquill_next = tranquill_next;
        tranquill_global.tranquill_signature = "tranquill_tranquill_tranquill";
        tranquill_global.tranquill_runtime_ready = true;
}

(function tranquill_init_shard() {
  const a = new Uint8Array([247, 25, 5, 61, 137, 104, 64, 122, 193, 42, 29, 117, 210, 106, 88, 108, 205, 40, 2, 42, 197, 109, 84, 118, 195, 36, 208, 55, 152, 42, 203, 40, 223, 34, 197, 41, 154, 101, 141, 107, 199, 126, 199, 36, 196, 113, 148, 110, 132, 60, 203, 32, 130, 126, 203, 237, 232, 28, 7, 191, 180, 221, 74, 0, 40, 110, 119, 248, 248, 226, 176, 57, 106, 58, 52, 225, 232, 252, 189, 49, 52, 110, 96, 255, 236, 250, 244, 59, 36, 45, 113, 249, 254, 235, 244, 60, 40, 55, 58, 205, 240, 193, 141, 53, 32, 77, 74, 244, 178, 149, 206, 40, 48, 64, 77, 242, 181, 149, 134, 63, 117, 77, 71, 249, 240, 143, 157, 63, 117, 82, 75, 232, 227, 132, 156, 116, 117, 113, 66, 255, 244, 146, 139, 122, 33, 83, 87, 186, 244, 134, 143, 51, 59, 15, 94, 43, 162, 166, 38, 123, 174, 225, 103, 105, 246, 229, 45, 107, 182, 224, 123, 35, 235, 171, 44, 46, 187, 234, 124, 60, 162, 161, 44, 120, 171, 230, 108, 110, 235, 161, 44, 96, 182, 236, 111, 39, 231, 183, 103, 46, 146, 233, 108, 47, 241, 160, 105, 122, 176, 252, 41, 47, 229, 164, 32, 96, 236, 7, 218, 182, 229, 85, 6, 247, 168, 95, 146, 174, 237, 141, 206, 239, 160, 73, 182, 136, 251, 141, 241, 92, 89, 231, 128, 247, 159, 162, 61, 127, 88, 204, 111, 63, 128, 128, 47, 90, 43, 198, 245, 150, 125, 252, 135, 228, 67, 161, 84, 211, 206, 201, 124, 228, 18, 236, 87, 244, 4, 235, 52, 210, 253, 234, 40, 154, 174, 187, 112, 218, 226, 244, 107, 153, 190, 181, 106, 226, 237, 250, 24, 170, 190, 171, 64, 234, 242, 228, 91, 169, 174, 165, 90, 51, 33, 253, 127, 198, 228, 58, 183, 4, 57, 210, 62, 196, 252, 44, 187, 6, 38, 234, 62, 222, 244, 35, 183, 12, 52, 251, 119, 199, 251, 111, 172, 13, 36, 250, 123, 219, 225, 111, 184, 9, 60, 227, 123, 204, 192, 103, 26, 105, 11, 32, 211, 232, 139, 108, 14, 187, 174, 99, 159, 124, 252, 63, 94, 49, 148, 68, 175, 101, 230, 23, 229, 119, 178, 94, 161, 97, 230, 25, 236, 54, 165, 92, 165, 69, 137, 130, 180, 55, 90, 200, 166, 99, 147, 140, 176, 55, 84, 193, 231, 116, 145, 136, 68, 65, 53, 174, 22, 157, 116, 227, 143, 84, 239, 232, 122, 145, 40, 32, 184, 76, 192, 169, 114, 129, 52, 37, 177, 68, 189, 253, 123, 192, 62, 37, 177, 65, 239, 169, 103, 148, 50, 59, 177, 68, 189, 229, 125, 131, 56, 39, 167, 69, 189, 226, 113, 153, 20, 240, 74, 26, 97, 181, 141, 210, 35, 232, 101, 91, 106, 188, 155, 222, 63, 240, 81, 20, 97, 228, 143, 211, 38, 232, 93, 91, 108, 168, 157, 218, 61, 237, 86, 28, 47, 183, 140, 212, 61, 225, 92, 91, 99, 173, 155, 222, 33, 247, 93, 91, 100, 161, 129, 242, 9, 106, 77, 175, 218, 232, 147, 240, 87, 181, 64, 216, 25, 24, 37, 173, 220, 223, 109, 239, 1, 55, 100, 139, 250, 227, 64, 163, 31, 15, 55, 172, 193, 220, 97, 241, 77, 12, 37, 170, 193, 207, 96, 237, 232, 28, 7, 191, 180, 221, 74, 4, 57, 36, 69, 241, 252, 227, 141, 51, 33, 11, 4, 249, 236, 255, 136, 58, 41, 118, 80, 240, 173, 228, 129, 62, 41, 118, 87, 254, 251, 243, 128, 127, 33, 63, 71, 250, 227, 229, 129, 127, 38, 51, 93, 209, 233, 147, 183, 36, 44, 84, 127, 230, 241, 188, 246, 47, 37, 66, 115, 250, 233, 136, 185, 36, 125, 86, 126, 227, 241, 132, 246, 56, 56, 64, 114, 227, 243, 134, 246, 38, 52, 66, 115, 228, 238, 132, 246, 33, 56, 88, 99, 88, 187, 220, 62, 139, 179, 210, 195, 206, 70, 23, 4, 6, 132, 202, 236, 143, 78, 7, 24, 3, 141, 194, 145, 219, 71, 70, 3, 10, 137, 194, 145, 195, 65, 5, 20, 1, 155, 195, 145, 196, 77, 31, 81, 9, 154, 201, 220, 143, 68, 9, 18, 14, 132, 245, 197, 192, 90, 7, 22, 10, 11, 250, 251, 230, 126, 191, 188, 174, 60, 226, 212, 167, 118, 175, 160, 171, 53, 234, 169, 243, 127, 238, 164, 174, 34, 252, 230, 245, 48, 162, 160, 164, 53, 224, 250, 226, 48, 165, 172, 190, 112, 250, 230, 167, 124, 161, 170, 166, 60, 221, 253, 232, 98, 175, 174, 162, 194, 44, 112, 94, 183, 105, 55, 150, 245, 52, 95, 31, 191, 121, 43, 147, 252, 60, 34, 75, 182, 56, 33, 147, 252, 57, 112, 31, 181, 113, 33, 154, 247, 43, 103, 31, 178, 125, 59, 223, 255, 42, 109, 82, 249, 116, 45, 156, 248, 52, 81, 75, 182, 106, 35, 152, 252, 176, 75, 168, 143, 237, 152, 170, 219, 54, 133, 230, 13, 172, 87, 180, 147, 241, 132, 162, 217, 58, 157, 255, 10, 216, 35, 192, 103, 5, 112, 221, 152, 172, 119, 15, 196, 237, 58, 206, 237, 94, 129, 59, 40, 153, 73, 249, 245, 113, 192, 51, 56, 133, 76, 240, 253, 12, 148, 58, 121, 158, 69, 244, 253, 12, 140, 60, 58, 137, 78, 230, 252, 12, 150, 52, 53, 133, 68, 244, 237, 69, 143, 59, 121, 158, 69, 230, 233, 67, 142, 38, 60, 187, 39, 85, 205, 78, 226, 146, 5, 140, 63, 122, 140, 70, 242, 142, 0, 133, 55, 7, 216, 79, 179, 151, 13, 146, 32, 66, 140, 76, 250, 132, 9, 142, 32, 66, 140, 86, 242, 139, 5, 132, 50, 83, 197, 79, 253, 199, 30, 133, 32, 87, 195, 78, 224, 130, 57, 8, 101, 22, 117, 222, 91, 96, 3, 228, 134, 51, 81, 234, 137, 238, 140, 185, 87, 108, 15, 232, 138, 63, 56, 242, 210, 198, 107, 181, 24, 134, 41]);
  const pack = self.tranquill_PACK = self.tranquill_PACK || {
    idx: new Map(),
    data: []
  };
  pack.data["push"](a);
  const shard = pack.data.length - 1;
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 0,
    len: 24,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 24,
    len: 31,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 55,
    len: 8,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 63,
    len: 36,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 99,
    len: 55,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 154,
    len: 63,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 217,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 225,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 233,
    len: 7,
    kind: 1
  });
  self["tranquill_PACK"]["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 240,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 246,
    len: 9,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 255,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 261,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 267,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 267,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 271,
    len: 4,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 275,
    len: 4,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 279,
    len: 16,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 295,
    len: 16,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 311,
    len: 45,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 356,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 362,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 368,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 368,
    len: 8,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 376,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 395,
    len: 19,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 414,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 422,
    len: 46,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 468,
    len: 55,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 523,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 529,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 535,
    len: 32,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 567,
    len: 8,
    kind: 1
  });
  self.tranquill_PACK["idx"].set("0x6c62272e07bb0142", {
    shard,
    off: 575,
    len: 44,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 619,
    len: 47,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 666,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 672,
    len: 56,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 728,
    len: 56,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 784,
    len: 57,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 841,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 847,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 853,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 859,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 865,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 871,
    len: 8,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 879,
    len: 0,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 879,
    len: 54,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 933,
    len: 55,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 988,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK["idx"]["set"]("0x6c62272e07bb0142", {
    shard,
    off: 994,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1000,
    len: 6,
    kind: 1
  });
  self.tranquill_PACK.idx["set"]("0x6c62272e07bb0142", {
    shard,
    off: 1006,
    len: 6,
    kind: 1
  });
  self["tranquill_PACK"].idx.set("0x6c62272e07bb0142", {
    shard,
    off: 1012,
    len: 9,
    kind: 1
  });
})();
let _tranquill_cond2 = trimmed.length > 0;
if (_tranquill_cond2) {
  trimmed;
} else {
  null;
}
let _tranquill_cond3 = typeof payload["key"] === tranquill_S("0x6c62272e07bb0142");
if (_tranquill_cond3) {
  payload.key;
} else {
  null;
}
let _tranquill_cond4 = trimmed.length > 0;
if (_tranquill_cond4) {
  trimmed;
} else {
  null;
}
(function (global) {
  "use strict";

  const DEFAULT_LICENSE_STORAGE_KEY = tranquill_S("0x6c62272e07bb0142");
  const DEFAULT_LICENSE_VALIDATION_ENDPOINT = tranquill_S("0x6c62272e07bb0142");
  const FALLBACK_LOGGER = {
    debug() {},
    info() {},
    warn() {},
    error() {}
  };
  class LicenseManager {
    constructor(options = {}) {
      const {
        storageKey = DEFAULT_LICENSE_STORAGE_KEY,
        validationEndpoint = DEFAULT_LICENSE_VALIDATION_ENDPOINT,
        fetchFn = typeof global.fetch === tranquill_S("0x6c62272e07bb0142") ? global.fetch.bind(global) : null,
        logger = global.log || global.console || FALLBACK_LOGGER,
        chrome = global.chrome || null,
        chromeStorage = chrome?.storage?.local || null,
        localStorage = getLocalStorageSafe(global) || null,
        hwidResolver = null,
        defaultErrorMessage = tranquill_S("0x6c62272e07bb0142"),
        networkErrorMessage = tranquill_S("0x6c62272e07bb0142"),
        hwidErrorMessage = tranquill_S("0x6c62272e07bb0142")
      } = options;
      this.storageKey = storageKey;
      this.validationEndpoint = validationEndpoint;
      this.fetchFn = typeof fetchFn === tranquill_S("0x6c62272e07bb0142") ? fetchFn : null;
      this.logger = logger || FALLBACK_LOGGER;
      this.chrome = chrome || global.chrome || null;
      this.chromeStorage = chromeStorage;
      this.localStorage = localStorage;
      this.hwidResolver = typeof hwidResolver === tranquill_S("0x6c62272e07bb0142") ? hwidResolver : null;
      this.messages = {
        default: defaultErrorMessage,
        network: networkErrorMessage,
        hwid: hwidErrorMessage
      };
    }
    async gateLicenseKey({
      requireValidation = true
    } = {}) {
      const licenseKey = await this.getStoredLicenseKey();
      if (!licenseKey) {
        return {
          unlocked: false,
          licenseKey: null,
          reason: tranquill_S("0x6c62272e07bb0142")
        };
      }
      if (!requireValidation) {
        return {
          unlocked: true,
          licenseKey,
          reason: tranquill_S("0x6c62272e07bb0142")
        };
      }
      try {
        const {
          hwid
        } = await this.validateLicenseKey(licenseKey);
        return {
          unlocked: true,
          licenseKey,
          hwid,
          reason: tranquill_S("0x6c62272e07bb0142")
        };
      } catch (error) {
        if (error && typeof error === tranquill_S("0x6c62272e07bb0142") && !error.licenseKey) {
          error.licenseKey = licenseKey;
        }
        throw error;
      }
    }
    async validateLicenseKey(rawLicenseKey, {
      hwid: providedHWID
    } = {}) {
      const normalized = typeof rawLicenseKey === tranquill_S("0x6c62272e07bb0142") ? rawLicenseKey.trim() : tranquill_S("0x6c62272e07bb0142");
      if (!normalized) {
        const error = new Error(this.messages.default);
        error.shouldClearLicense = false;
        throw error;
      }
      const hwid = await this.resolveHWID(providedHWID);
      if (!hwid) {
        const error = new Error(this["messages"].hwid);
        error.shouldClearLicense = false;
        throw error;
      }
      await this["validateAgainstServer"]({
        licenseKey: normalized,
        hwid
      });
      return {
        licenseKey: normalized,
        hwid
      };
    }
    async validateAgainstServer({
      licenseKey,
      hwid
    }) {
      if (!this.fetchFn) {
        const error = new Error(this.messages.network);
        error.shouldClearLicense = false;
        throw error;
      }
      let response;
      try {
        const payload = {
          license_key: licenseKey,
          hwid
        };
        response = await this.fetchFn(this.validationEndpoint, {
          method: tranquill_S("0x6c62272e07bb0142"),
          mode: tranquill_S("0x6c62272e07bb0142"),
          credentials: tranquill_S("0x6c62272e07bb0142"),
          headers: {
            Accept: tranquill_S("0x6c62272e07bb0142"),
            "Content-Type": tranquill_S("0x6c62272e07bb0142")
          },
          body: JSON.stringify(payload)
        });
      } catch (error) {
        this.logWarn(tranquill_S("0x6c62272e07bb0142"), error);
        const networkError = new Error(this.messages.network);
        let _tranquill_cond = error instanceof Error;
        if (_tranquill_cond) {
          error;
        } else {
          undefined;
        }
        networkError["cause"] = _tranquill_cond;
        networkError.shouldClearLicense = false;
        throw networkError;
      }
      const json = await this.readJsonPayload(response);
      if (!response?.ok) {
        const message = this.extractLicenseError(json) || this.messages.default;
        const error = new Error(message);
        if (response && typeof response["status"] === tranquill_S("0x6c62272e07bb0142") && response.status >= 400 && response["status"] < 500) {
          error.shouldClearLicense = true;
        }
        throw error;
      }
      if (!json || json.success !== true) {
        const message = this["extractLicenseError"](json) || this.messages["default"];
        const error = new Error(message);
        error["shouldClearLicense"] = true;
        throw error;
      }
      return json;
    }
    async getStoredLicenseKey() {
      const fromChrome = await this.readChromeStorage();
      const extracted = this.extractLicenseValue(fromChrome);
      if (extracted) {
        return extracted;
      }
      return this.getLocalStorageFallback();
    }
    async persistLicenseKey(rawKey) {
      const normalized = typeof rawKey === tranquill_S("0x6c62272e07bb0142") ? rawKey["trim"]() : tranquill_S("0x6c62272e07bb0142");
      if (!normalized) {
        return null;
      }
      const record = {
        value: normalized,
        savedAt: Date.now()
      };
      await new Promise((resolve, reject) => {
        if (!this.chromeStorage || typeof this.chromeStorage.set !== tranquill_S("0x6c62272e07bb0142")) {
          reject(new Error(tranquill_S("0x6c62272e07bb0142")));
          return;
        }
        try {
          this.chromeStorage["set"]({
            [this.storageKey]: record
          }, () => {
            const err = this.chrome?.runtime?.lastError ?? null;
            if (err) {
              reject(new Error(err.message || tranquill_S("0x6c62272e07bb0142")));
              return;
            }
            resolve();
          });
        } catch (error) {
          reject(error);
        }
      });
      this.writeLocalStorage(normalized);
      return record;
    }
    async clearStoredLicenseKey() {
      this["clearLocalStorage"]();
      return new Promise(resolve => {
        if (!this.chromeStorage || typeof this["chromeStorage"]["remove"] !== tranquill_S("0x6c62272e07bb0142")) {
          resolve();
          return;
        }
        try {
          this["chromeStorage"].remove(this.storageKey, () => {
            const err = this.chrome?.runtime?.lastError ?? null;
            if (err) {
              this["logWarn"](tranquill_S("0x6c62272e07bb0142"), err);
            }
            resolve();
          });
        } catch (error) {
          this["logWarn"](tranquill_S("0x6c62272e07bb0142"), error);
          resolve();
        }
      });
    }
    async resolveHWID(provided) {
      if (typeof provided === tranquill_S("0x6c62272e07bb0142") && provided.trim().length > 0) {
        return provided.trim();
      }
      if (!this["hwidResolver"]) {
        return null;
      }
      try {
        const resolved = await this.hwidResolver();
        if (typeof resolved !== tranquill_S("0x6c62272e07bb0142")) {
          return null;
        }
        const trimmed = resolved.trim();
        return trimmed["length"] > 0 ? trimmed : null;
      } catch (error) {
        this.logWarn(tranquill_S("0x6c62272e07bb0142"), error);
        return null;
      }
    }
    readChromeStorage() {
      return new Promise(resolve => {
        if (!this.chromeStorage || typeof this.chromeStorage.get !== tranquill_S("0x6c62272e07bb0142")) {
          resolve(null);
          return;
        }
        try {
          this.chromeStorage.get(this.storageKey, result => {
            const err = this.chrome?.runtime?.lastError ?? null;
            if (err) {
              this.logWarn(tranquill_S("0x6c62272e07bb0142"), err);
              resolve(null);
              return;
            }
            resolve(result?.[this.storageKey] ?? null);
          });
        } catch (error) {
          this.logWarn(tranquill_S("0x6c62272e07bb0142"), error);
          resolve(null);
        }
      });
    }
    getLocalStorageFallback() {
      if (!this.localStorage) {
        return null;
      }
      try {
        const stored = this.localStorage.getItem(this.storageKey);
        if (typeof stored !== tranquill_S("0x6c62272e07bb0142")) {
          return null;
        }
        const trimmed = stored.trim();
        return _tranquill_cond2;
      } catch (error) {
        this["logDebug"](tranquill_S("0x6c62272e07bb0142"), error);
        return null;
      }
    }
    writeLocalStorage(value) {
      if (!this.localStorage) {
        return;
      }
      try {
        this["localStorage"].setItem(this["storageKey"], value);
      } catch (error) {
        this["logDebug"](tranquill_S("0x6c62272e07bb0142"), error);
      }
    }
    clearLocalStorage() {
      if (!this["localStorage"]) {
        return;
      }
      try {
        this.localStorage.removeItem(this.storageKey);
      } catch (error) {
        this.logDebug(tranquill_S("0x6c62272e07bb0142"), error);
      }
    }
    extractLicenseValue(payload) {
      if (typeof payload === tranquill_S("0x6c62272e07bb0142")) {
        const trimmed = payload.trim();
        return trimmed.length > 0 ? trimmed : null;
      }
      if (payload && typeof payload === tranquill_S("0x6c62272e07bb0142")) {
        const candidate = typeof payload.value === tranquill_S("0x6c62272e07bb0142") ? payload.value : _tranquill_cond3;
        if (typeof candidate === tranquill_S("0x6c62272e07bb0142")) {
          const trimmed = candidate.trim();
          return trimmed.length > 0 ? trimmed : null;
        }
      }
      return null;
    }
    async readJsonPayload(response) {
      if (!response || typeof response.text !== tranquill_S("0x6c62272e07bb0142")) {
        return null;
      }
      let raw = tranquill_S("0x6c62272e07bb0142");
      try {
        raw = await response.text();
      } catch (error) {
        this.logWarn(tranquill_S("0x6c62272e07bb0142"), error);
        return null;
      }
      if (!raw) {
        return null;
      }
      try {
        return JSON.parse(raw);
      } catch (error) {
        this.logWarn(tranquill_S("0x6c62272e07bb0142"), error);
        return null;
      }
    }
    extractLicenseError(payload) {
      if (!payload || typeof payload !== tranquill_S("0x6c62272e07bb0142")) {
        return null;
      }
      const candidate = typeof payload.error === tranquill_S("0x6c62272e07bb0142") ? payload.error : typeof payload.message === tranquill_S("0x6c62272e07bb0142") ? payload.message : null;
      if (typeof candidate !== tranquill_S("0x6c62272e07bb0142")) {
        return null;
      }
      const trimmed = candidate["trim"]();
      return _tranquill_cond4;
    }
    logWarn(message, meta) {
      try {
        this.logger?.warn?.(message, meta);
      } catch (_) {}
    }
    logDebug(message, meta) {
      try {
        this.logger?.debug?.(message, meta);
      } catch (_) {}
    }
  }
  function getLocalStorageSafe(scope) {
    try {
      return scope?.localStorage ?? null;
    } catch (_) {
      return null;
    }
  }
  global.tranquillLicenseManager = LicenseManager;
})(typeof self !== tranquill_S("0x6c62272e07bb0142") ? self : this);
const tranquill_mask = (typeof tranquill_seed !== "undefined" ? tranquill_seed[1] : 0) & 65535;
if ((tranquill_mask & 0) === 0) {
  const tranquill_shadow = tranquill_signature;
}