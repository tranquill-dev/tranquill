/* tranquill.runtime.js */
(function (global) {
        const root = typeof globalThis !== "undefined" ? globalThis : global || self;

        function rotr(x, n) {
                return (x >>> n) | (x << (32 - n));
        }

        function toUint32(n) {
                return n >>> 0;
        }

        function tranquill_sha256(bytes) {
                const k = new Uint32Array([
                        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
                        0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
                        0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
                        0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
                        0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
                        0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
                        0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
                        0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
                        0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
                        0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
                        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
                        0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
                        0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5,
                        0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
                        0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
                        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
                ]);
                const msg = new Uint8Array(((bytes.length + 9 + 63) >> 6) << 6);
                msg.set(bytes);
                msg[bytes.length] = 0x80;
                const bitLen = bytes.length * 8;
                msg[msg.length - 4] = (bitLen >>> 24) & 0xff;
                msg[msg.length - 3] = (bitLen >>> 16) & 0xff;
                msg[msg.length - 2] = (bitLen >>> 8) & 0xff;
                msg[msg.length - 1] = bitLen & 0xff;

                let h0 = 0x6a09e667;
                let h1 = 0xbb67ae85;
                let h2 = 0x3c6ef372;
                let h3 = 0xa54ff53a;
                let h4 = 0x510e527f;
                let h5 = 0x9b05688c;
                let h6 = 0x1f83d9ab;
                let h7 = 0x5be0cd19;

                const w = new Uint32Array(64);

                for (let i = 0; i < msg.length; i += 64) {
                        for (let j = 0; j < 16; j += 1) {
                                const idx = i + j * 4;
                                w[j] =
                                        (msg[idx] << 24) |
                                        (msg[idx + 1] << 16) |
                                        (msg[idx + 2] << 8) |
                                        msg[idx + 3];
                        }
                        for (let j = 16; j < 64; j += 1) {
                                const s0 =
                                        rotr(w[j - 15], 7) ^
                                        rotr(w[j - 15], 18) ^
                                        (w[j - 15] >>> 3);
                                const s1 =
                                        rotr(w[j - 2], 17) ^
                                        rotr(w[j - 2], 19) ^
                                        (w[j - 2] >>> 10);
                                w[j] = toUint32(w[j - 16] + s0 + w[j - 7] + s1);
                        }

                        let a = h0;
                        let b = h1;
                        let c = h2;
                        let d = h3;
                        let e = h4;
                        let f = h5;
                        let g = h6;
                        let h = h7;

                        for (let j = 0; j < 64; j += 1) {
                                const s1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
                                const ch = (e & f) ^ (~e & g);
                                const temp1 = toUint32(h + s1 + ch + k[j] + w[j]);
                                const s0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
                                const maj = (a & b) ^ (a & c) ^ (b & c);
                                const temp2 = toUint32(s0 + maj);

                                h = g;
                                g = f;
                                f = e;
                                e = toUint32(d + temp1);
                                d = c;
                                c = b;
                                b = a;
                                a = toUint32(temp1 + temp2);
                        }

                        h0 = toUint32(h0 + a);
                        h1 = toUint32(h1 + b);
                        h2 = toUint32(h2 + c);
                        h3 = toUint32(h3 + d);
                        h4 = toUint32(h4 + e);
                        h5 = toUint32(h5 + f);
                        h6 = toUint32(h6 + g);
                        h7 = toUint32(h7 + h);
                }

                const out = new Uint8Array(32);
                const words = [h0, h1, h2, h3, h4, h5, h6, h7];
                for (let i = 0; i < words.length; i += 1) {
                        out[i * 4] = (words[i] >>> 24) & 0xff;
                        out[i * 4 + 1] = (words[i] >>> 16) & 0xff;
                        out[i * 4 + 2] = (words[i] >>> 8) & 0xff;
                        out[i * 4 + 3] = words[i] & 0xff;
                }
                return out;
        }

        function collectEntropy() {
                const encoder = new TextEncoder();
                const parts = [];
                try {
                        if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
                                parts.push(encoder.encode(chrome.runtime.id));
                        }
                } catch (error) {
                        void error;
                }
                try {
                        if (typeof location !== "undefined" && location.hostname) {
                                parts.push(encoder.encode(location.hostname));
                        }
                } catch (error) {
                        void error;
                }
                try {
                        if (typeof navigator !== "undefined" && navigator.hardwareConcurrency) {
                                parts.push(Uint8Array.of(navigator.hardwareConcurrency & 0xff));
                        }
                } catch (error) {
                        void error;
                }
                parts.push(encoder.encode("tranquill_salt::2f0f87f34a1e53d00c2022851b781c29"));
                let total = 0;
                for (const part of parts) total += part.length;
                const buffer = new Uint8Array(total);
                let offset = 0;
                for (const part of parts) {
                        buffer.set(part, offset);
                        offset += part.length;
                }
                return buffer;
        }

        function deriveSeed() {
                try {
                        const data = collectEntropy();
                        const digest = tranquill_sha256(data);
                        const view = new DataView(digest.buffer);
                        return [
                                view.getUint32(0),
                                view.getUint32(4),
                                view.getUint32(8),
                                view.getUint32(12),
                        ];
                } catch (error) {
                        void error;
                        return [0x9e3779b9, 0x243f6a88, 0xb7e15162, 0x8aed2a6b];
                }
        }

        const buildSeed = deriveSeed();
        root.tranquill_seed = buildSeed;
        root.tranquill_build_seed = [0x76423fbb,0xfbf61b1b,0xa6a1fa26,0xe247d6f8];

        function xs128pStep(state) {
                let s1 = state[0] | 0;
                const s0 = state[1] | 0;
                state[0] = s0;
                s1 ^= s1 << 23;
                state[1] = (s1 ^ s0 ^ (s1 >>> 18) ^ (s0 >>> 5)) | 0;
                return (state[1] + s0) | 0;
        }

        function createState(seed, tweak) {
                return [
                        (seed[0] ^ tweak) >>> 0,
                        (seed[1] ^ ((tweak << 1) >>> 0)) >>> 0,
                        seed[2] >>> 0,
                        seed[3] >>> 0,
                ];
        }

        function unmaskBytes(buffer, seed, offset, length) {
                const state = createState(seed, offset ^ length);
                for (let i = 0; i < length; i += 1) {
                        const value = xs128pStep(state) & 0xff;
                        buffer[offset + i] ^= value;
                }
        }

        const decoderCache = new Map();
        root.tranquill_PACK = root.tranquill_PACK || { idx: new Map(), data: [] };

        function ensureArrayBuffer(slice) {
                return new Uint8Array(slice);
        }

        function getMeta(id) {
                return root.tranquill_PACK.idx.get(id) || null;
        }

        function decodeString(id) {
                if (decoderCache.has(id)) {
                                return decoderCache.get(id);
                }
                const meta = getMeta(id);
                if (!meta) {
                        return "";
                }
                const shard = root.tranquill_PACK.data[meta.shard];
                const segment = ensureArrayBuffer(
                        shard.subarray(meta.off, meta.off + meta.len)
                );
                unmaskBytes(segment, root.tranquill_build_seed, 0, segment.length);
                const text = new TextDecoder().decode(segment);
                decoderCache.set(id, text);
                return text;
        }

        function decodeNumber(id) {
                const meta = getMeta(id);
                if (!meta) {
                        return 0;
                }
                const shard = root.tranquill_PACK.data[meta.shard];
                const segment = ensureArrayBuffer(
                        shard.subarray(meta.off, meta.off + meta.len)
                );
                unmaskBytes(segment, root.tranquill_build_seed, 0, segment.length);
                let result = 0n;
                let shift = 0n;
                for (let i = 0; i < segment.length; i += 1) {
                        const byte = BigInt(segment[i]);
                        result |= (byte & 0x7fn) << shift;
                        if ((byte & 0x80n) === 0n) {
                                break;
                        }
                        shift += 7n;
                }
                const zigzag = (result >> 1n) ^ (-(result & 1n));
                const number = Number(zigzag);
                if (Number.isSafeInteger(number)) {
                        return number;
                }
                return parseFloat(new TextDecoder().decode(segment));
        }

        function decodeRegex(id) {
                const source = decodeString(id);
                if (!source.startsWith("/")) {
                        return new RegExp(source);
                }
                const lastSlash = source.lastIndexOf("/");
                const pattern = source.slice(1, lastSlash);
                const flags = source.slice(lastSlash + 1);
                return new RegExp(pattern, flags);
        }

        function tranquill_next(state) {
                return ((state * 1103515245 + 12345) >>> 0) & 0xffff;
        }

        root.tranquill_S = function (id) {
                return decodeString(id >>> 0);
        };
        root.tranquill_RN = function (id) {
                return decodeNumber(id >>> 0);
        };
        root.tranquill_RX = function (id) {
                return decodeRegex(id >>> 0);
        };
        root.tranquill_next = tranquill_next;
        root.tranquill_signature = "tranquill_tranquill_tranquill";
})(this);
